import { Download } from "lucide-react";
import { Badge, Empty, ErrorState, Loading, Meter, PageHead, Panel, coverageTone } from "../components/ui";
import { useAuth } from "../lib/auth";
import { SOURCE_LABEL, fmtDate } from "../lib/format";
import { useApi } from "../lib/hooks";
import type { CoverageRow, GroundLevel } from "../lib/types";

interface Detail {
  knowledge_captured: { week: string; records: number }[];
  by_source_type: Record<string, number>;
  coverage: CoverageRow[];
  most_common_failures: { failure_mode: string; asset_tag: string; mentions: number }[];
  frequently_asked: { question: string; count: number }[];
  unresolved_questions: { question: string; reason: string; at: string }[];
  groundedness_distribution: Record<string, number>;
  conflicts: Record<string, number>;
  technician_contribution: { name: string; title: string; records: number; approved_procedures: number }[];
  ai_requests: { kind: string; status: string; count: number; avg_latency_ms: number }[];
}

const G_ORDER: GroundLevel[] = ["HIGH", "MEDIUM", "LOW", "INSUFFICIENT"];
const G_COLOR: Record<string, string> = { HIGH: "var(--ok)", MEDIUM: "var(--accent)", LOW: "var(--warn)", INSUFFICIENT: "var(--danger)" };

export default function Analytics() {
  const { can } = useAuth();
  const { data, error, loading, reload } = useApi<Detail>("/api/analytics/detail");
  if (loading && !data) return <Loading />;
  if (error) return <ErrorState error={error} onRetry={() => void reload()} />;
  if (!data) return null;
  const maxWeek = Math.max(1, ...data.knowledge_captured.map((w) => w.records));
  const maxFail = Math.max(1, ...data.most_common_failures.map((f) => f.mentions));
  const gTotal = Object.values(data.groundedness_distribution).reduce((a, b) => a + b, 0);
  const maxContrib = Math.max(1, ...data.technician_contribution.map((t) => t.records));

  return (
    <div className="stack" style={{ gap: 20 }}>
      <PageHead eyebrow="Knowledge intelligence" title="Analytics" actions={can("reports:export") && <a className="btn" href="/api/analytics/export.csv"><Download />Export CSV</a>}>
        How much expert knowledge has been captured, where the gaps are, and whether technicians are getting grounded answers.
      </PageHead>

      <div className="grid g-2">
        <Panel title="Knowledge captured" sub="Records per week">
          {!data.knowledge_captured.length ? <Empty title="No captures yet" /> : (
            <>
              <div className="chart-bars" role="img" aria-label="Records captured per week">
                {data.knowledge_captured.map((w) => <div key={w.week} className="bar" style={{ height: `${(w.records / maxWeek) * 100}%` }} title={`${w.week}: ${w.records}`} />)}
              </div>
              <div className="chart-x">{data.knowledge_captured.map((w) => <span key={w.week}>{fmtDate(w.week).slice(0, 6)}</span>)}</div>
              <div className="row-wrap mt-12">{Object.entries(data.by_source_type).map(([k, v]) => <Badge key={k}>{SOURCE_LABEL[k] ?? k}: {v}</Badge>)}</div>
            </>
          )}
        </Panel>
        <Panel title="Assistant groundedness" sub={`${gTotal} answers`}>
          {!gTotal ? <Empty title="No questions asked yet" /> : (
            <div className="stack-sm">
              <div style={{ display: "flex", height: 14, borderRadius: 999, overflow: "hidden", border: "1px solid var(--line)" }}>
                {G_ORDER.map((g) => data.groundedness_distribution[g] ? <div key={g} style={{ width: `${(data.groundedness_distribution[g]! / gTotal) * 100}%`, background: G_COLOR[g] }} title={g} /> : null)}
              </div>
              {G_ORDER.map((g) => (
                <div key={g} className="hbar"><span className="row"><span className="dot" style={{ background: G_COLOR[g] }} />{g === "INSUFFICIENT" ? "Escalated (insufficient)" : g}</span><Meter value={((data.groundedness_distribution[g] ?? 0) / gTotal) * 100} /><span className="v">{data.groundedness_distribution[g] ?? 0}</span></div>
              ))}
            </div>
          )}
        </Panel>
      </div>

      <div className="grid g-2">
        <Panel title="Knowledge coverage" sub="Per asset, 0–100">
          {data.coverage.map((c) => (
            <div key={c.asset_id} className="hbar"><span><span className="tag">{c.asset_tag}</span> <span className="muted small">{c.name}</span></span><Meter value={c.coverage} tone={coverageTone(c.coverage)} /><span className="v">{c.coverage}%</span></div>
          ))}
        </Panel>
        <Panel title="Most common failures" sub="By mentions across expert sources">
          {!data.most_common_failures.length ? <Empty title="No failure modes yet" /> : data.most_common_failures.map((f) => (
            <div key={f.failure_mode + f.asset_tag} className="hbar"><span style={{ textTransform: "capitalize" }}>{f.failure_mode} <span className="tag">{f.asset_tag}</span></span><Meter value={(f.mentions / maxFail) * 100} tone="warn" /><span className="v">{f.mentions}</span></div>
          ))}
        </Panel>
      </div>

      <div className="grid g-2">
        <Panel title="Frequently asked questions" tight>
          {!data.frequently_asked.length ? <Empty title="No questions yet" /> : (
            <table className="table"><tbody>{data.frequently_asked.map((q) => <tr key={q.question}><td>{q.question}</td><td className="mono" style={{ width: 50 }}>{q.count}×</td></tr>)}</tbody></table>
          )}
        </Panel>
        <Panel title="Unresolved questions" sub="Answered “insufficient verified knowledge” — candidates for the next Knowledge Harvest" tight>
          {!data.unresolved_questions.length ? <Empty title="None" /> : (
            <table className="table"><tbody>{data.unresolved_questions.map((q, i) => <tr key={i}><td><div>{q.question}</div><div className="tiny faint">{q.reason}</div></td><td className="small faint nowrap">{fmtDate(q.at)}</td></tr>)}</tbody></table>
          )}
        </Panel>
      </div>

      <div className="grid g-2">
        <Panel title="Technician contribution" tight>
          <table className="table">
            <thead><tr><th>Technician</th><th style={{ width: "40%" }}>Records</th><th>Approved procedures</th></tr></thead>
            <tbody>{data.technician_contribution.map((t) => (
              <tr key={t.name}><td><div>{t.name}</div><div className="tiny faint">{t.title}</div></td><td><div className="row"><div style={{ flex: 1 }}><Meter value={(t.records / maxContrib) * 100} /></div><span className="mono small">{t.records}</span></div></td><td className="mono">{t.approved_procedures}</td></tr>
            ))}</tbody>
          </table>
        </Panel>
        <div className="stack">
          <Panel title="Knowledge conflicts">
            <div className="row-wrap">{Object.keys(data.conflicts).length ? Object.entries(data.conflicts).map(([k, v]) => <Badge key={k} tone={k === "open" ? "warn" : "ok"}>{k}: {v}</Badge>) : <span className="small faint">None detected</span>}</div>
          </Panel>
          <Panel title="AI requests" sub="Provider calls logged by the backend" tight>
            {!data.ai_requests.length ? <div className="panel-body small faint">No external AI calls — running in local rules mode.</div> : (
              <table className="table"><thead><tr><th>Kind</th><th>Status</th><th>Calls</th><th>Avg latency</th></tr></thead>
                <tbody>{data.ai_requests.map((a) => <tr key={a.kind + a.status}><td>{a.kind}</td><td><Badge tone={a.status === "ok" ? "ok" : "danger"}>{a.status}</Badge></td><td className="mono">{a.count}</td><td className="mono small">{a.avg_latency_ms} ms</td></tr>)}</tbody></table>
            )}
          </Panel>
        </div>
      </div>
    </div>
  );
}
