import { Bot, CheckCircle2, Flag, Mic, MicOff, Play, SendHorizonal, Sparkles } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { useToast } from "../components/toast";
import { Badge, Empty, ErrorState, Loading, Meter, PageHead, Panel, StatusBadge, coverageTone } from "../components/ui";
import { ApiError, api } from "../lib/api";
import { cls, timeAgo } from "../lib/format";
import { useApi } from "../lib/hooks";
import { LiveTranscriber, speechRecognitionSupported } from "../lib/recorder";
import type { Asset, CoverageItem, HarvestSession } from "../lib/types";

export default function Harvest() {
  const [params] = useSearchParams();
  const assets = useApi<{ items: Asset[] }>("/api/assets");
  const sessions = useApi<{ items: { id: string; status: string; asset: { asset_tag: string; name: string }; coverage: CoverageItem[]; turns: number; created_at: string; record_id: string | null }[] }>("/api/harvest/sessions");
  const [assetId, setAssetId] = useState(params.get("asset") ?? "");
  const [session, setSession] = useState<HarvestSession | null>(null);
  const [error, setError] = useState<ApiError | null>(null);
  const [busy, setBusy] = useState(false);

  const start = async () => {
    setBusy(true);
    setError(null);
    try {
      setSession(await api.post<HarvestSession>("/api/harvest/sessions", { asset_id: assetId }));
    } catch (e) {
      setError(e as ApiError);
    } finally {
      setBusy(false);
    }
  };
  const open = async (id: string) => {
    try {
      setSession(await api.get<HarvestSession>(`/api/harvest/sessions/${id}`));
    } catch (e) {
      setError(e as ApiError);
    }
  };

  if (session) return <Interview s={session} setS={setSession} onExit={() => { setSession(null); void sessions.reload(); }} />;

  return (
    <div className="stack" style={{ gap: 20 }}>
      <PageHead eyebrow="AI interview agent" title="Knowledge Harvest">
        An AI interviewer draws out what a senior technician knows about one machine — asking follow-ups, catching common mistakes and tracking which knowledge areas are still missing.
      </PageHead>
      <div className="split">
        <Panel title="Start an interview">
          <div className="stack">
            <select className="select" value={assetId} onChange={(e) => setAssetId(e.target.value)} aria-label="Machine">
              <option value="">Choose a machine…</option>
              {assets.data?.items.map((a) => <option key={a.id} value={a.id}>{a.asset_tag} · {a.name}</option>)}
            </select>
            <p className="small muted">Plan 10–15 minutes with the technician. Answers can be typed or spoken. When you finish, the interview becomes a knowledge record and runs through the same extraction pipeline and supervisor review as any recording.</p>
            {error && <ErrorState error={error} />}
            <div><button className="btn primary" disabled={!assetId || busy} onClick={() => void start()}><Play />{busy ? "Starting…" : "Start Knowledge Harvest"}</button></div>
          </div>
        </Panel>
        <Panel title="Coverage areas">
          <div className="stack-sm small muted">
            <div><strong style={{ color: "var(--text)" }}>Machine Basics</strong> — normal operation, operating ranges, key components</div>
            <div><strong style={{ color: "var(--text)" }}>Failure Modes</strong> — what goes wrong, symptoms, causes</div>
            <div><strong style={{ color: "var(--text)" }}>Troubleshooting</strong> — what to check first, and what juniors get wrong</div>
            <div><strong style={{ color: "var(--text)" }}>Safety</strong> — machine-specific hazards and precautions</div>
            <div><strong style={{ color: "var(--text)" }}>Rare Failures</strong> — the once-a-decade problems only veterans remember</div>
          </div>
        </Panel>
      </div>
      <Panel title="Previous interviews" tight>
        {sessions.loading && !sessions.data ? <Loading /> : !sessions.data?.items.length ? <Empty icon={<Sparkles />} title="No interviews yet" /> : (
          <table className="table">
            <thead><tr><th>Machine</th><th>Status</th><th>Answers</th><th>Coverage</th><th>Started</th><th /></tr></thead>
            <tbody>{sessions.data.items.map((s) => {
              const avg = s.coverage.length ? Math.round(s.coverage.reduce((a, c) => a + c.percent, 0) / s.coverage.length) : 0;
              return (
                <tr key={s.id}>
                  <td><span className="tag">{s.asset.asset_tag}</span> {s.asset.name}</td>
                  <td><StatusBadge status={s.status} /></td>
                  <td className="mono">{Math.floor(s.turns / 2)}</td>
                  <td style={{ width: 200 }}><div className="row"><div style={{ flex: 1 }}><Meter value={avg} tone={coverageTone(avg)} /></div><span className="mono small">{avg}%</span></div></td>
                  <td className="small faint">{timeAgo(s.created_at)}</td>
                  <td>{s.status === "active" ? <button className="btn sm" onClick={() => void open(s.id)}>Resume</button> : s.record_id ? <Link className="btn sm ghost" to={`/app/library/${s.record_id}`}>View record</Link> : null}</td>
                </tr>
              );
            })}</tbody>
          </table>
        )}
      </Panel>
    </div>
  );
}

function Blocks({ pct }: { pct: number }) {
  const on = Math.round(pct / 10);
  return <span className="blocks" aria-hidden>{"█".repeat(on)}<span className="off">{"█".repeat(10 - on)}</span></span>;
}

function Interview({ s, setS, onExit }: { s: HarvestSession; setS: (s: HarvestSession) => void; onExit: () => void }) {
  const toast = useToast();
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);
  const [listening, setListening] = useState(false);
  const [lastFound, setLastFound] = useState<Record<string, unknown> | null>(null);
  const stt = useRef<LiveTranscriber | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const voiceUsed = useRef(false);
  useEffect(() => endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }), [s.turns.length]);
  useEffect(() => () => stt.current?.stop(), []);

  const send = async () => {
    const t = text.trim();
    if (!t) return;
    stt.current?.stop();
    setListening(false);
    setBusy(true);
    setError(null);
    try {
      const res = await api.post<HarvestSession>(`/api/harvest/sessions/${s.id}/answer`, { text: t, source: voiceUsed.current ? "voice" : "typed" });
      setS(res);
      setLastFound(res.extracted_from_answer ?? null);
      setText("");
      voiceUsed.current = false;
    } catch (e) {
      setError(e as ApiError);
    } finally {
      setBusy(false);
    }
  };
  const finish = async () => {
    setBusy(true);
    try {
      const res = await api.post<HarvestSession>(`/api/harvest/sessions/${s.id}/finish`);
      setS(res);
      toast.ok(`Interview saved as ${res.record_ref} — extraction running`);
    } catch (e) {
      toast.error(e);
    } finally {
      setBusy(false);
    }
  };
  const voice = () => {
    if (listening) {
      stt.current?.stop();
      setListening(false);
      return;
    }
    const base = text ? text + " " : "";
    const tr = new LiveTranscriber("en-IN");
    tr.onUpdate = (f, i) => setText(base + [...f.map((x) => x.text), i].join(" ").trim());
    if (tr.start(performance.now())) {
      stt.current = tr;
      voiceUsed.current = true;
      setListening(true);
    }
  };
  const active = s.status === "active";
  const answered = s.turns.filter((t) => t.role === "technician").length;

  return (
    <div className="split">
      <div className="stack">
        <PageHead eyebrow={`Knowledge Harvest · ${s.agent_mode === "llm" ? "LLM interviewer" : "rules interviewer (harvest-rules-v1)"}`} title={`${s.asset.asset_tag} · ${s.asset.name}`}
          actions={<button className="btn ghost" onClick={onExit}>Back</button>} />
        <Panel>
          <div className="interview">
            {s.turns.map((t, i) => t.role === "agent" ? (
              <div key={i} className="q-bubble rise">
                <div className="who-ai"><Bot /></div>
                <div>
                  <div className="q-text">{t.text}</div>
                  {t.reason && <div className="why">WHY THIS QUESTION · {t.reason} · {t.category?.replace("_", " ")}</div>}
                </div>
              </div>
            ) : (
              <div key={i} className="a-bubble rise">{t.text}{t.source === "voice" && <span className="badge" style={{ marginLeft: 8 }}><Mic />voice</span>}</div>
            ))}
            {!active && (
              <div className="notice info"><CheckCircle2 style={{ color: "var(--ok)" }} /><span>Interview complete. {s.record_id && <>Saved as a knowledge record — <Link to={`/app/library/${s.record_id}`}>open it to watch the extraction</Link>. It needs supervisor approval before the assistant can cite it.</>}</span></div>
            )}
            <div ref={endRef} />
          </div>
        </Panel>
        {active && (
          <>
            {error && <ErrorState error={error} />}
            <div className="composer-box">
              <textarea rows={3} value={text} onChange={(e) => setText(e.target.value)} placeholder="Answer in your own words…" aria-label="Answer"
                onKeyDown={(e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) void send(); }} maxLength={5000} />
              {speechRecognitionSupported() && <button className={cls("btn icon", listening && "rec")} onClick={voice} aria-label={listening ? "Stop dictation" : "Answer by voice"}>{listening ? <MicOff /> : <Mic />}</button>}
              <button className="btn primary icon" disabled={busy || !text.trim()} onClick={() => void send()} aria-label="Send answer"><SendHorizonal /></button>
            </div>
            <div className="row"><span className="tiny faint">Ctrl + Enter to send</span><div className="spacer" /><button className="btn" disabled={busy || answered === 0} onClick={() => void finish()}><Flag />Finish & save interview</button></div>
          </>
        )}
      </div>
      <div className="stack" style={{ position: "sticky", top: 72 }}>
        <Panel title="Knowledge Coverage">
          <div className="stack-sm">
            {s.coverage.map((c) => (
              <div key={c.category} className="cov-row">
                <span>{c.label}</span>
                <span className="row" style={{ gap: 8 }}><Blocks pct={c.percent} /><span style={{ flex: 1 }}><Meter value={c.percent} tone={coverageTone(c.percent)} /></span></span>
                <span className="pct">{c.percent}%</span>
              </div>
            ))}
          </div>
          {s.gaps.length > 0 && <div className="small mt-16"><span className="faint">Missing knowledge areas:</span> <span className="row-wrap mt-8">{s.gaps.map((g) => <Badge key={g} tone="warn">{g}</Badge>)}</span></div>}
        </Panel>
        {lastFound && Object.keys(lastFound).length > 0 && (
          <Panel title="Captured from last answer" sub="Live rule-based extraction">
            <div className="stack-sm small">
              {Object.entries(lastFound).map(([k, v]) => (
                <div key={k}><span className="faint">{k.replace("_", " ")}:</span> {Array.isArray(v) ? v.map((x) => <Badge key={String(x)}>{String(x)}</Badge>) : <Badge tone="info">detected</Badge>}</div>
              ))}
            </div>
          </Panel>
        )}
      </div>
    </div>
  );
}
