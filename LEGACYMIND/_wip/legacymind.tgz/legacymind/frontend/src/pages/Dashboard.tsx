import { AlertTriangle, ArrowRight, BookOpen, ClipboardCheck, Factory, GitCompareArrows, Info, Mic, PlayCircle, ShieldAlert, Wrench } from "lucide-react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Empty, ErrorState, Meter, PageHead, Panel, Skeleton, Stat, coverageTone } from "../components/ui";
import { useAuth } from "../lib/auth";
import { cls, timeAgo } from "../lib/format";
import { useApi } from "../lib/hooks";
import type { Summary } from "../lib/types";

const TOUR = [
  ["The factory", "Five synthetic machines in the asset registry, each with a QR code.", "/app/assets"],
  ["Senior technician knowledge", "Rajesh Kumar’s P-103 recording: transcript, timestamps, source playback.", "/app/library/LM-1042"],
  ["AI extraction", "Pipeline stages and the symptoms, components, steps and safety extracted from the recording.", "/app/library/LM-1042?tab=extraction"],
  ["Knowledge graph", "Machine → failure mode → symptoms → procedure → safety for P-103.", "/app/graph?asset=P-103"],
  ["Junior technician question", "Ask: “Pump P-103 is making a grinding sound during startup. What should I check?”", "/app/assistant?q=Pump%20P-103%20is%20making%20a%20grinding%20sound%20during%20startup.%20What%20should%20I%20check%3F"],
  ["Grounded answer + source + safety", "Steps with citations, the original recording at 02:14, safety warnings and groundedness.", "/app/assistant?q=Pump%20P-103%20is%20making%20a%20grinding%20sound%20during%20startup.%20What%20should%20I%20check%3F"],
  ["Honest refusal", "Ask about a machine that isn’t in the plant — LegacyMind escalates instead of guessing.", "/app/assistant?q=How%20do%20I%20recalibrate%20the%20vision%20sensor%20on%20packaging%20line%20PK-09%3F"],
  ["Supervisor review + conflict", "Two technicians disagree on the CV-04 first check. Approve, edit or resolve.", "/app/review"],
] as const;

export default function Dashboard() {
  const { session, can } = useAuth();
  const [params] = useSearchParams();
  const nav = useNavigate();
  const { data, error, loading, reload } = useApi<Summary>("/api/analytics/summary");
  const isDemo = !!session?.organization?.is_demo;
  const first = session?.user.full_name.split(" ")[0];

  return (
    <div className="stack" style={{ gap: 20 }}>
      <PageHead eyebrow="Command center" title={`Good to see you, ${first}`}
        actions={
          <>
            {can("knowledge:capture") && <Link className="btn" to="/app/capture"><Mic />Capture knowledge</Link>}
            {can("assistant:use") && <Link className="btn primary" to="/app/assistant"><Wrench />Ask the assistant</Link>}
          </>
        }>
        Knowledge health for {session?.organization?.name?.replace(" (Synthetic Demo)", "")}.
      </PageHead>

      {error && <ErrorState error={error} onRetry={() => void reload()} />}

      {isDemo && <DemoTour highlight={!!params.get("tour")} />}

      <div className="grid g-6">
        {loading && !data ? (
          Array.from({ length: 6 }).map((_, i) => <div key={i} className="panel stat"><Skeleton h={10} w={80} /><div className="mt-12"><Skeleton h={28} w={60} /></div></div>)
        ) : data ? (
          <>
            <Stat label="Total assets" value={data.totals.assets} icon={<Factory size={16} />} />
            <Stat label="Knowledge records" value={data.totals.knowledge_records} icon={<BookOpen size={16} />} />
            <Stat label="Approved procedures" value={data.totals.approved_procedures} tone="hl" icon={<ClipboardCheck size={16} />} />
            <Stat label="Pending reviews" value={data.totals.pending_reviews} tone={data.totals.pending_reviews ? "w" : undefined} icon={<Info size={16} />} />
            <Stat label="Open conflicts" value={data.totals.open_conflicts} tone={data.totals.open_conflicts ? "w" : undefined} icon={<GitCompareArrows size={16} />} />
            <Stat label="Knowledge coverage" value={`${data.average_coverage}%`} foot="average across assets" icon={<ShieldAlert size={16} />} />
          </>
        ) : null}
      </div>

      <div className="split">
        <Panel title="Knowledge coverage by asset" sub="Approved procedures 40 · failure modes 20 · approved safety 20 · approved expert sources 20" tight>
          {data && data.coverage.length === 0 && <Empty title="No assets yet" action={can("assets:write") ? <Link className="btn" to="/app/assets">Register an asset</Link> : undefined}>Register machines to start tracking knowledge coverage.</Empty>}
          {data && data.coverage.length > 0 && (
            <div className="table-wrap">
              <table className="table">
                <thead><tr><th>Asset</th><th>Criticality</th><th style={{ width: "36%" }}>Coverage</th><th>Procedures</th><th>Safety</th></tr></thead>
                <tbody>
                  {data.coverage.map((c) => (
                    <tr key={c.asset_id} className="click" onClick={() => nav(`/app/assets/${c.asset_tag}`)}>
                      <td><Link to={`/app/assets/${c.asset_tag}`} onClick={(e) => e.stopPropagation()}><span className="tag">{c.asset_tag}</span></Link> <span className="muted">{c.name}</span></td>
                      <td><span className={cls("badge", c.criticality === "critical" ? "danger" : c.criticality === "high" ? "warn" : undefined)}>{c.criticality}</span></td>
                      <td><div className="row"><div style={{ flex: 1 }}><Meter value={c.coverage} tone={coverageTone(c.coverage)} /></div><span className="mono small" style={{ width: 36, textAlign: "right" }}>{c.coverage}%</span></div></td>
                      <td className="mono">{c.approved_procedures}</td>
                      <td className="mono">{c.safety_warnings}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          {loading && !data && <div className="panel-body stack">{[0, 1, 2, 3].map((i) => <Skeleton key={i} h={22} />)}</div>}
        </Panel>

        <div className="stack">
          <Panel title="Critical alerts" tight>
            {data && data.alerts.length === 0 && <Empty title="No alerts" icon={<ShieldAlert />}>Nothing needs attention right now.</Empty>}
            {data?.alerts.map((a, i) => (
              <Link key={i} to={a.link} className="list-item" style={{ color: "inherit", textDecoration: "none" }}>
                <AlertTriangle size={16} style={{ color: a.severity === "danger" ? "var(--danger)" : a.severity === "warning" ? "var(--warn)" : "var(--accent)", flex: "none", marginTop: 2 }} />
                <span style={{ flex: 1 }}>{a.message}</span>
                <ArrowRight size={14} className="faint" />
              </Link>
            ))}
          </Panel>
          <Panel title="Recent activity" tight>
            {data && data.recent_activity.length === 0 && <Empty title="No activity yet" />}
            {data?.recent_activity.map((a) => (
              <div key={a.id} className="list-item small">
                <span className="dot idle" style={{ marginTop: 6 }} />
                <span style={{ flex: 1 }}><strong>{a.actor}</strong> <span className="muted">{a.action}</span></span>
                <span className="faint nowrap">{timeAgo(a.at)}</span>
              </div>
            ))}
          </Panel>
        </div>
      </div>
    </div>
  );
}

function DemoTour({ highlight }: { highlight: boolean }) {
  return (
    <Panel className={highlight ? "accent" : undefined} title={<span className="row"><PlayCircle size={16} style={{ color: "var(--accent)" }} />Two-minute demo tour</span>}
      sub="Follow these steps in order. Everything shown is synthetic demo data.">
      <div className="grid g-4">
        {TOUR.map(([t, d, href], i) => (
          <Link key={t} to={href} className="panel" style={{ padding: 14, color: "inherit", textDecoration: "none", background: "var(--bg-2)" }}>
            <div className="row"><span className="tag">{String(i + 1).padStart(2, "0")}</span><strong className="small">{t}</strong></div>
            <p className="small muted mt-8">{d}</p>
          </Link>
        ))}
      </div>
    </Panel>
  );
}
