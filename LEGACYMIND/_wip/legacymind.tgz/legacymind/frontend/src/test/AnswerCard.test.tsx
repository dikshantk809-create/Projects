import { render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { AnswerCard } from "../components/AnswerCard";
import type { Answer } from "../lib/types";

const base: Answer = {
  status: "answered", mode: "extractive", question: "Pump P-103 grinding?",
  machine: { id: "a1", asset_tag: "P-103", name: "Hydraulic Pump", location: "Plant A / Line 3", status: "operational", criticality: "high" },
  reported_symptom: "grinding sound during startup", summary: "Approved procedure PR-103-01.",
  steps: [{ order: 1, text: "Inspect Valve V-03", citations: ["S1"] }],
  safety: [{ text: "Apply lockout/tagout before inspection.", severity: "danger", hazard_type: "stored_energy", citation: "S1" }],
  policy_notice: "Plant policy reminder.", sources: [{ type: "knowledge_record", ref: "LM-1042", id: "r1" }, { type: "asset", ref: "P-103", id: "a1" }],
  evidence: [{ id: "S1", kind: "procedure_step", record_id: "r1", record_ref: "LM-1042", title: "t", source_type: "audio", technician: "Rajesh Kumar", technician_title: "Senior Technician", recorded_at: "2026-08-14T10:00:00Z", start: 134, end: 168, timestamp: "02:14-02:48", quote: "first inspect Valve V-03", recording_id: "rec1", playable_audio: false, is_synthetic: true, review_status: "approved", ai_version: "rules-v1" }],
  procedure: { id: "p1", ref: "PR-103-01", title: "Grinding", risk_level: "high", requires_supervisor: true, status: "approved", approved_by: "Amit Sharma", approved_at: null, tools: ["pressure gauge"], parts: [] },
  groundedness: { level: "HIGH", score: 0.8, components: {}, explanation: "x" }, conflicts: [],
  escalation: { required: true, reason: "PR-103-01 is a high-risk procedure: supervisor sign-off required before execution.", message: "" },
  related_other_assets: [], unsupported_removed: 0, retrieval: { backend: "numpy", embedder: "local-hash-v1", hits: [] },
};

const renderCard = (a: Answer) => render(<MemoryRouter><AnswerCard a={a} /></MemoryRouter>);

describe("AnswerCard", () => {
  it("renders the grounded answer with evidence, safety and sources", () => {
    renderCard(base);
    expect(screen.getByText("Troubleshooting Recommendation")).toBeInTheDocument();
    expect(screen.getByText("Inspect Valve V-03")).toBeInTheDocument();
    expect(screen.getByText(/GROUNDEDNESS: HIGH/)).toBeInTheDocument();
    expect(screen.getByText("Rajesh Kumar")).toBeInTheDocument();
    expect(screen.getByText("02:14-02:48")).toBeInTheDocument();
    expect(screen.getByText("Apply lockout/tagout before inspection.")).toBeInTheDocument();
    expect(screen.getByText("Supervisor review required")).toBeInTheDocument();
    expect(screen.getByText(/Knowledge Record LM-1042/)).toBeInTheDocument();
    expect(screen.getByText("SYNTHETIC")).toBeInTheDocument();
  });

  it("renders the insufficient-evidence state without steps", () => {
    renderCard({ ...base, status: "insufficient", steps: [], evidence: [], procedure: null,
      summary: "I could not find sufficient verified plant knowledge for this question. Please contact the maintenance supervisor.",
      groundedness: { level: "INSUFFICIENT", score: 0, components: {}, explanation: "Asset PK-09 is not in the plant asset registry." } });
    expect(screen.getByText("Insufficient verified knowledge")).toBeInTheDocument();
    expect(screen.getByText(/could not find sufficient verified plant knowledge/)).toBeInTheDocument();
    expect(screen.queryByText("Inspect Valve V-03")).not.toBeInTheDocument();
    expect(screen.getByText("Ask your supervisor")).toBeInTheDocument();
  });

  it("shows knowledge conflicts side by side", () => {
    const side = (ref: string, author: string, step: string) => ({ procedure_id: ref, ref, title: "t", status: "approved", author, first_steps: [step] });
    renderCard({ ...base, conflicts: [{ id: "c1", type: "different_first_check", description: "d", recommended_action: "Supervisor review required.",
      procedure_a: side("PR-04-01", "Rajesh Kumar", "Check the tail pulley alignment"), procedure_b: side("PR-04-02", "Amit Sharma", "Check the idler rollers") }] });
    expect(screen.getByText("KNOWLEDGE CONFLICT")).toBeInTheDocument();
    expect(screen.getByText("Check the tail pulley alignment")).toBeInTheDocument();
    expect(screen.getByText("Check the idler rollers")).toBeInTheDocument();
  });
});
