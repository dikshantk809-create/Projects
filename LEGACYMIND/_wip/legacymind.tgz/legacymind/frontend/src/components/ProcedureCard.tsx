import { AlertTriangle, BadgeCheck, ChevronDown, ChevronRight, Quote } from "lucide-react";
import { useState, type ReactNode } from "react";
import { Link } from "react-router-dom";
import { cls, fmtDate, fmtTs } from "../lib/format";
import type { Procedure, SafetyOut } from "../lib/types";
import { Badge, RiskBadge, StatusBadge, SyntheticBadge } from "./ui";

export function ProcedureCard({ p, safety, actions, defaultOpen = false }: { p: Procedure; safety?: SafetyOut[]; actions?: ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  const warnings = safety ?? p.safety_warnings ?? [];
  return (
    <div className={cls("panel", p.status === "approved" && "accent")} style={{ background: "var(--bg-2)" }}>
      <button className="panel-head" style={{ width: "100%", background: "none", border: 0, color: "inherit", cursor: "pointer", textAlign: "left", borderBottom: open ? undefined : 0 }}
        onClick={() => setOpen(!open)} aria-expanded={open}>
        {open ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
        <span className="mono small faint">{p.ref}</span>
        <strong style={{ flex: 1, minWidth: 0 }} className="ellipsis">{p.title}</strong>
        <RiskBadge risk={p.risk_level} />
        <StatusBadge status={p.status} />
      </button>
      {open && (
        <div className="panel-body stack">
          <div className="row-wrap small">
            {p.asset && <Link to={`/app/assets/${p.asset.asset_tag}`}><span className="tag">{p.asset.asset_tag}</span></Link>}
            {p.failure_mode && <Badge tone="info">Failure mode: {p.failure_mode.name}</Badge>}
            {p.symptoms.map((s) => <Badge key={s} tone="warn">{s}</Badge>)}
            {p.is_synthetic && <SyntheticBadge />}
          </div>
          <ol className="steps">
            {p.steps.map((s) => (
              <li key={s.order}>
                <div>
                  <div>{s.text}</div>
                  {s.source?.quote && (
                    <div className="small faint mt-8 row" style={{ alignItems: "flex-start" }}>
                      <Quote size={12} style={{ flex: "none", marginTop: 4 }} />
                      <span>“{s.source.quote}”{s.source.start !== null && s.source.start !== undefined && <span className="mono" style={{ color: "var(--accent)" }}> · {fmtTs(s.source.start)}–{fmtTs(s.source.end)}</span>}{s.source.edited_by && <em> · edited by {s.source.edited_by}</em>}</span>
                    </div>
                  )}
                </div>
                <span className="mono tiny faint cites">{s.confidence !== undefined ? `${Math.round(s.confidence * 100)}%` : ""}</span>
              </li>
            ))}
          </ol>
          {warnings.length > 0 && (
            <div className="stack-sm">
              {warnings.map((w) => (
                <div key={w.id} className={cls("safety-card small", w.severity === "danger" && "danger")}><AlertTriangle />{w.text}<span className="spacer" /><StatusBadge status={w.status} /></div>
              ))}
            </div>
          )}
          {(p.tools.length > 0 || p.parts.length > 0) && (
            <div className="row-wrap small">
              {p.tools.length > 0 && <><span className="faint">Tools:</span>{p.tools.map((t) => <Badge key={t}>{t}</Badge>)}</>}
              {p.parts.length > 0 && <><span className="faint">Parts:</span>{p.parts.map((t) => <Badge key={t}>{t}</Badge>)}</>}
            </div>
          )}
          <div className="row-wrap tiny faint">
            <span>Author: {p.author?.full_name ?? "—"}</span>
            <span>· v{p.version}</span>
            <span>· AI: <span className="mono">{p.ai_version}</span></span>
            <span>· confidence {Math.round(p.confidence * 100)}%</span>
            {p.requires_supervisor && <span className="badge warn">Supervisor sign-off required</span>}
            {p.approved_by && <span className="badge ok"><BadgeCheck />Approved by {p.approved_by.full_name} · {fmtDate(p.approved_at)}</span>}
            {p.record_id && <Link to={`/app/library/${p.record_id}`}>View source record →</Link>}
          </div>
          {actions}
        </div>
      )}
    </div>
  );
}
