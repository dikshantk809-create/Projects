# LegacyMind API

Base path `/api`. Interactive OpenAPI docs: **`/api/docs`** (schema at `/api/openapi.json`).

## Conventions

- **Auth:** session cookie `lm_session` (httpOnly) set by `/api/auth/login`, `/register` or `/demo/launch`. API clients may instead send `Authorization: Bearer <access_token>` (returned by the same endpoints).
- **Errors:** every non-2xx response has the shape
  ```json
  {"error": {"code": "not_found", "message": "Asset not found.", "error_id": "a1b2c3d4e5", "request_id": "…", "details": …}}
  ```
  `422 validation_error` includes `details: [{field, message}]`. Unexpected errors return `500 internal_error` with a reference and no internals.
- **Request IDs:** send `X-Request-ID` to correlate; it is echoed back (sanitised) or generated.
- **Rate limits:** `429 rate_limited` with `details.retry_after_s`.
- **IDs:** 32-char hex. Human references also resolve where noted: asset tag (`P-103`), record ref (`LM-1042`), procedure ref (`PR-103-01`).
- **Roles → permissions:** see `app/security.py`. Junior technicians only ever receive approved knowledge.

## Operations

| Method | Path | Description |
|---|---|---|
| GET | `/health` | Liveness (no dependencies). |
| GET | `/ready` | Readiness: database, migration head, storage; `config_warnings`. 503 when not ready. |

## Auth — `/api/auth`

| Method | Path | Body / notes |
|---|---|---|
| POST | `/login` | `{email, password}` → session + `access_token`. Generic 401 on failure. Rate-limited. |
| POST | `/register` | `{organization_name, plant_name, full_name, email, password}` → creates org + admin. Disabled when `ALLOW_PUBLIC_REGISTRATION=false`. |
| POST | `/logout` | Clears the cookie. |
| POST | `/logout-all` | Revokes all sessions of the current user. |
| GET | `/me` | `{user, organization, permissions[]}` |

## Demo — `/api/demo`

| Method | Path | Notes |
|---|---|---|
| GET | `/api/demo` | Whether demo mode is enabled and the personas. |
| POST | `/api/demo/launch?persona=supervisor\|junior\|senior\|admin` | Ensures the synthetic plant exists and signs in as the persona. |
| POST | `/api/demo/reset` | Rebuilds the synthetic plant. |

## Assets — `/api/assets` (`assets:read`; writes `assets:write`)

| Method | Path | Notes |
|---|---|---|
| GET | `` | `?q=&status=&department_id=` → items with `knowledge_count`, `approved_procedures`. |
| POST | `` | `{asset_tag, name, machine_type, manufacturer, model, serial_number, department_id, location, installed_on, status, criticality, description}` |
| GET | `/{id or tag}` | Asset page: asset, components, procedures, failure modes (+symptoms, causes), records, recordings, documents, maintenance history, approved safety warnings, `qr_url`. |
| PATCH | `/{id}` | Partial update. |
| DELETE | `/{id}` | 409 if knowledge exists (decommission instead). |
| GET | `/{id}/qr.svg?base_url=https://…` | QR code encoding `{base_url}/app/assets/{TAG}`. |
| POST | `/{id}/events` | `{occurred_on, event_type, summary, downtime_hours}` (`knowledge:capture`). |
| POST | `/{id}/documents` | multipart `file`, `category` (manual, machine, part, fault, wiring, control_panel, other). Text extracted (PDF/DOCX/TXT/OCR). |

## Knowledge — `/api/knowledge`

| Method | Path | Notes |
|---|---|---|
| POST | `/records` | multipart (`knowledge:capture`): `title`, `source_type` (audio, video, image, document, text, interview), `asset_id?`, `notes?`, `segments?` (JSON `[{start,end,text}]` from browser speech), `transcript_source?`, `duration_s?`, `image_category?`, `files[]` (≤10). Returns the record brief; processing starts in the background. |
| GET | `/records` | Filters: `q, asset_id, technician_id, department_id, failure_mode, review_status, source_type, date_from, date_to, limit, offset`. |
| GET | `/records/{id or ref}` | Full record: transcript + segments, `processing_stages`, extraction, recordings, documents, procedures, safety warnings. Poll while `processing_status` is `queued`/`processing`. |
| PUT | `/records/{id}/transcript` | `{transcript}` — supply/correct text (contributor or supervisor); reprocesses. |
| POST | `/records/{id}/reprocess` | Supervisor: re-run the pipeline (approved procedures are kept). |
| GET | `/procedures` | `?asset_id=&status=&q=` |
| GET | `/procedures/{id or ref}` | Procedure + safety warnings + source record + **traceability** rows (record, recording/document, technician, start/end, quote, confidence, AI version). |
| GET | `/facets` | Filter options and `max_upload_mb`. |

## Assistant — `/api/assistant` (`assistant:use`)

| Method | Path | Notes |
|---|---|---|
| POST | `/ask` | `{question, conversation_id?, asset_id?}` → `{conversation_id, message}`; `message.answer` is the grounded answer below. |
| GET | `/conversations` | Current user's conversations. |
| GET | `/conversations/{id}` | Messages with stored answers (audit trail). |

**Answer object** (abridged):

```json
{
  "status": "answered | insufficient",
  "mode": "extractive | llm-grounded (openai:gpt-4o-mini) | none",
  "machine": {"asset_tag": "P-103", "name": "Hydraulic Pump", "location": "Plant A / Line 3"},
  "reported_symptom": "grinding sound during startup",
  "summary": "Approved procedure PR-103-01: …",
  "steps": [{"order": 1, "text": "Inspect Valve V-03", "citations": ["S2"]}],
  "safety": [{"text": "Before any inspection on P-103, stop the pump and apply lockout/tagout…", "severity": "danger", "citation": "S1"}],
  "policy_notice": "Plant policy reminder (standard notice, not generated from evidence): …",
  "evidence": [{"id": "S2", "record_ref": "LM-1042", "technician": "Rajesh Kumar", "recorded_at": "2026-08-14T10:00:00+00:00",
                "timestamp": "02:14-02:48", "start": 134, "end": 168, "quote": "…first inspect Valve V-03…",
                "recording_id": "…", "playable_audio": false, "is_synthetic": true, "ai_version": "rules-v1"}],
  "sources": [{"type": "knowledge_record", "ref": "LM-1042"}, {"type": "asset", "ref": "P-103"}, {"type": "procedure", "ref": "PR-103-01"}],
  "procedure": {"ref": "PR-103-01", "risk_level": "high", "requires_supervisor": true, "approved_by": "Amit Sharma"},
  "groundedness": {"level": "HIGH | MEDIUM | LOW | INSUFFICIENT", "score": 0.78, "components": {…}, "explanation": "…"},
  "conflicts": [{"procedure_a": {…}, "procedure_b": {…}, "recommended_action": "Supervisor review required."}],
  "escalation": {"required": true, "reason": "PR-103-01 is a high-risk procedure: supervisor sign-off required before execution."},
  "unsupported_removed": 0,
  "retrieval": {"backend": "pgvector", "embedder": "local-hash-v1", "hits": [{"chunk_id": "…", "fused": 0.05, "vector": 0.4, "bm25": 7.1, "graph": 0.8}]}
}
```

## Knowledge Harvest — `/api/harvest` (`harvest:run`)

| Method | Path | Notes |
|---|---|---|
| POST | `/sessions` | `{asset_id}` → session with first question and zero coverage. |
| GET | `/sessions` / `/sessions/{id}` | List / get. |
| POST | `/sessions/{id}/answer` | `{text, source: typed|voice}` → updated turns, coverage, gaps, `extracted_from_answer`, next question (`reason` explains why it was asked). |
| POST | `/sessions/{id}/finish` | Converts the interview into a knowledge record (`record_ref`) and processes it. |

## Review — `/api/reviews` (`knowledge:review`)

| Method | Path | Notes |
|---|---|---|
| GET | `/queue` | Pending procedures (+ safety), pending records, open conflicts, recent decisions. |
| POST | `/procedures/{id}` | `{decision: approve|reject|needs_changes, comment, edits?: {title, steps:[{text, component}], risk_level, symptoms}}`. Reject requires a comment. Unchanged steps keep their evidence; edited steps are marked `edited_by`. |
| POST | `/records/{id}` | Same decisions for a whole record (cascades to its procedures and safety warnings). |
| POST | `/conflicts/{id}/resolve` | `{status: resolved|dismissed, preferred_procedure_id?, resolution}` (`conflicts:resolve`). Choosing a procedure approves it and supersedes the other. |
| GET | `/stats` | `{pending_procedures, open_conflicts}` |

## Graph — `/api/graph`

| Method | Path | Notes |
|---|---|---|
| GET | `` | `?asset_id=&include_pending=` → `{nodes, edges, backend}` (juniors: approved only). |
| GET | `/cypher` | Idempotent Cypher (`MERGE`) export for Neo4j (`reports:export`). |
| POST | `/neo4j/sync` | Push to Neo4j when `NEO4J_URI` is set; clear 503 otherwise (`org:manage`). |

## Analytics — `/api/analytics`

| Method | Path | Notes |
|---|---|---|
| GET | `/summary` | Dashboard totals, per-asset coverage, alerts, recent activity (`knowledge:read`). |
| GET | `/detail` | Captures per week, by source type, coverage, most common failures, FAQ, unresolved questions, groundedness distribution, conflicts, technician contribution, AI request stats (`analytics:read`). |
| GET | `/export.csv` | Knowledge register export (`reports:export`). |

## Administration — `/api/admin`

| Method | Path | Notes |
|---|---|---|
| GET/POST | `/users` | List / create (`users:manage`). |
| PATCH | `/users/{id}` | Role, active, title, department, password (revokes sessions). Self-demotion blocked. |
| GET/POST/DELETE | `/departments` | Create/delete need `org:manage`; delete blocked while assets are assigned. |
| GET | `/plants` | Plants of the organization. |
| GET | `/audit` | `?action=prefix&limit=` (`audit:read`). |
| GET | `/system` | Which AI capabilities are genuinely active (LLM, embeddings, transcription, OCR, vector backend, graph, storage) and config problems (admins). |

## Media — `/api/media`

| Method | Path | Notes |
|---|---|---|
| GET | `/recordings/{id}` | Authenticated audio/video stream with HTTP `Range` support (seek to cited timestamps). |
| GET | `/documents/{id}` | Authenticated document/image download. |
