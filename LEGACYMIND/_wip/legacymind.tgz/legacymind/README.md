# LegacyMind

**Capture the experience. Preserve the knowledge. Empower the next technician.**

LegacyMind is an AI-powered industrial knowledge-capture and maintenance assistant. Senior technicians *talk* — record audio or video on the shop floor, upload photos and manuals, or answer an AI interviewer — and LegacyMind turns that into structured, supervisor-approved maintenance knowledge. Junior technicians then ask questions in plain language and get answers **grounded only in their plant's approved knowledge**, with the technician, recording date and exact timestamp behind every step.

```
RAW KNOWLEDGE → MULTIMODAL PROCESSING → STRUCTURED KNOWLEDGE → KNOWLEDGE GRAPH + VECTOR SEARCH
             → GROUNDED RETRIEVAL → AI REASONING → TRACEABLE ANSWER
```

> Ask *“Pump P-103 is making a grinding sound during startup. What should I check?”* and LegacyMind answers with the approved procedure (inspect Valve V-03, check for blockage), the lockout/tagout warning, Rajesh Kumar's original recording at **02:14–02:48**, a groundedness level, and a supervisor-escalation flag for the high-risk procedure. Ask about a machine it knows nothing about and it says **“I could not find sufficient verified plant knowledge for this question. Please contact the maintenance supervisor.”**

---

## What is real, what is optional, what is planned

| Capability | Status |
|---|---|
| Auth (scrypt, httpOnly session cookie, token revocation), 4-role RBAC, audit log | **Implemented** |
| Asset registry, QR codes (built-in encoder, verified by OpenCV decoding in tests), maintenance history, documents | **Implemented** |
| Capture: in-browser audio/video recording, live speech-to-text (Web Speech API), images, PDF/DOCX/TXT, text notes | **Implemented** |
| Server transcription (OpenAI Whisper) | **Implemented, optional** — needs `OPENAI_API_KEY`; otherwise browser STT or a typed transcript. Never invented. |
| 10-stage processing pipeline with per-stage status | **Implemented** |
| Extraction of machine, component, symptom, failure mode, cause, procedure, tool, part, safety, misconceptions | **Implemented** — LLM extractor with quote verification when a key is set; deterministic `rules-v1` extractor otherwise |
| Knowledge graph (asset → component → failure mode → symptom → procedure → safety → source → technician) | **Implemented in PostgreSQL**; Cypher export + optional Neo4j sync |
| Hybrid retrieval: vector (pgvector / numpy) + BM25 + graph, fused with RRF | **Implemented** |
| Grounded answers: citations, timestamps, source playback, safety, groundedness, escalation, conflict surfacing | **Implemented** |
| Knowledge Harvest interview agent with coverage tracking | **Implemented** (rules agent; LLM-generated follow-ups when a key is set) |
| Supervisor review: approve / edit / reject, conflict resolution | **Implemented** |
| Analytics, CSV export, health/readiness, structured logs, AI request log | **Implemented** |
| Embeddings | `local-hash-v1` offline hashing embeddings by default (**lexical**, not deep semantic); OpenAI embeddings optional |
| On-prem / edge (Ollama + local embeddings + Docker Compose) | **Designed and wired** (Ollama provider exists); **not validated on plant hardware** |
| Computer vision, AR, IoT, predictive maintenance, digital twins | **Planned** — see [ARCHITECTURE.md](ARCHITECTURE.md#future-extensions) |

The demo factory **NovaTech Manufacturing Plant** is fictional and labelled **Synthetic Demo Data** everywhere. Its recordings have transcripts but no real audio; “Play source” reads the cited segment with the browser's synthetic voice and says so.

## Quick start

### Windows — one click

1. Install **Python 3.12** (python.org, tick “Add python.exe to PATH”) and **Node.js LTS** (nodejs.org).
2. Double-click **`START-LEGACYMIND.bat`**. The first run installs everything (a few minutes, needs internet); later runs start in seconds.
3. Your browser opens at http://127.0.0.1:5173 → click **Launch Demo**.

| File | What it does |
|---|---|
| `START-LEGACYMIND.bat` | Checks Python/Node, installs packages when needed, starts the API (port 8000, SQLite, synthetic demo plant) and the web UI (port 5173), opens the browser. Close the two “LegacyMind” windows to stop. |
| `RUN-TESTS.bat` | Backend tests, AI evaluation (`backend/eval/results.md`), frontend tests and production build. |
| `RESET-DEMO-DATA.bat` | Deletes the local database and uploads; the demo is rebuilt on next start. |

Optional AI keys: create `backend\.env` with e.g. `AI_PROVIDER=openai` and `OPENAI_API_KEY=...` (see `.env.example`).

### Docker (PostgreSQL + pgvector, production-like)

```bash
cp .env.example .env            # optional: add OPENAI_API_KEY / ANTHROPIC_API_KEY
docker compose up --build
# open http://localhost:8080  →  "Launch Demo"
```

Services start in dependency order with health checks: `postgres` (pgvector) → `backend` (runs migrations, seeds the demo) → `frontend` (nginx, proxies `/api`).

### Manual local development (macOS / Linux / Windows)

```bash
# API (Python 3.11+)
cd backend
python -m venv .venv && . .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt
uvicorn app.main:app --reload --port 8000          # SQLite by default; migrations + demo seed on startup

# Web (Node 20+) — in another terminal
cd frontend
npm install
npm run dev                                        # http://localhost:5173 (proxies /api to :8000)
```

Demo accounts (password `LegacyMind-Demo-2026`, override with `DEMO_PASSWORD`): `amit.sharma@novatech.demo` (supervisor), `rahul.verma@novatech.demo` (junior technician), `rajesh.kumar@novatech.demo` (senior technician), `priya.nair@novatech.demo` (administrator). Or just click **Launch Demo**.

### Enabling an LLM

```bash
AI_PROVIDER=openai        OPENAI_API_KEY=sk-...        # or
AI_PROVIDER=anthropic     ANTHROPIC_API_KEY=...        # or (on-prem)
AI_PROVIDER=ollama        OLLAMA_BASE_URL=http://ollama:11434  MODEL_NAME=llama3.1:8b
TRANSCRIPTION_PROVIDER=openai   EMBEDDING_PROVIDER=openai       # optional
```

If a provider is misconfigured or unreachable the app keeps working in the labelled local mode, `/ready` and **Administration → System status** report the problem, and failed calls are logged in the AI request log.

## Tests and evaluation

```bash
cd backend && pytest -q                         # unit, API, auth, DB, pipeline, retrieval, review, harvest
TEST_DATABASE_URL=postgresql://... pytest -q    # same suite on PostgreSQL + pgvector
python -m eval.run_eval                         # golden-set AI evaluation → eval/results.md
cd frontend && npm test && npm run typecheck && npm run build
cd e2e && npx playwright test                   # against a running server (BASE_URL)
```

Measured results are in [AI_EVALUATION.md](AI_EVALUATION.md).

## Repository layout

```
backend/     FastAPI app (app/), Alembic migrations, tests, AI evaluation (eval/)
frontend/    React + TypeScript + Vite UI
e2e/         Playwright end-to-end tests and screenshot capture
docs/        Project report, pitch deck content, demo script, screenshots
.github/     CI/CD (lint → type check → tests → build → e2e → docker → deploy)
```

## Documentation

- [Architecture](ARCHITECTURE.md) · [API](API.md) · [Deployment](DEPLOYMENT.md) · [Security](SECURITY.md) · [AI evaluation](AI_EVALUATION.md) · [Contributing](CONTRIBUTING.md)
- Interactive API docs at `/api/docs` on any running instance.
