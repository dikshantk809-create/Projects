"""Embedding providers.

* ``local`` (default) - ``local-hash-v1``: a deterministic feature-hashing
  embedding over canonicalised unigrams, bigrams and character 4-grams. It is
  fully offline, so it runs on air-gapped plant servers, but it captures
  lexical rather than deep semantic similarity. It is labelled as such in the UI.
* ``openai`` - ``text-embedding-3-small`` (or EMBEDDING_MODEL) requested at
  EMBEDDING_DIM dimensions so both providers share one vector column.
"""

from __future__ import annotations

import hashlib
import time
from typing import Protocol

import numpy as np

from ..config import get_settings
from .llm import _post_with_retries, log_ai_request
from .text import tokenize


class Embedder(Protocol):
    name: str
    dim: int

    def embed(self, texts: list[str]) -> list[list[float]]: ...


def _h(feature: str) -> int:
    return int.from_bytes(hashlib.blake2b(feature.encode(), digest_size=8).digest(), "little")


class LocalHashEmbedder:
    name = "local-hash-v1"

    def __init__(self, dim: int) -> None:
        self.dim = dim

    def _vec(self, text: str) -> np.ndarray:
        v = np.zeros(self.dim, dtype=np.float64)
        toks = tokenize(text)
        feats: dict[str, float] = {}
        for t in toks:
            feats["u:" + t] = feats.get("u:" + t, 0.0) + 1.0
            if len(t) > 4 and "-" not in t:
                padded = f"#{t}#"
                for i in range(len(padded) - 3):
                    g = "c:" + padded[i : i + 4]
                    feats[g] = feats.get(g, 0.0) + 0.25
        for a, b in zip(toks, toks[1:]):
            k = f"b:{a}_{b}"
            feats[k] = feats.get(k, 0.0) + 0.7
        for f, w in feats.items():
            h = _h(f)
            idx = h % self.dim
            sign = 1.0 if (h >> 63) & 1 else -1.0
            v[idx] += sign * (1.0 + np.log(w)) if w >= 1 else sign * w
        n = np.linalg.norm(v)
        return v / n if n > 0 else v

    def embed(self, texts: list[str]) -> list[list[float]]:
        return [self._vec(t).tolist() for t in texts]


class OpenAIEmbedder:
    def __init__(self, dim: int, model: str) -> None:
        self.dim = dim
        self.model = model
        self.name = f"openai:{model}"

    def embed(self, texts: list[str]) -> list[list[float]]:
        s = get_settings()
        started = time.monotonic()
        out: list[list[float]] = []
        try:
            for i in range(0, len(texts), 64):
                batch = texts[i : i + 64]
                data = _post_with_retries(
                    f"{s.openai_base_url.rstrip('/')}/embeddings",
                    headers={"Authorization": f"Bearer {s.openai_api_key}"},
                    payload={"model": self.model, "input": batch, "dimensions": self.dim},
                )
                out.extend(item["embedding"] for item in sorted(data["data"], key=lambda d: d["index"]))
        except Exception as exc:
            log_ai_request(kind="embedding", provider="openai", model=self.model, status="error",
                           latency_ms=int((time.monotonic() - started) * 1000), error=str(exc))
            raise
        log_ai_request(kind="embedding", provider="openai", model=self.model, status="ok",
                       latency_ms=int((time.monotonic() - started) * 1000))
        return out


_cached: Embedder | None = None


def get_embedder() -> Embedder:
    global _cached
    s = get_settings()
    if _cached is not None and _cached.dim == s.embedding_dim:
        return _cached
    if s.embedding_provider == "openai" and s.openai_api_key:
        _cached = OpenAIEmbedder(s.embedding_dim, s.embedding_model)
    else:
        _cached = LocalHashEmbedder(s.embedding_dim)
    return _cached


def reset_embedder() -> None:
    global _cached
    _cached = None


def cosine_matrix(query: list[float], matrix: np.ndarray) -> np.ndarray:
    q = np.asarray(query, dtype=np.float64)
    qn = np.linalg.norm(q)
    if qn == 0 or matrix.size == 0:
        return np.zeros(matrix.shape[0])
    norms = np.linalg.norm(matrix, axis=1)
    norms[norms == 0] = 1.0
    return (matrix @ q) / (norms * qn)
