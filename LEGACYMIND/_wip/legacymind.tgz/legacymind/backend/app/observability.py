"""Structured logging, request IDs and error-monitoring hooks."""

from __future__ import annotations

import contextvars
import json
import logging
import sys
import time
import uuid
from collections.abc import Callable
from typing import Any

request_id_var: contextvars.ContextVar[str] = contextvars.ContextVar("request_id", default="-")

# Error-monitoring hook: set by integrations (e.g. Sentry) at startup. Receives
# (exception, context). Kept dependency-free on purpose.
_error_hooks: list[Callable[[BaseException, dict[str, Any]], None]] = []


def register_error_hook(fn: Callable[[BaseException, dict[str, Any]], None]) -> None:
    _error_hooks.append(fn)


def report_exception(exc: BaseException, context: dict[str, Any]) -> None:
    for hook in _error_hooks:
        try:
            hook(exc, context)
        except Exception:  # pragma: no cover - hooks must never break requests
            logging.getLogger("legacymind").warning("error hook failed", exc_info=True)


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created)) + f".{int(record.msecs):03d}Z",
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
            "request_id": request_id_var.get(),
        }
        extra = getattr(record, "extra_fields", None)
        if isinstance(extra, dict):
            payload.update(extra)
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


def configure_logging(level: str = "INFO", as_json: bool = True) -> None:
    root = logging.getLogger()
    root.handlers.clear()
    handler = logging.StreamHandler(sys.stdout)
    if as_json:
        handler.setFormatter(JsonFormatter())
    else:
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s [%(request_id)s] %(message)s"))
        handler.addFilter(_RequestIdFilter())
    root.addHandler(handler)
    root.setLevel(level)
    logging.getLogger("uvicorn.access").setLevel("WARNING")


class _RequestIdFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = request_id_var.get()
        return True


def log_event(logger: logging.Logger, msg: str, level: int = logging.INFO, **fields: Any) -> None:
    logger.log(level, msg, extra={"extra_fields": fields})


def new_request_id() -> str:
    return uuid.uuid4().hex[:16]
