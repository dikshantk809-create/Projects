from __future__ import annotations

import re

from fastapi import APIRouter, Depends, Request, Response
from pydantic import BaseModel, Field, field_validator

from ..validation import Email
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import get_db, utcnow
from ..deps import audit, auth_rate_limit, get_current_user
from ..errors import AppError, Conflict, Forbidden, Unauthorized
from ..models import Organization, Plant, User
from ..security import SESSION_COOKIE, create_session_token, hash_password, password_problems, verify_password
from ..serializers import user_out

router = APIRouter(prefix="/api/auth", tags=["auth"])

# Constant-time-ish defence against user enumeration: verify against a dummy hash
_DUMMY_HASH = hash_password("dummy-password-for-timing-1")


class LoginIn(BaseModel):
    email: Email
    password: str = Field(min_length=1, max_length=200)


class RegisterIn(BaseModel):
    organization_name: str = Field(min_length=2, max_length=200)
    plant_name: str = Field(default="Main Plant", min_length=2, max_length=200)
    full_name: str = Field(min_length=2, max_length=200)
    email: Email
    password: str = Field(min_length=10, max_length=200)

    @field_validator("organization_name", "plant_name", "full_name")
    @classmethod
    def _strip(cls, v: str) -> str:
        v = re.sub(r"[<>]", "", v).strip()
        if len(v) < 2:
            raise ValueError("too short")
        return v


def set_session_cookie(response: Response, user: User) -> str:
    s = get_settings()
    token = create_session_token(user.id, user.org_id, user.role, user.token_version)
    response.set_cookie(
        SESSION_COOKIE, token, max_age=s.access_token_minutes * 60, httponly=True, secure=s.cookie_secure,
        samesite=s.cookie_samesite, path="/",
    )
    return token


def session_payload(user: User, db: Session) -> dict:
    org = db.get(Organization, user.org_id)
    return {"user": user_out(user), "organization": {"id": org.id, "name": org.name, "is_demo": org.is_demo} if org else None}


@router.post("/login", dependencies=[Depends(auth_rate_limit)])
def login(body: LoginIn, request: Request, response: Response, db: Session = Depends(get_db)) -> dict:
    user = db.scalar(select(User).where(func.lower(User.email) == body.email.lower()))
    ok = verify_password(body.password, user.password_hash if user else _DUMMY_HASH)
    if not user or not ok:
        audit(db, action="auth.login_failed", user=None, org_id=user.org_id if user else None, request=request,
              details={"email": body.email.lower()})
        db.commit()
        raise Unauthorized("Incorrect email or password.", code="invalid_credentials")
    if not user.is_active:
        raise Forbidden("This account is disabled. Contact your plant administrator.")
    user.last_login_at = utcnow()
    audit(db, action="auth.login", user=user, entity_type="user", entity_id=user.id, request=request)
    db.commit()
    token = set_session_cookie(response, user)
    return {**session_payload(user, db), "access_token": token, "token_type": "bearer"}


@router.post("/register", dependencies=[Depends(auth_rate_limit)], status_code=201)
def register(body: RegisterIn, request: Request, response: Response, db: Session = Depends(get_db)) -> dict:
    if not get_settings().allow_public_registration:
        raise Forbidden("Self-service registration is disabled. Ask your administrator for an account.")
    problems = password_problems(body.password)
    if problems:
        raise AppError("Password must contain " + ", ".join(problems) + ".", code="weak_password", status_code=422)
    if db.scalar(select(User).where(func.lower(User.email) == body.email.lower())):
        raise Conflict("An account with this email already exists.", code="email_taken")
    base = re.sub(r"[^a-z0-9]+", "-", body.organization_name.lower()).strip("-")[:60] or "org"
    slug, n = base, 1
    while db.scalar(select(Organization).where(Organization.slug == slug)):
        n += 1
        slug = f"{base}-{n}"
    org = Organization(name=body.organization_name, slug=slug)
    db.add(org)
    db.flush()
    db.add(Plant(org_id=org.id, name=body.plant_name))
    user = User(org_id=org.id, email=body.email.lower(), full_name=body.full_name, role="admin",
                title="Plant Administrator", password_hash=hash_password(body.password))
    db.add(user)
    db.flush()
    audit(db, action="auth.register", user=user, entity_type="organization", entity_id=org.id, request=request)
    db.commit()
    token = set_session_cookie(response, user)
    return {**session_payload(user, db), "access_token": token, "token_type": "bearer"}


@router.post("/logout")
def logout(request: Request, response: Response, db: Session = Depends(get_db)) -> dict:
    s = get_settings()
    response.delete_cookie(SESSION_COOKIE, path="/", secure=s.cookie_secure, samesite=s.cookie_samesite, httponly=True)
    return {"ok": True}


@router.post("/logout-all")
def logout_all(request: Request, response: Response, user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> dict:
    """Invalidate every session of the current user (token_version bump)."""
    user.token_version += 1
    audit(db, action="auth.logout_all", user=user, request=request)
    db.commit()
    response.delete_cookie(SESSION_COOKIE, path="/")
    return {"ok": True}


@router.get("/me")
def me(user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> dict:
    from ..security import PERMISSIONS

    return {**session_payload(user, db), "permissions": sorted(PERMISSIONS.get(user.role, set()))}
