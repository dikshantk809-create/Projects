from __future__ import annotations

import csv
import io
import re
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any

from fastapi import APIRouter, Depends, Response
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import require
from ..models import (
    AIRequestLog,
    Asset,
    AuditLog,
    FailureMode,
    KnowledgeConflict,
    KnowledgeRecord,
    KnowledgeSource,
    Message,
    Procedure,
    SafetyWarning,
    User,
)
from ..serializers import iso

router = APIRouter(prefix="/api/analytics", tags=["analytics"])

ACTIVITY_LABELS = {
    "knowledge.capture": "captured knowledge",
    "review.procedure.approve": "approved a procedure",
    "review.procedure.reject": "rejected a procedure",
    "review.record.approve": "approved a knowledge record",
    "review.conflict.resolve": "resolved a knowledge conflict",
    "harvest.finish": "completed a Knowledge Harvest interview",
    "harvest.start": "started a Knowledge Harvest interview",
    "assistant.ask": "asked the assistant",
    "asset.create": "registered an asset",
}


def asset_coverage(db: Session, org_id: str) -> list[dict[str, Any]]:
    """Coverage score per asset (0-100): approved procedure 40, failure modes 20, approved safety 20, approved expert source 20."""
    out = []
    for a in db.scalars(select(Asset).where(Asset.org_id == org_id).order_by(Asset.asset_tag)).all():
        n_proc = db.scalar(select(func.count()).select_from(Procedure).where(Procedure.asset_id == a.id, Procedure.status == "approved")) or 0
        n_fm = db.scalar(select(func.count()).select_from(FailureMode).where(FailureMode.asset_id == a.id)) or 0
        n_sw = db.scalar(select(func.count()).select_from(SafetyWarning).where(SafetyWarning.asset_id == a.id, SafetyWarning.status == "approved")) or 0
        n_src = db.scalar(select(func.count()).select_from(KnowledgeRecord).where(KnowledgeRecord.asset_id == a.id, KnowledgeRecord.review_status == "approved")) or 0
        score = min(40, 20 * n_proc) + min(20, 10 * n_fm) + min(20, 10 * n_sw) + min(20, 10 * n_src)
        out.append({"asset_id": a.id, "asset_tag": a.asset_tag, "name": a.name, "criticality": a.criticality,
                    "coverage": score, "approved_procedures": n_proc, "failure_modes": n_fm, "safety_warnings": n_sw,
                    "approved_sources": n_src})
    return out


@router.get("/summary")
def summary(user: User = Depends(require("knowledge:read")), db: Session = Depends(get_db)) -> dict:
    org = user.org_id

    def count(model: Any, *conds: Any) -> int:
        return int(db.scalar(select(func.count()).select_from(model).where(model.org_id == org, *conds)) or 0)

    cov = asset_coverage(db, org)
    alerts: list[dict[str, Any]] = []
    for a in db.scalars(select(Asset).where(Asset.org_id == org, Asset.status.in_(("down", "degraded")))).all():
        alerts.append({"severity": "danger" if a.status == "down" else "warning", "kind": "asset_status",
                       "message": f"{a.asset_tag} {a.name} is {a.status}.", "link": f"/app/assets/{a.asset_tag}"})
    n_conf = count(KnowledgeConflict, KnowledgeConflict.status == "open")
    if n_conf:
        alerts.append({"severity": "warning", "kind": "conflict", "message": f"{n_conf} open knowledge conflict(s) need supervisor review.", "link": "/app/review"})
    n_high = count(Procedure, Procedure.status == "pending_review", Procedure.risk_level.in_(("high", "critical")))
    if n_high:
        alerts.append({"severity": "warning", "kind": "high_risk_pending", "message": f"{n_high} high-risk procedure card(s) awaiting approval.", "link": "/app/review"})
    for c in cov:
        if c["criticality"] in ("high", "critical") and c["coverage"] < 40:
            alerts.append({"severity": "info", "kind": "coverage_gap", "message": f"{c['asset_tag']} is {c['criticality']}-criticality with only {c['coverage']}% knowledge coverage.",
                           "link": "/app/harvest"})
    since = datetime.now(timezone.utc) - timedelta(days=7)
    n_unres = int(db.scalar(select(func.count()).select_from(Message).where(Message.org_id == org, Message.role == "assistant",
                                                                            Message.groundedness == "INSUFFICIENT", Message.created_at >= since)) or 0)
    if n_unres:
        alerts.append({"severity": "info", "kind": "unanswered", "message": f"{n_unres} question(s) this week could not be answered from verified knowledge.", "link": "/app/analytics"})

    logs = db.scalars(select(AuditLog).where(AuditLog.org_id == org, AuditLog.action.in_(list(ACTIVITY_LABELS))).order_by(AuditLog.created_at.desc()).limit(12)).all()
    users = {u.id: u for u in db.scalars(select(User).where(User.org_id == org)).all()}
    activity = [{"id": lg.id, "actor": users[lg.user_id].full_name if lg.user_id in users else "System",
                 "action": ACTIVITY_LABELS.get(lg.action, lg.action), "entity_type": lg.entity_type, "entity_id": lg.entity_id,
                 "at": iso(lg.created_at)} for lg in logs]
    return {
        "totals": {
            "assets": count(Asset),
            "knowledge_records": count(KnowledgeRecord),
            "approved_procedures": count(Procedure, Procedure.status == "approved"),
            "pending_reviews": count(Procedure, Procedure.status.in_(("pending_review", "needs_changes"))) + count(KnowledgeRecord, KnowledgeRecord.review_status == "pending"),
            "open_conflicts": n_conf,
            "safety_warnings": count(SafetyWarning, SafetyWarning.status == "approved"),
        },
        "coverage": cov,
        "average_coverage": round(sum(c["coverage"] for c in cov) / len(cov)) if cov else 0,
        "alerts": alerts[:10],
        "recent_activity": activity,
    }


def _normalize_q(q: str) -> str:
    return re.sub(r"[^a-z0-9- ]", "", q.lower()).strip()


@router.get("/detail")
def detail(user: User = Depends(require("analytics:read")), db: Session = Depends(get_db)) -> dict:
    org = user.org_id
    records = db.scalars(select(KnowledgeRecord).where(KnowledgeRecord.org_id == org)).unique().all()
    weekly: dict[str, int] = defaultdict(int)
    by_type: Counter[str] = Counter()
    for r in records:
        dt = r.recorded_at or r.created_at
        monday = (dt - timedelta(days=dt.weekday())).date().isoformat()
        weekly[monday] += 1
        by_type[r.source_type] += 1

    fm_counts = db.execute(
        select(FailureMode.name, Asset.asset_tag, func.count(KnowledgeSource.id))
        .join(Asset, Asset.id == FailureMode.asset_id)
        .join(KnowledgeSource, (KnowledgeSource.entity_id == FailureMode.id) & (KnowledgeSource.entity_type == "failure_mode"), isouter=True)
        .where(FailureMode.org_id == org)
        .group_by(FailureMode.name, Asset.asset_tag)
    ).all()
    common = sorted(({"failure_mode": n, "asset_tag": t, "mentions": int(c)} for n, t, c in fm_counts), key=lambda x: -x["mentions"])[:10]

    user_msgs = db.scalars(select(Message).where(Message.org_id == org, Message.role == "user")).all()
    faq = Counter(_normalize_q(m.content) for m in user_msgs)
    asst = db.scalars(select(Message).where(Message.org_id == org, Message.role == "assistant")).all()
    ground = Counter(m.groundedness or "UNKNOWN" for m in asst)
    unresolved = [{"question": (m.answer or {}).get("question", ""), "reason": ((m.answer or {}).get("groundedness") or {}).get("explanation", ""),
                   "at": iso(m.created_at)} for m in sorted(asst, key=lambda m: m.created_at, reverse=True) if m.groundedness == "INSUFFICIENT"][:15]

    contrib = db.execute(select(User.full_name, User.title, func.count(KnowledgeRecord.id)).join(KnowledgeRecord, KnowledgeRecord.contributor_id == User.id)
                         .where(User.org_id == org).group_by(User.full_name, User.title)).all()
    authored = dict(db.execute(select(User.full_name, func.count(Procedure.id)).join(Procedure, Procedure.author_id == User.id)
                               .where(User.org_id == org, Procedure.status == "approved").group_by(User.full_name)).all())
    conflicts = Counter(db.scalars(select(KnowledgeConflict.status).where(KnowledgeConflict.org_id == org)).all())
    ai = db.execute(select(AIRequestLog.kind, AIRequestLog.status, func.count(), func.avg(AIRequestLog.latency_ms))
                    .where(AIRequestLog.org_id == org).group_by(AIRequestLog.kind, AIRequestLog.status)).all()
    return {
        "knowledge_captured": [{"week": k, "records": v} for k, v in sorted(weekly.items())],
        "by_source_type": dict(by_type),
        "coverage": asset_coverage(db, org),
        "most_common_failures": common,
        "frequently_asked": [{"question": q, "count": c} for q, c in faq.most_common(10) if q],
        "unresolved_questions": unresolved,
        "groundedness_distribution": dict(ground),
        "conflicts": dict(conflicts),
        "technician_contribution": [{"name": n, "title": t, "records": int(c), "approved_procedures": int(authored.get(n, 0))} for n, t, c in contrib],
        "ai_requests": [{"kind": k, "status": s, "count": int(c), "avg_latency_ms": int(avg or 0)} for k, s, c, avg in ai],
    }


@router.get("/export.csv")
def export_csv(user: User = Depends(require("reports:export")), db: Session = Depends(get_db)) -> Response:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["ref", "title", "asset", "source_type", "contributor", "recorded_at", "processing_status", "review_status", "ai_version", "synthetic"])
    for r in db.scalars(select(KnowledgeRecord).where(KnowledgeRecord.org_id == user.org_id).order_by(KnowledgeRecord.ref)).unique().all():
        w.writerow([r.ref, r.title, r.asset.asset_tag if r.asset else "", r.source_type, r.contributor.full_name if r.contributor else "",
                    iso(r.recorded_at or r.created_at), r.processing_status, r.review_status, r.ai_version, "yes" if r.is_synthetic else "no"])
    return Response(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": 'attachment; filename="legacymind-knowledge.csv"'})
