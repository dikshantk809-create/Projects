"""LegacyMind API application factory.

Wires middleware (request IDs, security headers, CORS, body-size limit,
structured access logs), error handlers, routers, health/readiness probes,
demo-mode endpoints and (optionally) serves the built frontend so the whole
product can run as a single container.
"""

from __future__ import annotations

import logging
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from sqlalchemy import text
from sqlalchemy.orm import Session

from .api import admin, analytics, assets, assistant, auth, graph, harvest, knowledge, media, reviews
from .config import get_settings
from .db import get_db, get_engine, session_factory
from .deps import audit, rate_limit
from .errors import AppError, error_body, install_error_handlers
from .observability import configure_logging, log_event, new_request_id, request_id_var

logger = logging.getLogger("legacymind.http")

SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "camera=(self), microphone=(self), geolocation=()",
    "Cross-Origin-Opener-Policy": "same-origin",
}
# The SPA is served from the same origin; media is blob/data for recordings & QR codes.
CSP = (
    "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; "
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; "
    "script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
)


def _bootstrap_database() -> None:
    """Create/upgrade the schema and seed the synthetic demo when enabled."""
    from .migrate import upgrade_to_head

    settings = get_settings()
    upgrade_to_head()
    if settings.demo_mode and settings.seed_demo_on_startup:
        from .seed.demo_data import seed_demo

        db = session_factory()()
        try:
            seed_demo(db)
        finally:
            db.close()


@asynccontextmanager
async def lifespan(app: FastAPI):  # pragma: no cover - exercised by the running server
    settings = get_settings()
    configure_logging(settings.log_level, settings.log_json)
    if settings.is_production:
        settings.effective_secret_key  # noqa: B018 - raises early if SECRET_KEY is missing
    try:
        _bootstrap_database()
    except Exception:
        logger.exception("startup_bootstrap_failed")
        raise
    log_event(logger, "startup", env=settings.app_env, version=settings.app_version,
              config_problems=settings.config_problems())
    yield


def create_app(*, bootstrap: bool = True) -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title="LegacyMind API",
        version=settings.app_version,
        description="Industrial tribal-knowledge capture and grounded maintenance intelligence.",
        lifespan=lifespan if bootstrap else None,
        docs_url="/api/docs",
        redoc_url=None,
        openapi_url="/api/openapi.json",
    )

    # ------------------------------------------------------------------ middleware
    max_body = settings.max_upload_mb * 1024 * 1024 + 1024 * 1024  # files + form overhead

    @app.middleware("http")
    async def request_context(request: Request, call_next):  # type: ignore[no-untyped-def]
        rid = request.headers.get("x-request-id") or new_request_id()
        rid = "".join(ch for ch in rid if ch.isalnum() or ch in "-_")[:64] or new_request_id()
        token = request_id_var.set(rid)
        started = time.monotonic()
        try:
            length = request.headers.get("content-length")
            if length and length.isdigit() and int(length) > max_body:
                response: Response = JSONResponse(
                    error_body("payload_too_large", f"Upload exceeds the {settings.max_upload_mb} MB limit.", rid),
                    status_code=413,
                )
            else:
                response = await call_next(request)
        finally:
            request_id_var.reset(token)
        response.headers["X-Request-ID"] = rid
        for k, v in SECURITY_HEADERS.items():
            response.headers.setdefault(k, v)
        if not request.url.path.startswith("/api/docs"):
            response.headers.setdefault("Content-Security-Policy", CSP)
        if settings.cookie_secure:
            response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        if request.url.path.startswith("/api/"):
            response.headers.setdefault("Cache-Control", "no-store")
        elapsed = int((time.monotonic() - started) * 1000)
        if request.url.path not in ("/health", "/ready"):
            log_event(logger, "request", method=request.method, path=request.url.path, status=response.status_code,
                      duration_ms=elapsed, request_id=rid)
        return response

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origin_list,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Content-Type", "Authorization", "X-Request-ID", "X-Requested-With"],
        expose_headers=["X-Request-ID"],
        max_age=600,
    )

    install_error_handlers(app)

    # ------------------------------------------------------------------ routers
    for r in (auth, assets, knowledge, assistant, harvest, reviews, graph, analytics, admin, media):
        app.include_router(r.router, dependencies=[Depends(rate_limit("api"))])

    # ------------------------------------------------------------------ probes
    @app.get("/health", tags=["ops"])
    def health() -> dict[str, Any]:
        """Liveness: the process is up. Never touches dependencies."""
        return {"status": "ok", "service": "legacymind-api", "version": settings.app_version}

    @app.get("/ready", tags=["ops"])
    def ready() -> JSONResponse:
        """Readiness: database reachable, schema migrated, storage writable."""
        from .migrate import current_revision, head_revision
        from .services.storage import get_storage

        checks: dict[str, Any] = {}
        ok = True
        try:
            with get_engine().connect() as conn:
                conn.execute(text("SELECT 1"))
            checks["database"] = "ok"
        except Exception as exc:  # noqa: BLE001
            checks["database"] = f"error: {type(exc).__name__}"
            ok = False
        try:
            cur, head = current_revision(), head_revision()
            checks["migrations"] = "ok" if cur == head else f"pending (db={cur}, head={head})"
            ok = ok and cur == head
        except Exception as exc:  # noqa: BLE001
            checks["migrations"] = f"error: {type(exc).__name__}"
            ok = False
        try:
            checks["storage"] = "ok" if get_storage().healthy() else "not writable"
            ok = ok and checks["storage"] == "ok"
        except Exception as exc:  # noqa: BLE001
            checks["storage"] = f"error: {type(exc).__name__}"
            ok = False
        problems = settings.config_problems()
        # Configuration problems (e.g. missing AI key) degrade features but do not make the service unready:
        # the app falls back to clearly-labelled local modes.
        body = {"status": "ready" if ok else "not_ready", "checks": checks, "config_warnings": problems}
        return JSONResponse(body, status_code=200 if ok else 503)

    # ------------------------------------------------------------------ demo mode
    @app.get("/api/demo", tags=["demo"])
    def demo_info() -> dict[str, Any]:
        from .seed.demo_data import PERSONAS, USERS

        if not settings.demo_mode:
            return {"enabled": False}
        return {
            "enabled": True,
            "label": "Synthetic Demo Data",
            "factory": "NovaTech Manufacturing Plant",
            "personas": [
                {"key": k, "email": PERSONAS[k], "full_name": u["full_name"], "title": u["title"], "role": u["role"]}
                for k, u in zip(PERSONAS, USERS)
            ],
        }

    @app.post("/api/demo/launch", tags=["demo"], dependencies=[Depends(rate_limit("demo", 20))])
    def demo_launch(request: Request, response: Response, persona: str = "supervisor",
                    db: Session = Depends(get_db)) -> dict[str, Any]:
        """One-click demo: ensure the synthetic factory exists and sign in as a demo persona."""
        from sqlalchemy import select

        from .api.auth import session_payload, set_session_cookie
        from .models import User
        from .seed.demo_data import PERSONAS, seed_demo

        if not settings.demo_mode:
            raise AppError("Demo mode is disabled on this deployment.", code="demo_disabled", status_code=404)
        if persona not in PERSONAS:
            raise AppError("Unknown demo persona.", code="invalid_persona", status_code=422)
        seed_demo(db)
        user = db.scalar(select(User).where(User.email == PERSONAS[persona]))
        if user is None:  # pragma: no cover - seed guarantees the user
            raise AppError("Demo user missing; reset the demo.", code="demo_broken", status_code=500)
        audit(db, action="demo.launch", user=user, entity_type="user", entity_id=user.id, request=request,
              details={"persona": persona})
        db.commit()
        token = set_session_cookie(response, user)
        return {**session_payload(user, db), "access_token": token, "token_type": "bearer", "demo": True}

    @app.post("/api/demo/reset", tags=["demo"], dependencies=[Depends(rate_limit("demo-reset", 3))])
    def demo_reset(request: Request, db: Session = Depends(get_db)) -> dict[str, Any]:
        """Rebuild the synthetic factory from scratch (demo deployments only)."""
        from .seed.demo_data import seed_demo

        if not settings.demo_mode:
            raise AppError("Demo mode is disabled on this deployment.", code="demo_disabled", status_code=404)
        org = seed_demo(db, force=True)
        return {"ok": True, "organization_id": org.id}

    # ------------------------------------------------------------------ SPA (single-container mode)
    dist = Path(settings.frontend_dist) if settings.frontend_dist else None
    if dist is not None and (dist / "index.html").exists():
        index = dist / "index.html"

        @app.get("/{full_path:path}", include_in_schema=False)
        def spa(full_path: str) -> Response:
            if full_path.startswith("api/"):
                return JSONResponse(error_body("not_found", "Not found.", new_request_id()), status_code=404)
            candidate = (dist / full_path).resolve()
            if full_path and dist.resolve() in candidate.parents and candidate.is_file():
                cache = "public, max-age=31536000, immutable" if "/assets/" in f"/{full_path}" else "no-cache"
                return FileResponse(candidate, headers={"Cache-Control": cache})
            return FileResponse(index, headers={"Cache-Control": "no-cache"})

    return app


app = create_app()
