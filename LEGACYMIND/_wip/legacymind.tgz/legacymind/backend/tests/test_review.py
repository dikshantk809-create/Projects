"""Human-in-the-loop: approval gates retrieval, edits keep provenance, conflicts, RBAC."""

import time

from app.ai.answer import answer_question
from app.db import session_factory


def _capture(client, tag, text, title="note"):
    client.post("/api/assets", json={"asset_tag": tag, "name": f"Machine {tag}", "criticality": "medium"})
    r = client.post("/api/knowledge/records", data={"title": title, "source_type": "text", "notes": text})
    assert r.status_code == 201, r.text
    for _ in range(50):
        rec = client.get(f"/api/knowledge/records/{r.json()['ref']}").json()
        if rec["processing_status"] == "processed":
            return rec
        time.sleep(0.1)
    raise AssertionError(rec["processing_status"])


def _org_id(client):
    return client.get("/api/auth/me").json()["organization"]["id"]


def test_approval_gates_assistant(client, fresh_org):
    rec = _capture(client, "FN-1", "When fan FN-1 is vibrating at high speed, first check the fan blades for build-up. Then check the mounting bolts.")
    org = _org_id(client)
    db = session_factory()()
    try:
        before = answer_question(db, org, "FN-1 is vibrating at high speed")
        assert before["status"] == "insufficient", "unapproved knowledge must not be used"
    finally:
        db.close()
    pid = rec["procedures"][0]["id"]
    assert client.post(f"/api/reviews/procedures/{pid}", json={"decision": "approve", "comment": "ok"}).status_code == 200
    db = session_factory()()
    try:
        after = answer_question(db, org, "FN-1 is vibrating at high speed")
        assert after["status"] == "answered"
        assert "blades" in after["steps"][0]["text"].lower()
    finally:
        db.close()
    assert client.get(f"/api/knowledge/records/{rec['id']}").json()["review_status"] == "approved"


def test_reject_requires_comment_and_edit_keeps_provenance(client, fresh_org):
    rec = _capture(client, "GB-1", "If gearbox GB-1 is overheating, check the oil level first. Then inspect the cooler for blockage.")
    pid = rec["procedures"][0]["id"]
    r = client.post(f"/api/reviews/procedures/{pid}", json={"decision": "reject", "comment": ""})
    assert r.status_code == 422 and r.json()["error"]["code"] == "comment_required"
    orig = rec["procedures"][0]["steps"]
    edits = {"steps": [{"text": orig[0]["text"]}, {"text": "Measure gearbox temperature with an infrared thermometer"}], "risk_level": "high"}
    p = client.post(f"/api/reviews/procedures/{pid}", json={"decision": "approve", "comment": "edited", "edits": edits}).json()
    assert p["version"] == 2 and p["risk_level"] == "high" and p["requires_supervisor"]
    assert p["steps"][0]["source"]["quote"] == orig[0]["source"]["quote"], "unchanged step keeps its evidence"
    assert p["steps"][1]["source"]["edited_by"] == "Test Admin", "new step is marked as supervisor-edited"
    hist = client.get("/api/reviews/queue").json()["recent_reviews"]
    assert hist[0]["decision"] == "approved"


def test_conflict_detection_and_resolution(client, fresh_org):
    a = _capture(client, "CV-8", "When the CV-8 belt is mistracking, check the tail pulley alignment first. Then check the belt tension.", "A")
    client.post(f"/api/reviews/procedures/{a['procedures'][0]['id']}", json={"decision": "approve", "comment": "ok"})
    b = _capture(client, "CV-8", "For belt mistracking on CV-8, check the idler rollers first for seized bearings. Then clean the return idlers.", "B")
    q = client.get("/api/reviews/queue").json()
    assert len(q["conflicts"]) == 1
    c = q["conflicts"][0]
    assert c["status"] == "open" and "different first checks" in c["description"]
    org = _org_id(client)
    db = session_factory()()
    try:
        ans = answer_question(db, org, "CV-8 belt is mistracking")
        assert ans["conflicts"] and ans["escalation"]["required"]
    finally:
        db.close()
    bad = client.post(f"/api/reviews/conflicts/{c['id']}/resolve", json={"preferred_procedure_id": "nope", "resolution": "x y z"})
    assert bad.status_code == 422
    winner = b["procedures"][0]["id"]
    res = client.post(f"/api/reviews/conflicts/{c['id']}/resolve", json={"preferred_procedure_id": winner, "resolution": "Idlers first per OEM."})
    assert res.status_code == 200 and res.json()["status"] == "resolved"
    statuses = {p["id"]: p["status"] for p in client.get("/api/knowledge/procedures").json()["items"]}
    assert statuses[winner] == "approved" and statuses[a["procedures"][0]["id"]] == "superseded"
    assert client.post(f"/api/reviews/conflicts/{c['id']}/resolve", json={"resolution": "again"}).status_code == 409


def test_technician_cannot_review(as_senior):
    q = as_senior.get("/api/reviews/queue")
    assert q.status_code == 403
