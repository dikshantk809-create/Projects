from app.security import (
    create_session_token, decode_session_token, has_permission, hash_password, password_problems, verify_password,
)


def test_password_hash_roundtrip_and_salt():
    h1, h2 = hash_password("Correct-horse-1"), hash_password("Correct-horse-1")
    assert h1 != h2, "each hash must use a fresh salt"
    assert h1.startswith("scrypt$")
    assert verify_password("Correct-horse-1", h1)
    assert not verify_password("wrong-password-1", h1)


def test_verify_rejects_malformed_hashes():
    assert not verify_password("x", "")
    assert not verify_password("x", "bcrypt$abc")
    assert not verify_password("x", "scrypt$1$2$3$notbase64$@@")


def test_password_policy():
    assert password_problems("short1") == ["at least 10 characters"]
    assert "a number" in password_problems("onlyletterslong")
    assert password_problems("Str0ng-enough") == []


def test_session_token_roundtrip_and_tamper():
    tok = create_session_token("u1", "o1", "technician", 3)
    claims = decode_session_token(tok)
    assert claims and claims["sub"] == "u1" and claims["tv"] == 3
    assert decode_session_token(tok[:-2] + ("A" if tok[-1] != "A" else "B") + tok[-1]) is None
    assert decode_session_token("garbage") is None


def test_rbac_matrix():
    assert has_permission("admin", "users:manage")
    assert has_permission("supervisor", "knowledge:review")
    assert not has_permission("technician", "knowledge:review")
    assert not has_permission("junior_technician", "knowledge:capture")
    assert has_permission("junior_technician", "assistant:use")
    assert not has_permission("nobody", "assets:read")
