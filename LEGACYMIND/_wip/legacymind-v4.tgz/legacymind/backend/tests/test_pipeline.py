"""AI processing pipeline: extraction quality, hallucination guard, traceability."""

import json
import time

from app.ai import extraction as ex_mod
from app.ai.extraction import LLMExtractor, RuleExtractor, extract_knowledge

P103 = [
    {"start": 100, "end": 134, "text": "Before any inspection on P-103, stop the pump and apply lockout/tagout, because this is a high-pressure hydraulic system. Never loosen a fitting while the accumulator is still charged; bleed off the pressure first."},
    {"start": 134, "end": 168, "text": "Whenever Pump P-103 produces a grinding sound during startup, first inspect Valve V-03. If pressure is below the normal range, check the valve for blockage."},
    {"start": 168, "end": 202, "text": "New technicians usually replace the pump when they hear that noise, but that is unnecessary. Clean the valve and the suction strainer, then restart the pump."},
]


def test_rule_extractor_p103():
    ex = RuleExtractor().extract(P103, {"P-103"}, {"P-103": "Hydraulic Pump"})
    assert ex.asset_tags == ["P-103"]
    assert "grinding sound during startup" in [s["name"] for s in ex.symptoms]
    assert "valve blockage" in [f["name"] for f in ex.failure_modes]
    assert any("V-03" in c["name"] for c in ex.components)
    assert ex.misconceptions, "should capture 'juniors replace the pump - unnecessary'"
    steps = [s["text"] for s in ex.procedures[0]["steps"]]
    assert any("lockout/tagout" in s for s in steps)
    assert any(s.startswith("Inspect Valve V-03") for s in steps)
    assert not any("replace the pump" in s.lower() for s in steps), "misconceptions must not become steps"
    inspect = next(s for s in ex.procedures[0]["steps"] if "V-03" in s["text"])
    assert (inspect["start"], inspect["end"]) == (134, 168), "steps inherit source timestamps"
    assert any(s["severity"] == "danger" for s in ex.safety)


def test_rule_extractor_ignores_questions():
    ex = RuleExtractor().extract([{"start": 0, "end": 5, "text": "What symptoms normally indicate valve blockage?"}], set(), {})
    assert not ex.failure_modes and not ex.procedures


def test_every_rule_item_is_a_literal_span():
    ex = RuleExtractor().extract(P103, {"P-103"}, {})
    text = " ".join(s["text"] for s in P103)
    for group in (ex.symptoms, ex.failure_modes, ex.components, ex.safety):
        for item in group:
            assert item["quote"] in text


def test_llm_extractor_discards_unverifiable_items(monkeypatch):
    fake = {
        "asset_tags": ["P-103", "ZZ-999"],
        "symptoms": [{"name": "grinding sound during startup", "quote": "produces a grinding sound during startup"},
                     {"name": "smoke from motor", "quote": "the motor was smoking heavily"}],  # hallucinated
        "procedures": [{"title": "Grinding", "symptoms": ["grinding"], "steps": [
            {"text": "Inspect Valve V-03", "component": "V-03", "quote": "first inspect Valve V-03"},
            {"text": "Replace the motor bearings", "component": "", "quote": "first inspect Valve V-03"},  # quote does not support text
            {"text": "Call the OEM hotline", "component": "", "quote": "call the manufacturer"},  # quote not in transcript
        ]}],
        "safety": [{"text": "Apply lockout/tagout", "quote": "apply lockout/tagout"}],
        "summary": "s",
    }
    monkeypatch.setattr(ex_mod, "complete_json", lambda *a, **k: fake)
    res = LLMExtractor().extract(P103, {"P-103"}, {"P-103": "Hydraulic Pump"})
    assert res is not None
    assert res.asset_tags == ["P-103"], "unknown asset tags are dropped"
    assert [s["name"] for s in res.symptoms] == ["grinding sound during startup"]
    assert [s["text"] for s in res.procedures[0]["steps"]] == ["Inspect Valve V-03"]
    assert res.dropped_unverified == 3
    assert res.procedures[0]["steps"][0]["start"] == 134


def test_extract_knowledge_falls_back_to_rules_when_llm_fails(monkeypatch):
    monkeypatch.setattr(ex_mod, "llm_configured", lambda: True)
    monkeypatch.setattr(ex_mod, "complete_json", lambda *a, **k: None)
    assert extract_knowledge(P103, {"P-103"}).method == "rules-v1"


def _wait_processed(client, ref, timeout=20):
    deadline = time.time() + timeout
    while time.time() < deadline:
        r = client.get(f"/api/knowledge/records/{ref}").json()
        if r["processing_status"] not in ("queued", "processing"):
            return r
        time.sleep(0.2)
    raise AssertionError("record not processed in time")


def test_capture_text_record_end_to_end(client, fresh_org):
    aid = client.post("/api/assets", json={"asset_tag": "P-7", "name": "Feed Pump"}).json()["id"]
    notes = ("Whenever pump P-7 makes a knocking noise at full load, first check the coupling alignment with a dial indicator. "
             "If the coupling is misaligned, realign the motor. Always isolate the motor and apply lockout/tagout before touching the coupling.")
    r = client.post("/api/knowledge/records", data={"title": "P-7 knocking", "source_type": "text", "notes": notes})
    assert r.status_code == 201
    ref = r.json()["ref"]
    rec = _wait_processed(client, ref)
    assert rec["processing_status"] == "processed"
    assert rec["asset"]["id"] == aid, "machine mapping from the text"
    stages = {s["name"]: s["status"] for s in rec["processing_stages"]}
    assert stages["knowledge_structuring"] == "done" and stages["indexing"] == "done"
    assert rec["procedures"] and rec["procedures"][0]["status"] == "pending_review"
    assert rec["review_status"] == "pending"
    proc = client.get(f"/api/knowledge/procedures/{rec['procedures'][0]['id']}").json()
    assert proc["traceability"], "procedure must carry traceability to its source"
    assert all(t["record_id"] == rec["id"] and t["ai_version"] for t in proc["traceability"])


def test_browser_transcript_segments_are_used(client, fresh_org):
    segs = [{"start": 0, "end": 6, "text": "Conveyor CV-9 belt is slipping."}, {"start": 6, "end": 14, "text": "When the belt is slipping, check the belt tension first."}]
    client.post("/api/assets", json={"asset_tag": "CV-9", "name": "Conveyor"})
    r = client.post("/api/knowledge/records", data={"title": "CV-9 slip", "source_type": "audio", "segments": json.dumps(segs), "transcript_source": "browser_speech"},
                    files=[("files", ("a.webm", b"\x1a\x45\xdf\xa3" + b"\x00" * 64, "audio/webm"))])
    assert r.status_code == 201, r.text
    rec = _wait_processed(client, r.json()["ref"])
    assert rec["transcript_source"] == "browser_speech"
    assert rec["recordings"][0]["has_file"]
    step = rec["procedures"][0]["steps"][0]
    assert step["source"]["start"] == 6


def test_recording_without_transcript_needs_transcript(client, fresh_org):
    r = client.post("/api/knowledge/records", data={"title": "silent", "source_type": "audio"},
                    files=[("files", ("a.webm", b"\x1a\x45\xdf\xa3" + b"\x00" * 64, "audio/webm"))])
    rec = _wait_processed(client, r.json()["ref"])
    assert rec["processing_status"] == "needs_transcript", "no STT provider -> never invent a transcript"
    fix = client.put(f"/api/knowledge/records/{rec['id']}/transcript", json={"transcript": "If the pump is overheating, check the oil level first."})
    assert fix.status_code == 200
    assert _wait_processed(client, rec["ref"])["processing_status"] == "processed"


def test_capture_validation(client, fresh_org):
    assert client.post("/api/knowledge/records", data={"title": "empty", "source_type": "text"}).json()["error"]["code"] == "empty_record"
    assert client.post("/api/knowledge/records", data={"title": "bad", "source_type": "hologram", "notes": "x y z"}).status_code == 422
    bad_segments = client.post("/api/knowledge/records", data={"title": "bad", "source_type": "audio", "segments": "{not json"})
    assert bad_segments.json()["error"]["code"] == "invalid_segments"
