import { Bot, Hand, History, Mic, MicOff, Plus, SendHorizonal } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { AnswerCard } from "../components/AnswerCard";
import { ErrorState, Panel } from "../components/ui";
import { ApiError, api } from "../lib/api";
import { useAuth } from "../lib/auth";
import { cls, timeAgo } from "../lib/format";
import { useApi } from "../lib/hooks";
import { LiveTranscriber, speechRecognitionSupported } from "../lib/recorder";
import { answerToSpeech, speak, speechSupported, stopSpeaking } from "../lib/speech";
import type { Asset, ChatMessage } from "../lib/types";

const SUGGESTIONS = [
  "Pump P-103 is making a grinding sound during startup. What should I check?",
  "CV-04 belt is mistracking, what should I check first?",
  "HP-01 ram is drifting down during the hold",
  "CP-02 compressor is short cycling",
  "How do I recalibrate the vision sensor on packaging line PK-09?",
];

export default function Assistant() {
  const [params, setParams] = useSearchParams();
  const { session } = useAuth();
  const assets = useApi<{ items: Asset[] }>("/api/assets");
  const convs = useApi<{ items: { id: string; title: string; asset_id: string | null; created_at: string }[] }>("/api/assistant/conversations");
  const [assetId, setAssetId] = useState(params.get("asset") ?? "");
  const [convId, setConvId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);
  const [listening, setListening] = useState(false);
  const [handsFree, setHandsFree] = useState(false);
  const handsFreeRef = useRef(false);
  handsFreeRef.current = handsFree;
  const silenceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const sttRef = useRef<LiveTranscriber | null>(null);
  const endRef = useRef<HTMLDivElement>(null);
  const asked = useRef<string | null>(null);

  useEffect(() => endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }), [messages, busy]);

  const ask = async (question: string) => {
    const q = question.trim();
    if (q.length < 3 || busy) return;
    setBusy(true);
    setError(null);
    setInput("");
    const tmp: ChatMessage = { id: `tmp-${Date.now()}`, role: "user", content: q, answer: null, groundedness: null, escalated: false, created_at: new Date().toISOString() };
    setMessages((m) => [...m, tmp]);
    try {
      const res = await api.post<{ conversation_id: string; message: ChatMessage }>("/api/assistant/ask", { question: q, conversation_id: convId, asset_id: assetId || null }, { timeout: 90_000 });
      setConvId(res.conversation_id);
      setMessages((m) => [...m, res.message]);
      if (handsFreeRef.current && res.message.answer) speak(answerToSpeech(res.message.answer));
      void convs.reload();
    } catch (e) {
      setError(e as ApiError);
      setMessages((m) => m.filter((x) => x.id !== tmp.id));
      setInput(q);
    } finally {
      setBusy(false);
    }
  };

  // deep links: /app/assistant?q=... (demo tour, QR pages)
  useEffect(() => {
    const q = params.get("q");
    if (q && asked.current !== q) {
      asked.current = q;
      void ask(q);
      const p = new URLSearchParams(params);
      p.delete("q");
      setParams(p, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params]);

  const openConv = async (id: string) => {
    setError(null);
    try {
      const c = await api.get<{ id: string; asset_id: string | null; messages: ChatMessage[] }>(`/api/assistant/conversations/${id}`);
      setConvId(c.id);
      setMessages(c.messages);
      setAssetId(c.asset_id ?? "");
    } catch (e) {
      setError(e as ApiError);
    }
  };

  const newChat = () => {
    setConvId(null);
    setMessages([]);
    setError(null);
  };

  const askRef = useRef(ask);
  askRef.current = ask;

  const stopListening = () => {
    if (silenceTimer.current) clearTimeout(silenceTimer.current);
    sttRef.current?.stop();
    sttRef.current = null;
    setListening(false);
  };

  const toggleVoice = () => {
    if (listening) {
      stopListening();
      return;
    }
    stopSpeaking();
    const stt = new LiveTranscriber("en-IN");
    stt.onUpdate = (finals, interim) => {
      const text = [...finals.map((s) => s.text), interim].join(" ").trim();
      setInput(text);
      // Hands-free: when the technician stops talking for ~1.8 s, send the question automatically.
      if (handsFreeRef.current && finals.length && !interim) {
        if (silenceTimer.current) clearTimeout(silenceTimer.current);
        silenceTimer.current = setTimeout(() => {
          stopListening();
          void askRef.current(text);
        }, 1800);
      }
    };
    stt.onError = () => setListening(false);
    if (stt.start(performance.now())) {
      sttRef.current = stt;
      setListening(true);
    }
  };

  useEffect(() => () => { stopSpeaking(); sttRef.current?.stop(); }, []);

  const asset = assets.data?.items.find((a) => a.id === assetId);
  return (
    <div className="split" style={{ gridTemplateColumns: "minmax(0, 2.3fr) minmax(260px, 1fr)" }}>
      <div className="chat">
        <div className="page-head" style={{ marginBottom: 8 }}>
          <div>
            <div className="eyebrow">Grounded maintenance assistant</div>
            <h1>Ask LegacyMind</h1>
            <p>Answers come only from supervisor-approved plant knowledge — with the technician, recording and timestamp behind every step.</p>
          </div>
        </div>
        <div className="chat-scroll">
          {messages.length === 0 && !busy && (
            <Panel>
              <div className="stack">
                <div className="row"><Bot style={{ color: "var(--accent)" }} /><strong>What’s happening on the machine?</strong></div>
                <p className="small muted">Describe the symptom and name the machine if you can (e.g. “P-103”). If LegacyMind has no verified knowledge, it will tell you and point you to your supervisor.</p>
                <div className="suggest">{SUGGESTIONS.map((s) => <button key={s} onClick={() => void ask(s)}>{s}</button>)}</div>
              </div>
            </Panel>
          )}
          {messages.map((m) =>
            m.role === "user" ? <div key={m.id} className="msg-user rise">{m.content}</div> : m.answer ? <AnswerCard key={m.id} a={m.answer} messageId={m.id} feedback={m.feedback} /> : null,
          )}
          {busy && (
            <div className="panel rise" style={{ padding: 16 }}>
              <div className="row small muted"><div className="spinner" />Retrieving approved knowledge · vector + keyword + graph → verifying citations…</div>
            </div>
          )}
          {error && <ErrorState error={error} />}
          <div ref={endRef} />
        </div>
        <div className="composer">
          <form className="composer-box" onSubmit={(e) => { e.preventDefault(); void ask(input); }}>
            <textarea rows={1} value={input} onChange={(e) => setInput(e.target.value)} placeholder={asset ? `Ask about ${asset.asset_tag} ${asset.name}…` : "e.g. Pump P-103 is making a grinding sound during startup. What should I check?"}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void ask(input); } }} aria-label="Question" maxLength={1000} />
            {speechRecognitionSupported() && (
              <button type="button" className={cls("btn icon", listening && "rec")} onClick={toggleVoice} aria-label={listening ? "Stop voice input" : "Ask by voice"} title="Ask by voice">{listening ? <MicOff /> : <Mic />}</button>
            )}
            <button className="btn primary icon" type="submit" disabled={busy || input.trim().length < 3} aria-label="Send"><SendHorizonal /></button>
          </form>
          <div className="row mt-8" style={{ flexWrap: "wrap" }}>
            {speechRecognitionSupported() && speechSupported() && (
              <button type="button" className={cls("btn sm", handsFree ? "primary" : "ghost")} onClick={() => { setHandsFree(!handsFree); if (handsFree) stopSpeaking(); }}
                aria-pressed={handsFree} title="Speak your question; the answer is read aloud — for gloved hands on the shop floor">
                <Hand />{handsFree ? "Hands-free ON" : "Hands-free mode"}
              </button>
            )}
            <span className="tiny faint">LegacyMind supports, but never replaces, your plant’s approved safety procedures and supervisor sign-off.</span>
          </div>
        </div>
      </div>

      <div className="stack" style={{ position: "sticky", top: 72 }}>
        <Panel title="Machine context" sub="Scope answers to one asset (optional)">
          <select className="select" value={assetId} onChange={(e) => setAssetId(e.target.value)} aria-label="Machine context">
            <option value="">Detect from question</option>
            {assets.data?.items.map((a) => <option key={a.id} value={a.id}>{a.asset_tag} · {a.name}</option>)}
          </select>
          {asset && <div className="small muted mt-8">{asset.location} · {asset.status}</div>}
        </Panel>
        <Panel title={<span className="row"><History size={15} />Conversations</span>} actions={<button className="btn sm ghost" onClick={newChat}><Plus />New</button>} tight>
          {!convs.data?.items.length ? <div className="panel-body small faint">No conversations yet.</div> : (
            <div style={{ maxHeight: 420, overflow: "auto" }}>
              {convs.data.items.map((c) => (
                <button key={c.id} className="list-item" onClick={() => void openConv(c.id)}
                  style={{ width: "100%", background: c.id === convId ? "var(--panel-3)" : "transparent", border: 0, borderBottom: "1px solid var(--line)", color: "inherit", textAlign: "left", cursor: "pointer" }}>
                  <div style={{ minWidth: 0 }}><div className="small ellipsis">{c.title}</div><div className="tiny faint">{timeAgo(c.created_at)}</div></div>
                </button>
              ))}
            </div>
          )}
        </Panel>
        {session?.user.role === "junior_technician" && (
          <div className="notice"><Bot /><span className="small">You see supervisor-approved knowledge only. If an answer says “Ask supervisor”, contact your maintenance supervisor before proceeding.</span></div>
        )}
      </div>
    </div>
  );
}
