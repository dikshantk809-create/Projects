import {
  Activity, BookOpen, Bot, ClipboardCheck, Cpu, Factory, LayoutDashboard, LogOut, Menu, Mic, Network, Search, Settings, Sparkles, WifiOff,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "../lib/auth";
import { ROLE_LABEL, cls, initials } from "../lib/format";
import { useApi, useOnline } from "../lib/hooks";
import type { SystemStatus } from "../lib/types";
import { CommandPalette } from "./CommandPalette";
import { Brand } from "./Logo";

interface NavItem { to: string; label: string; icon: ReactNode; perm?: string; count?: number }

export function AppLayout() {
  const { session, can, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const loc = useLocation();
  const online = useOnline();
  const sys = useApi<SystemStatus>("/api/admin/system");
  const stats = useApi<{ pending_procedures: number; open_conflicts: number }>(can("knowledge:review") ? "/api/reviews/stats" : null);
  const [paletteOpen, setPaletteOpen] = useState(false);
  useEffect(() => setOpen(false), [loc.pathname]);
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPaletteOpen((o) => !o);
      }
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, []);
  useEffect(() => {
    if (can("knowledge:review")) void stats.reload();
    // refresh review badge when navigating
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loc.pathname]);

  if (!session) return null;
  const reviewCount = (stats.data?.pending_procedures ?? 0) + (stats.data?.open_conflicts ?? 0);

  const groups: { label: string; items: NavItem[] }[] = [
    {
      label: "Operate",
      items: [
        { to: "/app", label: "Dashboard", icon: <LayoutDashboard /> },
        { to: "/app/assistant", label: "AI Assistant", icon: <Bot />, perm: "assistant:use" },
        { to: "/app/assets", label: "Assets", icon: <Factory />, perm: "assets:read" },
        { to: "/app/library", label: "Knowledge Library", icon: <BookOpen />, perm: "knowledge:read" },
      ],
    },
    {
      label: "Capture",
      items: [
        { to: "/app/capture", label: "Knowledge Capture", icon: <Mic />, perm: "knowledge:capture" },
        { to: "/app/harvest", label: "Knowledge Harvest", icon: <Sparkles />, perm: "harvest:run" },
      ],
    },
    {
      label: "Govern",
      items: [
        { to: "/app/review", label: "Supervisor Review", icon: <ClipboardCheck />, perm: "knowledge:review", count: reviewCount },
        { to: "/app/graph", label: "Knowledge Graph", icon: <Network />, perm: "knowledge:read" },
        { to: "/app/analytics", label: "Analytics", icon: <Activity />, perm: "analytics:read" },
        { to: "/app/admin", label: "Administration", icon: <Settings />, perm: "users:manage" },
      ],
    },
  ];

  const current = groups.flatMap((g) => g.items).filter((i) => (i.to === "/app" ? loc.pathname === "/app" : loc.pathname.startsWith(i.to)))[0];

  return (
    <div className="shell">
      <aside className={cls("sidebar", open && "open")} aria-label="Main navigation">
        <Link to="/app" className="brand"><Brand /></Link>
        {groups.map((g) => {
          const items = g.items.filter((i) => !i.perm || can(i.perm));
          if (!items.length) return null;
          return (
            <nav className="nav-group" key={g.label}>
              <div className="nav-label">{g.label}</div>
              {items.map((i) => (
                <NavLink key={i.to} to={i.to} end={i.to === "/app"} className={({ isActive }) => cls("nav-link", isActive && "active")}>
                  {i.icon}
                  <span>{i.label}</span>
                  {!!i.count && <span className="nav-count">{i.count}</span>}
                </NavLink>
              ))}
            </nav>
          );
        })}
        <div className="sidebar-foot">
          <div className="user-chip">
            <div className="avatar">{initials(session.user.full_name)}</div>
            <div style={{ minWidth: 0, flex: 1 }}>
              <div className="ellipsis" style={{ fontWeight: 500 }}>{session.user.full_name}</div>
              <div className="tiny faint ellipsis">{ROLE_LABEL[session.user.role]}</div>
            </div>
            <button className="btn ghost icon sm" onClick={() => void logout()} aria-label="Sign out" title="Sign out"><LogOut /></button>
          </div>
        </div>
      </aside>
      {open && <div className="modal-back" style={{ zIndex: 55, background: "rgba(0,0,0,.4)" }} onClick={() => setOpen(false)} />}
      <div className="main">
        {session.organization?.is_demo && (
          <div className="synthetic-bar">SYNTHETIC DEMO DATA — NovaTech Manufacturing Plant is fictional. No real industrial records are shown.</div>
        )}
        <header className="topbar">
          <button className="btn ghost icon menu-btn" onClick={() => setOpen(true)} aria-label="Open navigation"><Menu /></button>
          <div className="crumbs">
            <span className="ellipsis">{session.organization?.name?.replace(" (Synthetic Demo)", "")}</span>
            <span>/</span>
            <b>{current?.label ?? "LegacyMind"}</b>
          </div>
          <div className="topbar-right">
            {can("knowledge:read") && (
              <button className="btn sm" onClick={() => setPaletteOpen(true)} aria-label="Search (Ctrl+K)" title="Search (Ctrl+K)">
                <Search /><span className="hide-sm">Search</span><span className="mono tiny faint hide-sm">Ctrl K</span>
              </button>
            )}
            {!online && <span className="badge danger"><WifiOff />Offline</span>}
            {sys.data && (
              <span className={cls("badge", sys.data.llm.configured ? "accent" : "info")} title={`Embeddings: ${sys.data.embeddings.provider} · Vector: ${sys.data.vector_backend}`}>
                <Cpu />
                {sys.data.llm.configured ? `AI: ${sys.data.llm.provider}` : "AI: local rules mode"}
              </span>
            )}
          </div>
        </header>
        <main className="content" id="main">
          <Outlet />
        </main>
        <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} />
      </div>
    </div>
  );
}
