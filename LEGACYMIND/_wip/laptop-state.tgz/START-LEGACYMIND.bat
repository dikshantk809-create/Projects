@echo off
setlocal EnableExtensions EnableDelayedExpansion
title LegacyMind - Launcher
cd /d "%~dp0"
if not exist "%~dp0logs" mkdir "%~dp0logs"

echo.
echo  ==============================================================
echo    LEGACYMIND  -  Industrial Knowledge Intelligence
echo    One-click launcher (first run installs everything)
echo  ==============================================================
echo.

rem ---------------------------------------------------------------
rem 1. Find Python 3.10 - 3.13
rem ---------------------------------------------------------------
set "PY="
for %%V in (3.12 3.11 3.13 3.10) do (
  if not defined PY (
    py -%%V -c "import sys" >nul 2>&1 && set "PY=py -%%V"
  )
)
if not defined PY (
  python -c "import sys; sys.exit(0 if (3,10) <= sys.version_info[:2] <= (3,13) else 1)" >nul 2>&1 && set "PY=python"
)
if not defined PY (
  echo [ERROR] Python 3.10 - 3.13 not found.
  echo         Install Python 3.12 from https://www.python.org/downloads/
  echo         and tick "Add python.exe to PATH" during setup. Then run this file again.
  pause & exit /b 1
)
echo [OK] Python: %PY%

rem ---------------------------------------------------------------
rem 2. Find Node.js 18+
rem ---------------------------------------------------------------
where node >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Node.js not found. Install the LTS version from https://nodejs.org/ and run this file again.
  pause & exit /b 1
)
for /f "tokens=1 delims=." %%a in ('node -v') do set "NODEMAJOR=%%a"
set "NODEMAJOR=%NODEMAJOR:v=%"
if %NODEMAJOR% LSS 18 (
  echo [ERROR] Node.js 18 or newer is required. Found:
  node -v
  pause & exit /b 1
)
echo [OK] Node.js:
node -v

rem ---------------------------------------------------------------
rem 3. Backend: virtual environment + packages (only when needed)
rem ---------------------------------------------------------------
cd /d "%~dp0backend"
if not exist ".venv\Scripts\python.exe" (
  echo.
  echo [SETUP] Creating Python virtual environment...
  %PY% -m venv .venv
  if errorlevel 1 ( echo [ERROR] Could not create the virtual environment. & pause & exit /b 1 )
)
set "NEEDPIP=1"
if exist ".venv\.req-installed" (
  fc /b requirements.txt ".venv\.req-installed" >nul 2>&1 && set "NEEDPIP=0"
)
if "%NEEDPIP%"=="1" (
  echo.
  echo [SETUP] Installing backend packages ^(first run takes a few minutes^)...
  ".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt > "%~dp0logs\setup-backend.log" 2>&1
  if errorlevel 1 ( type "%~dp0logs\setup-backend.log" & echo [ERROR] Backend package installation failed. See logs\setup-backend.log & pause & exit /b 1 )
  copy /y requirements.txt ".venv\.req-installed" >nul
)
echo [OK] Backend ready

rem ---------------------------------------------------------------
rem 4. Frontend packages (only when needed)
rem ---------------------------------------------------------------
cd /d "%~dp0frontend"
if not exist "node_modules\.bin\vite.cmd" (
  echo.
  echo [SETUP] Installing frontend packages ^(first run takes a few minutes^)...
  call npm install --no-audit --no-fund > "%~dp0logs\setup-frontend.log" 2>&1
  if errorlevel 1 ( type "%~dp0logs\setup-frontend.log" & echo [ERROR] Frontend package installation failed. See logs\setup-frontend.log & pause & exit /b 1 )
)
echo [OK] Frontend ready

rem ---------------------------------------------------------------
rem 5. Start the API (SQLite database, synthetic demo plant)
rem    Optional AI keys: create backend\.env  (see .env.example)
rem ---------------------------------------------------------------
rem Stop an older LegacyMind still running on ports 8000/5173 (clean restart)
for %%P in (8000 5173) do (
  for /f "tokens=5" %%I in ('netstat -ano ^| findstr /r /c:":%%P .*LISTENING"') do (
    echo [INFO] Stopping previous process on port %%P ^(PID %%I^)
    taskkill /PID %%I /F >nul 2>&1
  )
)
timeout /t 1 /nobreak >nul
if exist "%~dp0logs\api.log" del /q "%~dp0logs\api.log" >nul 2>&1

cd /d "%~dp0backend"
echo.
echo [START] LegacyMind API on http://127.0.0.1:8000
start "LegacyMind API (close this window to stop)" cmd /k "set DATABASE_URL=sqlite:///./legacymind.db&& set DEMO_MODE=true&& set SEED_DEMO_ON_STARTUP=true&& set LOG_JSON=false&& set LOG_FILE=..\logs\api.log&& set PYTHONUNBUFFERED=1&& .venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload --reload-dir app"

echo [WAIT] Waiting for the API (first start builds the demo plant, ~30-60 s)...
set /a TRIES=0
:waitapi
set /a TRIES+=1
curl -s -o nul -f http://127.0.0.1:8000/ready >nul 2>&1
if not errorlevel 1 goto apiready
if %TRIES% GEQ 90 (
  echo [ERROR] The API did not start. See the "LegacyMind API" window or logs\api.log
  pause & exit /b 1
)
timeout /t 2 /nobreak >nul
goto waitapi
:apiready
echo [OK] API is ready

rem ---------------------------------------------------------------
rem 6. Start the web UI and open the browser
rem ---------------------------------------------------------------
cd /d "%~dp0frontend"
echo [START] LegacyMind web UI on http://localhost:5173
start "LegacyMind Web (close this window to stop)" powershell -NoExit -ExecutionPolicy Bypass -Command "npm run dev -- --host 127.0.0.1 --port 5173 --strictPort 2>&1 | Tee-Object -FilePath '..\logs\web.log'"
timeout /t 5 /nobreak >nul
start "" "http://127.0.0.1:5173/"

echo.
echo  ==============================================================
echo    LegacyMind is running:  http://127.0.0.1:5173
echo    API docs:               http://127.0.0.1:8000/api/docs
echo    Click "Launch Demo" to explore the synthetic NovaTech plant.
echo    Demo password: LegacyMind-Demo-2026
echo    To stop: close the two "LegacyMind" windows.
echo  ==============================================================
echo.
pause
