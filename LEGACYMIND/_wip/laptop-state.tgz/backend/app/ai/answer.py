"""Grounded answer generation with traceable evidence.

Design rules (enforced in code, not just in prompts):

1. Only approved knowledge is retrieved (see retrieval.py).
2. A question about a named plant asset is answered only from that asset's
   knowledge. No evidence -> an explicit "insufficient" answer + escalation.
3. Steps come from approved procedure cards (extractive mode) or from an LLM
   whose every step must cite evidence IDs *and* be lexically supported by the
   cited text; unsupported steps are removed and counted.
4. Safety warnings come from the database, never from the LLM, so they cannot
   be hallucinated away or invented.
5. Open conflicts on the chosen procedure are surfaced and force escalation.
"""

from __future__ import annotations

import re
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..models import Asset, KnowledgeRecord, Procedure, Recording, SafetyWarning, User
from .conflicts import open_conflicts_for_procedures
from .extraction import SYMPTOM_PATTERNS
from .llm import complete_json, llm_configured, provider_label
from .retrieval import Hit, RetrievalResult, retrieve
from .text import token_overlap, tokenize

INSUFFICIENT_MESSAGE = (
    "I could not find sufficient verified plant knowledge for this question. Please contact the maintenance supervisor."
)
POLICY_NOTICE = (
    "Plant policy reminder (standard notice, not generated from evidence): stop the machine and apply your site's "
    "approved lockout/tagout procedure before any inspection."
)


def _fmt_ts(t: float | None) -> str | None:
    if t is None:
        return None
    return f"{int(t // 60):02d}:{int(t % 60):02d}"


class _EvidenceBook:
    """Collects cited sources and assigns stable IDs (S1, S2, ...)."""

    def __init__(self, db: Session) -> None:
        self.db = db
        self.items: list[dict[str, Any]] = []
        self._index: dict[tuple[Any, ...], str] = {}

    def add(self, record_id: str | None, start: float | None, end: float | None, quote: str, kind: str) -> str | None:
        if not record_id:
            return None
        # one citation per distinct quote: two steps spoken in the same segment must not share a quote
        key = (record_id, start, end, " ".join(quote.split())[:300])
        if key in self._index:
            return self._index[key]
        rec = self.db.get(KnowledgeRecord, record_id)
        if rec is None:
            return None
        tech: User | None = rec.contributor
        recording = self.db.scalar(select(Recording).where(Recording.record_id == rec.id))
        sid = f"S{len(self.items) + 1}"
        self._index[key] = sid
        self.items.append({
            "id": sid,
            "kind": kind,
            "record_id": rec.id,
            "record_ref": rec.ref,
            "title": rec.title,
            "source_type": rec.source_type,
            "technician": tech.full_name if tech else None,
            "technician_title": tech.title if tech else None,
            "recorded_at": (rec.recorded_at or rec.created_at).isoformat(),
            "start": start,
            "end": end,
            "timestamp": f"{_fmt_ts(start)}-{_fmt_ts(end)}" if start is not None and end is not None else None,
            "quote": quote[:600],
            "recording_id": recording.id if recording else None,
            "playable_audio": bool(recording and recording.storage_key),
            "is_synthetic": rec.is_synthetic,
            "review_status": rec.review_status,
            "ai_version": rec.ai_version,
        })
        return sid


def _reported_symptom(query: str, proc: Procedure | None) -> str | None:
    for pat in SYMPTOM_PATTERNS:
        m = pat.search(query)
        if m:
            return m.group(0).strip()
    if proc and proc.symptoms:
        q = set(tokenize(query))
        best = max(proc.symptoms, key=lambda s: len(q & set(tokenize(s))))
        if q & set(tokenize(best)):
            return best
    return None


def _groundedness(res: RetrievalResult, primary: tuple[Procedure, float] | None) -> dict[str, Any]:
    a = res.analysis
    hits = res.hits
    if not hits:
        return {"level": "INSUFFICIENT", "score": 0.0, "components": {}, "explanation": "No approved evidence matched."}
    content = set(a.content_tokens)
    evidence_text = " ".join(h.text for h in hits[:4])
    ev_toks = set(tokenize(evidence_text))
    coverage = (len(content & ev_toks) / len(content)) if content else 0.5
    vec_top = max((h.vector for h in hits), default=0.0)
    vec_norm = min(1.0, max(0.0, vec_top) / 0.55)
    graph = primary[1] if primary else 0.0
    score = 0.45 * coverage + 0.25 * vec_norm + 0.30 * min(1.0, graph / 0.6)
    if a.asset is None:
        score *= 0.85  # unscoped questions are inherently less certain
    if primary and graph >= 0.35 and coverage >= 0.6 and score >= 0.62:
        level = "HIGH"
    elif score >= 0.48:
        level = "MEDIUM"
    elif score >= get_settings().groundedness_min_score:
        level = "LOW"
    else:
        level = "INSUFFICIENT"
    explanation = (
        f"{int(coverage * 100)}% of the question's key terms appear in approved evidence; "
        f"best semantic match {vec_top:.2f}; "
        + (f"knowledge-graph match to an approved procedure ({graph:.2f})." if primary else "no approved procedure matched in the knowledge graph.")
    )
    return {"level": level, "score": round(score, 3),
            "components": {"term_coverage": round(coverage, 3), "vector_similarity": round(vec_top, 3), "graph_match": round(graph, 3)},
            "explanation": explanation}


def _asset_payload(asset: Asset | None) -> dict[str, Any] | None:
    if asset is None:
        return None
    return {"id": asset.id, "asset_tag": asset.asset_tag, "name": asset.name, "location": asset.location,
            "status": asset.status, "criticality": asset.criticality}


def _insufficient(res: RetrievalResult, reason: str, extra: dict[str, Any] | None = None) -> dict[str, Any]:
    a = res.analysis
    related = []
    for h in res.other_asset_hits[:3]:
        related.append({"chunk_type": h.chunk_type, "asset_id": h.asset_id, "excerpt": h.text[:160]})
    return {
        "status": "insufficient",
        "mode": "none",
        "question": a.query,
        "machine": _asset_payload(a.asset),
        "reported_symptom": _reported_symptom(a.query, None),
        "summary": INSUFFICIENT_MESSAGE,
        "steps": [],
        "safety": [],
        "policy_notice": POLICY_NOTICE,
        "evidence": [],
        "sources": [],
        "procedure": None,
        "groundedness": {"level": "INSUFFICIENT", "score": 0.0, "components": {}, "explanation": reason},
        "conflicts": [],
        "escalation": {"required": True, "reason": reason, "message": "Escalate to the maintenance supervisor."},
        "related_other_assets": related,
        "unsupported_removed": 0,
        "retrieval": {"backend": res.backend, "embedder": res.embedder, "hits": [h.as_debug() for h in res.hits]},
        **(extra or {}),
    }


def _safety_for(db: Session, proc: Procedure | None, asset: Asset | None, book: _EvidenceBook) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    conds = []
    if proc is not None:
        conds.append(SafetyWarning.procedure_id == proc.id)
    if asset is not None:
        conds.append(SafetyWarning.asset_id == asset.id)
    if not conds:
        return out
    from sqlalchemy import or_

    rows = db.scalars(select(SafetyWarning).where(or_(*conds), SafetyWarning.status == "approved")).all()
    rows = sorted(rows, key=lambda w: (0 if proc is not None and w.procedure_id == proc.id else 1, 0 if w.severity == "danger" else 1))
    for w in rows:
        key = w.text.lower()
        if key in seen:
            continue
        seen.add(key)
        from ..models import KnowledgeSource

        src = db.scalar(select(KnowledgeSource).where(KnowledgeSource.entity_type == "safety_warning", KnowledgeSource.entity_id == w.id))
        cite = book.add(w.record_id, src.start_s if src else None, src.end_s if src else None, src.quote if src else w.text, "safety") if w.record_id else None
        out.append({"text": w.text, "severity": w.severity, "hazard_type": w.hazard_type, "citation": cite})
        if len(out) >= 5:
            break
    return out


def _conflict_payload(db: Session, proc: Procedure) -> list[dict[str, Any]]:
    out = []
    for c in open_conflicts_for_procedures(db, [proc.id]):
        def side(p: Procedure) -> dict[str, Any]:
            return {"procedure_id": p.id, "ref": p.ref, "title": p.title, "status": p.status,
                    "author": p.author.full_name if p.author else None,
                    "first_steps": [s["text"] for s in sorted(p.steps, key=lambda s: s["order"])[:3]]}
        out.append({"id": c.id, "type": c.conflict_type, "description": c.description,
                    "procedure_a": side(c.procedure_a), "procedure_b": side(c.procedure_b),
                    "recommended_action": "Supervisor review required."})
    return out


def _llm_steps(res: RetrievalResult, primary: Procedure | None, org_id: str) -> tuple[list[dict[str, Any]], int, str] | None:
    """Ask the LLM to compose steps from evidence; verify citations & support."""
    blocks: list[tuple[str, Hit]] = [(f"E{i + 1}", h) for i, h in enumerate(res.hits[:6])]
    if not blocks:
        return None
    evidence = "\n\n".join(f"[{eid}] ({h.chunk_type}) {h.text}" for eid, h in blocks)
    machine = f"{res.analysis.asset.asset_tag} {res.analysis.asset.name}" if res.analysis.asset else "not specified"
    data = complete_json(
        "You are LegacyMind, an industrial maintenance assistant. Answer ONLY from the evidence blocks. "
        "Every step must cite one or more evidence ids like \"E1\". If the evidence does not answer the question, "
        "set answerable=false. Never add steps from general knowledge. Do not write safety warnings (they are added separately). "
        'Return JSON: {"answerable": bool, "summary": str, "steps": [{"text": str, "evidence": [str]}]}',
        f"Machine: {machine}\nQuestion: {res.analysis.query}\n\nEvidence:\n{evidence}",
        kind="chat", org_id=org_id, max_tokens=900,
    )
    if not data or not data.get("answerable"):
        return None
    by_id = dict(blocks)
    steps, removed = [], 0
    for st in data.get("steps") or []:
        if not isinstance(st, dict):
            continue
        txt = str(st.get("text", "")).strip()
        cites = [c for c in st.get("evidence") or [] if c in by_id]
        support = max((token_overlap(txt, by_id[c].text) for c in cites), default=0.0)
        if not txt or not cites or support < 0.5:
            removed += 1
            continue
        steps.append({"text": txt, "hits": [by_id[c] for c in cites]})
    if not steps:
        return None
    return steps, removed, str(data.get("summary") or "")[:500]


def answer_question(db: Session, org_id: str, question: str, context_asset_id: str | None = None) -> dict[str, Any]:
    res = retrieve(db, org_id, question, context_asset_id)
    a = res.analysis

    if a.unknown_tags and a.asset is None:
        return _insufficient(res, f"Asset {', '.join(a.unknown_tags)} is not in the plant asset registry.")
    if a.asset is not None and a.asset_explicit and not res.hits:
        reason = f"No approved knowledge exists for {a.asset.asset_tag} ({a.asset.name}) that matches this question."
        if res.other_asset_hits:
            reason += " Related knowledge exists for other machines but is not applicable without verification."
        return _insufficient(res, reason)
    if not res.hits:
        return _insufficient(res, "No approved plant knowledge matched this question.")

    primary = res.graph_procedures[0] if res.graph_procedures and res.graph_procedures[0][1] >= 0.2 else None
    if primary is None:
        # a procedure card retrieved by vector/keyword can still be primary
        for h in res.hits[:5]:
            if h.procedure_id:
                p = db.get(Procedure, h.procedure_id)
                if p is not None and p.status == "approved":
                    primary = (p, 0.0)
                    break
    g = _groundedness(res, primary if primary and primary[1] > 0 else None)
    if g["level"] == "INSUFFICIENT":
        return _insufficient(res, g["explanation"], {"groundedness": g})

    proc = primary[0] if primary else None
    asset = a.asset or (proc.asset if proc else None)
    book = _EvidenceBook(db)
    steps: list[dict[str, Any]] = []
    removed = 0
    mode = "extractive"
    summary = ""

    llm_out = _llm_steps(res, proc, org_id) if llm_configured() else None
    if llm_out:
        mode = f"llm-grounded ({provider_label()})"
        raw_steps, removed, summary = llm_out
        for i, st in enumerate(raw_steps, start=1):
            cites = [book.add(h.record_id, h.start_s, h.end_s, h.text, h.chunk_type) for h in st["hits"]]
            steps.append({"order": i, "text": st["text"], "citations": [c for c in cites if c]})
    elif proc is not None:
        for st in sorted(proc.steps, key=lambda s: s.get("order", 0)):
            src = st.get("source") or {}
            cite = book.add(src.get("record_id") or proc.record_id, src.get("start"), src.get("end"), src.get("quote", st["text"]), "procedure_step")
            steps.append({"order": st.get("order"), "text": st["text"], "citations": [cite] if cite else []})
        summary = f"Approved procedure {proc.ref}: {proc.title}."
    else:
        # No structured procedure: return verbatim expert excerpts instead of synthesising steps.
        summary = "No approved step-by-step procedure matches; relevant approved expert knowledge is quoted below."
        for h in res.hits[:3]:
            book.add(h.record_id, h.start_s, h.end_s, h.text, h.chunk_type)

    # Procedure steps already cite the exact sentences; add one wider transcript window only when no
    # step citation exists, so the evidence list stays short and every item earns its place.
    if not any(st["citations"] for st in steps):
        for h in res.hits[:4]:
            if h.chunk_type == "transcript" and (proc is None or h.record_id == proc.record_id):
                book.add(h.record_id, h.start_s, h.end_s, h.text, "transcript")

    safety = _safety_for(db, proc, asset, book)
    conflicts = _conflict_payload(db, proc) if proc else []
    if conflicts and g["level"] == "HIGH":
        g["level"] = "MEDIUM"
        g["explanation"] += " Capped at MEDIUM because of an open knowledge conflict."

    escalation_reasons = []
    if conflicts:
        escalation_reasons.append("Conflicting procedures exist for this problem.")
    if g["level"] == "LOW":
        escalation_reasons.append("Evidence is weak; verify with the maintenance supervisor.")
    if proc is not None and proc.requires_supervisor:
        escalation_reasons.append(f"{proc.ref} is a {proc.risk_level}-risk procedure: supervisor sign-off required before execution.")

    sources: list[dict[str, Any]] = []
    for ev in book.items:
        if not any(s["ref"] == ev["record_ref"] for s in sources):
            sources.append({"type": "knowledge_record", "ref": ev["record_ref"], "id": ev["record_id"]})
    if asset is not None:
        sources.append({"type": "asset", "ref": asset.asset_tag, "id": asset.id})
    if proc is not None:
        sources.append({"type": "procedure", "ref": proc.ref, "id": proc.id})

    return {
        "status": "answered",
        "mode": mode,
        "question": question,
        "machine": _asset_payload(asset),
        "reported_symptom": _reported_symptom(question, proc),
        "summary": summary,
        "steps": steps,
        "safety": safety,
        "policy_notice": POLICY_NOTICE,
        "evidence": book.items,
        "sources": sources,
        "procedure": {
            "id": proc.id, "ref": proc.ref, "title": proc.title, "risk_level": proc.risk_level,
            "requires_supervisor": proc.requires_supervisor, "status": proc.status,
            "approved_by": proc.approved_by.full_name if proc.approved_by else None,
            "approved_at": proc.approved_at.isoformat() if proc.approved_at else None,
            "tools": proc.tools, "parts": proc.parts,
        } if proc else None,
        "groundedness": g,
        "conflicts": conflicts,
        "escalation": {
            "required": bool(escalation_reasons),
            "reason": " ".join(escalation_reasons),
            "message": "Contact the maintenance supervisor before proceeding." if escalation_reasons else "",
        },
        "related_other_assets": [],
        "unsupported_removed": removed,
        "retrieval": {"backend": res.backend, "embedder": res.embedder, "hits": [h.as_debug() for h in res.hits]},
    }


def title_from_question(q: str) -> str:
    q = re.sub(r"\s+", " ", q).strip()
    return q[:80] + ("..." if len(q) > 80 else "")
