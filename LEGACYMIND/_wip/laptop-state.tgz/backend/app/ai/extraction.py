"""Knowledge extraction: transcript -> structured maintenance knowledge.

Two extractors produce the same schema:

* ``LLMExtractor`` - used when an LLM provider is configured. Every item the
  model returns must carry a verbatim ``quote``; items whose quote cannot be
  located in the transcript are discarded (hallucination guard) and the
  remaining items inherit the timestamps of the segment they were found in.
* ``RuleExtractor`` (``rules-v3``) - deterministic pattern/gazetteer extractor
  used offline or when the LLM is unavailable. Lower recall, but every item is
  a literal span of the source.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from .llm import complete_json, llm_configured, provider_label
from .text import find_tags, sentences, token_overlap, tokenize

RULES_VERSION = "rules-v3"

# ---------------------------------------------------------------------------
# Gazetteers & patterns
# ---------------------------------------------------------------------------

_SOUND_ADJ = r"(?:grinding|squealing|squeaking|knocking|rattling|humming|hissing|clicking|whining|banging|screeching|buzzing|chattering|clunking|scraping|whistling)"
_CONTEXT = r"(?:\s+(?:during|at|on|when|while|under)\s+(?:the\s+)?(?:start-?up|starting|start|shutdown|load|high speed|low speed|idle|cold start|full load|acceleration|deceleration|operation|each cycle|the end of the stroke|the stroke))?"

SYMPTOM_PATTERNS: list[re.Pattern[str]] = [
    re.compile(rf"\b{_SOUND_ADJ}\s+(?:sound|noise)s?{_CONTEXT}", re.I),
    re.compile(rf"\b(?:unusual|strange|loud|abnormal|metallic)\s+(?:sound|noise){_CONTEXT}", re.I),
    re.compile(r"\b(?:pressure|temperature|flow|speed|oil level|fluid level|voltage|current|amperage|output)\s+(?:drops?|dropping|falls?|falling|fluctuates?|fluctuating|spikes?|rises?|rising|is (?:low|high|unstable)|goes (?:low|high|up|down)|below (?:the )?normal(?: range)?|above (?:the )?normal(?: range)?)", re.I),
    re.compile(r"\b(?:low|high|fluctuating|unstable|erratic|dropping|excessive)\s+(?:hydraulic\s+|oil\s+|air\s+|discharge\s+|system\s+)?(?:pressure|temperature|flow|oil level|voltage|current|amperage|speed)", re.I),
    re.compile(rf"\b(?:excessive\s+|heavy\s+|severe\s+|strong\s+)?vibration{_CONTEXT}", re.I),
    re.compile(r"\b(?:overheating|over-heating|runs? hot|running hot|overheats)\b", re.I),
    re.compile(r"\b(?:oil|fluid|hydraulic|air|coolant|water)\s+leak(?:s|age|ing)?\b", re.I),
    re.compile(r"\b(?:burning|burnt)\s+smell\b|\bsmoke\b", re.I),
    re.compile(r"\b(?:belt\s+)?slipping\b|\bslips\b", re.I),
    re.compile(r"\b(?:motor|breaker|drive|overload)\s+(?:trips?|tripping)\b|\bkeeps tripping\b", re.I),
    re.compile(r"\b(?:jerky|erratic|slow|sluggish)\s+(?:motion|movement|response|stroke|cycle|ram movement|travel)\b", re.I),
    re.compile(r"\b(?:chatter marks|poor surface finish|dimensional (?:error|drift)|tool chatter|spindle runout)\b", re.I),
    re.compile(r"\b(?:belt|conveyor|product)\s+(?:mistracking|tracking off|drifting|drifts to one side|runs off)\b|\bmistracking\b", re.I),
    re.compile(r"\b(?:alarm|error code|fault code)\s+[A-Z0-9-]{2,10}\b", re.I),
    re.compile(r"\b(?:does not|doesn't|won't|fails to)\s+(?:start|build pressure|reach pressure|hold pressure|load|unload)\b", re.I),
    re.compile(r"\b(?:short[- ]cycling|frequent cycling|hard starting)\b", re.I),
    re.compile(r"\b(?:ram|cylinder|slide)\s+(?:drift(?:s|ing)?|creep(?:s|ing)?)\b", re.I),
]

FAILURE_PATTERNS: list[tuple[re.Pattern[str], str | None]] = [
    (re.compile(r"\b(valve|filter|line|nozzle|strainer|port|orifice|suction|intake|drain|cooler)\s+(?:blockage|clog(?:ging)?|restriction)\b", re.I), "{0} blockage"),
    (re.compile(r"\b(valve|filter|line|nozzle|strainer|port|orifice|suction|intake|drain|cooler)\s+for\s+(?:a\s+|any\s+)?(?:blockage|clog(?:ging)?|restriction)\b", re.I), "{0} blockage"),
    (re.compile(r"\b(?:blocked|clogged|choked|restricted)\s+(valve|filter|line|nozzle|strainer|port|orifice|suction|intake|drain|cooler)\b", re.I), "{0} blockage"),
    (re.compile(r"\b(bearing|seal|belt|gear|coupling|impeller|motor|brush|spindle bearing|valve seat|piston seal|wear ring)s?\s+(?:failure|wear|damage|is worn|are worn|worn out|fails)\b", re.I), "{0} wear"),
    (re.compile(r"\b(?:worn|damaged|cracked|broken|failed)\s+(bearing|seal|belt|gear|coupling|impeller|brush(?:es)?|insert|wear ring|o-ring|gasket|valve seat)\b", re.I), "{0} wear"),
    (re.compile(r"\b(?:loose|slack)\s+(belt|coupling|mounting bolts?|terminal|connection)\b", re.I), "loose {0}"),
    (re.compile(r"\b(misalignment|cavitation|contamination|air ingress|aeration|overload|lubrication failure|insufficient lubrication|belt mistracking)\b", re.I), None),
    (re.compile(r"\bair in the (?:system|lines|oil|hydraulic lines)\b", re.I), "air in hydraulic system"),
    (re.compile(r"\blow (oil|fluid|refrigerant) level\b", re.I), "low {0} level"),
    (re.compile(r"\b(?:sticking|stuck)\s+(valve|relief valve|solenoid|spool)\b", re.I), "sticking {0}"),
]

CAUSE_PATTERNS = [
    re.compile(r"\b(?:because of|because|due to|caused by|results? from)\s+([^.;,]{4,90})", re.I),
    re.compile(r"\b(?:usually|normally|mostly|nine times out of ten)\s+(?:it'?s|it is|means|the cause is)\s+([^.;,]{4,90})", re.I),
    re.compile(r"\b(?:the (?:root )?cause is|it indicates|that indicates|which means)\s+([^.;,]{4,90})", re.I),
]

ACTION_VERBS = (
    "inspect", "check", "verify", "measure", "test", "replace", "clean", "flush", "tighten", "loosen", "adjust",
    "align", "realign", "re-align", "lubricate", "grease", "drain", "refill", "top up", "bleed", "reset", "restart",
    "stop", "shut", "isolate", "lock", "tag", "depressurize", "depressurise", "release", "remove", "install", "open",
    "close", "record", "listen", "look", "compare", "rotate", "turn", "confirm", "wait", "apply", "torque",
    "calibrate", "retension", "re-tension", "tension", "disconnect", "reconnect", "purge", "blow out", "examine",
    "switch off", "power down", "bleed off", "vent", "note", "log", "feel", "monitor", "run", "jog", "cycle",
    "back off", "loosen off", "clear", "reseat", "re-seat", "swap", "change", "fill", "wipe", "secure", "call",
    "escalate", "report", "use", "wear", "ensure", "make sure",
)
_VERB_RE = re.compile(r"\b(" + "|".join(re.escape(v) for v in sorted(ACTION_VERBS, key=len, reverse=True)) + r")\b", re.I)

COMPONENT_WORDS = (
    "relief valve", "check valve", "solenoid valve", "control valve", "drain valve", "intake valve", "valve",
    "suction strainer", "strainer", "return filter", "suction filter", "intake filter", "air filter", "oil filter",
    "filter", "bearing", "seal", "impeller", "motor", "coupling", "belt", "pulley", "spindle", "chuck", "hose",
    "accumulator", "gearbox", "cylinder", "piston", "nozzle", "pressure sensor", "sensor", "limit switch",
    "contactor", "vfd", "drive", "roller", "idler", "tensioner", "tail pulley", "head pulley", "oil separator",
    "cooler", "fan", "ram", "hydraulic unit", "reservoir", "tank", "manifold", "ball screw",
    "way covers", "tool changer", "coolant pump", "unloader valve", "pressure switch", "separator element",
)
TOOL_WORDS = (
    "pressure gauge", "multimeter", "clamp meter", "torque wrench", "feeler gauge", "dial indicator",
    "mechanic's stethoscope", "stethoscope", "infrared thermometer", "ir thermometer", "thermal camera",
    "vibration meter", "vibration analyzer", "laser alignment tool", "alignment laser", "allen key", "hex key",
    "spanner", "wrench", "grease gun", "flashlight", "torch", "borescope", "megger", "insulation tester",
    "tachometer", "oil sample kit", "straight edge", "belt tension gauge", "leak detection spray", "soap solution",
)
PART_WORDS = (
    "seal kit", "seal", "gasket", "o-ring", "filter element", "separator element", "bearing", "belt", "fuse",
    "hose", "coupling insert", "wear ring", "impeller", "brushes", "contactor", "cartridge", "spool", "valve seat",
    "piston seal", "wiper seal", "v-belt", "idler roller", "lagging",
)

# Hazard / precaution vocabulary. Deliberately excludes words that also describe normal operation or symptoms
# ("never" in "almost never gives problems", "voltage drops", "pressure falls", "accumulator is charged").
SAFETY_KEYWORDS = re.compile(
    r"\b(lockout|tagout|loto|lock out|tag out|isolate|isolation|depressuri[sz]e|bleed (?:off )?(?:the )?(?:pressure|air|accumulator)|"
    r"residual pressure|stored (?:energy|air pressure)|ppe|gloves|goggles|safety glasses|face shield|ear protection|hearing protection|"
    r"danger|caution|warning|high[- ]pressure (?:hydraulic |oil |air )?(?:system|oil|line|fluid)|electrocution|arc flash|"
    r"cause (?:serious )?(?:injury|injuries|burns)|risk of|burns|hot surface|hot enough|rotating|moving parts|pinch points?|"
    r"safety blocks?|injection injur(?:y|ies)|permit to work|confined space|zero energy|live (?:wire|circuit|parts|panel)|"
    r"main power is isolated|isolate the main power)\b",
    re.I,
)
# A prohibition is only a safety instruction when it is an imperative: "Never loosen...", "Do not open...".
PROHIBITION_RE = re.compile(r"(?:^|[;.]\s*)(?:never|do not|don't)\s+[a-z]+", re.I)


def is_safety_statement(sentence: str) -> bool:
    return bool(SAFETY_KEYWORDS.search(sentence) or PROHIBITION_RE.search(sentence.strip()))


_HAZARDS = [
    ("hydraulic_pressure", r"hydraulic|pressure|accumulator|injection|depressur|bleed"),
    ("electrical", r"electric|voltage|live|arc flash|electrocution|panel|contactor|vfd|power"),
    ("mechanical", r"rotating|moving parts|pinch|guard|entangle|crush|belt|pulley|chuck|spindle"),
    ("thermal", r"hot|burn|temperature|heat"),
    ("stored_energy", r"stored energy|zero energy|lockout|tagout|loto|isolat"),
    ("ppe", r"ppe|gloves|goggles|glasses|face shield|ear protection|hearing"),
]
MISCONCEPTION_RE = re.compile(
    r"\b(?:new|junior|young|inexperienced)\s+(?:guys|technicians|techs|people|fitters|operators)?\b.*\b(?:usually|normally|often|always|tend to)\b"
    r"|\bunnecessary\b|\bwaste of (?:time|money)\b|\bdon'?t need to\b|\bno need to\b|\bmistake\b",
    re.I,
)
_SAFETY_PREP_RE = re.compile(r"\b(stop|shut|isolate|lock|tag|depressuri|bleed|power down|switch off|wear|ppe)", re.I)
_DIAGNOSTIC_RE = re.compile(r"\b(inspect|check|verify|measure|test|examine|look|listen|compare|clean|replace|adjust|align|tighten)\b", re.I)
_CONTEXT_START = re.compile(r"^(?:before|after|when|whenever|once|while|until|as soon as)\b", re.I)
_COND_START = re.compile(r"^(?:if|unless|in case|should)\b", re.I)


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class Span:
    text: str
    start: float | None
    end: float | None
    sentence: str


@dataclass
class Extraction:
    method: str
    asset_tags: list[str] = field(default_factory=list)
    components: list[dict[str, Any]] = field(default_factory=list)
    symptoms: list[dict[str, Any]] = field(default_factory=list)
    failure_modes: list[dict[str, Any]] = field(default_factory=list)
    causes: list[dict[str, Any]] = field(default_factory=list)
    procedures: list[dict[str, Any]] = field(default_factory=list)
    tools: list[dict[str, Any]] = field(default_factory=list)
    parts: list[dict[str, Any]] = field(default_factory=list)
    safety: list[dict[str, Any]] = field(default_factory=list)
    misconceptions: list[dict[str, Any]] = field(default_factory=list)
    summary: str = ""
    dropped_unverified: int = 0

    def as_dict(self) -> dict[str, Any]:
        return {k: getattr(self, k) for k in self.__dataclass_fields__}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _sentence_spans(segments: list[dict[str, Any]]) -> list[Span]:
    spans: list[Span] = []
    for seg in segments:
        text = str(seg.get("text", "")).strip()
        if not text:
            continue
        for s in sentences(text):
            spans.append(Span(s, seg.get("start"), seg.get("end"), s))
    return spans


def _clean(s: str) -> str:
    s = re.sub(r"\s+", " ", s).strip(" ,;:-")
    return s


def _cap(s: str) -> str:
    return s[:1].upper() + s[1:] if s else s


def _uniq_by(items: list[dict[str, Any]], key: str) -> list[dict[str, Any]]:
    seen: set[str] = set()
    out = []
    for it in items:
        k = str(it.get(key, "")).lower()
        if k and k not in seen:
            seen.add(k)
            out.append(it)
    return out


def _item(name: str, span: Span, confidence: float, **extra: Any) -> dict[str, Any]:
    return {"name": name, "quote": span.sentence, "start": span.start, "end": span.end, "confidence": round(confidence, 2), **extra}


def hazard_type(text: str) -> str:
    low = text.lower()
    for name, pat in _HAZARDS:
        if re.search(pat, low):
            return name
    return "general"


def severity(text: str) -> str:
    if re.search(r"\b(never|do not|don't|danger|fatal|serious injur|high[- ]pressure|live|arc flash|injection)\b", text, re.I):
        return "danger"
    return "warning"


def _clauses(sentence: str) -> list[str]:
    parts = re.split(r";|,\s*(?:and\s+)?then\s+|\bthen\b|,\s*after that\s*,?|,\s*and\s+(?=(?:" + "|".join(ACTION_VERBS[:40]) + r")\b)|,\s*", sentence)
    return [_clean(p) for p in parts if p and _clean(p)]


def _step_from_clause(clause: str) -> str | None:
    c = re.sub(r"^(?:and|so|also|first(?:ly)?|second(?:ly)?|next|finally|always|just|you|you should|you have to|you need to|we|we always|i always|i|then|after that|now|the first thing (?:to do )?is to|the first thing you do is|start by|begin by)\b[\s,]*", "", clause, flags=re.I)
    c = re.sub(r"^(?:first(?:ly)?|then|always|just|to)\b[\s,]*", "", c, flags=re.I)
    m = _VERB_RE.search(c)
    if not m:
        return None
    if m.start() > 25:  # verb buried deep in the clause -> probably descriptive, not an instruction
        return None
    step = _clean(c[m.start():])
    if len(step.split()) < 2:
        return None
    return _cap(step.rstrip("."))


def _component_in(text: str, asset_tags: set[str]) -> str | None:
    for tag in find_tags(text):
        if tag not in asset_tags:
            m = re.search(r"([A-Za-z]+(?:\s[A-Za-z]+)?)\s+" + re.escape(tag), text, re.I)
            if m and m.group(1).lower() not in ("the", "check", "inspect", "on", "of", "at"):
                word = m.group(1).split()[-1]
                return f"{_cap(word.lower())} {tag}"
            return tag
    low = text.lower()
    for w in COMPONENT_WORDS:
        if re.search(rf"\b{re.escape(w)}\b", low):
            return w
    return None


def first_check_target(step_text: str, asset_tags: set[str] | None = None) -> str:
    """The object of a procedure's first diagnostic step - used for conflict detection."""
    comp = _component_in(step_text, asset_tags or set())
    if comp:
        return comp.lower()
    toks = [t for t in tokenize(step_text) if t not in ("inspect", "replace", "clean")]
    return " ".join(toks[:3])


# ---------------------------------------------------------------------------
# Rule extractor
# ---------------------------------------------------------------------------


class RuleExtractor:
    method = RULES_VERSION

    def extract(self, segments: list[dict[str, Any]], known_asset_tags: set[str], asset_names: dict[str, str] | None = None) -> Extraction:
        ex = Extraction(method=self.method)
        spans = _sentence_spans(segments)
        full = " ".join(s.text for s in spans)
        asset_names = asset_names or {}

        # assets mentioned by tag or by name
        for tag in find_tags(full):
            if tag in known_asset_tags and tag not in ex.asset_tags:
                ex.asset_tags.append(tag)
        low_full = full.lower()
        for tag, name in asset_names.items():
            if tag not in ex.asset_tags and name and re.search(rf"\b{re.escape(name.lower())}\b", low_full):
                ex.asset_tags.append(tag)

        topics: list[dict[str, Any]] = []
        current: dict[str, Any] | None = None

        for sp in spans:
            s = sp.text
            is_question = s.rstrip().endswith("?")
            # ---- symptoms
            found_symptoms = []
            for pat in SYMPTOM_PATTERNS:
                for m in pat.finditer(s):
                    name = _clean(m.group(0).lower())
                    name = re.sub(r"\bstart up\b", "startup", name).replace("start-up", "startup")
                    found_symptoms.append(_item(name, sp, 0.7 if not is_question else 0.5))
            # dedupe overlapping (keep longest)
            found_symptoms.sort(key=lambda x: -len(x["name"]))
            kept: list[dict[str, Any]] = []
            for fs in found_symptoms:
                if not any(fs["name"] in k["name"] for k in kept):
                    kept.append(fs)
            if not is_question:
                ex.symptoms.extend(kept)

            # ---- failure modes
            for pat, template in FAILURE_PATTERNS:
                for m in pat.finditer(s):
                    name = template.format(*[g.lower() for g in m.groups()]) if template else m.group(1).lower()
                    if not is_question:
                        ex.failure_modes.append(_item(name, sp, 0.65))

            # ---- causes
            for pat in CAUSE_PATTERNS:
                for m in pat.finditer(s):
                    if not is_question and not is_safety_statement(s):
                        ex.causes.append(_item(_clean(m.group(1)), sp, 0.55))

            # ---- tools / parts / components
            low = s.lower()
            for w in TOOL_WORDS:
                if re.search(rf"\b{re.escape(w)}\b", low):
                    ex.tools.append(_item(w, sp, 0.7))
            for m in re.finditer(r"\b(?:replace|change|swap|renew|fit a new|install a new)\s+(?:the\s+|a\s+|an\s+)?((?:[a-z0-9-]+\s){0,2}?(?:" + "|".join(re.escape(p) for p in PART_WORDS) + r"))\b", low):
                ex.parts.append(_item(m.group(1).strip(), sp, 0.65))
            comp = _component_in(s, known_asset_tags)
            if comp and not is_question:
                ex.components.append(_item(comp, sp, 0.6, tag=next((t for t in find_tags(comp)), "")))

            # ---- misconceptions ("juniors usually replace the pump - unnecessary")
            if MISCONCEPTION_RE.search(s) and not is_question:
                ex.misconceptions.append(_item(_clean(s), sp, 0.6))

            # ---- safety
            if is_safety_statement(s) and not is_question:
                ex.safety.append(
                    {"text": _cap(_clean(s)).rstrip(".") + ".", "hazard_type": hazard_type(s), "severity": severity(s),
                     "quote": sp.sentence, "start": sp.start, "end": sp.end, "confidence": 0.7}
                )

            # ---- topic segmentation: a sentence that states a (new) symptom opens a topic
            if kept and not is_question:
                names = {k["name"] for k in kept}
                if current is None or not (names & set(current["symptoms"])):
                    current = {"symptoms": [k["name"] for k in kept], "steps": [], "start": sp.start}
                    topics.append(current)
                else:
                    for n in names:
                        if n not in current["symptoms"]:
                            current["symptoms"].append(n)

            # ---- steps
            if is_question or (MISCONCEPTION_RE.search(s) and not re.search(r"\b(instead|rather)\b", s, re.I)):
                continue
            clauses = _clauses(s)
            pending_cond: str | None = None
            for cl in clauses:
                if _COND_START.match(cl):
                    # "If pressure is below normal" -> condition attached to the next step
                    body = _COND_START.sub("", cl).strip()
                    if not _step_from_clause(body) or re.search(r"\b(is|are|was|has|have|shows|reads|drops|falls|stays|keeps)\b", cl, re.I):
                        pending_cond = cl
                        continue
                if _CONTEXT_START.match(cl):
                    continue
                step = _step_from_clause(cl)
                if not step:
                    continue
                if re.match(r"^(?:never|do not|don't)\b", cl, re.I):
                    continue  # prohibitions are captured as safety warnings
                if pending_cond:
                    step = f"{_cap(pending_cond)}, {step[0].lower()}{step[1:]}"
                    pending_cond = None
                if current is None:
                    current = {"symptoms": [], "steps": [], "start": sp.start}
                    topics.append(current)
                comp_s = _component_in(step, known_asset_tags)
                current["steps"].append(
                    {"text": step, "component": comp_s or "", "quote": sp.sentence, "start": sp.start, "end": sp.end,
                     "confidence": 0.7 if comp_s else 0.6}
                )

        # ---- a symptom-less preamble (usually isolation / LOTO) belongs to the next topic
        merged: list[dict[str, Any]] = []
        for i, t in enumerate(topics):
            nxt = topics[i + 1] if i + 1 < len(topics) else None
            if not t["symptoms"] and t["steps"] and nxt is not None and nxt["symptoms"]:
                nxt["steps"] = t["steps"] + nxt["steps"]
                continue
            merged.append(t)
        topics = merged

        # ---- a topic whose only steps are isolation/safety prep ("stop it, lock it out") is not a
        #      troubleshooting procedure on its own: fold it into the next topic, keeping its symptoms
        folded: list[dict[str, Any]] = []
        pending: dict[str, Any] | None = None
        for t in topics:
            if pending is not None:
                t["symptoms"] = pending["symptoms"] + [x for x in t["symptoms"] if x not in pending["symptoms"]]
                t["steps"] = pending["steps"] + t["steps"]
                pending = None
            only_prep = bool(t["steps"]) and all(_SAFETY_PREP_RE.search(st["text"]) and not _DIAGNOSTIC_RE.search(st["text"])
                                                 for st in t["steps"])
            if only_prep and t is not topics[-1]:
                pending = t
                continue
            folded.append(t)
        topics = folded

        # ---- procedures from topics with steps
        for t in topics:
            if not t["steps"]:
                continue
            steps = []
            seen: set[str] = set()
            for st in t["steps"]:
                key = st["text"].lower()
                if key in seen:
                    continue
                seen.add(key)
                steps.append({**st, "order": len(steps) + 1})
            title_basis = t["symptoms"][0] if t["symptoms"] else (ex.failure_modes[0]["name"] if ex.failure_modes else "general maintenance")
            ex.procedures.append(
                {
                    "title": f"{_cap(title_basis)} - troubleshooting",
                    "symptoms": t["symptoms"],
                    "steps": steps,
                    "confidence": round(sum(s["confidence"] for s in steps) / len(steps), 2),
                }
            )

        ex.symptoms = _uniq_by(ex.symptoms, "name")
        ex.failure_modes = _uniq_by(ex.failure_modes, "name")
        ex.causes = _uniq_by(ex.causes, "name")
        ex.tools = _uniq_by(ex.tools, "name")
        ex.parts = _uniq_by(ex.parts, "name")
        ex.components = _uniq_by(ex.components, "name")
        ex.misconceptions = _uniq_by(ex.misconceptions, "name")
        ex.safety = _uniq_by(ex.safety, "text")
        ex.summary = " ".join(sp.text for sp in spans if not sp.text.endswith("?"))[:400]
        return ex


# ---------------------------------------------------------------------------
# LLM extractor with verification
# ---------------------------------------------------------------------------

_LLM_SYSTEM = """You are an industrial maintenance knowledge engineer. Extract ONLY what the technician actually said.
Never add steps, causes, tools or safety advice that are not stated in the transcript.
Every item MUST include "quote": an exact sentence or phrase copied from the transcript.
Return JSON with keys: asset_tags (list of strings), components [{name, quote}], symptoms [{name, quote}],
failure_modes [{name, quote}], causes [{name, quote}], procedures [{title, symptoms: [str], steps: [{text, component, quote}]}],
tools [{name, quote}], parts [{name, quote}], safety [{text, hazard_type, severity: "warning"|"danger", quote}],
misconceptions [{name, quote}] (things technicians wrongly do), summary (<= 2 sentences)."""


def _locate(quote: str, spans: list[Span]) -> Span | None:
    if not quote:
        return None
    q = quote.strip().strip('"').lower()
    for sp in spans:
        if q and q in sp.text.lower():
            return sp
    best, best_score = None, 0.0
    for sp in spans:
        sc = token_overlap(quote, sp.text)
        if sc > best_score:
            best, best_score = sp, sc
    return best if best_score >= 0.6 else None


class LLMExtractor:
    def __init__(self) -> None:
        self.method = f"llm:{provider_label()}"

    def extract(self, segments: list[dict[str, Any]], known_asset_tags: set[str], asset_names: dict[str, str] | None = None,
                org_id: str | None = None) -> Extraction | None:
        spans = _sentence_spans(segments)
        if not spans:
            return None
        lines = "\n".join(
            f"[{_fmt(sp.start)}] {sp.text}" if sp.start is not None else sp.text for sp in spans
        )
        assets = ", ".join(f"{t} ({n})" for t, n in (asset_names or {}).items()) or "none"
        data = complete_json(
            _LLM_SYSTEM,
            f"Known plant assets: {assets}\n\nTranscript:\n{lines}",
            kind="extraction", org_id=org_id, max_tokens=2500,
        )
        if not data:
            return None
        ex = Extraction(method=self.method)
        dropped = 0

        def verified(items: Any, key: str = "name") -> list[dict[str, Any]]:
            nonlocal dropped
            out = []
            for it in items if isinstance(items, list) else []:
                if not isinstance(it, dict) or not it.get(key):
                    continue
                sp = _locate(str(it.get("quote", "")), spans)
                if sp is None:
                    dropped += 1
                    continue
                out.append({**{k: v for k, v in it.items() if k != "quote"}, "quote": sp.sentence, "start": sp.start,
                            "end": sp.end, "confidence": 0.8})
            return out

        ex.asset_tags = [t for t in (data.get("asset_tags") or []) if isinstance(t, str) and t.upper() in known_asset_tags]
        ex.components = verified(data.get("components"))
        ex.symptoms = verified(data.get("symptoms"))
        ex.failure_modes = verified(data.get("failure_modes"))
        ex.causes = verified(data.get("causes"))
        ex.tools = verified(data.get("tools"))
        ex.parts = verified(data.get("parts"))
        ex.misconceptions = verified(data.get("misconceptions"))
        ex.safety = [
            {**s, "hazard_type": s.get("hazard_type") or hazard_type(s["text"]),
             "severity": s.get("severity") if s.get("severity") in ("warning", "danger") else severity(s["text"])}
            for s in verified(data.get("safety"), key="text")
        ]
        for proc in data.get("procedures") or []:
            if not isinstance(proc, dict):
                continue
            steps = []
            for st in verified(proc.get("steps"), key="text"):
                # a step must be supported by its quote, not merely have one
                if token_overlap(st["text"], st["quote"]) < 0.35:
                    dropped += 1
                    continue
                steps.append({**st, "order": len(steps) + 1, "component": st.get("component") or ""})
            if steps:
                ex.procedures.append({
                    "title": str(proc.get("title") or "Troubleshooting procedure")[:200],
                    "symptoms": [str(x) for x in proc.get("symptoms") or []][:8],
                    "steps": steps,
                    "confidence": 0.8,
                })
        ex.summary = str(data.get("summary") or "")[:600]
        ex.dropped_unverified = dropped
        return ex


def _fmt(t: float | None) -> str:
    if t is None:
        return "--:--"
    return f"{int(t // 60):02d}:{int(t % 60):02d}"


def extract_knowledge(segments: list[dict[str, Any]], known_asset_tags: set[str], asset_names: dict[str, str] | None = None,
                      org_id: str | None = None) -> Extraction:
    """LLM extraction when configured (with verification), otherwise rules. Never raises."""
    if llm_configured():
        try:
            res = LLMExtractor().extract(segments, known_asset_tags, asset_names, org_id=org_id)
            if res is not None and (res.procedures or res.symptoms or res.safety):
                return res
        except Exception:  # pragma: no cover - defensive; fall back to rules
            pass
    return RuleExtractor().extract(segments, known_asset_tags, asset_names)
