_Measured 2026-09-27 16:06 UTC · LLM: `local-rules` · embeddings: `local-hash-v1` · database: `sqlite`_

### Grounded question answering

| Metric | Value | Definition |
|---|---|---|
| Retrieval recall@8 | 100% | Answerable questions whose expected source record is in the top-8 fused hits |
| Answer accuracy | 92% | Answered, correct machine, and all expected key terms present in the steps |
| Refusal accuracy | 100% | Unanswerable questions correctly answered with “insufficient verified knowledge” |
| Citation accuracy | 100% | Evidence items that come from the expected source record (or are safety evidence) |
| Unsupported-step rate | 0% | Answer steps whose cited quotes do not lexically support them (≥50% token overlap) |
| Hallucination rate | 0% | (Unsupported steps + unanswerable questions that were answered) / (steps + unanswerable questions) |
| Safety recall | 100% | Answers that include the expected safety warning |
| Conflict surfacing | 100% | Questions on a conflicted procedure where the conflict is shown |
| Mean groundedness score | 0.773 vs 0.071 | Answerable vs unanswerable questions |
| Latency p50 / p95 | 11.0 ms / 14.3 ms | End-to-end `answer_question` on the eval machine |

20 questions (12 answerable, 8 unanswerable).

| Case | Question | Result | Groundedness | Cited |
|---|---|---|---|---|
| qa01 | Pump P-103 is making a grinding sound during startup. What should I check? | ✅ answered | HIGH (0.74) | LM-1042 |
| qa02 | P-103 grinds when it starts up | ✅ answered | HIGH (0.836) | LM-1042 |
| qa03 | what do I inspect first when the hydraulic pump on line 3 is noisy at start | ✅ answered | MEDIUM (0.807) | LM-1042 |
| qa04 | P-103 discharge pressure below normal range | ✅ answered | MEDIUM (0.609) | LM-1042 |
| qa05 | CNC-07 spindle is squealing at high speed | ✅ answered | HIGH (0.848) | LM-1043 |
| qa06 | Spindle on the CNC machining centre screeches at 12000 rpm, what should I check? | ❌ insufficient | INSUFFICIENT (0.327) | — |
| qa07 | CP-02 compressor is short cycling | ✅ answered | HIGH (0.931) | LM-1044 |
| qa08 | Air compressor CP-02 is overheating | ✅ answered | HIGH (0.886) | LM-1044 |
| qa09 | HP-01 ram is drifting down during the hold | ✅ answered | HIGH (0.906) | LM-1045 |
| qa10 | The hydraulic press ram creeps down at top dead centre | ✅ answered | MEDIUM (0.657) | LM-1045 |
| qa11 | CV-04 belt is mistracking, what should I check first? | ✅ answered | MEDIUM (0.956) | LM-1046 |
| qa12 | conveyor CV-04 belt drifting to one side | ✅ answered | MEDIUM (0.779) | LM-1046 |
| un01 | How do I recalibrate the vision sensor on packaging line PK-09? | ✅ insufficient | INSUFFICIENT (0.098) | — |
| un02 | What torque should I use on the CNC-07 turret bolts? | ✅ insufficient | INSUFFICIENT (0.0) | — |
| un03 | What is the capital of France? | ✅ insufficient | INSUFFICIENT (0.03) | — |
| un04 | CP-02 compressor is making a grinding sound during startup | ✅ insufficient | INSUFFICIENT (0.054) | — |
| un05 | How do I replace the PLC battery on robot RB-12? | ✅ insufficient | INSUFFICIENT (0.105) | — |
| un06 | HP-01 is hissing near the hose bundle | ✅ insufficient | INSUFFICIENT (0.027) | — |
| un07 | Conveyor CV-04 motor smells of burning | ✅ insufficient | INSUFFICIENT (0.091) | — |
| un08 | Write me a poem about pumps | ✅ insufficient | INSUFFICIENT (0.162) | — |

### Knowledge extraction (`rules-v3`, 6 held-out transcripts)

| Entity | Precision | Recall | F1 | TP / predicted / gold |
|---|---|---|---|---|
| asset tags | 1.00 | 1.00 | 1.00 | 6 / 6 / 6 |
| symptoms | 0.55 | 1.00 | 0.71 | 6 / 11 / 6 |
| failure modes | 1.00 | 1.00 | 1.00 | 5 / 5 / 5 |
| components | 0.64 | 0.82 | 0.72 | 9 / 14 / 11 |
| tools | 0.83 | 1.00 | 0.91 | 5 / 6 / 5 |
| steps | 0.90 | 0.86 | 0.88 | 18 / 20 / 21 |

Safety statement detected in 100% of transcripts.
