"""Synthetic demo factory: "NovaTech Manufacturing Plant".

EVERYTHING HERE IS SYNTHETIC DEMO DATA. People, machines, recordings and
maintenance history are fictional and flagged ``is_synthetic=True`` so the UI
labels them. Recordings have transcripts but no real audio (the UI offers
browser text-to-speech playback, labelled as synthetic).

The seed deliberately goes through the *real* pipeline: transcripts are
processed by the same extraction, structuring, indexing and conflict-detection
code as user uploads, and approvals use the same review logic.
"""

from __future__ import annotations

import logging
import os
from datetime import date, datetime, timedelta, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..ai.answer import answer_question
from ..ai.pipeline import process_record
from ..models import (
    AnswerFeedback,
    Asset,
    AuditLog,
    Conversation,
    Department,
    Document,
    KnowledgeRecord,
    MaintenanceEvent,
    Message,
    Organization,
    Plant,
    Procedure,
    ProcedureExecution,
    Recording,
    User,
)
from ..security import hash_password

logger = logging.getLogger("legacymind.seed")

DEMO_ORG_SLUG = "novatech-demo"
DEMO_PASSWORD = os.environ.get("DEMO_PASSWORD", "LegacyMind-Demo-2026")
SYNTHETIC_NOTE = "Synthetic Demo Data - fictional plant, people and machines."

PERSONAS = {
    "senior": "rajesh.kumar@novatech.demo",
    "supervisor": "amit.sharma@novatech.demo",
    "junior": "rahul.verma@novatech.demo",
    "admin": "priya.nair@novatech.demo",
}


def _dt(y: int, m: int, d: int, h: int = 10) -> datetime:
    return datetime(y, m, d, h, 0, tzinfo=timezone.utc)


def _segs(*items: tuple[float, float, str]) -> list[dict[str, Any]]:
    return [{"start": s, "end": e, "text": t} for s, e, t in items]


ASSETS = [
    dict(asset_tag="HP-01", name="Hydraulic Press", machine_type="Hydraulic press, 250 t", manufacturer="Kaveri Hydraulics",
         model="KH-250", serial_number="KH250-1187", location="Plant A / Line 1", dept="Production", installed_on=date(2009, 3, 12),
         status="operational", criticality="critical",
         description="250-tonne down-stroking press for body panels. Hydraulic unit with accumulator."),
    dict(asset_tag="P-103", name="Hydraulic Pump", machine_type="Axial piston pump", manufacturer="Siemens", model="HP-500",
         serial_number="HP500-40321", location="Plant A / Line 3", dept="Production", installed_on=date(2012, 7, 2),
         status="operational", criticality="high",
         description="Feeds the Line 3 hydraulic circuit. Normal discharge pressure 140-160 bar."),
    dict(asset_tag="CNC-07", name="CNC Machining Centre", machine_type="Vertical machining centre", manufacturer="Apex CNC Systems",
         model="VMC-850", serial_number="VMC850-2231", location="Plant B / Cell 2", dept="Machining", installed_on=date(2016, 11, 20),
         status="degraded", criticality="high", description="3-axis VMC, 12,000 rpm spindle, grease-lubricated spindle bearings."),
    dict(asset_tag="CV-04", name="Conveyor", machine_type="Flat belt conveyor, 42 m", manufacturer="Ferro Conveyors",
         model="FC-1200", serial_number="FC1200-0904", location="Plant A / Dispatch", dept="Logistics", installed_on=date(2014, 5, 6),
         status="operational", criticality="medium", description="Transfers finished panels to dispatch."),
    dict(asset_tag="CP-02", name="Air Compressor", machine_type="Rotary screw compressor, 55 kW", manufacturer="AirPro Compressors",
         model="RS-55", serial_number="RS55-7720", location="Utilities Room 1", dept="Utilities", installed_on=date(2011, 1, 18),
         status="operational", criticality="high", description="Plant compressed air, 7.5 bar. Oil-injected rotary screw."),
]

USERS = [
    dict(email=PERSONAS["senior"], full_name="Rajesh Kumar", title="Senior Technician", role="technician", years=28, dept="Production"),
    dict(email=PERSONAS["supervisor"], full_name="Amit Sharma", title="Maintenance Engineer", role="supervisor", years=14, dept="Production"),
    dict(email=PERSONAS["junior"], full_name="Rahul Verma", title="Junior Technician", role="junior_technician", years=1, dept="Production"),
    dict(email=PERSONAS["admin"], full_name="Priya Nair", title="Plant Administrator", role="admin", years=9, dept=None),
]

# (ref, title, asset, author, source_type, recorded, segments, approve)
RECORDS: list[dict[str, Any]] = [
    dict(ref="LM-1042", title="P-103 startup grinding - valve V-03", asset="P-103", author="senior", source="audio", when=_dt(2026, 8, 14), approve=True,
         segments=_segs(
             (0, 18, "This is Rajesh Kumar, senior technician, recording notes on hydraulic pump P-103 on line 3. Normal discharge pressure on this pump is 140 to 160 bar and it should run quietly after the first few seconds."),
             (18, 52, "Most of the trouble on P-103 comes from valve blockage. Over the years the inlet valve V-03 gets blocked with sludge from the reservoir, usually because the suction strainer was not cleaned on schedule."),
             (52, 100, "The motor and the coupling almost never give problems on this unit. In twelve years we changed the coupling insert only twice."),
             (100, 134, "Before any inspection on P-103, stop the pump and apply lockout/tagout, because this is a high-pressure hydraulic system. Never loosen a fitting while the accumulator is still charged; bleed off the pressure first."),
             (134, 168, "Whenever Pump P-103 produces a grinding sound during startup, first inspect Valve V-03. If pressure is below the normal range, check the valve for blockage."),
             (168, 202, "New technicians usually replace the pump when they hear that noise, but that is unnecessary. Clean the valve and the suction strainer, then restart the pump and confirm the discharge pressure is back to 140 bar."),
             (202, 225, "Use a pressure gauge on the discharge port and wear safety glasses and gloves, because hydraulic oil can be hot."),
         )),
    dict(ref="LM-1043", title="CNC-07 spindle squeal at high speed", asset="CNC-07", author="senior", source="video", when=_dt(2026, 8, 18), approve=True,
         segments=_segs(
             (0, 20, "Spindle notes for CNC-07. The spindle bearings are grease lubricated and they run at up to 12,000 rpm."),
             (20, 45, "Never reach into the enclosure while the spindle is rotating. Wait for the spindle to stop completely and lock out the main disconnect before you touch anything."),
             (45, 78, "When the CNC-07 spindle makes a squealing noise at high speed, check the spindle bearing temperature with an infrared thermometer. If the temperature is above 60 degrees, stop the machine and check the grease line for blockage."),
             (78, 104, "Then check the drawbar clamping force and inspect the tool holder taper for fretting marks."),
             (104, 130, "Chatter marks on the part usually mean a worn tool holder or loose spindle bearing, so do not just reduce the feed rate and carry on."),
         )),
    dict(ref="LM-1044", title="CP-02 short cycling and overheating", asset="CP-02", author="supervisor", source="text", when=_dt(2026, 8, 21), approve=True,
         segments=_segs(
             (None, None, "Air compressor CP-02 notes by Amit Sharma, maintenance engineer."),
             (None, None, "Before opening any panel, isolate the main power and bleed the air receiver to zero, because stored air pressure can cause serious injury."),
             (None, None, "If CP-02 is short cycling, check the pressure switch settings first. Then inspect the unloader valve and listen for air leaks on the discharge line with a leak detection spray."),
             (None, None, "When CP-02 is overheating, clean the cooler fins and check the oil level. A blocked cooler is the cause in most cases, due to dust from the dispatch area."),
         )),
    dict(ref="LM-1045", title="Knowledge Harvest interview - HP-01 Hydraulic Press", asset="HP-01", author="senior", source="interview", when=_dt(2026, 8, 25), approve=True,
         segments=_segs(
             (0, 8, "What problems occur most frequently on HP-01 (Hydraulic Press)?"),
             (8, 30, "Ram drift is the big one. When the ram is holding at top dead centre it slowly creeps down."),
             (30, 36, "What symptoms normally indicate ram drift?"),
             (36, 60, "The ram drifts during the hold, the pressure drops on the gauge and sometimes the hydraulic unit gets hot. Worn piston seals are the usual cause."),
             (60, 66, "What would an inexperienced technician usually check or do first?"),
             (66, 84, "They normally adjust the relief valve, but that is a mistake and it hides the problem."),
             (84, 90, "What should they check instead?"),
             (90, 130, "First lower the ram onto blocks and apply lockout/tagout. Then check the piston seals for leakage, and inspect the counterbalance valve. If the seals are worn, replace the seal kit."),
             (130, 136, "What safety precautions are required?"),
             (136, 160, "Never work under the ram unless it is resting on safety blocks. Bleed the accumulator to zero before opening any hydraulic line."),
         )),
    dict(ref="LM-1046", title="CV-04 belt mistracking", asset="CV-04", author="senior", source="audio", when=_dt(2026, 9, 2), approve=True,
         segments=_segs(
             (0, 25, "Conveyor CV-04 at dispatch. The most common problem is the belt drifting to one side."),
             (25, 50, "Stop the conveyor and apply lockout/tagout before touching the belt, because of pinch points at the pulleys."),
             (50, 90, "When the CV-04 belt is mistracking, check the tail pulley alignment first. Then check the belt tension on both sides with a belt tension gauge and adjust the take-up screws evenly."),
         )),
    dict(ref="LM-1047", title="CV-04 tracking - idler check", asset="CV-04", author="supervisor", source="text", when=_dt(2026, 9, 9), approve=False,
         segments=_segs(
             (None, None, "Engineering note for conveyor CV-04."),
             (None, None, "For belt mistracking on CV-04, check the idler rollers first for seized bearings and material build-up. Then clean the return idlers."),
         )),
    dict(ref="LM-1048", title="HP-01 hissing near hose bundle", asset="HP-01", author="senior", source="audio", when=_dt(2026, 9, 16), approve=False,
         segments=_segs(
             (0, 22, "Quick note on HP-01. If you hear a hissing noise near the hose bundle on the left column, that is usually an oil leak at a hose fitting."),
             (22, 50, "Never feel for a hydraulic leak with your hand, because a pinhole leak can cause an injection injury. Stop the press and bleed the pressure, then inspect the hose fittings with a flashlight and replace the damaged hose."),
         )),
]

QUESTIONS = [
    ("junior", "Pump P-103 is making a grinding sound during startup. What should I check?"),
    ("junior", "CV-04 belt is mistracking, what should I check first?"),
    ("junior", "How do I recalibrate the vision sensor on packaging line PK-09?"),
    ("junior", "CNC-07 spindle is squealing at high speed"),
]

# Synthetic "did this fix it?" feedback on the demo questions
FEEDBACK = {
    "Pump P-103 is making a grinding sound during startup. What should I check?": "resolved",
    "CNC-07 spindle is squealing at high speed": "not_resolved",
}

MAINTENANCE = [
    ("P-103", date(2026, 6, 3), "corrective", "Grinding at startup; V-03 cleaned, suction strainer cleaned. Pump not replaced.", 3.0),
    ("P-103", date(2025, 11, 12), "preventive", "Coupling insert replaced during annual PM.", 2.0),
    ("HP-01", date(2026, 7, 19), "corrective", "Ram drift; piston seal kit replaced.", 11.5),
    ("CNC-07", date(2026, 9, 10), "inspection", "Spindle squeal reported at 10k rpm; grease line partially blocked. Monitoring.", 1.5),
    ("CV-04", date(2026, 8, 28), "corrective", "Belt mistracking; tail pulley realigned.", 2.5),
    ("CP-02", date(2026, 5, 22), "preventive", "Cooler fins cleaned, separator element changed.", 4.0),
]


def demo_org(db: Session) -> Organization | None:
    return db.scalar(select(Organization).where(Organization.slug == DEMO_ORG_SLUG))


def _demo_is_current(db: Session, org: Organization) -> bool:
    """Demo data built by an older release lacks feedback/executions; rebuild it (synthetic data only)."""
    return db.scalar(select(ProcedureExecution.id).where(ProcedureExecution.org_id == org.id).limit(1)) is not None


def seed_demo(db: Session, force: bool = False) -> Organization:
    existing = demo_org(db)
    if existing and not force and _demo_is_current(db, existing):
        return existing
    if existing and not force:
        logger.info("demo_outdated_reseeding")
        force = True
    if existing and force:
        db.delete(existing)
        db.commit()

    org = Organization(name="NovaTech Manufacturing Plant (Synthetic Demo)", slug=DEMO_ORG_SLUG, is_demo=True)
    db.add(org)
    db.flush()
    plant = Plant(org_id=org.id, name="NovaTech Plant A/B", location="Synthetic - Pune Industrial Estate")
    db.add(plant)
    db.flush()
    deps: dict[str, Department] = {}
    for name in ("Production", "Machining", "Logistics", "Utilities"):
        d = Department(org_id=org.id, plant_id=plant.id, name=name)
        db.add(d)
        deps[name] = d
    db.flush()

    users: dict[str, User] = {}
    pw = hash_password(DEMO_PASSWORD)
    for key, u in zip(PERSONAS, USERS):
        user = User(org_id=org.id, email=u["email"], full_name=u["full_name"], title=u["title"], role=u["role"],
                    years_experience=u["years"], password_hash=pw, department_id=deps[u["dept"]].id if u["dept"] else None,
                    created_at=_dt(2026, 7, 1))
        db.add(user)
        users[key] = user
    db.flush()

    assets: dict[str, Asset] = {}
    for a in ASSETS:
        spec = dict(a)
        dept = spec.pop("dept")
        asset = Asset(org_id=org.id, plant_id=plant.id, department_id=deps[dept].id, is_synthetic=True, created_at=_dt(2026, 7, 1), **spec)
        db.add(asset)
        assets[asset.asset_tag] = asset
    db.flush()

    for tag, when, kind, summary, hours in MAINTENANCE:
        db.add(MaintenanceEvent(org_id=org.id, asset_id=assets[tag].id, occurred_on=when, event_type=kind, summary=summary,
                                technician_id=users["senior"].id, downtime_hours=hours))

    # a synthetic reference document attached to P-103 (plain text, processed by the real extractor path)
    from ..services.storage import get_storage

    doc_text = ("P-103 quick reference (SYNTHETIC DEMO DOCUMENT)\nModel HP-500 axial piston pump. Normal discharge pressure 140-160 bar.\n"
                "Suction strainer cleaning interval: every 500 running hours.\nHydraulic oil: ISO VG 46.")
    key = f"{org.id}/assets/{assets['P-103'].id}/p103-quick-reference.txt"
    get_storage().put(key, doc_text.encode(), "text/plain")
    db.add(Document(org_id=org.id, asset_id=assets["P-103"].id, kind="txt", category="manual", filename="p103-quick-reference.txt",
                    mime_type="text/plain", size_bytes=len(doc_text), storage_key=key, extracted_text=doc_text, extraction_method="utf8"))
    db.commit()

    from ..api.reviews import DecisionIn, _apply_procedure_decision

    for spec in RECORDS:
        author = users[spec["author"]]
        rec = KnowledgeRecord(
            org_id=org.id, ref=spec["ref"], title=spec["title"], asset_id=assets[spec["asset"]].id, contributor_id=author.id,
            source_type=spec["source"], segments=spec["segments"], transcript=" ".join(s["text"] for s in spec["segments"]),
            transcript_source="synthetic", recorded_at=spec["when"], created_at=spec["when"], is_synthetic=True,
            notes=SYNTHETIC_NOTE,
        )
        db.add(rec)
        db.flush()
        if spec["source"] in ("audio", "video"):
            last = spec["segments"][-1]["end"]
            db.add(Recording(org_id=org.id, record_id=rec.id, kind=spec["source"], filename=f"{spec['ref'].lower()}-synthetic.webm",
                             mime_type="audio/webm" if spec["source"] == "audio" else "video/webm", storage_key=None,
                             duration_s=float(last) if last else None, is_synthetic=True))
        db.commit()
        db.refresh(rec)
        process_record(db, rec)
        db.add(AuditLog(org_id=org.id, user_id=author.id, action="knowledge.capture", entity_type="knowledge_record", entity_id=rec.id,
                        created_at=spec["when"], details={"synthetic": True}))
        if spec["approve"]:
            for p in db.scalars(select(Procedure).where(Procedure.record_id == rec.id)).all():
                _apply_procedure_decision(db, p, DecisionIn(decision="approve", comment="Verified on the shop floor (synthetic demo)."), users["supervisor"])
                p.approved_at = spec["when"] + timedelta(days=1)
                db.add(AuditLog(org_id=org.id, user_id=users["supervisor"].id, action="review.procedure.approve", entity_type="procedure",
                                entity_id=p.id, created_at=spec["when"] + timedelta(days=1), details={"synthetic": True}))
            rec.review_status = "approved"
            from ..ai.pipeline import sync_record_chunk_approval

            sync_record_chunk_approval(db, rec)
        db.commit()

    # a few real assistant interactions so analytics are not empty (answers are generated live by the system)
    for persona, q in QUESTIONS:
        u = users[persona]
        conv = Conversation(org_id=org.id, user_id=u.id, title=q[:80], created_at=_dt(2026, 9, 20))
        db.add(conv)
        db.flush()
        ans = answer_question(db, org.id, q)
        db.add(Message(conversation_id=conv.id, org_id=org.id, role="user", content=q, created_at=_dt(2026, 9, 20)))
        amsg = Message(conversation_id=conv.id, org_id=org.id, role="assistant", content=ans["summary"], answer=ans,
                       groundedness=ans["groundedness"]["level"], escalated=ans["escalation"]["required"],
                       asset_id=(ans.get("machine") or {}).get("id"), created_at=_dt(2026, 9, 20, 11))
        db.add(amsg)
        db.flush()
        outcome = FEEDBACK.get(q)
        if outcome and ans["status"] == "answered":
            db.add(AnswerFeedback(org_id=org.id, message_id=amsg.id, user_id=u.id, outcome=outcome,
                                  asset_id=(ans.get("machine") or {}).get("id"), procedure_id=(ans.get("procedure") or {}).get("id"),
                                  comment="Synthetic demo feedback.", created_at=_dt(2026, 9, 20, 12)))
    db.commit()

    # one completed guided execution of the approved P-103 procedure (synthetic)
    p103 = db.scalar(select(Procedure).where(Procedure.asset_id == assets["P-103"].id, Procedure.status == "approved"))
    if p103 is not None:
        from ..models import SafetyWarning

        warn_ids = [w.id for w in db.scalars(select(SafetyWarning).where(SafetyWarning.procedure_id == p103.id,
                                                                            SafetyWarning.status == "approved")).all()]
        finished = _dt(2026, 9, 21, 9)
        ev = MaintenanceEvent(org_id=org.id, asset_id=assets["P-103"].id, occurred_on=finished.date(), event_type="corrective",
                              summary=f"Guided procedure {p103.ref} ({p103.title}) via LegacyMind: {len(p103.steps)}/{len(p103.steps)} steps, problem resolved. Notes: V-03 partially blocked, cleaned.",
                              technician_id=users["junior"].id, downtime_hours=1.5)
        db.add(ev)
        db.flush()
        db.add(ProcedureExecution(org_id=org.id, procedure_id=p103.id, asset_id=assets["P-103"].id, user_id=users["junior"].id,
                                  status="completed", outcome="resolved", procedure_version=p103.version,
                                  safety_acknowledged=warn_ids + ["lockout_tagout"],
                                  step_states=[{"order": s["order"], "done": True, "at": finished.isoformat()} for s in p103.steps],
                                  notes="V-03 partially blocked, cleaned. (synthetic)", finished_at=finished,
                                  maintenance_event_id=ev.id, created_at=finished - timedelta(minutes=40)))
        db.commit()
    logger.info("demo_seeded", extra={"extra_fields": {"org_id": org.id}})
    return org
