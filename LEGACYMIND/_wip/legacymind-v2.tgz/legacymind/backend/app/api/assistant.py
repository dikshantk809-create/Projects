from __future__ import annotations

from fastapi import APIRouter, Depends, Query, Request
from typing import Literal

from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..ai.answer import answer_question, title_from_question
from ..db import get_db
from ..deps import audit, rate_limit, require
from ..errors import AppError, NotFound
from ..models import AnswerFeedback, Asset, Conversation, Message, User
from ..serializers import iso
from ..validation import CleanText

router = APIRouter(prefix="/api/assistant", tags=["assistant"])


class AskIn(BaseModel):
    question: CleanText = Field(min_length=3, max_length=1000)
    conversation_id: str | None = None
    asset_id: str | None = None


def _msg_out(m: Message, feedback: AnswerFeedback | None = None) -> dict:
    return {"id": m.id, "role": m.role, "content": m.content, "answer": m.answer, "groundedness": m.groundedness,
            "escalated": m.escalated, "created_at": iso(m.created_at),
            "feedback": {"outcome": feedback.outcome, "comment": feedback.comment} if feedback else None}


class FeedbackIn(BaseModel):
    outcome: Literal["resolved", "partially", "not_resolved", "wrong_answer"]
    comment: CleanText = Field(default="", max_length=2000)


@router.post("/ask", dependencies=[Depends(rate_limit("assistant", 40))])
def ask(body: AskIn, request: Request, user: User = Depends(require("assistant:use")), db: Session = Depends(get_db)) -> dict:
    asset_id = body.asset_id
    if asset_id:
        a = db.get(Asset, asset_id)
        if a is None or a.org_id != user.org_id:
            raise AppError("Unknown asset.", code="invalid_asset", status_code=422)
    conv = None
    if body.conversation_id:
        conv = db.get(Conversation, body.conversation_id)
        if conv is None or conv.user_id != user.id:
            raise NotFound("Conversation not found.")
        asset_id = asset_id or conv.asset_id
    if conv is None:
        conv = Conversation(org_id=user.org_id, user_id=user.id, asset_id=asset_id, title=title_from_question(body.question))
        db.add(conv)
        db.flush()
    db.add(Message(conversation_id=conv.id, org_id=user.org_id, role="user", content=body.question, asset_id=asset_id))
    answer = answer_question(db, user.org_id, body.question, asset_id)
    msg = Message(
        conversation_id=conv.id, org_id=user.org_id, role="assistant", content=answer["summary"], answer=answer,
        groundedness=answer["groundedness"]["level"], asset_id=(answer.get("machine") or {}).get("id"),
        escalated=bool(answer["escalation"]["required"]),
    )
    db.add(msg)
    audit(db, action="assistant.ask", user=user, entity_type="conversation", entity_id=conv.id, request=request,
          details={"groundedness": msg.groundedness, "status": answer["status"]})
    db.commit()
    return {"conversation_id": conv.id, "message": _msg_out(msg)}


@router.get("/conversations")
def conversations(limit: int = Query(default=30, ge=1, le=100), user: User = Depends(require("assistant:use")), db: Session = Depends(get_db)) -> dict:
    rows = db.scalars(select(Conversation).where(Conversation.user_id == user.id).order_by(Conversation.created_at.desc()).limit(limit)).all()
    return {"items": [{"id": c.id, "title": c.title, "asset_id": c.asset_id, "created_at": iso(c.created_at)} for c in rows]}


@router.get("/conversations/{conversation_id}")
def conversation(conversation_id: str, user: User = Depends(require("assistant:use")), db: Session = Depends(get_db)) -> dict:
    c = db.get(Conversation, conversation_id)
    if c is None or c.user_id != user.id:
        raise NotFound("Conversation not found.")
    msgs = db.scalars(select(Message).where(Message.conversation_id == c.id).order_by(Message.created_at)).all()
    fb = {f.message_id: f for f in db.scalars(select(AnswerFeedback).where(
        AnswerFeedback.message_id.in_([m.id for m in msgs]), AnswerFeedback.user_id == user.id)).all()} if msgs else {}
    return {"id": c.id, "title": c.title, "asset_id": c.asset_id, "messages": [_msg_out(m, fb.get(m.id)) for m in msgs]}


@router.post("/messages/{message_id}/feedback")
def feedback(message_id: str, body: FeedbackIn, request: Request, user: User = Depends(require("assistant:use")),
             db: Session = Depends(get_db)) -> dict:
    """“Did this fix it?” — closes the loop between answers and real outcomes on the shop floor."""
    m = db.get(Message, message_id)
    conv = db.get(Conversation, m.conversation_id) if m else None
    if m is None or conv is None or conv.user_id != user.id or m.role != "assistant":
        raise NotFound("Answer not found.")
    ans = m.answer or {}
    f = db.scalar(select(AnswerFeedback).where(AnswerFeedback.message_id == m.id, AnswerFeedback.user_id == user.id))
    if f is None:
        f = AnswerFeedback(org_id=user.org_id, message_id=m.id, user_id=user.id, outcome=body.outcome)
        db.add(f)
    f.outcome = body.outcome
    f.comment = body.comment
    f.asset_id = (ans.get("machine") or {}).get("id") or m.asset_id
    f.procedure_id = (ans.get("procedure") or {}).get("id")
    audit(db, action="assistant.feedback", user=user, entity_type="message", entity_id=m.id, request=request,
          details={"outcome": body.outcome, "procedure": (ans.get("procedure") or {}).get("ref")})
    db.commit()
    return _msg_out(m, f)
