"""Guided execution, answer feedback, knowledge-at-risk, harvest suggestions, global search."""

import time


def _ready_procedure(client, tag="GX-1", risk_text=True):
    client.post("/api/assets", json={"asset_tag": tag, "name": f"Machine {tag}", "criticality": "high"})
    notes = (f"Before touching {tag}, stop the machine and apply lockout/tagout because of high-pressure oil. "
             f"When {tag} is overheating, check the oil level first. Then inspect the cooler for blockage.")
    ref = client.post("/api/knowledge/records", data={"title": "t", "source_type": "text", "notes": notes}).json()["ref"]
    for _ in range(50):
        rec = client.get(f"/api/knowledge/records/{ref}").json()
        if rec["processing_status"] == "processed":
            break
        time.sleep(0.1)
    pid = rec["procedures"][0]["id"]
    return pid, rec


def test_execution_requires_approved_procedure_and_safety_gate(client, fresh_org):
    pid, _ = _ready_procedure(client)
    r = client.post("/api/executions", json={"procedure_id": pid})
    assert r.status_code == 409 and r.json()["error"]["code"] == "procedure_not_approved"
    client.post(f"/api/reviews/procedures/{pid}", json={"decision": "approve", "comment": "ok"})
    pre = client.get(f"/api/executions/preflight/{pid}").json()
    assert pre["executable"] and pre["lockout_required"] and pre["safety_warnings"]
    warn_ids = [w["id"] for w in pre["safety_warnings"]]
    r = client.post("/api/executions", json={"procedure_id": pid, "safety_acknowledged": [], "lockout_confirmed": True})
    assert r.json()["error"]["code"] == "safety_not_acknowledged"
    r = client.post("/api/executions", json={"procedure_id": pid, "safety_acknowledged": warn_ids, "lockout_confirmed": False})
    assert r.json()["error"]["code"] == "lockout_not_confirmed"
    e = client.post("/api/executions", json={"procedure_id": pid, "safety_acknowledged": warn_ids, "lockout_confirmed": True})
    assert e.status_code == 201
    ex = e.json()
    assert ex["progress"] == {"done": 0, "total": len(ex["steps"]), "percent": 0}
    assert ex["steps"][0]["evidence"]["quote"], "each step carries its source evidence"


def test_execution_steps_in_order_and_completion_logs_maintenance(client, fresh_org):
    pid, _ = _ready_procedure(client, "GX-2")
    client.post(f"/api/reviews/procedures/{pid}", json={"decision": "approve", "comment": "ok"})
    pre = client.get(f"/api/executions/preflight/{pid}").json()
    ex = client.post("/api/executions", json={"procedure_id": pid, "safety_acknowledged": [w["id"] for w in pre["safety_warnings"]],
                                               "lockout_confirmed": True}).json()
    steps = ex["steps"]
    if len(steps) > 1:
        bad = client.patch(f"/api/executions/{ex['id']}/steps/{steps[1]['order']}", json={"done": True})
        assert bad.json()["error"]["code"] == "step_out_of_order"
    early = client.post(f"/api/executions/{ex['id']}/complete", json={"outcome": "resolved"})
    assert early.json()["error"]["code"] == "steps_incomplete"
    for s in steps:
        r = client.patch(f"/api/executions/{ex['id']}/steps/{s['order']}", json={"done": True, "note": "ok"})
        assert r.status_code == 200
    done = client.post(f"/api/executions/{ex['id']}/complete", json={"outcome": "resolved", "notes": "cooler was blocked"}).json()
    assert done["status"] == "completed" and done["progress"]["percent"] == 100 and done["maintenance_event_id"]
    hist = client.get("/api/assets/GX-2").json()["maintenance_history"]
    assert "Guided procedure" in hist[0]["summary"] and "resolved" in hist[0]["summary"]
    assert client.post(f"/api/executions/{ex['id']}/complete", json={"outcome": "resolved"}).status_code == 409
    items = client.get("/api/executions").json()["items"]
    assert items[0]["id"] == ex["id"] and items[0]["done"] == len(steps)


def test_answer_feedback_roundtrip(as_junior):
    r = as_junior.post("/api/assistant/ask", json={"question": "Pump P-103 is making a grinding sound during startup. What should I check?"}).json()
    mid = r["message"]["id"]
    fb = as_junior.post(f"/api/assistant/messages/{mid}/feedback", json={"outcome": "not_resolved", "comment": "still grinding"})
    assert fb.status_code == 200 and fb.json()["feedback"]["outcome"] == "not_resolved"
    again = as_junior.post(f"/api/assistant/messages/{mid}/feedback", json={"outcome": "resolved"})
    assert again.json()["feedback"]["outcome"] == "resolved", "feedback is updated, not duplicated"
    conv = as_junior.get(f"/api/assistant/conversations/{r['conversation_id']}").json()
    assert conv["messages"][-1]["feedback"]["outcome"] == "resolved"
    assert as_junior.post("/api/assistant/messages/nope/feedback", json={"outcome": "resolved"}).status_code == 404


def test_knowledge_risk(as_supervisor):
    risk = as_supervisor.get("/api/insights/knowledge-risk").json()
    by_tag = {a["asset_tag"]: a for a in risk["assets"]}
    # P-103 knowledge comes only from Rajesh Kumar (28 yrs) on a high-criticality pump
    assert by_tag["P-103"]["expert_count"] == 1 and by_tag["P-103"]["risk"] == "critical"
    assert any(e["name"] == "Rajesh Kumar" and "P-103" in e["sole_source_assets"] for e in risk["single_source_experts"])
    summary = as_supervisor.get("/api/analytics/summary").json()
    assert summary["knowledge_risk"]["assets_at_risk"] >= 1


def test_harvest_suggestions(as_supervisor):
    items = as_supervisor.get("/api/harvest/suggestions").json()["items"]
    assert items and items == sorted(items, key=lambda x: -x["priority"])
    tags = {i["asset_tag"] for i in items}
    assert "CNC-07" in tags, "CNC-07 has a 'not resolved' answer in the demo"
    cnc = next(i for i in items if i["asset_tag"] == "CNC-07")
    assert any("did not fix" in r for r in cnc["reasons"]) and cnc["suggested_questions"]


def test_global_search(as_supervisor, as_junior):
    r = as_supervisor.get("/api/search", params={"q": "p-103"}).json()
    assert r["assets"][0]["asset_tag"] == "P-103"
    assert any(x["ref"] == "LM-1042" for x in r["records"])
    assert as_supervisor.get("/api/search", params={"q": ""}).status_code == 422


def test_junior_search_hides_pending(as_junior):
    r = as_junior.get("/api/search", params={"q": "hissing"}).json()
    assert not any(x["ref"] == "LM-1048" for x in r["records"])


def test_analytics_detail_includes_feedback_and_executions(as_supervisor):
    d = as_supervisor.get("/api/analytics/detail").json()
    assert d["feedback"]["total"] >= 2
    assert d["executions"]["by_outcome"].get("resolved", 0) >= 1
