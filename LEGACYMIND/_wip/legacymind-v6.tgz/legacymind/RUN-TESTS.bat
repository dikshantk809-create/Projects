@echo off
setlocal EnableExtensions
title LegacyMind - Tests
cd /d "%~dp0"
if not exist "%~dp0logs" mkdir "%~dp0logs"
if not exist "backend\.venv\Scripts\python.exe" (
  echo Run START-LEGACYMIND.bat once first ^(it installs everything^).
  pause & exit /b 1
)
set "L=%~dp0logs"

echo === Installing backend test tools ...
cd /d "%~dp0backend"
".venv\Scripts\python.exe" -m pip install -r requirements-dev.txt > "%L%\tests-setup.log" 2>&1
if errorlevel 1 ( type "%L%\tests-setup.log" & echo [ERROR] pip install failed & pause & exit /b 1 )

echo === Backend tests (logs\tests-backend.log) ...
".venv\Scripts\python.exe" -m pytest -q -p no:cacheprovider > "%L%\tests-backend.log" 2>&1
set "R1=%errorlevel%"
powershell -NoProfile -Command "Get-Content '%L%\tests-backend.log' -Tail 25"

echo === AI evaluation (logs\eval.log, backend\eval\results.md) ...
".venv\Scripts\python.exe" -m eval.run_eval > "%L%\eval.log" 2>&1
set "R2=%errorlevel%"

echo === Frontend unit tests (logs\tests-frontend.log) ...
cd /d "%~dp0frontend"
call npm test > "%L%\tests-frontend.log" 2>&1
set "R3=%errorlevel%"

echo === Frontend type check + production build (logs\build-frontend.log) ...
call npm run build > "%L%\build-frontend.log" 2>&1
set "R4=%errorlevel%"

echo === Frontend lint (logs\lint-frontend.log) ...
call npm run lint > "%L%\lint-frontend.log" 2>&1
set "R5=%errorlevel%"

cd /d "%~dp0backend"
echo === Backend lint (logs\lint-backend.log) ...
".venv\Scripts\python.exe" -m ruff check app tests eval > "%L%\lint-backend.log" 2>&1
set "R6=%errorlevel%"

(
echo backend_tests=%R1%
echo ai_eval=%R2%
echo frontend_tests=%R3%
echo frontend_build=%R4%
echo frontend_lint=%R5%
echo backend_lint=%R6%
) > "%L%\summary.txt"

echo.
echo ================================================================
type "%L%\summary.txt"
echo   (0 = passed). Details in the logs folder.
echo ================================================================
pause
