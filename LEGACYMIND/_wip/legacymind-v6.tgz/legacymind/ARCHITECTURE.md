# LegacyMind architecture

This document explains how LegacyMind is built and **why** each decision was made. The guiding rules: *reliability over complexity, grounded AI over impressive-but-fake AI, evidence over hallucination.*

## 1. System overview

```
 ┌──────────────────────────── Browser (React + TypeScript) ─────────────────────────────┐
 │ Landing · Dashboard · Assets/QR · Capture (MediaRecorder + Web Speech) · Library       │
 │ Assistant · Knowledge Harvest · Graph · Supervisor Review · Analytics · Administration │
 └───────────────────────────────┬────────────────────────────────────────────────────────┘
                                 │ same-origin /api  (httpOnly session cookie)
                ┌────────────────▼────────────────┐   nginx (Docker) / Vercel rewrite /
                │        FastAPI application       │   the API itself (single container)
                │ auth · RBAC · rate limit · audit │
                │ validation · error IDs · logs    │
                └──┬───────────┬──────────┬────────┘
                   │           │          │
     ┌─────────────▼──┐  ┌─────▼──────┐ ┌─▼─────────────────────┐
     │ Processing      │  │ Retrieval  │ │ Provider abstraction   │
     │ pipeline        │  │ vector     │ │ LLM: OpenAI/Anthropic/ │
     │ (10 stages)     │  │ + BM25     │ │      Ollama/none       │
     │                 │  │ + graph    │ │ STT: Whisper/browser   │
     └───────┬─────────┘  │ → RRF      │ │ Embed: local/OpenAI    │
             │            └─────┬──────┘ └────────────────────────┘
     ┌───────▼──────────────────▼───────────────────────────┐
     │ PostgreSQL 16 — system of record                      │
     │  relational knowledge graph · pgvector embeddings     │
     │  traceability (knowledge_sources) · audit · reviews   │
     └───────────────────────────────────────────────────────┘
       Object storage: local volume or S3-compatible (MinIO/R2/S3)
       Optional: Neo4j replica (Cypher export/sync)
```

## 2. Key decisions

| Decision | Choice | Why |
|---|---|---|
| API framework | **FastAPI** (Python 3.11) | Typed request validation (Pydantic), OpenAPI docs for free, the Python AI ecosystem. |
| Database | **PostgreSQL + pgvector**, SQLite for dev/tests | One transactional store for records, graph, vectors and audit — no cross-store consistency problems. SQLite keeps local dev and CI dependency-free. |
| Knowledge graph | **Relational graph in PostgreSQL**; Neo4j optional replica | The spec allows Neo4j "if practical". A second database would make deployment fragile and create consistency issues. Tables + foreign keys *are* the graph; `/api/graph/cypher` exports it and `/api/graph/neo4j/sync` pushes it when `NEO4J_URI` is set. The app never depends on Neo4j. |
| Vector search | **pgvector** (`<=>` cosine) on Postgres, **numpy** brute-force elsewhere | Same `VectorType` column works on both. Brute force is exact and fast enough for tens of thousands of chunks; pgvector scales further. |
| Keyword search | **In-process BM25** with an industrial synonym lexicon, cached per org | Exact tags (`P-103`, `V-03`) matter more than semantics in maintenance; BM25 with tag-preserving tokenisation handles them. Cache invalidates on chunk count / approval changes. |
| Fusion | **Reciprocal-rank fusion** (vector 1.0, BM25 1.0, graph 1.3) + same-asset boost | Rank-based fusion avoids calibrating incomparable scores. |
| LLM access | Plain HTTPS via `httpx` (no vendor SDKs), retries with backoff, timeouts, request log | Small dependency surface; one code path for OpenAI, Anthropic and Ollama. |
| No-key mode | Deterministic `rules-v1` extractor, extractive answers, offline hashing embeddings | The product must be demonstrable without an API key **without pretending**. Every surface labels which mode is active. |
| Background work | FastAPI `BackgroundTasks`, per-stage status persisted in the record | No queue infrastructure for the MVP; status is durable and visible. A worker queue (e.g. RQ/Celery) is a drop-in replacement of `run_pipeline`. |
| Auth | Signed JWT in an **httpOnly, SameSite=Lax cookie**, scrypt hashes, `token_version` revocation | Same-origin deployment (nginx / Vercel rewrite / single container) means no tokens in JS-readable storage and no CORS for the UI. |
| Frontend | **React + Vite + TypeScript**, hand-written CSS design system, self-hosted fonts | Fast, no UI-kit look, works offline on a plant network (no CDN dependencies). |

## 3. Data model

Core tables (see `backend/app/models.py`, migration `backend/migrations/versions/`):

- **Tenancy & identity:** `organizations`, `plants`, `departments`, `users` (role, `token_version`).
- **Assets:** `assets` (tag unique per org, status, criticality, `is_synthetic`), `components`, `maintenance_events`.
- **Capture:** `knowledge_records` (ref `LM-1042`, source type, processing status + stages, review status, transcript + timed `segments`, extraction JSON, `ai_version`), `recordings`, `documents`.
- **Structured knowledge (graph nodes):** `failure_modes` (+ causes), `symptoms`, `failure_mode_symptoms` (edge), `procedures` (ref `PR-103-01`, steps with per-step source quote/timestamps, risk, status, version, approver), `safety_warnings`.
- **Traceability:** `knowledge_sources` — for every structured fact: record, recording/document, technician, `start_s`/`end_s`, verbatim quote, confidence, AI version.
- **Retrieval:** `knowledge_chunks` — transcript windows and procedure cards with embeddings and an `approved` flag.
- **Governance:** `knowledge_conflicts`, `reviews`, `audit_logs`, `ai_request_logs`.
- **Assistant & harvest:** `conversations`, `messages` (full answer JSON stored for audit), `harvest_sessions`.

Indexes cover org scoping, review queues (`org_id, review_status`), procedure lookups (`asset_id, status`), chunk approval (`org_id, approved`), traceability (`entity_type, entity_id`) and audit time ranges.

### Graph model

```
(Technician)-[:CONTRIBUTED]->(KnowledgeRecord)-[:SOURCE_OF]->(Procedure)
(Asset)-[:HAS_COMPONENT]->(Component)
(Asset)-[:HAS_FAILURE_MODE]->(FailureMode)-[:HAS_SYMPTOM]->(Symptom)
(FailureMode)-[:RESOLVED_BY]->(Procedure)-[:REQUIRES_SAFETY]->(SafetyWarning)
(Procedure)-[:CONFLICTS_WITH]->(Procedure)          # open conflicts only
```

## 4. Processing pipeline

`backend/app/ai/pipeline.py` — each stage writes `{name, status, detail, at}` so the UI shows real progress, and a failure never leaves a record stuck in “processing”.

1. **Preprocessing** — collect files; extract document text (pypdf, python-docx, UTF-8, Tesseract OCR when installed).
2. **Transcription** — client-supplied timed segments (browser speech) → Whisper (if configured) → notes/documents. With none of these the record is `needs_transcript`; a technician can type it. Nothing is invented.
3–6. **Entity, procedure, failure-mode and safety extraction** — LLM extractor (every item must carry a verbatim quote that is located in the transcript; unlocatable or unsupported items are discarded and counted) or the `rules-v1` extractor (pattern/gazetteer; every item is a literal span). Items inherit the timestamps of their source sentence.
7. **Machine mapping** — explicit asset, else tags/names mentioned in the transcript.
8. **Structuring** — components, failure modes (+causes), symptoms and edges, procedure cards (`pending_review`), safety warnings, and `knowledge_sources` rows for every fact.
9. **Indexing** — transcript windows (~80 words, keeping timestamps) and procedure cards are embedded into `knowledge_chunks`.
10. **Conflict detection** — procedures for the same asset and problem (shared failure mode or ≥0.3 symptom Jaccard) whose first *diagnostic* step targets a different component (safety prep such as LOTO is skipped) open a `knowledge_conflict`.

## 5. Retrieval and grounded answering

`backend/app/ai/retrieval.py`, `backend/app/ai/answer.py`.

1. **Query analysis** — asset tags/names (registered vs unknown tags), component tags, content tokens.
2. **Candidates** — vector top-40, BM25 top-40, graph: asset → approved procedures scored by symptom / failure-mode / step overlap, plus the source-transcript chunks of those procedures.
3. **Fusion** — RRF; same-asset boost; **strict asset scoping**: if the question names an asset, evidence from other machines is excluded (and reported as “related knowledge exists for other machines, not applicable without verification”).
4. **Groundedness** — `0.45·term coverage + 0.25·vector similarity + 0.30·graph match` (×0.85 when no asset is identified) → HIGH / MEDIUM / LOW / INSUFFICIENT with a human-readable explanation.
5. **Answer composition**
   - *Refusal* when: unknown asset tag, no approved evidence for a named asset, or groundedness INSUFFICIENT → the standard message + escalation.
   - *Extractive* (no LLM): steps of the best approved procedure card, each citing its source quote and timestamp.
   - *LLM-grounded*: the model may only use evidence blocks; each step must cite evidence IDs; steps whose citations are invalid or whose text is not supported (<50% token overlap) are **removed and counted**.
   - **Safety warnings are pulled from approved database rows, never generated**, plus a fixed, labelled plant-policy notice.
   - Open conflicts on the chosen procedure are shown side by side, cap groundedness at MEDIUM and force escalation. High/critical-risk procedures always flag “Supervisor review required”.
6. **Evidence** — each citation carries record ref, technician, date, timestamp range, quote, recording ID, synthetic flag and AI version; the UI plays the exact slice of the recording.

Only chunks with `approved=true` are retrievable. Approving a procedure (or record) flips its chunks; rejecting removes them from retrieval.

## 6. Knowledge Harvest agent

`backend/app/ai/harvest.py`. State: asked questions, coverage per area (Machine Basics, Failure Modes, Troubleshooting, Safety, Rare Failures), extracted symptoms/failure modes/steps. Each answer is scored with the rules extractor; follow-up policy:
failure mode without symptoms → *“What symptoms normally indicate X?”*; symptom without steps → *“When you notice X, what do you check first?”*; → *“What would an inexperienced technician usually check first?”* → *“What should they check instead?”*; steps without safety → *“What safety precautions are required before you …?”*; otherwise the lowest-coverage area. With an LLM configured, the model proposes the next question (validated: must be a question, bounded length, valid category) and the rules policy is the fallback. Finishing converts the interview into a timed `interview` record that goes through the normal pipeline and review.

## 7. Security architecture

See [SECURITY.md](SECURITY.md). Summary: scrypt password hashes; signed short-lived session tokens in httpOnly cookies with server-side revocation (`token_version`); RBAC permission matrix enforced per endpoint; strict org scoping on every query; upload allow-list + magic-byte + MIME + size checks and sanitised filenames; path-traversal-safe storage keys; security headers and CSP; CORS allow-list; per-IP rate limits (stricter on auth); audit log of every write; error IDs instead of stack traces; secrets only from the environment.

## 8. Observability

- JSON structured logs with request IDs (`X-Request-ID` propagated/generated), access logs with latency.
- `/health` (liveness, no dependencies) and `/ready` (database, migration head, storage writable; config warnings).
- `ai_request_logs`: provider, model, status, latency, tokens, error — visible in Analytics.
- Error-monitoring hook (`observability.register_error_hook`) to plug in Sentry or similar.
- Pipeline stage status per record.

## 9. Deployment topologies

**Cloud (implemented):** Vercel (UI, rewrites `/api` to the API) + Render/Railway (API container) + managed PostgreSQL with pgvector + S3-compatible storage + external LLM API. Or a single container (root `Dockerfile`) serving UI and API from one origin. See [DEPLOYMENT.md](DEPLOYMENT.md).

**On-prem / edge (designed, not validated on plant hardware):**

```
 Factory network (no internet required)
 ┌──────────────────────────────────────────────┐
 │ docker compose --profile local-llm           │
 │  frontend (nginx) → backend (FastAPI)        │
 │  postgres + pgvector (local vector DB)       │
 │  ollama (local SLM, e.g. llama3.1:8b)        │
 │  EMBEDDING_PROVIDER=local (offline hashing)  │
 │  STORAGE_BACKEND=local or MinIO              │
 └──────────────────────────────────────────────┘
```

What is real today: the Ollama provider path, offline embeddings, local storage, self-hosted fonts and no CDN dependencies, Docker Compose profiles. What is not yet done: offline Whisper (e.g. faster-whisper), local semantic embedding models, hardware sizing, and validation on an air-gapped site. Browser speech recognition in Chrome uses a cloud service, so fully offline capture needs server-side local STT.

## 10. Future extensions

The data model leaves room for these without schema upheaval; **none is implemented in the MVP**:

- **Computer vision / equipment recognition:** image documents are already stored per asset/category; a vision model can populate `components` and link fault photos to failure modes.
- **AR / smart glasses / wearables / voice-first:** the assistant API is UI-agnostic; answers are structured JSON (steps, safety, evidence) suited to heads-up display.
- **IoT sensor integration & predictive maintenance:** attach telemetry to `assets`; use symptoms (e.g. “pressure below normal range”) as rule triggers that open the matching approved procedure.
- **Digital twins:** the knowledge graph becomes the maintenance layer of a twin.
- **Multilingual technicians:** capture already supports `hi-IN` speech; translation of procedures with provenance retained.
- **Cross-plant federation:** organizations → plants hierarchy; federated retrieval across plants with per-plant approval.
