# AI evaluation

LegacyMind is evaluated on two golden datasets that live in the repository and are re-run by CI (`python -m eval.run_eval`). Every number below was produced by that script on real system output — nothing is hand-entered. Results are also written to `backend/eval/results.md` / `results.json` on each run.

## Datasets

**`backend/eval/golden_qa.json` — grounded question answering (20 questions).** Questions about the synthetic NovaTech plant:

- 12 *answerable* questions with the expected source record, machine, key terms that must appear in the steps, expected safety terms, and (for CV-04) an expected knowledge conflict. Several are paraphrases that avoid the recordings' wording (“P-103 grinds when it starts up”, “the hydraulic press ram creeps down at top dead centre”).
- 8 *unanswerable* questions that must be refused: machines not in the registry (PK-09, RB-12), a real machine with no knowledge on the topic (CNC-07 turret bolts), a symptom that exists only for a *different* machine (grinding on CP-02 vs P-103), knowledge that exists but is not yet approved (HP-01 hissing), and off-topic requests.

**`backend/eval/golden_extraction.json` — knowledge extraction (6 transcripts).** Held-out transcripts that are *not* part of the demo seed, with hand-labelled asset tags, symptoms, failure modes, components, tools, procedure steps and safety statements. The extractor was not tuned against these.

## Metrics

| Metric | Definition |
|---|---|
| Retrieval recall@8 | Answerable questions whose expected source record appears in the top-8 fused (vector + BM25 + graph) hits |
| Answer accuracy | Answered, correct machine, all expected key terms present in the steps |
| Refusal accuracy | Unanswerable questions answered with “I could not find sufficient verified plant knowledge…” |
| Citation accuracy | Evidence items that come from the expected source record (or are safety evidence) |
| Unsupported-step rate | Answer steps whose cited quotes share < 50% of the step's content tokens |
| Hallucination rate | (unsupported steps + unanswerable questions that were answered) / (steps + unanswerable questions) |
| Safety recall | Answers that include the expected safety warning |
| Conflict surfacing | Questions on a conflicted procedure where the conflict is shown |
| Groundedness separation | Mean groundedness score, answerable vs unanswerable |
| Extraction P / R / F1 | Fuzzy one-to-one matching (containment or ≥ 60% token overlap; ≥ 50% for steps) |

## Configuration evaluated

Local mode — no external AI: `rules-v1` extractor, `local-hash-v1` offline embeddings (lexical, not deep-semantic), SQLite + numpy vector search, extractive answers. This is the mode that runs with no API key. With an LLM and semantic embeddings configured the same script measures that configuration.

## Results

### Run 1 — baseline (27 Sep 2026, Windows 11 laptop, Python 3.12)

| Metric | Value |
|---|---|
| Retrieval recall@8 | **100%** |
| Answer accuracy | **83%** (10 / 12) |
| Refusal accuracy | **100%** (8 / 8) |
| Citation accuracy | **100%** |
| Unsupported-step rate | 28% |
| Hallucination rate | 24% |
| Safety recall | **100%** |
| Conflict surfacing | 50% (1 / 2) |
| Mean groundedness | 0.771 answerable vs 0.071 unanswerable |
| Latency p50 / p95 | 14.0 ms / 18.1 ms |

| Extraction | Precision | Recall | F1 |
|---|---|---|---|
| Asset tags | 1.00 | 1.00 | 1.00 |
| Symptoms | 0.55 | 1.00 | 0.71 |
| Failure modes | 1.00 | 1.00 | 1.00 |
| Components | 0.64 | 0.82 | 0.72 |
| Tools | 0.83 | 1.00 | 0.91 |
| Procedure steps | 0.90 | 0.86 | 0.88 |
| Safety statement detected | 100% of transcripts | | |

**What run 1 revealed**

1. *A real citation bug.* Evidence was de-duplicated by (record, start, end). When two steps were spoken in the same segment — e.g. “stop the pump and apply lockout/tagout” and “bleed off the pressure first” — both steps cited the first sentence. That is most of the 28% “unsupported” steps: the step was correct but pointed at the neighbouring sentence. **Fixed:** citations are now keyed by the exact quote.
2. *Fallback procedure selection was too narrow.* For “conveyor CV-04 belt drifting to one side” the approved procedure card was retrieved but ranked 4th, below transcript chunks, so no steps (and therefore no conflict warning) were returned. **Fixed:** the fallback now considers the top 5 hits.
3. *A genuine limitation, not fixed by tuning:* “Spindle on the CNC machining centre screeches at 12000 rpm” scores 0.31 (just below the refusal threshold) because the offline embeddings are lexical and “12000” vs “12,000” and “screeches” vs “squealing noise” share few tokens. LegacyMind refuses rather than guessing, which is the intended failure mode; semantic embeddings (`EMBEDDING_PROVIDER=openai`) are the proper remedy. We did not add synonyms targeted at the golden questions.
4. *Extraction over-generates symptoms* (precision 0.55): generic phrases such as “vibration” are extracted alongside the precise symptom. Supervisor review catches these; recall (1.00) is the property that matters for capture.

### Run 2 — after the fixes above

Pending: re-run `RUN-TESTS.bat` (or `python -m eval.run_eval`) — this section is updated with the measured values, not estimates.

## Honest limitations of this evaluation

- The QA set is small (20 questions) and built on synthetic data written by the project team; it measures behaviour and regressions, not real-plant accuracy.
- Lexical overlap is a proxy for support; it cannot detect a fluent step that uses the evidence's words but reverses its meaning. The LLM-grounded path adds evidence-ID verification, and supervisor review is the final safeguard.
- A pilot with real technicians — measuring the “Did this fix it?” resolution rate that LegacyMind now records per procedure — is the metric that matters in production.
