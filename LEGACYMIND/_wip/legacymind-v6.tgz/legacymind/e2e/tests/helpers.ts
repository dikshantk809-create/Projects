import { expect, type Page } from "@playwright/test";

export async function launchDemo(page: Page, persona: "supervisor" | "junior" | "senior" | "admin" = "supervisor") {
  const res = await page.request.post(`/api/demo/launch?persona=${persona}`);
  expect(res.ok()).toBeTruthy();
}

export async function ask(page: Page, question: string) {
  await page.getByLabel("Question").fill(question);
  await page.getByRole("button", { name: "Send" }).click();
}
