import { expect, test } from "@playwright/test";
import { ask, launchDemo } from "./helpers";

test.describe("public", () => {
  test("landing page tells the story and links to the demo", async ({ page }) => {
    await page.goto("/");
    await expect(page.getByRole("heading", { name: /Your Factory Has 30 Years of Knowledge/ })).toBeVisible();
    for (const id of ["problem", "how", "capabilities", "architecture", "security", "roi", "faq"]) {
      await expect(page.locator(`#${id}`)).toBeVisible();
    }
    await page.getByRole("link", { name: /Explore Demo/ }).click();
    await expect(page).toHaveURL(/\/demo$/);
    await expect(page.getByText("Synthetic Demo Data.")).toBeVisible();
  });

  test("login validation and protected routes", async ({ page }) => {
    await page.goto("/app/assets");
    await expect(page).toHaveURL(/\/login\?next=/);
    await page.getByLabel("Email").fill("amit.sharma@novatech.demo");
    await page.getByLabel("Password").fill("wrong-password");
    await page.getByRole("button", { name: /Sign in/ }).click();
    await expect(page.getByRole("alert")).toContainText("Incorrect email or password");
    await page.getByLabel("Password").fill("LegacyMind-Demo-2026");
    await page.getByRole("button", { name: /Sign in/ }).click();
    await expect(page).toHaveURL(/\/app\/assets$/);
    await expect(page.getByText("P-103").first()).toBeVisible();
  });
});

test.describe("demo walkthrough", () => {
  test("one-click demo lands on the dashboard with the tour", async ({ page }) => {
    await page.goto("/demo");
    await page.getByRole("button", { name: /Amit Sharma/ }).click();
    await expect(page).toHaveURL(/\/app\?tour=1/);
    await expect(page.getByText("Two-minute demo tour")).toBeVisible();
    await expect(page.getByText("SYNTHETIC DEMO DATA").first()).toBeVisible();
    await expect(page.locator(".stat-value").first()).toHaveText("5");
  });

  test("junior gets a grounded, cited answer with safety and evidence", async ({ page }) => {
    await launchDemo(page, "junior");
    await page.goto("/app/assistant");
    await ask(page, "Pump P-103 is making a grinding sound during startup. What should I check?");
    const answer = page.getByRole("article", { name: "Assistant answer" }).last();
    await expect(answer).toContainText("Troubleshooting Recommendation");
    await expect(answer).toContainText("Inspect Valve V-03");
    await expect(answer).toContainText(/GROUNDEDNESS: (HIGH|MEDIUM)/);
    await expect(answer).toContainText("Rajesh Kumar");
    await expect(answer).toContainText("02:14-02:48");
    await expect(answer.locator(".safety-card").first()).toBeVisible();
    await expect(answer).toContainText("Knowledge Record LM-1042");
    await expect(answer.getByRole("button", { name: /Play/ }).first()).toBeVisible();
  });

  test("unknown machine is refused and escalated", async ({ page }) => {
    await launchDemo(page, "junior");
    await page.goto("/app/assistant");
    await ask(page, "How do I recalibrate the vision sensor on packaging line PK-09?");
    const answer = page.getByRole("article", { name: "Assistant answer" }).last();
    await expect(answer).toContainText("I could not find sufficient verified plant knowledge");
    await expect(answer).toContainText("GROUNDEDNESS: INSUFFICIENT");
  });

  test("conflicting procedures are shown, not silently chosen", async ({ page }) => {
    await launchDemo(page, "junior");
    await page.goto("/app/assistant");
    await ask(page, "CV-04 belt is mistracking, what should I check first?");
    await expect(page.getByText("KNOWLEDGE CONFLICT")).toBeVisible();
    await expect(page.getByText("Supervisor review required").first()).toBeVisible();
  });

  test("asset page shows machine info, QR code and procedures", async ({ page }) => {
    await launchDemo(page, "supervisor");
    await page.goto("/app/assets/P-103");
    await expect(page.getByRole("heading", { name: "P-103 · Hydraulic Pump" })).toBeVisible();
    await expect(page.getByAltText("QR code for P-103")).toBeVisible();
    await expect(page.getByText("Siemens")).toBeVisible();
    await page.getByRole("tab", { name: /Maintenance history/ }).click();
    await expect(page.getByText(/V-03 cleaned/)).toBeVisible();
  });

  test("capture text knowledge runs the real pipeline", async ({ page }) => {
    await launchDemo(page, "senior");
    await page.goto("/app/capture");
    await page.getByRole("tab", { name: "Text notes" }).click();
    await page.getByLabel("Asset").selectOption({ label: "CP-02 · Air Compressor" });
    await page.getByPlaceholder(/Whenever pump P-103/).fill("When CP-02 is making a knocking noise at start, check the motor coupling first. Then inspect the mounting bolts. Always isolate the main power before opening the panel.");
    await page.getByRole("button", { name: /Submit for AI processing/ }).click();
    await expect(page).toHaveURL(/\/app\/library\/LM-\d+/);
    await expect(page.getByText("Processed — awaiting supervisor review")).toBeVisible({ timeout: 30_000 });
    await page.getByRole("tab", { name: /AI extraction/ }).click();
    await expect(page.getByText("knocking noise at start").first()).toBeVisible();
  });

  test("knowledge library search and filters", async ({ page }) => {
    await launchDemo(page, "supervisor");
    await page.goto("/app/library");
    await page.getByLabel("Search knowledge").fill("V-03");
    await expect(page.getByRole("cell", { name: "LM-1042" })).toBeVisible();
    await page.getByLabel("Approval status").selectOption("pending");
    await expect(page.getByRole("cell", { name: "LM-1042" })).toHaveCount(0);
  });

  test("record page shows transcript, timestamps and pipeline stages", async ({ page }) => {
    await launchDemo(page, "supervisor");
    await page.goto("/app/library/LM-1042?t=140");
    await expect(page.getByText("02:14").first()).toBeVisible();
    await expect(page.getByText("Conflict detection")).toBeVisible();
    await expect(page.getByText("Synthetic transcript · no audio")).toBeVisible();
  });

  test("supervisor review queue shows pending cards and the conflict", async ({ page }) => {
    await launchDemo(page, "supervisor");
    await page.goto("/app/review");
    await expect(page.getByRole("tab", { name: /Procedure cards/ })).toBeVisible();
    await page.getByRole("tab", { name: /Knowledge conflicts/ }).click();
    await expect(page.getByText("⚠ KNOWLEDGE CONFLICT")).toBeVisible();
  });

  test("knowledge graph renders", async ({ page }) => {
    await launchDemo(page, "supervisor");
    await page.goto("/app/graph?asset=P-103");
    await expect(page.getByRole("img", { name: "Knowledge graph" })).toBeVisible();
    await expect(page.getByText(/\d+ nodes · \d+ edges/)).toBeVisible();
  });

  test("junior cannot reach supervisor areas", async ({ page }) => {
    await launchDemo(page, "junior");
    await page.goto("/app/review");
    await expect(page.getByText("Not available for your role")).toBeVisible();
    await expect(page.getByRole("link", { name: "Supervisor Review" })).toHaveCount(0);
  });
});
