// Captures the screenshots used in docs/REPORT and the pitch deck:  npx playwright test --project=screenshots
import { test } from "@playwright/test";
import { ask, launchDemo } from "./helpers";

const OUT = process.env.SHOT_DIR ?? "../docs/screenshots";

test("capture product screenshots", async ({ page }) => {
  test.setTimeout(180_000);
  await page.goto("/");
  await page.waitForTimeout(4000);
  await page.screenshot({ path: `${OUT}/01-landing.png` });
  await launchDemo(page, "supervisor");
  await page.goto("/app?tour=1");
  await page.waitForLoadState("networkidle");
  await page.screenshot({ path: `${OUT}/02-dashboard.png`, fullPage: true });
  await page.goto("/app/assets/P-103");
  await page.waitForLoadState("networkidle");
  await page.screenshot({ path: `${OUT}/03-asset-p103.png`, fullPage: true });
  await page.goto("/app/library/LM-1042");
  await page.waitForLoadState("networkidle");
  await page.screenshot({ path: `${OUT}/04-record-transcript.png`, fullPage: true });
  await page.goto("/app/library/LM-1042?tab=extraction");
  await page.waitForLoadState("networkidle");
  await page.screenshot({ path: `${OUT}/05-ai-extraction.png`, fullPage: true });
  await page.goto("/app/graph?asset=P-103");
  await page.waitForTimeout(5000);
  await page.screenshot({ path: `${OUT}/06-knowledge-graph.png` });
  await page.goto("/app/assistant");
  await ask(page, "Pump P-103 is making a grinding sound during startup. What should I check?");
  await page.getByText("Inspect Valve V-03").first().waitFor();
  await page.waitForTimeout(600);
  await page.screenshot({ path: `${OUT}/07-assistant-grounded-answer.png`, fullPage: true });
  await page.goto("/app/assistant");
  await ask(page, "How do I recalibrate the vision sensor on packaging line PK-09?");
  await page.getByText("I could not find sufficient verified plant knowledge").first().waitFor();
  await page.screenshot({ path: `${OUT}/08-assistant-refusal.png` });
  await page.goto("/app/assistant");
  await ask(page, "CV-04 belt is mistracking, what should I check first?");
  await page.getByText("KNOWLEDGE CONFLICT").first().waitFor();
  await page.screenshot({ path: `${OUT}/09-assistant-conflict.png`, fullPage: true });
  await page.goto("/app/review");
  await page.waitForLoadState("networkidle");
  await page.screenshot({ path: `${OUT}/10-supervisor-review.png`, fullPage: true });
  await page.goto("/app/capture");
  await page.waitForLoadState("networkidle");
  await page.screenshot({ path: `${OUT}/11-knowledge-capture.png` });
  await launchDemo(page, "senior");
  await page.goto("/app/harvest");
  await page.getByLabel("Machine").selectOption({ label: "CP-02 · Air Compressor" });
  await page.getByRole("button", { name: /Start Knowledge Harvest/ }).click();
  for (const a of ["Short cycling and overheating.", "The compressor starts and stops every few seconds and the discharge temperature rises.", "They usually replace the pressure switch, but that is unnecessary."]) {
    await page.getByLabel("Answer").fill(a);
    await page.getByRole("button", { name: "Send answer" }).click();
    await page.waitForTimeout(700);
  }
  await page.screenshot({ path: `${OUT}/12-knowledge-harvest.png`, fullPage: true });
  await launchDemo(page, "supervisor");
  await page.goto("/app/analytics");
  await page.waitForLoadState("networkidle");
  await page.screenshot({ path: `${OUT}/13-analytics.png`, fullPage: true });
});
