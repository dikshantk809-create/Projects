import { expect, test } from "@playwright/test";
import { ask, launchDemo } from "./helpers";

test("mobile: navigation drawer and assistant work without horizontal scroll", async ({ page }) => {
  await launchDemo(page, "junior");
  await page.goto("/app/assistant");
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  expect(overflow).toBeLessThanOrEqual(1);
  await ask(page, "Pump P-103 is making a grinding sound during startup. What should I check?");
  await expect(page.getByText("Inspect Valve V-03").first()).toBeVisible();
  await page.getByRole("button", { name: "Open navigation" }).click();
  await page.getByRole("link", { name: "Assets" }).click();
  await expect(page).toHaveURL(/\/app\/assets/);
});
