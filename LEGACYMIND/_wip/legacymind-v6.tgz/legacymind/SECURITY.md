# Security

Industrial maintenance knowledge describes how critical equipment fails and how it is isolated. LegacyMind treats it as sensitive data.

## Reporting a vulnerability

Please email the maintainers privately (do not open a public issue) with steps to reproduce. We aim to acknowledge within 3 working days.

## Controls

| Area | Control | Where |
|---|---|---|
| Passwords | scrypt (n=2¹⁴, r=8, p=1), 16-byte random salt, constant-time compare; policy ≥10 chars with letter + digit; dummy-hash verification to blunt user enumeration by timing | `app/security.py`, `app/api/auth.py` |
| Sessions | HS256-signed token, 12 h expiry (configurable), in an **httpOnly** cookie (`Secure` in production, `SameSite=Lax`); bearer header accepted for API clients; `token_version` lets admins/users revoke all sessions (bumped on password/role change, deactivation, “sign out everywhere”) | `app/security.py`, `app/deps.py` |
| Production guard | The API refuses to start in production without `SECRET_KEY`; `/ready` warns if it is shorter than 32 chars | `app/config.py`, `app/main.py` |
| Authorization | Explicit permission matrix for `admin`, `supervisor`, `technician`, `junior_technician`; every route declares its permission; junior technicians only see approved knowledge (records, procedures, recordings, graph) | `app/security.py`, routers |
| Tenant isolation | Every query is scoped by `org_id`; cross-org IDs return 404 (not 403) to avoid leaking existence | routers; `tests/test_assets.py::test_org_isolation` |
| Uploads | Extension allow-list; declared MIME must match; **magic-byte** signature check; UTF-8 check for text; size limit (`MAX_UPLOAD_MB`) enforced per file and early via `Content-Length`; filenames sanitised; storage keys generated server-side (no user path components); path traversal guarded | `app/services/storage.py`, `app/main.py` |
| Input validation | Pydantic models with lengths/patterns; control characters stripped; `<`/`>` stripped from org/user names; HTML escaped by React | `app/validation.py` |
| HTTP hardening | `X-Content-Type-Options`, `X-Frame-Options: DENY`, `Referrer-Policy`, `Permissions-Policy` (camera/mic self only), CSP, HSTS when `COOKIE_SECURE=true`, `Cache-Control: no-store` on API responses | `app/main.py`, `frontend/nginx.conf`, `frontend/vercel.json` |
| CORS | Allow-list from `CORS_ORIGINS`; the default deployments are same-origin so the UI needs none | `app/main.py` |
| Rate limiting | Per-IP sliding window: API 120/min, auth 10/min, capture 30/min, assistant 40/min, demo reset 3/min. In-process — put a shared limiter at the ingress for multi-instance deployments | `app/deps.py` |
| Audit | Login success/failure, registration, captures, reviews, edits, conflict resolution, assistant questions, admin changes — with user, IP and timestamp | `audit_logs`, Administration → Audit log |
| Errors | Uniform `{error: {code, message, error_id, request_id}}`; unexpected exceptions logged server-side with the error ID, never returned | `app/errors.py` |
| Secrets | Only via environment variables; `.env` is git-ignored; no keys in code, images or logs; AI request logs store errors truncated, never keys | `.env.example`, `app/ai/llm.py` |
| Media access | Recordings and documents are served only through authenticated, org-scoped endpoints (no public bucket URLs); S3 objects written with server-side encryption | `app/api/media.py`, `app/services/storage.py` |
| AI safety | Only approved knowledge is retrievable; safety warnings come from approved records, never generated; LLM output must cite evidence and is verified; open conflicts force escalation; high-risk procedures require supervisor sign-off | `app/ai/answer.py` |

## Operational guidance

- Set `APP_ENV=production`, a strong `SECRET_KEY`, `COOKIE_SECURE=true`, and serve over HTTPS.
- Change `DEMO_PASSWORD` or set `DEMO_MODE=false` on any internet-facing deployment; set `ALLOW_PUBLIC_REGISTRATION=false` for single-tenant plants.
- For on-prem deployments with confidential procedures, use `AI_PROVIDER=ollama` so no text leaves the site.
- Back up PostgreSQL and the storage volume; knowledge records are the product.

## Known limitations

- Rate limiting is per process.
- No MFA or SSO (SAML/OIDC) yet — recommended before enterprise rollout.
- Background processing runs in the API process; a crash mid-pipeline marks the record `failed` on the next attempt rather than retrying automatically.
