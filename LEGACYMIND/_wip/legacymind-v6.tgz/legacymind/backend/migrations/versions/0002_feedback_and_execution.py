"""Answer feedback and guided procedure execution.

Revision ID: 0002_feedback_execution
Revises: 0001_baseline
Create Date: 2026-09-27
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

import app.db

revision = "0002_feedback_execution"
down_revision = "0001_baseline"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "answer_feedback",
        sa.Column("id", sa.String(32), primary_key=True),
        sa.Column("org_id", sa.String(32), sa.ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False),
        sa.Column("message_id", sa.String(32), sa.ForeignKey("messages.id", ondelete="CASCADE"), nullable=False),
        sa.Column("user_id", sa.String(32), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("asset_id", sa.String(32), sa.ForeignKey("assets.id", ondelete="SET NULL"), nullable=True),
        sa.Column("procedure_id", sa.String(32), sa.ForeignKey("procedures.id", ondelete="SET NULL"), nullable=True),
        sa.Column("outcome", sa.String(20), nullable=False),
        sa.Column("comment", sa.Text(), nullable=False, server_default=""),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.UniqueConstraint("message_id", "user_id"),
    )
    op.create_index("ix_answer_feedback_org_id", "answer_feedback", ["org_id"])
    op.create_index("ix_answer_feedback_message_id", "answer_feedback", ["message_id"])
    op.create_index("ix_feedback_org_outcome", "answer_feedback", ["org_id", "outcome"])

    op.create_table(
        "procedure_executions",
        sa.Column("id", sa.String(32), primary_key=True),
        sa.Column("org_id", sa.String(32), sa.ForeignKey("organizations.id", ondelete="CASCADE"), nullable=False),
        sa.Column("procedure_id", sa.String(32), sa.ForeignKey("procedures.id", ondelete="CASCADE"), nullable=False),
        sa.Column("asset_id", sa.String(32), sa.ForeignKey("assets.id", ondelete="SET NULL"), nullable=True),
        sa.Column("user_id", sa.String(32), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("status", sa.String(20), nullable=False),
        sa.Column("procedure_version", sa.Integer(), nullable=False),
        sa.Column("safety_acknowledged", app.db.JSONType(), nullable=False),
        sa.Column("step_states", app.db.JSONType(), nullable=False),
        sa.Column("outcome", sa.String(20), nullable=False, server_default=""),
        sa.Column("notes", sa.Text(), nullable=False, server_default=""),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("maintenance_event_id", sa.String(32), sa.ForeignKey("maintenance_events.id", ondelete="SET NULL"), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_procedure_executions_org_id", "procedure_executions", ["org_id"])
    op.create_index("ix_procedure_executions_procedure_id", "procedure_executions", ["procedure_id"])
    op.create_index("ix_procedure_executions_asset_id", "procedure_executions", ["asset_id"])
    op.create_index("ix_exec_org_status", "procedure_executions", ["org_id", "status"])


def downgrade() -> None:
    op.drop_table("procedure_executions")
    op.drop_table("answer_feedback")
