"""Baseline schema: every LegacyMind table, index and constraint of release 1.0.

Revision ID: 0001_baseline
Revises:
Create Date: 2026-09-27

The baseline is materialised from the SQLAlchemy models (app/models.py). Tables
introduced by later revisions are listed in LATER_TABLES and excluded here, so
upgrading an existing 1.0 database and building a fresh one yield the same
schema. On PostgreSQL pgvector is enabled first so embedding columns use the
native ``vector`` type.
"""

from __future__ import annotations

from alembic import op

revision = "0001_baseline"
down_revision = None
branch_labels = None
depends_on = None

LATER_TABLES = {"answer_feedback", "procedure_executions"}  # created by 0002


def upgrade() -> None:
    from app import models  # noqa: F401 - registers tables
    from app.config import get_settings
    from app.db import Base

    bind = op.get_bind()
    if bind.dialect.name == "postgresql" and get_settings().use_pgvector:
        op.execute("CREATE EXTENSION IF NOT EXISTS vector")
    tables = [t for t in Base.metadata.sorted_tables if t.name not in LATER_TABLES]
    Base.metadata.create_all(bind=bind, tables=tables)


def downgrade() -> None:
    from app import models  # noqa: F401
    from app.db import Base

    tables = [t for t in Base.metadata.sorted_tables if t.name not in LATER_TABLES]
    Base.metadata.drop_all(bind=op.get_bind(), tables=tables)
