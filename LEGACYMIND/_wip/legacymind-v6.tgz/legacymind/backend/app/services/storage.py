"""Object storage abstraction.

* ``local``: files under STORAGE_LOCAL_PATH (mounted volume in Docker).
* ``s3``: any S3-compatible store (AWS S3, MinIO, Cloudflare R2) via boto3,
  which is imported lazily so the dependency is only needed when used.
"""

from __future__ import annotations

import hashlib
import os
import re
from pathlib import Path
from typing import Protocol

from ..config import get_settings
from ..errors import AppError

# Allowed upload types: extension -> (kind, accepted MIME prefixes)
ALLOWED_TYPES: dict[str, tuple[str, tuple[str, ...]]] = {
    ".webm": ("audio_or_video", ("audio/webm", "video/webm")),
    ".ogg": ("audio", ("audio/ogg", "application/ogg")),
    ".mp3": ("audio", ("audio/mpeg", "audio/mp3")),
    ".wav": ("audio", ("audio/wav", "audio/x-wav", "audio/wave")),
    ".m4a": ("audio", ("audio/mp4", "audio/x-m4a", "audio/m4a")),
    ".mp4": ("video", ("video/mp4",)),
    ".mov": ("video", ("video/quicktime",)),
    ".pdf": ("document", ("application/pdf",)),
    ".docx": ("document", ("application/vnd.openxmlformats-officedocument.wordprocessingml.document",)),
    ".txt": ("document", ("text/plain",)),
    ".png": ("image", ("image/png",)),
    ".jpg": ("image", ("image/jpeg",)),
    ".jpeg": ("image", ("image/jpeg",)),
    ".webp": ("image", ("image/webp",)),
}

# Magic-byte signatures: the declared extension must match the content.
_SIGNATURES: dict[str, list[bytes]] = {
    ".pdf": [b"%PDF"],
    ".png": [b"\x89PNG"],
    ".jpg": [b"\xff\xd8\xff"],
    ".jpeg": [b"\xff\xd8\xff"],
    ".webp": [b"RIFF"],
    ".docx": [b"PK\x03\x04"],
    ".webm": [b"\x1a\x45\xdf\xa3"],
    ".ogg": [b"OggS"],
    ".wav": [b"RIFF"],
    ".mp3": [b"ID3", b"\xff\xfb", b"\xff\xf3", b"\xff\xf2"],
}


def safe_filename(name: str) -> str:
    base = os.path.basename(name or "upload")
    base = re.sub(r"[^A-Za-z0-9._-]+", "_", base).strip("._") or "upload"
    return base[:120]


def validate_upload(filename: str, content_type: str, data: bytes) -> tuple[str, str]:
    """Return (extension, kind) or raise AppError with a user-friendly message."""
    settings = get_settings()
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_TYPES:
        raise AppError(
            f"File type '{ext or 'unknown'}' is not supported. Allowed: " + ", ".join(sorted(ALLOWED_TYPES)),
            code="unsupported_file_type", status_code=415,
        )
    if not data:
        raise AppError("The uploaded file is empty.", code="empty_file")
    if len(data) > settings.max_upload_mb * 1024 * 1024:
        raise AppError(f"File exceeds the {settings.max_upload_mb} MB upload limit.", code="file_too_large", status_code=413)
    kind, mimes = ALLOWED_TYPES[ext]
    ct = (content_type or "").split(";")[0].strip().lower()
    if ct and ct != "application/octet-stream" and not any(ct == m for m in mimes):
        raise AppError(f"Content type '{ct}' does not match the '{ext}' extension.", code="mime_mismatch", status_code=415)
    sigs = _SIGNATURES.get(ext)
    if sigs and not any(data.startswith(sig) for sig in sigs):
        raise AppError("File content does not match its extension.", code="invalid_file_content", status_code=415)
    if ext == ".txt":
        try:
            data.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise AppError("Text files must be UTF-8 encoded.", code="invalid_encoding") from exc
    if kind == "audio_or_video":
        kind = "video" if ct.startswith("video/") else "audio"
    return ext, kind


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class Storage(Protocol):
    def put(self, key: str, data: bytes, content_type: str) -> None: ...
    def get(self, key: str) -> bytes: ...
    def exists(self, key: str) -> bool: ...
    def healthy(self) -> bool: ...


class LocalStorage:
    def __init__(self, root: str) -> None:
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        p = (self.root / key).resolve()
        if self.root not in p.parents:
            raise AppError("Invalid storage key.", code="invalid_key")
        return p

    def put(self, key: str, data: bytes, content_type: str) -> None:
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_bytes(data)
        tmp.replace(p)

    def get(self, key: str) -> bytes:
        return self._path(key).read_bytes()

    def exists(self, key: str) -> bool:
        return self._path(key).exists()

    def healthy(self) -> bool:
        return os.access(self.root, os.W_OK)


class S3Storage:  # pragma: no cover - requires an S3 endpoint
    def __init__(self) -> None:
        import boto3  # type: ignore[import-not-found]

        s = get_settings()
        self.bucket = s.storage_bucket
        self.client = boto3.client(
            "s3",
            endpoint_url=s.storage_endpoint or None,
            aws_access_key_id=s.storage_access_key,
            aws_secret_access_key=s.storage_secret_key,
            region_name=s.storage_region,
        )

    def put(self, key: str, data: bytes, content_type: str) -> None:
        self.client.put_object(Bucket=self.bucket, Key=key, Body=data, ContentType=content_type,
                               ServerSideEncryption="AES256")

    def get(self, key: str) -> bytes:
        return self.client.get_object(Bucket=self.bucket, Key=key)["Body"].read()

    def exists(self, key: str) -> bool:
        try:
            self.client.head_object(Bucket=self.bucket, Key=key)
            return True
        except Exception:
            return False

    def healthy(self) -> bool:
        try:
            self.client.head_bucket(Bucket=self.bucket)
            return True
        except Exception:
            return False


_storage: Storage | None = None


def get_storage() -> Storage:
    global _storage
    if _storage is None:
        s = get_settings()
        _storage = S3Storage() if s.storage_backend == "s3" else LocalStorage(s.storage_local_path)
    return _storage


def reset_storage() -> None:
    global _storage
    _storage = None
