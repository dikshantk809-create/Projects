"""Dependency-free QR Code encoder (byte mode, versions 1-40) rendering to SVG.

Implements ISO/IEC 18004: Reed-Solomon ECC over GF(256), block interleaving,
function patterns, masking with penalty scoring, and format/version info.
Verified in the test-suite by decoding generated codes with OpenCV.
"""

from __future__ import annotations

_ECC_CODEWORDS_PER_BLOCK = {
    "L": [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
    "M": [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28],
    "Q": [-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
    "H": [-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30],
}
_NUM_BLOCKS = {
    "L": [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25],
    "M": [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49],
    "Q": [-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68],
    "H": [-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81],
}
_FORMAT_BITS = {"L": 1, "M": 0, "Q": 3, "H": 2}


def _raw_modules(ver: int) -> int:
    result = (16 * ver + 128) * ver + 64
    if ver >= 2:
        n = ver // 7 + 2
        result -= (25 * n - 10) * n - 55
        if ver >= 7:
            result -= 36
    return result


def _data_codewords(ver: int, ecl: str) -> int:
    return _raw_modules(ver) // 8 - _ECC_CODEWORDS_PER_BLOCK[ecl][ver] * _NUM_BLOCKS[ecl][ver]


def _gf_mul(x: int, y: int) -> int:
    z = 0
    for i in reversed(range(8)):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _rs_divisor(degree: int) -> list[int]:
    result = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(len(result)):
            result[j] = _gf_mul(result[j], root)
            if j + 1 < len(result):
                result[j] ^= result[j + 1]
        root = _gf_mul(root, 0x02)
    return result


def _rs_remainder(data: list[int], divisor: list[int]) -> list[int]:
    result = [0] * len(divisor)
    for b in data:
        factor = b ^ result.pop(0)
        result.append(0)
        for i, coef in enumerate(divisor):
            result[i] ^= _gf_mul(coef, factor)
    return result


class QrCode:
    def __init__(self, text: str, ecl: str = "M") -> None:
        data = text.encode("utf-8")
        for ver in range(1, 41):
            count_bits = 8 if ver <= 9 else 16
            needed = 4 + count_bits + 8 * len(data)
            if needed <= _data_codewords(ver, ecl) * 8:
                break
        else:
            raise ValueError("data too long for a QR code")
        self.version = ver
        self.ecl = ecl
        self.size = ver * 4 + 17
        bits: list[int] = []

        def append(val: int, n: int) -> None:
            bits.extend((val >> i) & 1 for i in reversed(range(n)))

        append(0b0100, 4)
        append(len(data), count_bits)
        for b in data:
            append(b, 8)
        cap = _data_codewords(ver, ecl) * 8
        append(0, min(4, cap - len(bits)))
        append(0, (8 - len(bits) % 8) % 8)
        pad = 0xEC
        while len(bits) < cap:
            append(pad, 8)
            pad ^= 0xEC ^ 0x11
        codewords = [int("".join(map(str, bits[i : i + 8])), 2) for i in range(0, len(bits), 8)]

        self.modules = [[False] * self.size for _ in range(self.size)]
        self.is_function = [[False] * self.size for _ in range(self.size)]
        self._draw_function_patterns()
        all_codewords = self._add_ecc_and_interleave(codewords)
        self._draw_codewords(all_codewords)

        best_mask, best_penalty = 0, None
        for mask in range(8):
            self._apply_mask(mask)
            self._draw_format_bits(mask)
            p = self._penalty()
            if best_penalty is None or p < best_penalty:
                best_mask, best_penalty = mask, p
            self._apply_mask(mask)  # undo (XOR)
        self._apply_mask(best_mask)
        self._draw_format_bits(best_mask)
        self.mask = best_mask

    # -- function patterns -------------------------------------------------
    def _set_fn(self, x: int, y: int, dark: bool) -> None:
        self.modules[y][x] = dark
        self.is_function[y][x] = True

    def _draw_function_patterns(self) -> None:
        for i in range(self.size):
            self._set_fn(6, i, i % 2 == 0)
            self._set_fn(i, 6, i % 2 == 0)
        for cx, cy in ((3, 3), (self.size - 4, 3), (3, self.size - 4)):
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    x, y = cx + dx, cy + dy
                    if 0 <= x < self.size and 0 <= y < self.size:
                        self._set_fn(x, y, max(abs(dx), abs(dy)) not in (2, 4))
        pos = self._alignment_positions()
        n = len(pos)
        for i in range(n):
            for j in range(n):
                if (i == 0 and j == 0) or (i == 0 and j == n - 1) or (i == n - 1 and j == 0):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        self._set_fn(pos[i] + dx, pos[j] + dy, max(abs(dx), abs(dy)) != 1)
        self._draw_format_bits(0)
        self._draw_version()

    def _alignment_positions(self) -> list[int]:
        if self.version == 1:
            return []
        n = self.version // 7 + 2
        step = (self.version * 8 + n * 3 + 5) // (n * 4 - 4) * 2
        result = [self.size - 7 - i * step for i in range(n - 1)] + [6]
        return list(reversed(result))

    def _draw_format_bits(self, mask: int) -> None:
        data = _FORMAT_BITS[self.ecl] << 3 | mask
        rem = data
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        bits = (data << 10 | rem) ^ 0x5412

        def bit(i: int) -> bool:
            return (bits >> i) & 1 != 0

        for i in range(0, 6):
            self._set_fn(8, i, bit(i))
        self._set_fn(8, 7, bit(6))
        self._set_fn(8, 8, bit(7))
        self._set_fn(7, 8, bit(8))
        for i in range(9, 15):
            self._set_fn(14 - i, 8, bit(i))
        for i in range(0, 8):
            self._set_fn(self.size - 1 - i, 8, bit(i))
        for i in range(8, 15):
            self._set_fn(8, self.size - 15 + i, bit(i))
        self._set_fn(8, self.size - 8, True)

    def _draw_version(self) -> None:
        if self.version < 7:
            return
        rem = self.version
        for _ in range(12):
            rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
        bits = self.version << 12 | rem
        for i in range(18):
            b = (bits >> i) & 1 != 0
            a, c = self.size - 11 + i % 3, i // 3
            self._set_fn(a, c, b)
            self._set_fn(c, a, b)

    # -- data --------------------------------------------------------------
    def _add_ecc_and_interleave(self, data: list[int]) -> list[int]:
        ver, ecl = self.version, self.ecl
        num_blocks = _NUM_BLOCKS[ecl][ver]
        ecc_len = _ECC_CODEWORDS_PER_BLOCK[ecl][ver]
        raw = _raw_modules(ver) // 8
        num_short = num_blocks - raw % num_blocks
        short_len = raw // num_blocks
        divisor = _rs_divisor(ecc_len)
        blocks: list[list[int]] = []
        k = 0
        for i in range(num_blocks):
            dat = data[k : k + short_len - ecc_len + (0 if i < num_short else 1)]
            k += len(dat)
            ecc = _rs_remainder(dat, divisor)
            if i < num_short:
                dat = dat + [0]
            blocks.append(dat + ecc)
        result: list[int] = []
        for i in range(len(blocks[0])):
            for j, blk in enumerate(blocks):
                if i != short_len - ecc_len or j >= num_short:
                    result.append(blk[i])
        return result

    def _draw_codewords(self, data: list[int]) -> None:
        i = 0
        right = self.size - 1
        while right >= 1:
            if right == 6:
                right = 5
            for vert in range(self.size):
                for j in range(2):
                    x = right - j
                    upward = ((right + 1) & 2) == 0
                    y = self.size - 1 - vert if upward else vert
                    if not self.is_function[y][x] and i < len(data) * 8:
                        self.modules[y][x] = (data[i >> 3] >> (7 - (i & 7))) & 1 != 0
                        i += 1
            right -= 2

    def _apply_mask(self, mask: int) -> None:
        for y in range(self.size):
            for x in range(self.size):
                if self.is_function[y][x]:
                    continue
                inv = (
                    (x + y) % 2 == 0, y % 2 == 0, x % 3 == 0, (x + y) % 3 == 0,
                    (x // 3 + y // 2) % 2 == 0, x * y % 2 + x * y % 3 == 0,
                    (x * y % 2 + x * y % 3) % 2 == 0, ((x + y) % 2 + x * y % 3) % 2 == 0,
                )[mask]
                if inv:
                    self.modules[y][x] = not self.modules[y][x]

    def _penalty(self) -> int:
        size, m = self.size, self.modules
        penalty = 0
        for lines in (m, [list(col) for col in zip(*m, strict=True)]):
            for row in lines:
                run, color = 0, None
                for v in row:
                    if v == color:
                        run += 1
                    else:
                        if run >= 5:
                            penalty += 3 + (run - 5)
                        run, color = 1, v
                if run >= 5:
                    penalty += 3 + (run - 5)
                s = "".join("1" if v else "0" for v in row)
                penalty += 40 * (s.count("10111010000") + s.count("00001011101"))
        for y in range(size - 1):
            for x in range(size - 1):
                c = m[y][x]
                if c == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                    penalty += 3
        dark = sum(v for row in m for v in row)
        total = size * size
        k = (abs(dark * 20 - total * 10) + total - 1) // total - 1
        penalty += max(0, k) * 10
        return penalty

    def to_svg(self, border: int = 4, dark: str = "#000000", light: str = "#ffffff") -> str:
        dim = self.size + border * 2
        parts = []
        for y in range(self.size):
            for x in range(self.size):
                if self.modules[y][x]:
                    parts.append(f"M{x + border},{y + border}h1v1h-1z")
        return (
            f'<svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 {dim} {dim}" shape-rendering="crispEdges">'
            f'<rect width="100%" height="100%" fill="{light}"/><path d="{"".join(parts)}" fill="{dark}"/></svg>'
        )


def qr_svg(text: str) -> str:
    return QrCode(text, "M").to_svg()
