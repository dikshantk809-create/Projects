"""Programmatic Alembic helpers.

The API runs ``upgrade_to_head()`` on startup (guarded by a PostgreSQL advisory
lock so several replicas can start at once). Operators can also run
``alembic upgrade head`` manually - both use the same migration scripts in
``backend/migrations``.
"""

from __future__ import annotations

from pathlib import Path

from alembic import command
from alembic.config import Config
from alembic.runtime.migration import MigrationContext
from alembic.script import ScriptDirectory
from sqlalchemy import text

from .config import get_settings
from .db import get_engine

BACKEND_DIR = Path(__file__).resolve().parent.parent
_LOCK_ID = 740_310_2026  # arbitrary constant for pg_advisory_lock


def alembic_config() -> Config:
    cfg = Config(str(BACKEND_DIR / "alembic.ini"))
    cfg.set_main_option("script_location", str(BACKEND_DIR / "migrations"))
    cfg.set_main_option("sqlalchemy.url", get_settings().database_url.replace("%", "%%"))
    return cfg


def head_revision() -> str | None:
    return ScriptDirectory.from_config(alembic_config()).get_current_head()


def current_revision() -> str | None:
    with get_engine().connect() as conn:
        return MigrationContext.configure(conn).get_current_revision()


def upgrade_to_head() -> None:
    engine = get_engine()
    cfg = alembic_config()
    if engine.dialect.name == "postgresql":
        with engine.connect() as conn:
            conn.execute(text("SELECT pg_advisory_lock(:k)"), {"k": _LOCK_ID})
            try:
                cfg.attributes["connection"] = conn
                command.upgrade(cfg, "head")
                conn.commit()
            finally:
                conn.execute(text("SELECT pg_advisory_unlock(:k)"), {"k": _LOCK_ID})
                conn.commit()
    else:
        with engine.begin() as conn:
            cfg.attributes["connection"] = conn
            command.upgrade(cfg, "head")
