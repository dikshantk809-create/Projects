"""SQLAlchemy ORM models.

The knowledge graph is modelled relationally (see ARCHITECTURE.md §Knowledge
Graph): assets, components, failure modes, symptoms, procedures and safety
warnings are first-class tables and their foreign keys / link tables are the
graph's edges. Neo4j is an optional read replica of the same model.
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Any

from sqlalchemy import (
    Boolean,
    Date,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .config import get_settings
from .db import Base, JSONType, VectorType, new_id, utcnow

ROLES = ("admin", "supervisor", "technician", "junior_technician")


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


# ---------------------------------------------------------------------------
# Tenancy & identity
# ---------------------------------------------------------------------------


class Organization(TimestampMixin, Base):
    __tablename__ = "organizations"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String(200))
    slug: Mapped[str] = mapped_column(String(80), unique=True)
    is_demo: Mapped[bool] = mapped_column(Boolean, default=False)


class Plant(TimestampMixin, Base):
    __tablename__ = "plants"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(200))
    location: Mapped[str] = mapped_column(String(300), default="")


class Department(TimestampMixin, Base):
    __tablename__ = "departments"
    __table_args__ = (UniqueConstraint("org_id", "name"),)
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    plant_id: Mapped[str | None] = mapped_column(ForeignKey("plants.id", ondelete="SET NULL"), nullable=True)
    name: Mapped[str] = mapped_column(String(120))


class User(TimestampMixin, Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    email: Mapped[str] = mapped_column(String(254), unique=True, index=True)
    full_name: Mapped[str] = mapped_column(String(200))
    title: Mapped[str] = mapped_column(String(120), default="")
    role: Mapped[str] = mapped_column(String(32), default="technician")
    password_hash: Mapped[str] = mapped_column(String(255))
    department_id: Mapped[str | None] = mapped_column(ForeignKey("departments.id", ondelete="SET NULL"), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    years_experience: Mapped[int | None] = mapped_column(Integer, nullable=True)
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    token_version: Mapped[int] = mapped_column(Integer, default=0)

    organization: Mapped[Organization] = relationship(lazy="joined")


# ---------------------------------------------------------------------------
# Assets
# ---------------------------------------------------------------------------


class Asset(TimestampMixin, Base):
    __tablename__ = "assets"
    __table_args__ = (UniqueConstraint("org_id", "asset_tag"),)
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    plant_id: Mapped[str | None] = mapped_column(ForeignKey("plants.id", ondelete="SET NULL"), nullable=True)
    department_id: Mapped[str | None] = mapped_column(ForeignKey("departments.id", ondelete="SET NULL"), nullable=True)
    asset_tag: Mapped[str] = mapped_column(String(40))
    name: Mapped[str] = mapped_column(String(200))
    machine_type: Mapped[str] = mapped_column(String(120), default="")
    manufacturer: Mapped[str] = mapped_column(String(120), default="")
    model: Mapped[str] = mapped_column(String(120), default="")
    serial_number: Mapped[str] = mapped_column(String(120), default="")
    location: Mapped[str] = mapped_column(String(200), default="")
    installed_on: Mapped[date | None] = mapped_column(Date, nullable=True)
    status: Mapped[str] = mapped_column(String(32), default="operational")
    criticality: Mapped[str] = mapped_column(String(16), default="medium")
    description: Mapped[str] = mapped_column(Text, default="")
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=False)

    department: Mapped[Department | None] = relationship(lazy="joined")
    components: Mapped[list[Component]] = relationship(back_populates="asset", cascade="all, delete-orphan")


class Component(TimestampMixin, Base):
    __tablename__ = "components"
    __table_args__ = (UniqueConstraint("asset_id", "name"),)
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    asset_id: Mapped[str] = mapped_column(ForeignKey("assets.id", ondelete="CASCADE"), index=True)
    tag: Mapped[str] = mapped_column(String(40), default="")
    name: Mapped[str] = mapped_column(String(160))
    component_type: Mapped[str] = mapped_column(String(80), default="")

    asset: Mapped[Asset] = relationship(back_populates="components")


class MaintenanceEvent(TimestampMixin, Base):
    __tablename__ = "maintenance_events"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    asset_id: Mapped[str] = mapped_column(ForeignKey("assets.id", ondelete="CASCADE"), index=True)
    occurred_on: Mapped[date] = mapped_column(Date)
    event_type: Mapped[str] = mapped_column(String(40), default="corrective")
    summary: Mapped[str] = mapped_column(Text)
    technician_id: Mapped[str | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    downtime_hours: Mapped[float | None] = mapped_column(Float, nullable=True)


# ---------------------------------------------------------------------------
# Knowledge capture
# ---------------------------------------------------------------------------


class KnowledgeRecord(TimestampMixin, Base):
    """One captured piece of raw knowledge (a recording, document, note or interview)."""

    __tablename__ = "knowledge_records"
    __table_args__ = (
        UniqueConstraint("org_id", "ref"),
        Index("ix_records_org_review", "org_id", "review_status"),
    )
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    ref: Mapped[str] = mapped_column(String(32))  # e.g. LM-1042
    title: Mapped[str] = mapped_column(String(300))
    asset_id: Mapped[str | None] = mapped_column(ForeignKey("assets.id", ondelete="SET NULL"), nullable=True, index=True)
    contributor_id: Mapped[str | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    source_type: Mapped[str] = mapped_column(String(20))  # audio|video|image|document|text|interview
    processing_status: Mapped[str] = mapped_column(String(20), default="queued")  # queued|processing|processed|failed|needs_transcript
    processing_stages: Mapped[list[dict[str, Any]]] = mapped_column(JSONType, default=list)
    processing_error: Mapped[str | None] = mapped_column(Text, nullable=True)
    review_status: Mapped[str] = mapped_column(String(20), default="pending")  # pending|approved|rejected|needs_changes
    transcript: Mapped[str] = mapped_column(Text, default="")
    transcript_source: Mapped[str] = mapped_column(String(40), default="")  # browser_speech|whisper|manual|document|synthetic
    segments: Mapped[list[dict[str, Any]]] = mapped_column(JSONType, default=list)  # [{start,end,text}]
    summary: Mapped[str] = mapped_column(Text, default="")
    extraction: Mapped[dict[str, Any]] = mapped_column(JSONType, default=dict)
    ai_version: Mapped[str] = mapped_column(String(80), default="")
    notes: Mapped[str] = mapped_column(Text, default="")
    recorded_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=False)

    asset: Mapped[Asset | None] = relationship(lazy="joined")
    contributor: Mapped[User | None] = relationship(lazy="joined")
    recordings: Mapped[list[Recording]] = relationship(back_populates="record", cascade="all, delete-orphan")
    documents: Mapped[list[Document]] = relationship(back_populates="record", cascade="all, delete-orphan")


class Recording(TimestampMixin, Base):
    __tablename__ = "recordings"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    record_id: Mapped[str] = mapped_column(ForeignKey("knowledge_records.id", ondelete="CASCADE"), index=True)
    kind: Mapped[str] = mapped_column(String(10))  # audio|video
    filename: Mapped[str] = mapped_column(String(255))
    mime_type: Mapped[str] = mapped_column(String(100))
    size_bytes: Mapped[int] = mapped_column(Integer, default=0)
    storage_key: Mapped[str | None] = mapped_column(String(400), nullable=True)
    sha256: Mapped[str] = mapped_column(String(64), default="")
    duration_s: Mapped[float | None] = mapped_column(Float, nullable=True)
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=False)

    record: Mapped[KnowledgeRecord] = relationship(back_populates="recordings")


class Document(TimestampMixin, Base):
    __tablename__ = "documents"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    record_id: Mapped[str | None] = mapped_column(ForeignKey("knowledge_records.id", ondelete="CASCADE"), nullable=True, index=True)
    asset_id: Mapped[str | None] = mapped_column(ForeignKey("assets.id", ondelete="SET NULL"), nullable=True, index=True)
    kind: Mapped[str] = mapped_column(String(12))  # pdf|docx|txt|image
    category: Mapped[str] = mapped_column(String(40), default="")  # machine|part|fault|wiring|control_panel|manual
    filename: Mapped[str] = mapped_column(String(255))
    mime_type: Mapped[str] = mapped_column(String(100))
    size_bytes: Mapped[int] = mapped_column(Integer, default=0)
    storage_key: Mapped[str] = mapped_column(String(400))
    sha256: Mapped[str] = mapped_column(String(64), default="")
    extracted_text: Mapped[str] = mapped_column(Text, default="")
    extraction_method: Mapped[str] = mapped_column(String(40), default="")

    record: Mapped[KnowledgeRecord | None] = relationship(back_populates="documents")


# ---------------------------------------------------------------------------
# Structured knowledge (graph entities)
# ---------------------------------------------------------------------------


class FailureMode(TimestampMixin, Base):
    __tablename__ = "failure_modes"
    __table_args__ = (UniqueConstraint("asset_id", "name"),)
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    asset_id: Mapped[str] = mapped_column(ForeignKey("assets.id", ondelete="CASCADE"), index=True)
    component_id: Mapped[str | None] = mapped_column(ForeignKey("components.id", ondelete="SET NULL"), nullable=True)
    name: Mapped[str] = mapped_column(String(200))
    description: Mapped[str] = mapped_column(Text, default="")
    causes: Mapped[list[str]] = mapped_column(JSONType, default=list)
    is_rare: Mapped[bool] = mapped_column(Boolean, default=False)


class Symptom(TimestampMixin, Base):
    __tablename__ = "symptoms"
    __table_args__ = (UniqueConstraint("org_id", "name"),)
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(200))


class FailureModeSymptom(Base):
    __tablename__ = "failure_mode_symptoms"
    failure_mode_id: Mapped[str] = mapped_column(ForeignKey("failure_modes.id", ondelete="CASCADE"), primary_key=True)
    symptom_id: Mapped[str] = mapped_column(ForeignKey("symptoms.id", ondelete="CASCADE"), primary_key=True)


class Procedure(TimestampMixin, Base):
    __tablename__ = "procedures"
    __table_args__ = (
        UniqueConstraint("org_id", "ref"),
        Index("ix_procedures_asset_status", "asset_id", "status"),
    )
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    ref: Mapped[str] = mapped_column(String(40))  # e.g. PR-103-07
    asset_id: Mapped[str | None] = mapped_column(ForeignKey("assets.id", ondelete="SET NULL"), nullable=True)
    failure_mode_id: Mapped[str | None] = mapped_column(ForeignKey("failure_modes.id", ondelete="SET NULL"), nullable=True)
    record_id: Mapped[str | None] = mapped_column(ForeignKey("knowledge_records.id", ondelete="SET NULL"), nullable=True, index=True)
    title: Mapped[str] = mapped_column(String(300))
    symptoms: Mapped[list[str]] = mapped_column(JSONType, default=list)
    # steps: [{order, text, component, source: {record_id, start, end, quote}}]
    steps: Mapped[list[dict[str, Any]]] = mapped_column(JSONType, default=list)
    tools: Mapped[list[str]] = mapped_column(JSONType, default=list)
    parts: Mapped[list[str]] = mapped_column(JSONType, default=list)
    risk_level: Mapped[str] = mapped_column(String(12), default="medium")  # low|medium|high|critical
    requires_supervisor: Mapped[bool] = mapped_column(Boolean, default=True)
    status: Mapped[str] = mapped_column(String(20), default="pending_review")  # draft|pending_review|approved|rejected|superseded
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    author_id: Mapped[str | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    approved_by_id: Mapped[str | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    approved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    ai_version: Mapped[str] = mapped_column(String(80), default="")
    is_synthetic: Mapped[bool] = mapped_column(Boolean, default=False)

    asset: Mapped[Asset | None] = relationship(lazy="joined")
    failure_mode: Mapped[FailureMode | None] = relationship(lazy="joined")
    author: Mapped[User | None] = relationship(foreign_keys=[author_id], lazy="joined")
    approved_by: Mapped[User | None] = relationship(foreign_keys=[approved_by_id], lazy="joined")


class SafetyWarning(TimestampMixin, Base):
    __tablename__ = "safety_warnings"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    asset_id: Mapped[str | None] = mapped_column(ForeignKey("assets.id", ondelete="CASCADE"), nullable=True, index=True)
    procedure_id: Mapped[str | None] = mapped_column(ForeignKey("procedures.id", ondelete="CASCADE"), nullable=True, index=True)
    record_id: Mapped[str | None] = mapped_column(ForeignKey("knowledge_records.id", ondelete="SET NULL"), nullable=True)
    text: Mapped[str] = mapped_column(Text)
    hazard_type: Mapped[str] = mapped_column(String(60), default="general")
    severity: Mapped[str] = mapped_column(String(12), default="warning")  # info|warning|danger
    status: Mapped[str] = mapped_column(String(20), default="pending_review")


class KnowledgeSource(TimestampMixin, Base):
    """Traceability link: which raw evidence supports which structured fact."""

    __tablename__ = "knowledge_sources"
    __table_args__ = (Index("ix_sources_entity", "entity_type", "entity_id"),)
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    entity_type: Mapped[str] = mapped_column(String(30))  # procedure|procedure_step|failure_mode|safety_warning|symptom
    entity_id: Mapped[str] = mapped_column(String(32))
    record_id: Mapped[str] = mapped_column(ForeignKey("knowledge_records.id", ondelete="CASCADE"), index=True)
    recording_id: Mapped[str | None] = mapped_column(ForeignKey("recordings.id", ondelete="SET NULL"), nullable=True)
    document_id: Mapped[str | None] = mapped_column(ForeignKey("documents.id", ondelete="SET NULL"), nullable=True)
    technician_id: Mapped[str | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    start_s: Mapped[float | None] = mapped_column(Float, nullable=True)
    end_s: Mapped[float | None] = mapped_column(Float, nullable=True)
    quote: Mapped[str] = mapped_column(Text, default="")
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    ai_version: Mapped[str] = mapped_column(String(80), default="")


class KnowledgeChunk(TimestampMixin, Base):
    """Retrieval unit (transcript window, procedure card or safety warning)."""

    __tablename__ = "knowledge_chunks"
    __table_args__ = (Index("ix_chunks_org_approved", "org_id", "approved"),)
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    record_id: Mapped[str | None] = mapped_column(ForeignKey("knowledge_records.id", ondelete="CASCADE"), nullable=True, index=True)
    asset_id: Mapped[str | None] = mapped_column(ForeignKey("assets.id", ondelete="SET NULL"), nullable=True, index=True)
    procedure_id: Mapped[str | None] = mapped_column(ForeignKey("procedures.id", ondelete="CASCADE"), nullable=True, index=True)
    chunk_type: Mapped[str] = mapped_column(String(20))  # transcript|procedure|document|safety
    text: Mapped[str] = mapped_column(Text)
    start_s: Mapped[float | None] = mapped_column(Float, nullable=True)
    end_s: Mapped[float | None] = mapped_column(Float, nullable=True)
    approved: Mapped[bool] = mapped_column(Boolean, default=False)
    embedding: Mapped[list[float] | None] = mapped_column(VectorType(get_settings().embedding_dim), nullable=True)
    embedding_model: Mapped[str] = mapped_column(String(80), default="")


class KnowledgeConflict(TimestampMixin, Base):
    __tablename__ = "knowledge_conflicts"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    asset_id: Mapped[str | None] = mapped_column(ForeignKey("assets.id", ondelete="CASCADE"), nullable=True)
    procedure_a_id: Mapped[str] = mapped_column(ForeignKey("procedures.id", ondelete="CASCADE"))
    procedure_b_id: Mapped[str] = mapped_column(ForeignKey("procedures.id", ondelete="CASCADE"))
    conflict_type: Mapped[str] = mapped_column(String(40), default="different_first_check")
    description: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="open")  # open|resolved|dismissed
    resolution: Mapped[str] = mapped_column(Text, default="")
    preferred_procedure_id: Mapped[str | None] = mapped_column(ForeignKey("procedures.id", ondelete="SET NULL"), nullable=True)
    resolved_by_id: Mapped[str | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    detected_by: Mapped[str] = mapped_column(String(40), default="rules")

    procedure_a: Mapped[Procedure] = relationship(foreign_keys=[procedure_a_id], lazy="joined")
    procedure_b: Mapped[Procedure] = relationship(foreign_keys=[procedure_b_id], lazy="joined")


class Review(TimestampMixin, Base):
    __tablename__ = "reviews"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    target_type: Mapped[str] = mapped_column(String(20))  # record|procedure|conflict|safety_warning
    target_id: Mapped[str] = mapped_column(String(32), index=True)
    reviewer_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    decision: Mapped[str] = mapped_column(String(20))  # approved|rejected|needs_changes|edited|resolved
    comment: Mapped[str] = mapped_column(Text, default="")
    changes: Mapped[dict[str, Any]] = mapped_column(JSONType, default=dict)

    reviewer: Mapped[User] = relationship(lazy="joined")


# ---------------------------------------------------------------------------
# Assistant & harvest
# ---------------------------------------------------------------------------


class Conversation(TimestampMixin, Base):
    __tablename__ = "conversations"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    asset_id: Mapped[str | None] = mapped_column(ForeignKey("assets.id", ondelete="SET NULL"), nullable=True)
    title: Mapped[str] = mapped_column(String(300), default="New conversation")


class Message(TimestampMixin, Base):
    __tablename__ = "messages"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    conversation_id: Mapped[str] = mapped_column(ForeignKey("conversations.id", ondelete="CASCADE"), index=True)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    role: Mapped[str] = mapped_column(String(12))  # user|assistant
    content: Mapped[str] = mapped_column(Text)
    answer: Mapped[dict[str, Any] | None] = mapped_column(JSONType, nullable=True)
    groundedness: Mapped[str | None] = mapped_column(String(16), nullable=True)
    asset_id: Mapped[str | None] = mapped_column(ForeignKey("assets.id", ondelete="SET NULL"), nullable=True)
    escalated: Mapped[bool] = mapped_column(Boolean, default=False)


class HarvestSession(TimestampMixin, Base):
    __tablename__ = "harvest_sessions"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    asset_id: Mapped[str] = mapped_column(ForeignKey("assets.id", ondelete="CASCADE"))
    technician_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    status: Mapped[str] = mapped_column(String(20), default="active")  # active|completed|abandoned
    coverage: Mapped[dict[str, Any]] = mapped_column(JSONType, default=dict)
    turns: Mapped[list[dict[str, Any]]] = mapped_column(JSONType, default=list)
    state: Mapped[dict[str, Any]] = mapped_column(JSONType, default=dict)
    record_id: Mapped[str | None] = mapped_column(ForeignKey("knowledge_records.id", ondelete="SET NULL"), nullable=True)
    agent_mode: Mapped[str] = mapped_column(String(20), default="rules")

    asset: Mapped[Asset] = relationship(lazy="joined")


# ---------------------------------------------------------------------------
# Closing the loop: answer feedback and guided procedure execution
# (added in migration 0002)
# ---------------------------------------------------------------------------


class AnswerFeedback(TimestampMixin, Base):
    """Technician feedback on an assistant answer: did the recommended procedure fix the problem?"""

    __tablename__ = "answer_feedback"
    __table_args__ = (UniqueConstraint("message_id", "user_id"), Index("ix_feedback_org_outcome", "org_id", "outcome"))
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    message_id: Mapped[str] = mapped_column(ForeignKey("messages.id", ondelete="CASCADE"), index=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    asset_id: Mapped[str | None] = mapped_column(ForeignKey("assets.id", ondelete="SET NULL"), nullable=True)
    procedure_id: Mapped[str | None] = mapped_column(ForeignKey("procedures.id", ondelete="SET NULL"), nullable=True)
    outcome: Mapped[str] = mapped_column(String(20))  # resolved|partially|not_resolved|wrong_answer
    comment: Mapped[str] = mapped_column(Text, default="")


class ProcedureExecution(TimestampMixin, Base):
    """A technician working through an approved procedure step by step on the shop floor."""

    __tablename__ = "procedure_executions"
    __table_args__ = (Index("ix_exec_org_status", "org_id", "status"),)
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), index=True)
    procedure_id: Mapped[str] = mapped_column(ForeignKey("procedures.id", ondelete="CASCADE"), index=True)
    asset_id: Mapped[str | None] = mapped_column(ForeignKey("assets.id", ondelete="SET NULL"), nullable=True, index=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"))
    status: Mapped[str] = mapped_column(String(20), default="in_progress")  # in_progress|completed|aborted
    procedure_version: Mapped[int] = mapped_column(Integer, default=1)
    safety_acknowledged: Mapped[list[str]] = mapped_column(JSONType, default=list)
    step_states: Mapped[list[dict[str, Any]]] = mapped_column(JSONType, default=list)  # [{order, done, at, note}]
    outcome: Mapped[str] = mapped_column(String(20), default="")  # resolved|not_resolved|escalated
    notes: Mapped[str] = mapped_column(Text, default="")
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    maintenance_event_id: Mapped[str | None] = mapped_column(ForeignKey("maintenance_events.id", ondelete="SET NULL"), nullable=True)

    procedure: Mapped[Procedure] = relationship(lazy="joined")
    user: Mapped[User] = relationship(lazy="joined")


# ---------------------------------------------------------------------------
# Observability & audit
# ---------------------------------------------------------------------------


class AuditLog(Base):
    __tablename__ = "audit_logs"
    __table_args__ = (Index("ix_audit_org_created", "org_id", "created_at"),)
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str | None] = mapped_column(ForeignKey("organizations.id", ondelete="CASCADE"), nullable=True)
    user_id: Mapped[str | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    action: Mapped[str] = mapped_column(String(80))
    entity_type: Mapped[str] = mapped_column(String(40), default="")
    entity_id: Mapped[str] = mapped_column(String(64), default="")
    ip_address: Mapped[str] = mapped_column(String(64), default="")
    details: Mapped[dict[str, Any]] = mapped_column(JSONType, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class AIRequestLog(Base):
    __tablename__ = "ai_request_logs"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    org_id: Mapped[str | None] = mapped_column(String(32), nullable=True, index=True)
    kind: Mapped[str] = mapped_column(String(40))  # chat|extraction|embedding|transcription|harvest|conflict
    provider: Mapped[str] = mapped_column(String(40))
    model: Mapped[str] = mapped_column(String(80), default="")
    status: Mapped[str] = mapped_column(String(20))  # ok|error|fallback
    latency_ms: Mapped[int] = mapped_column(Integer, default=0)
    input_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    output_tokens: Mapped[int | None] = mapped_column(Integer, nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
