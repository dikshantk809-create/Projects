"""Text normalisation shared by retrieval, embeddings and extraction.

Includes a small industrial-maintenance synonym lexicon so that "pump is noisy
when starting" and "grinding sound during startup" share vocabulary.
"""

from __future__ import annotations

import re
from functools import lru_cache

TAG_RE = re.compile(r"\b([A-Za-z]{1,4})[- ]?(\d{1,4}[A-Za-z]?)\b")
WORD_RE = re.compile(r"[A-Za-z]{1,4}-\d{1,4}[A-Za-z]?|[A-Za-z0-9]+(?:'[a-z]+)?")

STOPWORDS = frozenset(
    """a an the and or but if then than so to of in on at by for with from into onto over under is are was were be been
    being am do does did doing have has had having i me my we our you your he she it its they them their this that these
    those there here what which who whom whose when where why how all any both each few more most other some such no nor
    not only own same too very can will just should would could may might must shall also about as up down out off again
    further once during before after above below between through until while us let lets get got okay ok um uh like
    really basically actually thing things something anything please tell know what's whats i'm im it's its""".split()
)

# canonical -> variants. Keep conservative: only merge words technicians use
# interchangeably when describing faults.
_SYNONYM_GROUPS: dict[str, tuple[str, ...]] = {
    "noise": ("noise", "noisy", "sound", "sounds", "noises", "loud"),
    "grind": ("grind", "grinding", "grating", "scraping", "gritty"),
    "squeal": ("squeal", "squealing", "screech", "screeching", "squeak", "squeaking", "whine", "whining"),
    "knock": ("knock", "knocking", "banging", "bang", "clunk", "clunking", "rattle", "rattling"),
    "vibration": ("vibration", "vibrations", "vibrate", "vibrating", "shaking", "shake", "shakes", "wobble"),
    "pressure": ("pressure", "pressures", "psi", "bar"),
    "low": ("low", "drop", "drops", "dropping", "dropped", "loss", "falls", "falling", "decrease", "below", "reduced"),
    "high": ("high", "spike", "spikes", "above", "excessive", "rises", "rising"),
    "heat": ("heat", "hot", "overheat", "overheating", "overheats", "temperature", "temp", "thermal"),
    "leak": ("leak", "leaks", "leaking", "leakage", "drip", "dripping", "seep", "seeping"),
    "block": ("block", "blockage", "blocked", "clog", "clogged", "clogging", "obstruction", "obstructed", "choked", "restriction"),
    "inspect": ("inspect", "inspection", "check", "checking", "examine", "look", "verify"),
    "replace": ("replace", "replacing", "replacement", "swap", "change", "changing", "renew"),
    "clean": ("clean", "cleaning", "flush", "flushing", "purge"),
    "start": ("start", "startup", "start-up", "starting", "starts", "boot", "power-up"),
    "stop": ("stop", "stops", "stopping", "shutdown", "halt", "trip", "trips", "tripping", "stall", "stalls"),
    "misalign": ("misalign", "misaligned", "misalignment", "alignment", "offset"),
    "wear": ("wear", "worn", "wearing", "wornout"),
    "slip": ("slip", "slipping", "slips", "slack", "loose"),
    "lockout": ("lockout", "lockout/tagout", "loto", "tagout", "isolation", "isolate", "isolated"),
    "machine": ("machine", "equipment", "unit"),
}

_VARIANT_TO_CANON: dict[str, str] = {}
for _canon, _variants in _SYNONYM_GROUPS.items():
    for _v in _variants:
        _VARIANT_TO_CANON[_v] = _canon


def normalize_tag(tag: str) -> str:
    """'p103', 'P 103', 'p-103' -> 'P-103'."""
    m = TAG_RE.fullmatch(tag.strip())
    if not m:
        return tag.strip().upper()
    return f"{m.group(1).upper()}-{m.group(2).upper()}"


def find_tags(text: str) -> list[str]:
    tags: list[str] = []
    for m in re.finditer(r"\b([A-Za-z]{1,4})-(\d{1,4}[A-Za-z]?)\b", text):
        t = f"{m.group(1).upper()}-{m.group(2).upper()}"
        if t not in tags:
            tags.append(t)
    return tags


@lru_cache(maxsize=50_000)
def stem(word: str) -> str:
    """Tiny, predictable suffix stripper (good enough for BM25 recall)."""
    w = word
    if len(w) <= 4 or "-" in w:
        return w
    for suf in ("ations", "ation", "ments", "ment", "ingly", "ings", "ing", "edly", "ies", "ied", "ers", "er", "ed", "es", "ly", "s"):
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            w = w[: -len(suf)]
            if suf in ("ies", "ied"):
                w += "y"
            break
    if len(w) > 3 and w[-1] == w[-2] and w[-1] not in "lsz":
        w = w[:-1]
    return w


def canonical(word: str) -> str:
    lw = word.lower()
    if lw in _VARIANT_TO_CANON:
        return _VARIANT_TO_CANON[lw]
    if re.fullmatch(r"[a-z]{1,4}-\d{1,4}[a-z]?", lw):
        return lw.upper()
    return stem(lw)


def tokenize(text: str, *, keep_stopwords: bool = False) -> list[str]:
    """Lower-cased, canonicalised tokens. Asset/component tags stay intact (e.g. 'P-103')."""
    out: list[str] = []
    for raw in WORD_RE.findall(text):
        lw = raw.lower()
        if not keep_stopwords and lw in STOPWORDS:
            continue
        out.append(canonical(lw))
    return out


def sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[.!?])\s+|\n+", text)
    return [p.strip() for p in parts if p and p.strip()]


def jaccard(a: set[str], b: set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def token_overlap(claim: str, evidence: str) -> float:
    """Fraction of the claim's content tokens found in the evidence."""
    ct = set(tokenize(claim))
    if not ct:
        return 0.0
    et = set(tokenize(evidence))
    return len(ct & et) / len(ct)
