"""Speech-to-text.

Server-side: OpenAI Whisper API (``TRANSCRIPTION_PROVIDER=openai``) returning
segment timestamps. Client-side alternative: the capture UI can use the
browser's built-in speech recognition (Chrome/Edge) and upload the timed
transcript with the recording; such records are labelled
``transcript_source=browser_speech``. If neither is available the record is
marked ``needs_transcript`` and a technician can type/paste it - nothing is
invented.
"""

from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any

import httpx

from ..config import get_settings
from .llm import log_ai_request


@dataclass
class Transcript:
    text: str
    segments: list[dict[str, Any]]
    source: str
    duration_s: float | None = None


def transcription_available() -> bool:
    s = get_settings()
    return s.transcription_provider == "openai" and bool(s.openai_api_key)


def transcribe(data: bytes, filename: str, mime: str, org_id: str | None = None) -> Transcript | None:
    s = get_settings()
    if not transcription_available():
        return None
    started = time.monotonic()
    try:
        with httpx.Client(timeout=max(120.0, s.ai_timeout_seconds)) as client:
            resp = client.post(
                f"{s.openai_base_url.rstrip('/')}/audio/transcriptions",
                headers={"Authorization": f"Bearer {s.openai_api_key}"},
                data={"model": s.transcription_model, "response_format": "verbose_json"},
                files={"file": (filename, data, mime or "application/octet-stream")},
            )
        if resp.status_code >= 400:
            raise RuntimeError(f"HTTP {resp.status_code}: {resp.text[:200]}")
        body = resp.json()
    except Exception as exc:  # noqa: BLE001
        log_ai_request(kind="transcription", provider="openai", model=s.transcription_model, status="error",
                       latency_ms=int((time.monotonic() - started) * 1000), org_id=org_id, error=str(exc))
        return None
    log_ai_request(kind="transcription", provider="openai", model=s.transcription_model, status="ok",
                   latency_ms=int((time.monotonic() - started) * 1000), org_id=org_id)
    segments = [
        {"start": float(sg.get("start", 0)), "end": float(sg.get("end", 0)), "text": str(sg.get("text", "")).strip()}
        for sg in body.get("segments") or []
    ]
    text = str(body.get("text", "")).strip()
    if not segments and text:
        segments = [{"start": 0.0, "end": float(body.get("duration") or 0), "text": text}]
    return Transcript(text=text, segments=segments, source=f"whisper:{s.transcription_model}", duration_s=body.get("duration"))


def normalize_segments(raw: Any) -> list[dict[str, Any]]:
    """Validate client-provided timed segments (from browser speech recognition)."""
    out: list[dict[str, Any]] = []
    if not isinstance(raw, list):
        return out
    for item in raw[:2000]:
        if not isinstance(item, dict):
            continue
        text = str(item.get("text", "")).strip()[:2000]
        if not text:
            continue
        try:
            start = max(0.0, float(item.get("start", 0)))
            end = max(start, float(item.get("end", start)))
        except (TypeError, ValueError):
            continue
        out.append({"start": round(start, 2), "end": round(end, 2), "text": text})
    out.sort(key=lambda s: s["start"])
    return out


def segments_from_plain_text(text: str) -> list[dict[str, Any]]:
    """Untimed text (notes, documents) -> paragraph segments with no timestamps."""
    paras = [p.strip() for p in text.replace("\r", "").split("\n") if p.strip()]
    return [{"start": None, "end": None, "text": p} for p in paras]
