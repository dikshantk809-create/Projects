"""Knowledge processing pipeline.

    Audio/Video/Image/Document/Text
        -> preprocessing -> transcription -> entity extraction -> procedure extraction
        -> failure-mode extraction -> safety extraction -> machine mapping
        -> knowledge structuring -> indexing (chunks + embeddings) -> conflict detection

Every stage writes its status into ``KnowledgeRecord.processing_stages`` so the
UI can show real progress. Failures are captured per stage and never leave a
record stuck in "processing".
"""

from __future__ import annotations

import logging
import re
import traceback
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..db import session_factory, utcnow
from ..models import (
    Asset,
    Component,
    Document,
    FailureMode,
    FailureModeSymptom,
    KnowledgeChunk,
    KnowledgeRecord,
    KnowledgeSource,
    Procedure,
    SafetyWarning,
    Symptom,
)
from ..observability import log_event
from ..services.storage import get_storage
from .conflicts import detect_conflicts_for
from .documents import extract_text
from .embeddings import get_embedder
from .extraction import Extraction, extract_knowledge
from .transcription import segments_from_plain_text, transcribe

logger = logging.getLogger("legacymind.pipeline")

STAGES = [
    "preprocessing", "transcription", "entity_extraction", "procedure_extraction", "failure_mode_extraction",
    "safety_extraction", "machine_mapping", "knowledge_structuring", "indexing", "conflict_detection",
]


class _Stages:
    def __init__(self, record: KnowledgeRecord) -> None:
        self.record = record
        self.items: list[dict[str, Any]] = [{"name": n, "status": "pending", "detail": ""} for n in STAGES]

    def set(self, name: str, status: str, detail: str = "") -> None:
        for it in self.items:
            if it["name"] == name:
                it.update(status=status, detail=detail, at=utcnow().isoformat())
        self.record.processing_stages = [dict(i) for i in self.items]


# ---------------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------------


def run_pipeline(record_id: str) -> None:
    """Process one record in its own DB session (safe for background tasks)."""
    db = session_factory()()
    try:
        record = db.get(KnowledgeRecord, record_id)
        if record is None:
            return
        try:
            process_record(db, record)
        except Exception as exc:  # noqa: BLE001
            db.rollback()
            record = db.get(KnowledgeRecord, record_id)
            if record is not None:
                record.processing_status = "failed"
                record.processing_error = f"{type(exc).__name__}: {exc}"[:1000]
                db.commit()
            logger.error("pipeline_failed", extra={"extra_fields": {"record_id": record_id, "trace": traceback.format_exc()[-2000:]}})
    finally:
        db.close()


def process_record(db: Session, record: KnowledgeRecord) -> None:
    st = _Stages(record)
    record.processing_status = "processing"
    record.processing_error = None
    db.commit()

    # 1. preprocessing: collect raw text sources
    doc_texts: list[str] = []
    for doc in record.documents:
        if not doc.extracted_text:
            try:
                data = get_storage().get(doc.storage_key)
                ext = "." + doc.filename.rsplit(".", 1)[-1].lower() if "." in doc.filename else ""
                doc.extracted_text, doc.extraction_method = extract_text(data, ext)
            except Exception as exc:  # noqa: BLE001
                doc.extraction_method = f"failed: {type(exc).__name__}"
        if doc.extracted_text:
            doc_texts.append(doc.extracted_text)
    st.set("preprocessing", "done", f"{len(record.recordings)} recording(s), {len(record.documents)} document(s)")

    # 2. transcription
    if record.segments:
        st.set("transcription", "done", f"transcript provided ({record.transcript_source or 'client'})")
    elif record.recordings:
        rec = record.recordings[0]
        tr = None
        if rec.storage_key:
            tr = transcribe(get_storage().get(rec.storage_key), rec.filename, rec.mime_type, org_id=record.org_id)
        if tr:
            record.segments = tr.segments
            record.transcript = tr.text
            record.transcript_source = tr.source
            if tr.duration_s:
                rec.duration_s = float(tr.duration_s)
            st.set("transcription", "done", tr.source)
        elif not doc_texts and not record.notes.strip():
            st.set("transcription", "skipped", "No speech-to-text provider configured and no transcript supplied")
            record.processing_status = "needs_transcript"
            db.commit()
            return
        else:
            st.set("transcription", "skipped", "no server transcription; using notes/documents")
    else:
        st.set("transcription", "skipped", "no audio/video")

    if not record.segments:
        text_parts = [record.notes.strip()] + doc_texts
        combined = "\n".join(p for p in text_parts if p)
        record.segments = segments_from_plain_text(combined)
        record.transcript = combined
        record.transcript_source = record.transcript_source or ("document" if doc_texts else "manual")
    elif not record.transcript:
        record.transcript = " ".join(s["text"] for s in record.segments)

    if not record.transcript.strip():
        record.processing_status = "needs_transcript"
        st.set("entity_extraction", "skipped", "no text to analyse")
        db.commit()
        return

    # 3-6. extraction
    assets = db.scalars(select(Asset).where(Asset.org_id == record.org_id)).all()
    tags = {a.asset_tag for a in assets}
    names = {a.asset_tag: a.name for a in assets}
    ex = extract_knowledge(record.segments, tags, names, org_id=record.org_id)
    record.extraction = ex.as_dict()
    record.ai_version = ex.method
    record.summary = ex.summary
    st.set("entity_extraction", "done", f"{len(ex.components)} components, {len(ex.symptoms)} symptoms, {len(ex.tools)} tools, {len(ex.parts)} parts [{ex.method}]")
    st.set("procedure_extraction", "done", f"{len(ex.procedures)} procedure(s), {sum(len(p['steps']) for p in ex.procedures)} steps")
    st.set("failure_mode_extraction", "done", f"{len(ex.failure_modes)} failure mode(s), {len(ex.causes)} cause(s)")
    st.set("safety_extraction", "done", f"{len(ex.safety)} safety statement(s)")
    if ex.dropped_unverified:
        st.set("entity_extraction", "done", f"{st.items[2]['detail']}; {ex.dropped_unverified} unverifiable item(s) discarded")

    # 7. machine mapping
    asset = db.get(Asset, record.asset_id) if record.asset_id else None
    if asset is None and ex.asset_tags:
        asset = next((a for a in assets if a.asset_tag == ex.asset_tags[0]), None)
        if asset:
            record.asset_id = asset.id
    st.set("machine_mapping", "done" if asset else "skipped", f"{asset.asset_tag} {asset.name}" if asset else "no asset identified - supervisor should assign one")

    # 8. structuring
    created = structure_knowledge(db, record, asset, ex)
    st.set("knowledge_structuring", "done", f"{created['procedures']} procedure card(s), {created['safety']} safety warning(s), {created['failure_modes']} failure mode(s)")

    # 9. indexing
    n = index_record(db, record)
    st.set("indexing", "done", f"{n} chunk(s) embedded with {get_embedder().name}")

    # 10. conflicts
    conflicts = 0
    for proc in db.scalars(select(Procedure).where(Procedure.record_id == record.id)).all():
        conflicts += len(detect_conflicts_for(db, proc))
    st.set("conflict_detection", "done", f"{conflicts} conflict(s) detected")

    record.processing_status = "processed"
    db.commit()
    log_event(logger, "record_processed", record_id=record.id, method=ex.method, procedures=created["procedures"])


# ---------------------------------------------------------------------------
# Structuring
# ---------------------------------------------------------------------------


def next_procedure_ref(db: Session, org_id: str, asset: Asset | None) -> str:
    code = re.sub(r"[^0-9A-Z]", "", asset.asset_tag.split("-")[-1]) if asset else "GEN"
    prefix = f"PR-{code}-"
    existing = db.scalars(select(Procedure.ref).where(Procedure.org_id == org_id, Procedure.ref.like(f"{prefix}%"))).all()
    nums = [int(r.rsplit("-", 1)[-1]) for r in existing if r.rsplit("-", 1)[-1].isdigit()]
    return f"{prefix}{(max(nums) + 1 if nums else 1):02d}"


def next_record_ref(db: Session, org_id: str) -> str:
    refs = db.scalars(select(KnowledgeRecord.ref).where(KnowledgeRecord.org_id == org_id)).all()
    nums = [int(r.split("-")[-1]) for r in refs if r.split("-")[-1].isdigit()]
    return f"LM-{(max(nums) + 1) if nums else 1001}"


def _risk_level(asset: Asset | None, safety: list[dict[str, Any]]) -> str:
    if any(s.get("severity") == "danger" for s in safety):
        return "high" if not (asset and asset.criticality == "critical") else "critical"
    if asset and asset.criticality in ("high", "critical"):
        return "high" if asset.criticality == "critical" else "medium"
    if safety:
        return "medium"
    return "low"


def _get_or_create_symptom(db: Session, org_id: str, name: str) -> Symptom:
    name = name.strip().lower()[:200]
    sym = db.scalar(select(Symptom).where(Symptom.org_id == org_id, Symptom.name == name))
    if sym is None:
        sym = Symptom(org_id=org_id, name=name)
        db.add(sym)
        db.flush()
    return sym


def structure_knowledge(db: Session, record: KnowledgeRecord, asset: Asset | None, ex: Extraction) -> dict[str, int]:
    org_id = record.org_id
    counts = {"procedures": 0, "safety": 0, "failure_modes": 0}
    recording_id = record.recordings[0].id if record.recordings else None
    document_id = record.documents[0].id if record.documents else None

    def source(entity_type: str, entity_id: str, item: dict[str, Any]) -> None:
        db.add(KnowledgeSource(
            org_id=org_id, entity_type=entity_type, entity_id=entity_id, record_id=record.id,
            recording_id=recording_id, document_id=document_id, technician_id=record.contributor_id,
            start_s=item.get("start"), end_s=item.get("end"), quote=str(item.get("quote", ""))[:2000],
            confidence=float(item.get("confidence", 0.5)), ai_version=ex.method,
        ))

    fm_objs: list[FailureMode] = []
    if asset is not None:
        for c in ex.components:
            nm = str(c["name"])[:160]
            exists = db.scalar(select(Component).where(Component.asset_id == asset.id, func.lower(Component.name) == nm.lower()))
            if exists is None:
                db.add(Component(org_id=org_id, asset_id=asset.id, name=nm, tag=str(c.get("tag") or "")[:40]))
        causes = [c["name"] for c in ex.causes]
        for fm in ex.failure_modes:
            nm = str(fm["name"]).strip().lower()[:200]
            obj = db.scalar(select(FailureMode).where(FailureMode.asset_id == asset.id, FailureMode.name == nm))
            if obj is None:
                obj = FailureMode(org_id=org_id, asset_id=asset.id, name=nm, causes=causes[:5],
                                  description=str(fm.get("quote", ""))[:500])
                db.add(obj)
                db.flush()
                counts["failure_modes"] += 1
            else:
                obj.causes = list(dict.fromkeys((obj.causes or []) + causes))[:10]
            fm_objs.append(obj)
            source("failure_mode", obj.id, fm)
        db.flush()

    risk = _risk_level(asset, ex.safety)
    first_proc: Procedure | None = None
    for proc in ex.procedures:
        p = Procedure(
            org_id=org_id,
            ref=next_procedure_ref(db, org_id, asset),
            asset_id=asset.id if asset else None,
            failure_mode_id=fm_objs[0].id if fm_objs else None,
            record_id=record.id,
            title=proc["title"][:300],
            symptoms=proc.get("symptoms") or [s["name"] for s in ex.symptoms][:6],
            steps=[
                {"order": s["order"], "text": s["text"], "component": s.get("component", ""),
                 "source": {"record_id": record.id, "start": s.get("start"), "end": s.get("end"), "quote": s.get("quote", "")},
                 "confidence": s.get("confidence", 0.5)}
                for s in proc["steps"]
            ],
            tools=[t["name"] for t in ex.tools],
            parts=[p_["name"] for p_ in ex.parts],
            risk_level=risk,
            requires_supervisor=risk in ("high", "critical"),
            status="pending_review",
            confidence=float(proc.get("confidence", 0.5)),
            author_id=record.contributor_id,
            ai_version=ex.method,
            is_synthetic=record.is_synthetic,
        )
        db.add(p)
        db.flush()
        counts["procedures"] += 1
        first_proc = first_proc or p
        source("procedure", p.id, {"quote": proc["steps"][0].get("quote", ""), "start": proc["steps"][0].get("start"),
                                   "end": proc["steps"][-1].get("end"), "confidence": proc.get("confidence", 0.5)})
        for s in proc["steps"]:
            source("procedure_step", p.id, s)
        if fm_objs:
            for sname in p.symptoms:
                sym = _get_or_create_symptom(db, org_id, sname)
                link = db.get(FailureModeSymptom, (fm_objs[0].id, sym.id))
                if link is None:
                    db.add(FailureModeSymptom(failure_mode_id=fm_objs[0].id, symptom_id=sym.id))
        else:
            for sname in p.symptoms:
                _get_or_create_symptom(db, org_id, sname)

    for sw in ex.safety:
        w = SafetyWarning(
            org_id=org_id, asset_id=asset.id if asset else None, procedure_id=first_proc.id if first_proc else None,
            record_id=record.id, text=str(sw["text"])[:1000], hazard_type=sw.get("hazard_type", "general"),
            severity=sw.get("severity", "warning"), status="pending_review",
        )
        db.add(w)
        db.flush()
        counts["safety"] += 1
        source("safety_warning", w.id, sw)
    db.flush()
    return counts


# ---------------------------------------------------------------------------
# Indexing
# ---------------------------------------------------------------------------


def _windows(segments: list[dict[str, Any]], max_words: int = 80) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    cur: list[dict[str, Any]] = []
    words = 0
    for seg in segments:
        n = len(str(seg.get("text", "")).split())
        if cur and words + n > max_words:
            out.append(cur)  # type: ignore[arg-type]
            cur, words = [], 0
        cur.append(seg)
        words += n
    if cur:
        out.append(cur)  # type: ignore[arg-type]
    chunks = []
    for group in out:
        g: list[dict[str, Any]] = group  # type: ignore[assignment]
        chunks.append({
            "text": " ".join(str(s["text"]).strip() for s in g),
            "start": g[0].get("start"),
            "end": g[-1].get("end"),
        })
    return chunks


def procedure_card_text(p: Procedure, safety: list[SafetyWarning]) -> str:
    asset = f"{p.asset.asset_tag} {p.asset.name}" if p.asset else "general"
    steps = " ".join(f"{s['order']}. {s['text']}." for s in p.steps)
    sw = " ".join(w.text for w in safety)
    fm = f" Failure mode: {p.failure_mode.name}." if p.failure_mode else ""
    return (f"Procedure {p.ref}: {p.title}. Machine: {asset}.{fm} Symptoms: {', '.join(p.symptoms)}. "
            f"Steps: {steps} Tools: {', '.join(p.tools) or 'none stated'}. Safety: {sw or 'none recorded'}")


def index_record(db: Session, record: KnowledgeRecord) -> int:
    db.query(KnowledgeChunk).filter(KnowledgeChunk.record_id == record.id).delete()
    embedder = get_embedder()
    approved_record = record.review_status == "approved"
    rows: list[KnowledgeChunk] = []
    for w in _windows(record.segments):
        rows.append(KnowledgeChunk(
            org_id=record.org_id, record_id=record.id, asset_id=record.asset_id, chunk_type="transcript",
            text=w["text"], start_s=w["start"], end_s=w["end"], approved=approved_record,
        ))
    procs = db.scalars(select(Procedure).where(Procedure.record_id == record.id)).all()
    for p in procs:
        safety = db.scalars(select(SafetyWarning).where(SafetyWarning.procedure_id == p.id)).all()
        rows.append(KnowledgeChunk(
            org_id=record.org_id, record_id=record.id, asset_id=p.asset_id, procedure_id=p.id, chunk_type="procedure",
            text=procedure_card_text(p, list(safety)), approved=p.status == "approved",
        ))
    if rows:
        vecs = embedder.embed([r.text for r in rows])
        for r, v in zip(rows, vecs, strict=True):
            r.embedding = v
            r.embedding_model = embedder.name
        db.add_all(rows)
    db.flush()
    return len(rows)


def reindex_procedure(db: Session, p: Procedure) -> None:
    """Refresh a procedure card chunk after edits/approval."""
    db.query(KnowledgeChunk).filter(KnowledgeChunk.procedure_id == p.id).delete()
    safety = db.scalars(select(SafetyWarning).where(SafetyWarning.procedure_id == p.id)).all()
    text = procedure_card_text(p, list(safety))
    emb = get_embedder()
    db.add(KnowledgeChunk(
        org_id=p.org_id, record_id=p.record_id, asset_id=p.asset_id, procedure_id=p.id, chunk_type="procedure",
        text=text, approved=p.status == "approved", embedding=emb.embed([text])[0], embedding_model=emb.name,
    ))
    db.flush()


def sync_record_chunk_approval(db: Session, record: KnowledgeRecord) -> None:
    approved = record.review_status == "approved"
    for ch in db.scalars(select(KnowledgeChunk).where(KnowledgeChunk.record_id == record.id, KnowledgeChunk.chunk_type == "transcript")):
        ch.approved = approved
    db.flush()


def attach_document_text(db: Session, doc: Document) -> None:  # pragma: no cover - helper for asset documents
    data = get_storage().get(doc.storage_key)
    ext = "." + doc.filename.rsplit(".", 1)[-1].lower()
    doc.extracted_text, doc.extraction_method = extract_text(data, ext)
    db.flush()
