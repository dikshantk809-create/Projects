"""LLM provider abstraction.

Providers are called over plain HTTPS with httpx (no vendor SDKs), with
timeouts, bounded retries with exponential backoff, and request logging.
When ``AI_PROVIDER=none`` (or a provider fails), callers receive ``None`` and
fall back to deterministic, clearly-labelled local logic. We never pretend an
LLM answered when it did not.
"""

from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass
from typing import Any

import httpx

from ..config import get_settings
from ..db import session_factory
from ..models import AIRequestLog
from ..observability import log_event

logger = logging.getLogger("legacymind.ai")


class LLMError(RuntimeError):
    pass


@dataclass
class LLMResult:
    text: str
    provider: str
    model: str
    input_tokens: int | None = None
    output_tokens: int | None = None


DEFAULT_MODELS = {"openai": "gpt-4o-mini", "anthropic": "claude-sonnet-4-5", "ollama": "llama3.1:8b"}


def llm_configured() -> bool:
    s = get_settings()
    if s.ai_provider == "openai":
        return bool(s.openai_api_key)
    if s.ai_provider == "anthropic":
        return bool(s.anthropic_api_key)
    if s.ai_provider == "ollama":
        return True
    return False


def provider_label() -> str:
    s = get_settings()
    if not llm_configured():
        return "local-rules"
    return f"{s.ai_provider}:{s.model_name or DEFAULT_MODELS.get(s.ai_provider, '')}"


def log_ai_request(
    *, kind: str, provider: str, model: str, status: str, latency_ms: int, org_id: str | None = None,
    input_tokens: int | None = None, output_tokens: int | None = None, error: str | None = None,
) -> None:
    try:
        db = session_factory()()
        try:
            db.add(
                AIRequestLog(
                    org_id=org_id, kind=kind, provider=provider, model=model, status=status, latency_ms=latency_ms,
                    input_tokens=input_tokens, output_tokens=output_tokens, error=(error or None) and error[:2000],
                )
            )
            db.commit()
        finally:
            db.close()
    except Exception:  # pragma: no cover - logging must never break the request
        logger.warning("could not persist AI request log", exc_info=True)
    log_event(logger, "ai_request", kind=kind, provider=provider, model=model, status=status, latency_ms=latency_ms)


def _post_with_retries(url: str, *, headers: dict[str, str], payload: dict[str, Any]) -> dict[str, Any]:
    s = get_settings()
    last_exc: Exception | None = None
    for attempt in range(s.ai_max_retries + 1):
        try:
            with httpx.Client(timeout=s.ai_timeout_seconds) as client:
                resp = client.post(url, headers=headers, json=payload)
            if resp.status_code in (429, 500, 502, 503, 504) and attempt < s.ai_max_retries:
                time.sleep(min(8.0, 0.8 * 2**attempt))
                continue
            if resp.status_code >= 400:
                raise LLMError(f"provider returned HTTP {resp.status_code}: {resp.text[:300]}")
            return resp.json()
        except (httpx.TimeoutException, httpx.TransportError) as exc:
            last_exc = exc
            if attempt < s.ai_max_retries:
                time.sleep(min(8.0, 0.8 * 2**attempt))
                continue
    raise LLMError(f"provider unreachable: {last_exc}")


def complete(system: str, user: str, *, json_mode: bool = True, max_tokens: int = 1500, kind: str = "chat",
             org_id: str | None = None) -> LLMResult | None:
    """Run one completion. Returns None when no provider is configured or the call fails."""
    s = get_settings()
    if not llm_configured():
        return None
    provider = s.ai_provider
    model = s.model_name or DEFAULT_MODELS[provider]
    started = time.monotonic()
    try:
        if provider == "openai":
            payload: dict[str, Any] = {
                "model": model,
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
                "temperature": 0,
                "max_tokens": max_tokens,
            }
            if json_mode:
                payload["response_format"] = {"type": "json_object"}
            data = _post_with_retries(
                f"{s.openai_base_url.rstrip('/')}/chat/completions",
                headers={"Authorization": f"Bearer {s.openai_api_key}"},
                payload=payload,
            )
            text = data["choices"][0]["message"]["content"] or ""
            usage = data.get("usage") or {}
            result = LLMResult(text, provider, model, usage.get("prompt_tokens"), usage.get("completion_tokens"))
        elif provider == "anthropic":
            data = _post_with_retries(
                f"{s.anthropic_base_url.rstrip('/')}/v1/messages",
                headers={"x-api-key": s.anthropic_api_key, "anthropic-version": "2023-06-01"},
                payload={
                    "model": model,
                    "system": system + ("\nRespond with a single JSON object only." if json_mode else ""),
                    "max_tokens": max_tokens,
                    "temperature": 0,
                    "messages": [{"role": "user", "content": user}],
                },
            )
            text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
            usage = data.get("usage") or {}
            result = LLMResult(text, provider, model, usage.get("input_tokens"), usage.get("output_tokens"))
        else:  # ollama (on-prem / edge)
            payload = {
                "model": model,
                "stream": False,
                "options": {"temperature": 0},
                "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
            }
            if json_mode:
                payload["format"] = "json"
            data = _post_with_retries(f"{s.ollama_base_url.rstrip('/')}/api/chat", headers={}, payload=payload)
            text = (data.get("message") or {}).get("content", "")
            result = LLMResult(text, provider, model, data.get("prompt_eval_count"), data.get("eval_count"))
    except Exception as exc:  # noqa: BLE001 - any provider failure degrades to fallback
        log_ai_request(kind=kind, provider=provider, model=model, status="error",
                       latency_ms=int((time.monotonic() - started) * 1000), org_id=org_id, error=str(exc))
        return None
    log_ai_request(kind=kind, provider=provider, model=model, status="ok",
                   latency_ms=int((time.monotonic() - started) * 1000), org_id=org_id,
                   input_tokens=result.input_tokens, output_tokens=result.output_tokens)
    return result


def parse_json_object(text: str) -> dict[str, Any] | None:
    """Parse a JSON object from model output (tolerates ```json fences)."""
    text = text.strip()
    fence = re.search(r"```(?:json)?\s*(\{.*\})\s*```", text, re.S)
    if fence:
        text = fence.group(1)
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        return None
    try:
        obj = json.loads(text[start : end + 1])
    except json.JSONDecodeError:
        return None
    return obj if isinstance(obj, dict) else None


def complete_json(system: str, user: str, *, kind: str, org_id: str | None = None, max_tokens: int = 1500) -> dict[str, Any] | None:
    res = complete(system, user, json_mode=True, kind=kind, org_id=org_id, max_tokens=max_tokens)
    if res is None:
        return None
    return parse_json_object(res.text)
