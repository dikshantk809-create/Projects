"""Conflict detection between procedures from different technicians.

Two procedures conflict when they address the same problem on the same asset
(overlapping symptoms or the same failure mode) but prescribe a different
*first check*, or one says to replace a part the other says not to. LegacyMind
never silently picks one: it opens a ``KnowledgeConflict`` for supervisor review
and the assistant surfaces it in answers.
"""

from __future__ import annotations

import re

from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..models import KnowledgeConflict, Procedure
from .extraction import first_check_target
from .text import jaccard, tokenize

DETECTOR_VERSION = "conflict-rules-v1"
_DIAGNOSTIC = re.compile(r"\b(inspect|check|verify|measure|test|examine|look|listen|compare|feel)\b", re.I)
_SAFETY_PREP = re.compile(r"\b(stop|shut|isolate|lock|tag|depressuri|bleed|power down|switch off|wear|ppe)\b", re.I)


def _symptom_tokens(p: Procedure) -> set[str]:
    toks: set[str] = set()
    for s in p.symptoms or []:
        toks.update(tokenize(s))
    toks.update(tokenize(p.title.replace("troubleshooting", "")))
    return toks


def first_diagnostic_step(p: Procedure) -> str | None:
    """First step that is a diagnostic check (safety prep such as LOTO is skipped)."""
    for s in sorted(p.steps or [], key=lambda x: x.get("order", 0)):
        text = str(s.get("text", ""))
        if _SAFETY_PREP.search(text) and not _DIAGNOSTIC.search(text):
            continue
        if _DIAGNOSTIC.search(text) or s.get("component"):
            return text
    return None


def _target(p: Procedure) -> str | None:
    step = first_diagnostic_step(p)
    if not step:
        return None
    tags = {p.asset.asset_tag} if p.asset else set()
    return first_check_target(step, tags)


def _same_problem(a: Procedure, b: Procedure) -> bool:
    if a.failure_mode_id and a.failure_mode_id == b.failure_mode_id:
        return True
    return jaccard(_symptom_tokens(a), _symptom_tokens(b)) >= 0.3


def _targets_differ(ta: str, tb: str) -> bool:
    if ta == tb or ta in tb or tb in ta:
        return False
    tags_a = set(re.findall(r"[a-z]{1,4}-\d{1,4}", ta))
    tags_b = set(re.findall(r"[a-z]{1,4}-\d{1,4}", tb))
    if tags_a and tags_b:
        return tags_a.isdisjoint(tags_b)
    return jaccard(set(ta.split()), set(tb.split())) < 0.5


def detect_conflicts_for(db: Session, proc: Procedure) -> list[KnowledgeConflict]:
    if proc.asset_id is None or proc.status == "rejected":
        return []
    others = db.scalars(
        select(Procedure).where(
            Procedure.asset_id == proc.asset_id,
            Procedure.id != proc.id,
            Procedure.status.in_(("approved", "pending_review")),
        )
    ).all()
    created: list[KnowledgeConflict] = []
    ta = _target(proc)
    if not ta:
        return created
    for other in others:
        if other.record_id and other.record_id == proc.record_id:
            continue
        if not _same_problem(proc, other):
            continue
        tb = _target(other)
        if not tb or not _targets_differ(ta, tb):
            continue
        exists = db.scalar(
            select(KnowledgeConflict).where(
                or_(
                    (KnowledgeConflict.procedure_a_id == proc.id) & (KnowledgeConflict.procedure_b_id == other.id),
                    (KnowledgeConflict.procedure_a_id == other.id) & (KnowledgeConflict.procedure_b_id == proc.id),
                )
            )
        )
        if exists:
            continue
        a_author = other.author.full_name if other.author else "Technician A"
        b_author = proc.author.full_name if proc.author else "Technician B"
        conflict = KnowledgeConflict(
            org_id=proc.org_id,
            asset_id=proc.asset_id,
            procedure_a_id=other.id,
            procedure_b_id=proc.id,
            conflict_type="different_first_check",
            description=(
                f"Two technicians provided different first checks for the same problem. "
                f"{other.ref} ({a_author}) starts with '{tb}'; {proc.ref} ({b_author}) starts with '{ta}'."
            ),
            detected_by=DETECTOR_VERSION,
        )
        db.add(conflict)
        db.flush()
        created.append(conflict)
    return created


def open_conflicts_for_procedures(db: Session, procedure_ids: list[str]) -> list[KnowledgeConflict]:
    if not procedure_ids:
        return []
    return list(
        db.scalars(
            select(KnowledgeConflict).where(
                KnowledgeConflict.status == "open",
                or_(KnowledgeConflict.procedure_a_id.in_(procedure_ids), KnowledgeConflict.procedure_b_id.in_(procedure_ids)),
            )
        ).all()
    )
