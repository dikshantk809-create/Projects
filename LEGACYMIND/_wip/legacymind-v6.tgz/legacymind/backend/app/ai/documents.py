"""Text extraction from documents and images.

* PDF  -> pypdf text layer
* DOCX -> python-docx paragraphs and tables
* TXT  -> UTF-8
* Images -> Tesseract OCR when the ``tesseract`` binary is installed (it is in
  the Docker image). Without it the image is stored and marked "no text
  extracted" - we do not invent captions.
"""

from __future__ import annotations

import io
import shutil
import subprocess
import tempfile
from pathlib import Path


def extract_text(data: bytes, ext: str) -> tuple[str, str]:
    """Return (text, method)."""
    ext = ext.lower()
    if ext == ".txt":
        return data.decode("utf-8", errors="replace"), "utf8"
    if ext == ".pdf":
        from pypdf import PdfReader

        reader = PdfReader(io.BytesIO(data))
        pages = []
        for page in reader.pages[:200]:
            try:
                pages.append(page.extract_text() or "")
            except Exception:  # pragma: no cover - malformed page
                pages.append("")
        return "\n".join(pages).strip(), "pypdf"
    if ext == ".docx":
        import docx

        d = docx.Document(io.BytesIO(data))
        parts = [p.text for p in d.paragraphs if p.text.strip()]
        for table in d.tables:
            for row in table.rows:
                cells = [c.text.strip() for c in row.cells if c.text.strip()]
                if cells:
                    parts.append(" | ".join(cells))
        return "\n".join(parts).strip(), "python-docx"
    if ext in (".png", ".jpg", ".jpeg", ".webp"):
        return ocr_image(data, ext)
    return "", "unsupported"


def ocr_available() -> bool:
    return shutil.which("tesseract") is not None


def ocr_image(data: bytes, ext: str) -> tuple[str, str]:
    if not ocr_available():
        return "", "ocr-unavailable"
    with tempfile.TemporaryDirectory() as tmp:
        src = Path(tmp) / f"img{ext}"
        src.write_bytes(data)
        try:
            out = subprocess.run(
                ["tesseract", str(src), "stdout", "--psm", "6"], capture_output=True, timeout=60, check=False
            )
        except subprocess.TimeoutExpired:
            return "", "ocr-timeout"
        text = out.stdout.decode("utf-8", errors="replace").strip()
        return text, "tesseract"
