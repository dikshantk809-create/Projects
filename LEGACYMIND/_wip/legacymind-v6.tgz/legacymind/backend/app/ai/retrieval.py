"""Hybrid retrieval: vector + keyword (BM25) + knowledge-graph, fused with RRF.

Only *approved* knowledge is retrievable for answering. Asset scoping is
strict: when a question names a plant asset, evidence from other machines is
never used to answer it.
"""

from __future__ import annotations

import math
import re
import threading
from collections import Counter
from dataclasses import dataclass, field
from typing import Any

import numpy as np
from sqlalchemy import case, func, select, text
from sqlalchemy.orm import Session

from ..config import get_settings
from ..models import Asset, FailureMode, KnowledgeChunk, Procedure
from .embeddings import cosine_matrix, get_embedder
from .text import STOPWORDS, find_tags, jaccard, tokenize

GENERIC_QUERY_TERMS = {
    "inspect", "machine", "problem", "issue", "fix", "wrong", "happen", "need", "doe", "should", "procedure",
    "troubleshoot", "what", "why", "how", "do", "first", "step", "help", "make", "making", "is", "current",
}


@dataclass
class QueryAnalysis:
    query: str
    tokens: list[str]
    content_tokens: list[str]
    asset: Asset | None
    asset_explicit: bool
    unknown_tags: list[str]
    component_tags: list[str]


@dataclass
class Hit:
    chunk_id: str
    chunk_type: str
    text: str
    record_id: str | None
    asset_id: str | None
    procedure_id: str | None
    start_s: float | None
    end_s: float | None
    vector: float = 0.0
    bm25: float = 0.0
    graph: float = 0.0
    fused: float = 0.0
    ranks: dict[str, int] = field(default_factory=dict)

    def as_debug(self) -> dict[str, Any]:
        return {"chunk_id": self.chunk_id, "type": self.chunk_type, "fused": round(self.fused, 4),
                "vector": round(self.vector, 3), "bm25": round(self.bm25, 3), "graph": round(self.graph, 3)}


@dataclass
class RetrievalResult:
    analysis: QueryAnalysis
    hits: list[Hit]
    graph_procedures: list[tuple[Procedure, float]]
    other_asset_hits: list[Hit]
    backend: str
    embedder: str


# ---------------------------------------------------------------------------
# Query analysis
# ---------------------------------------------------------------------------


def analyze_query(db: Session, org_id: str, query: str, context_asset_id: str | None = None) -> QueryAnalysis:
    toks = tokenize(query)
    assets = db.scalars(select(Asset).where(Asset.org_id == org_id)).all()
    by_tag = {a.asset_tag.upper(): a for a in assets}
    tags = find_tags(query)
    asset: Asset | None = None
    unknown: list[str] = []
    comps: list[str] = []
    for t in tags:
        if t in by_tag and asset is None:
            asset = by_tag[t]
        elif t not in by_tag:
            comps.append(t)
    explicit = asset is not None
    if asset is None:
        # name mention, e.g. "the hydraulic press" / "compressor"
        qlow = query.lower()
        best, best_len = None, 0
        for a in assets:
            name = a.name.lower()
            if name and re.search(rf"\b{re.escape(name)}\b", qlow) and len(name) > best_len:
                best, best_len = a, len(name)
        if best is not None:
            asset, explicit = best, True
    # tags that look like asset tags (same prefix as a known asset) but are not registered
    known_prefixes = {a.asset_tag.split("-")[0].upper() for a in assets}
    for c in list(comps):
        if c.split("-")[0] in known_prefixes and not explicit:
            unknown.append(c)
            comps.remove(c)
    if asset is None and context_asset_id:
        asset = db.get(Asset, context_asset_id)
        if asset is not None and asset.org_id != org_id:
            asset = None
    content = [t for t in toks if t not in GENERIC_QUERY_TERMS and t not in STOPWORDS
               and not (asset is not None and t == asset.asset_tag)]
    if asset is not None:
        name_toks = set(tokenize(asset.name)) | set(tokenize(asset.machine_type))
        content = [t for t in content if t not in name_toks]
    return QueryAnalysis(query, toks, content, asset, explicit, unknown, comps)


# ---------------------------------------------------------------------------
# BM25 (in-process, cached per org)
# ---------------------------------------------------------------------------


class _BM25Index:
    def __init__(self, docs: list[tuple[str, list[str]]]) -> None:
        self.ids = [d[0] for d in docs]
        self.tfs = [Counter(toks) for _, toks in docs]
        self.lens = [len(toks) for _, toks in docs]
        self.avgdl = (sum(self.lens) / len(self.lens)) if self.lens else 1.0
        df: Counter[str] = Counter()
        for tf in self.tfs:
            df.update(tf.keys())
        n = len(docs)
        self.idf = {t: math.log(1 + (n - c + 0.5) / (c + 0.5)) for t, c in df.items()}

    def scores(self, q: list[str], k1: float = 1.4, b: float = 0.75) -> dict[str, float]:
        out: dict[str, float] = {}
        qset = list(dict.fromkeys(q))
        for i, tf in enumerate(self.tfs):
            s = 0.0
            for t in qset:
                f = tf.get(t)
                if not f:
                    continue
                s += self.idf.get(t, 0.0) * (f * (k1 + 1)) / (f + k1 * (1 - b + b * self.lens[i] / self.avgdl))
            if s > 0:
                out[self.ids[i]] = s
        return out


_bm25_cache: dict[str, tuple[tuple[Any, ...], _BM25Index]] = {}
_bm25_lock = threading.Lock()


def _bm25_for(db: Session, org_id: str, approved_only: bool) -> _BM25Index:
    stamp = db.execute(
        # approval flips must invalidate the cache, hence the approved-count term
        select(func.count(KnowledgeChunk.id), func.max(KnowledgeChunk.created_at),
               func.sum(case((KnowledgeChunk.approved.is_(True), 1), else_=0))).where(KnowledgeChunk.org_id == org_id)
    ).one()
    key = f"{org_id}:{approved_only}"
    sig = tuple(stamp)
    with _bm25_lock:
        cached = _bm25_cache.get(key)
        if cached and cached[0] == sig:
            return cached[1]
    q = select(KnowledgeChunk.id, KnowledgeChunk.text).where(KnowledgeChunk.org_id == org_id)
    if approved_only:
        q = q.where(KnowledgeChunk.approved.is_(True))
    docs = [(cid, tokenize(txt)) for cid, txt in db.execute(q).all()]
    idx = _BM25Index(docs)
    with _bm25_lock:
        _bm25_cache[key] = (sig, idx)
    return idx


def clear_bm25_cache() -> None:
    with _bm25_lock:
        _bm25_cache.clear()


# ---------------------------------------------------------------------------
# Vector search
# ---------------------------------------------------------------------------


def _vector_scores(db: Session, org_id: str, qvec: list[float], limit: int) -> dict[str, float]:
    s = get_settings()
    if s.use_pgvector and db.bind is not None and db.bind.dialect.name == "postgresql":
        rows = db.execute(
            text(
                "SELECT id, 1 - (embedding <=> CAST(:q AS vector)) AS sim FROM knowledge_chunks "
                "WHERE org_id = :org AND approved AND embedding IS NOT NULL "
                "ORDER BY embedding <=> CAST(:q AS vector) LIMIT :lim"
            ),
            {"q": "[" + ",".join(f"{x:.6f}" for x in qvec) + "]", "org": org_id, "lim": limit},
        ).all()
        return {r[0]: float(r[1]) for r in rows}
    rows = db.execute(
        select(KnowledgeChunk.id, KnowledgeChunk.embedding).where(
            KnowledgeChunk.org_id == org_id, KnowledgeChunk.approved.is_(True), KnowledgeChunk.embedding.is_not(None)
        )
    ).all()
    if not rows:
        return {}
    mat = np.asarray([r[1] for r in rows], dtype=np.float64)
    sims = cosine_matrix(qvec, mat)
    order = np.argsort(-sims)[:limit]
    return {rows[i][0]: float(sims[i]) for i in order}


# ---------------------------------------------------------------------------
# Graph retrieval
# ---------------------------------------------------------------------------


def graph_candidates(db: Session, analysis: QueryAnalysis) -> list[tuple[Procedure, float]]:
    """Asset -> failure modes / symptoms -> approved procedures, scored by symptom overlap."""
    if analysis.asset is None:
        return []
    procs = db.scalars(
        select(Procedure).where(Procedure.asset_id == analysis.asset.id, Procedure.status == "approved")
    ).all()
    q = set(analysis.content_tokens)
    out: list[tuple[Procedure, float]] = []
    for p in procs:
        sym_toks: set[str] = set()
        for s in p.symptoms or []:
            sym_toks.update(tokenize(s))
        fm_toks: set[str] = set()
        if p.failure_mode_id:
            fm = db.get(FailureMode, p.failure_mode_id)
            if fm:
                fm_toks = set(tokenize(fm.name))
        step_toks: set[str] = set()
        for st in p.steps or []:
            step_toks.update(tokenize(str(st.get("text", ""))))
        comp_bonus = 0.0
        for c in analysis.component_tags:
            if any(c.lower() in str(st.get("text", "")).lower() for st in p.steps or []):
                comp_bonus = 0.25
        if not q:
            score = 0.2 + comp_bonus
        else:
            sym_hit = len(q & sym_toks) / len(q)
            fm_hit = len(q & fm_toks) / len(q)
            step_hit = len(q & step_toks) / len(q)
            score = 0.6 * sym_hit + 0.25 * fm_hit + 0.15 * step_hit + comp_bonus + 0.1 * jaccard(q, sym_toks)
        if score > 0:
            out.append((p, min(1.0, score)))
    out.sort(key=lambda x: -x[1])
    return out


# ---------------------------------------------------------------------------
# Fusion
# ---------------------------------------------------------------------------


def retrieve(db: Session, org_id: str, query: str, context_asset_id: str | None = None, top_k: int | None = None) -> RetrievalResult:
    s = get_settings()
    k = top_k or s.retrieval_top_k
    analysis = analyze_query(db, org_id, query, context_asset_id)
    embedder = get_embedder()
    qvec = embedder.embed([query])[0]

    vec = _vector_scores(db, org_id, qvec, limit=40)
    bm = _bm25_for(db, org_id, approved_only=True).scores(analysis.tokens)
    graph_procs = graph_candidates(db, analysis)
    graph_by_proc = {p.id: sc for p, sc in graph_procs}

    candidate_ids = set(vec) | set(sorted(bm, key=lambda x: -bm[x])[:40])
    if graph_by_proc:
        rows = db.scalars(select(KnowledgeChunk.id).where(KnowledgeChunk.procedure_id.in_(list(graph_by_proc)))).all()
        candidate_ids.update(rows)
        # graph also pulls the source-transcript evidence of matched procedures
        rec_ids = [p.record_id for p, _ in graph_procs if p.record_id]
        if rec_ids:
            candidate_ids.update(db.scalars(select(KnowledgeChunk.id).where(
                KnowledgeChunk.record_id.in_(rec_ids), KnowledgeChunk.approved.is_(True))).all())
    if not candidate_ids:
        return RetrievalResult(analysis, [], graph_procs, [], "pgvector" if s.use_pgvector and not s.is_sqlite else "numpy", embedder.name)

    chunks = db.scalars(select(KnowledgeChunk).where(KnowledgeChunk.id.in_(list(candidate_ids)), KnowledgeChunk.approved.is_(True))).all()
    proc_by_record = {p.record_id: p.id for p, _ in graph_procs if p.record_id}
    hits: list[Hit] = []
    for c in chunks:
        g = 0.0
        if c.procedure_id and c.procedure_id in graph_by_proc:
            g = graph_by_proc[c.procedure_id]
        elif c.record_id in proc_by_record:
            g = 0.5 * graph_by_proc[proc_by_record[c.record_id]]
        hits.append(Hit(c.id, c.chunk_type, c.text, c.record_id, c.asset_id, c.procedure_id, c.start_s, c.end_s,
                        vector=vec.get(c.id, 0.0), bm25=bm.get(c.id, 0.0), graph=g))

    # Reciprocal-rank fusion
    for signal in ("vector", "bm25", "graph"):
        ranked = sorted((h for h in hits if getattr(h, signal) > 0), key=lambda h: -getattr(h, signal))
        for rank, h in enumerate(ranked, start=1):
            h.ranks[signal] = rank
    weights = {"vector": 1.0, "bm25": 1.0, "graph": 1.3}
    for h in hits:
        h.fused = sum(weights[sig] / (60 + r) for sig, r in h.ranks.items())
        if analysis.asset is not None and h.asset_id == analysis.asset.id:
            h.fused *= 1.25

    other: list[Hit] = []
    if analysis.asset is not None and analysis.asset_explicit:
        other = [h for h in hits if h.asset_id not in (analysis.asset.id, None)]
        hits = [h for h in hits if h.asset_id in (analysis.asset.id, None)]
    hits.sort(key=lambda h: -h.fused)
    other.sort(key=lambda h: -h.fused)
    backend = "pgvector" if (s.use_pgvector and db.bind is not None and db.bind.dialect.name == "postgresql") else "numpy"
    return RetrievalResult(analysis, hits[:k], graph_procs, other[:3], backend, embedder.name)
