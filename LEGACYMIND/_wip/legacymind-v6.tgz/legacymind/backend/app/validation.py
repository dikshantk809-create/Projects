"""Shared input validation types."""

from __future__ import annotations

import re
from typing import Annotated

from pydantic import AfterValidator, Field

_EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$")


def _email(v: str) -> str:
    v = v.strip().lower()
    if len(v) > 254 or not _EMAIL_RE.match(v):
        raise ValueError("not a valid email address")
    return v


def _clean_text(v: str) -> str:
    # strip control characters (keeps newlines/tabs); HTML is escaped by the UI
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", v).strip()


Email = Annotated[str, Field(max_length=254), AfterValidator(_email)]
CleanText = Annotated[str, AfterValidator(_clean_text)]
