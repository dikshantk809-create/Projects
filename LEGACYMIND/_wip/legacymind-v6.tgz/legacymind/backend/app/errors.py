"""Consistent API errors.

Every error response has the shape::

    {"error": {"code": "not_found", "message": "...", "error_id": "a1b2c3", "details": ...}}

Raw stack traces are never returned; unexpected exceptions are logged with the
error_id so support can find them.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from .observability import log_event, report_exception, request_id_var

logger = logging.getLogger("legacymind.errors")


class AppError(Exception):
    status_code = 400
    code = "bad_request"

    def __init__(self, message: str, *, code: str | None = None, status_code: int | None = None, details: Any = None):
        super().__init__(message)
        self.message = message
        if code:
            self.code = code
        if status_code:
            self.status_code = status_code
        self.details = details


class NotFound(AppError):
    status_code = 404
    code = "not_found"


class Forbidden(AppError):
    status_code = 403
    code = "forbidden"


class Unauthorized(AppError):
    status_code = 401
    code = "unauthorized"


class Conflict(AppError):
    status_code = 409
    code = "conflict"


class ServiceUnavailable(AppError):
    status_code = 503
    code = "service_unavailable"


def _error_id() -> str:
    return uuid.uuid4().hex[:10]


def error_body(code: str, message: str, error_id: str, details: Any = None) -> dict[str, Any]:
    body: dict[str, Any] = {"code": code, "message": message, "error_id": error_id, "request_id": request_id_var.get()}
    if details is not None:
        body["details"] = details
    return {"error": body}


def install_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(AppError)
    async def _app_error(_request: Request, exc: AppError) -> JSONResponse:
        eid = _error_id()
        if exc.status_code >= 500:
            log_event(logger, "app_error", logging.ERROR, code=exc.code, error_id=eid, message=exc.message)
        return JSONResponse(error_body(exc.code, exc.message, eid, exc.details), status_code=exc.status_code)

    @app.exception_handler(RequestValidationError)
    async def _validation(_request: Request, exc: RequestValidationError) -> JSONResponse:
        eid = _error_id()
        details = [
            {"field": ".".join(str(p) for p in err.get("loc", [])[1:]), "message": err.get("msg", "invalid")}
            for err in exc.errors()
        ]
        return JSONResponse(
            error_body("validation_error", "Some fields are invalid.", eid, details), status_code=422
        )

    @app.exception_handler(StarletteHTTPException)
    async def _http(_request: Request, exc: StarletteHTTPException) -> JSONResponse:
        eid = _error_id()
        code = {404: "not_found", 405: "method_not_allowed", 401: "unauthorized", 403: "forbidden", 413: "payload_too_large", 429: "rate_limited"}.get(
            exc.status_code, "http_error"
        )
        message = exc.detail if isinstance(exc.detail, str) else "Request failed."
        return JSONResponse(error_body(code, message, eid), status_code=exc.status_code, headers=getattr(exc, "headers", None))

    @app.exception_handler(Exception)
    async def _unhandled(request: Request, exc: Exception) -> JSONResponse:
        eid = _error_id()
        logger.error(
            "unhandled_exception",
            exc_info=exc,
            extra={"extra_fields": {"error_id": eid, "path": request.url.path, "method": request.method}},
        )
        report_exception(exc, {"error_id": eid, "path": request.url.path})
        return JSONResponse(
            error_body("internal_error", f"Something went wrong on our side. Reference: {eid}", eid),
            status_code=500,
        )
