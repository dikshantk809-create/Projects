"""Password hashing, session tokens and role permissions.

Passwords are hashed with scrypt (memory-hard KDF from the Python standard
library, parameters n=2**14, r=8, p=1 per OWASP guidance) with a per-password
random salt. Sessions are short-lived signed JWTs carried in an httpOnly cookie.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import re
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any

import jwt

from .config import get_settings

_SCRYPT_N, _SCRYPT_R, _SCRYPT_P, _DKLEN = 2**14, 8, 1, 32
SESSION_COOKIE = "lm_session"
CSRF_HEADER = "x-requested-with"


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, n=_SCRYPT_N, r=_SCRYPT_R, p=_SCRYPT_P, dklen=_DKLEN)
    return "scrypt${}${}${}${}${}".format(
        _SCRYPT_N, _SCRYPT_R, _SCRYPT_P, base64.b64encode(salt).decode(), base64.b64encode(digest).decode()
    )


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, n, r, p, salt_b64, digest_b64 = stored.split("$")
        if scheme != "scrypt":
            return False
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(digest_b64)
        actual = hashlib.scrypt(password.encode(), salt=salt, n=int(n), r=int(r), p=int(p), dklen=len(expected))
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False


_PASSWORD_RULES = [
    (re.compile(r".{10,}"), "at least 10 characters"),
    (re.compile(r"[A-Za-z]"), "a letter"),
    (re.compile(r"\d"), "a number"),
]


def password_problems(password: str) -> list[str]:
    return [msg for rx, msg in _PASSWORD_RULES if not rx.search(password)]


def create_session_token(user_id: str, org_id: str, role: str, token_version: int) -> str:
    settings = get_settings()
    now = datetime.now(timezone.utc)
    payload: dict[str, Any] = {
        "sub": user_id,
        "org": org_id,
        "role": role,
        "tv": token_version,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=settings.access_token_minutes)).timestamp()),
        "jti": secrets.token_hex(8),
    }
    return jwt.encode(payload, settings.effective_secret_key, algorithm="HS256")


def decode_session_token(token: str) -> dict[str, Any] | None:
    try:
        return jwt.decode(token, get_settings().effective_secret_key, algorithms=["HS256"])
    except jwt.PyJWTError:
        return None


# ---------------------------------------------------------------------------
# RBAC
# ---------------------------------------------------------------------------

PERMISSIONS: dict[str, set[str]] = {
    "admin": {
        "assets:read", "assets:write", "knowledge:read", "knowledge:capture", "knowledge:review",
        "assistant:use", "harvest:run", "analytics:read", "users:manage", "org:manage", "audit:read",
        "reports:export", "conflicts:resolve",
    },
    "supervisor": {
        "assets:read", "knowledge:read", "knowledge:capture", "knowledge:review", "assistant:use",
        "harvest:run", "analytics:read", "conflicts:resolve", "reports:export",
    },
    "technician": {"assets:read", "knowledge:read", "knowledge:capture", "assistant:use", "harvest:run"},
    "junior_technician": {"assets:read", "knowledge:read", "assistant:use"},
}


def has_permission(role: str, permission: str) -> bool:
    return permission in PERMISSIONS.get(role, set())
