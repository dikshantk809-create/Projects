"""ORM -> JSON serializers (kept explicit so no internal field leaks by accident)."""

from __future__ import annotations

from typing import Any

from .models import (
    Asset,
    Document,
    KnowledgeConflict,
    KnowledgeRecord,
    MaintenanceEvent,
    Procedure,
    Recording,
    SafetyWarning,
    User,
)


def iso(dt: Any) -> str | None:
    return dt.isoformat() if dt is not None else None


def user_out(u: User | None) -> dict[str, Any] | None:
    if u is None:
        return None
    return {
        "id": u.id, "email": u.email, "full_name": u.full_name, "title": u.title, "role": u.role,
        "department_id": u.department_id, "is_active": u.is_active, "years_experience": u.years_experience,
        "last_login_at": iso(u.last_login_at), "created_at": iso(u.created_at),
    }


def user_brief(u: User | None) -> dict[str, Any] | None:
    if u is None:
        return None
    return {"id": u.id, "full_name": u.full_name, "title": u.title, "role": u.role}


def asset_out(a: Asset) -> dict[str, Any]:
    return {
        "id": a.id, "asset_tag": a.asset_tag, "name": a.name, "machine_type": a.machine_type,
        "manufacturer": a.manufacturer, "model": a.model, "serial_number": a.serial_number,
        "department": a.department.name if a.department else None, "department_id": a.department_id,
        "plant_id": a.plant_id, "location": a.location, "installed_on": iso(a.installed_on), "status": a.status,
        "criticality": a.criticality, "description": a.description, "is_synthetic": a.is_synthetic,
        "created_at": iso(a.created_at),
    }


def recording_out(r: Recording) -> dict[str, Any]:
    return {
        "id": r.id, "kind": r.kind, "filename": r.filename, "mime_type": r.mime_type, "size_bytes": r.size_bytes,
        "duration_s": r.duration_s, "has_file": bool(r.storage_key), "is_synthetic": r.is_synthetic,
        "url": f"/api/media/recordings/{r.id}" if r.storage_key else None,
    }


def document_out(d: Document) -> dict[str, Any]:
    return {
        "id": d.id, "kind": d.kind, "category": d.category, "filename": d.filename, "mime_type": d.mime_type,
        "size_bytes": d.size_bytes, "extraction_method": d.extraction_method,
        "text_preview": (d.extracted_text or "")[:400], "url": f"/api/media/documents/{d.id}",
        "created_at": iso(d.created_at),
    }


def record_brief(r: KnowledgeRecord) -> dict[str, Any]:
    return {
        "id": r.id, "ref": r.ref, "title": r.title, "source_type": r.source_type,
        "asset": {"id": r.asset.id, "asset_tag": r.asset.asset_tag, "name": r.asset.name} if r.asset else None,
        "contributor": user_brief(r.contributor), "processing_status": r.processing_status,
        "review_status": r.review_status, "recorded_at": iso(r.recorded_at or r.created_at),
        "created_at": iso(r.created_at), "is_synthetic": r.is_synthetic, "summary": (r.summary or "")[:300],
        "ai_version": r.ai_version, "transcript_source": r.transcript_source,
    }


def record_out(r: KnowledgeRecord) -> dict[str, Any]:
    return {
        **record_brief(r),
        "transcript": r.transcript,
        "segments": r.segments or [],
        "processing_stages": r.processing_stages or [],
        "processing_error": r.processing_error,
        "extraction": r.extraction or {},
        "notes": r.notes,
        "recordings": [recording_out(x) for x in r.recordings],
        "documents": [document_out(d) for d in r.documents],
    }


def procedure_out(p: Procedure) -> dict[str, Any]:
    return {
        "id": p.id, "ref": p.ref, "title": p.title,
        "asset": {"id": p.asset.id, "asset_tag": p.asset.asset_tag, "name": p.asset.name} if p.asset else None,
        "failure_mode": {"id": p.failure_mode.id, "name": p.failure_mode.name} if p.failure_mode else None,
        "record_id": p.record_id, "symptoms": p.symptoms, "steps": p.steps, "tools": p.tools, "parts": p.parts,
        "risk_level": p.risk_level, "requires_supervisor": p.requires_supervisor, "status": p.status,
        "confidence": p.confidence, "author": user_brief(p.author), "approved_by": user_brief(p.approved_by),
        "approved_at": iso(p.approved_at), "version": p.version, "ai_version": p.ai_version,
        "is_synthetic": p.is_synthetic, "created_at": iso(p.created_at),
    }


def safety_out(w: SafetyWarning) -> dict[str, Any]:
    return {"id": w.id, "text": w.text, "hazard_type": w.hazard_type, "severity": w.severity, "status": w.status,
            "procedure_id": w.procedure_id, "record_id": w.record_id, "asset_id": w.asset_id}


def conflict_out(c: KnowledgeConflict) -> dict[str, Any]:
    return {
        "id": c.id, "asset_id": c.asset_id, "conflict_type": c.conflict_type, "description": c.description,
        "status": c.status, "resolution": c.resolution, "preferred_procedure_id": c.preferred_procedure_id,
        "procedure_a": procedure_out(c.procedure_a), "procedure_b": procedure_out(c.procedure_b),
        "detected_by": c.detected_by, "created_at": iso(c.created_at), "resolved_at": iso(c.resolved_at),
    }


def event_out(e: MaintenanceEvent) -> dict[str, Any]:
    return {"id": e.id, "occurred_on": iso(e.occurred_on), "event_type": e.event_type, "summary": e.summary,
            "technician_id": e.technician_id, "downtime_hours": e.downtime_hours}
