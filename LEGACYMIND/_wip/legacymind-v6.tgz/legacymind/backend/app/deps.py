"""Request dependencies: authentication, RBAC, rate limiting, audit logging."""

from __future__ import annotations

import threading
import time
from collections import defaultdict, deque
from collections.abc import Callable
from typing import Any

from fastapi import Depends, Request
from sqlalchemy.orm import Session

from .config import get_settings
from .db import get_db
from .errors import AppError, Forbidden, Unauthorized
from .models import AuditLog, User
from .security import SESSION_COOKIE, decode_session_token, has_permission


def _token_from_request(request: Request) -> str | None:
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    return request.cookies.get(SESSION_COOKIE)


def get_current_user(request: Request, db: Session = Depends(get_db)) -> User:
    token = _token_from_request(request)
    if not token:
        raise Unauthorized("Please sign in to continue.")
    claims = decode_session_token(token)
    if not claims:
        raise Unauthorized("Your session has expired. Please sign in again.")
    user = db.get(User, claims.get("sub"))
    if not user or not user.is_active or user.token_version != claims.get("tv"):
        raise Unauthorized("Your session is no longer valid. Please sign in again.")
    request.state.user = user
    return user


def optional_user(request: Request, db: Session = Depends(get_db)) -> User | None:
    try:
        return get_current_user(request, db)
    except Unauthorized:
        return None


def require(permission: str) -> Callable[..., User]:
    def _dep(user: User = Depends(get_current_user)) -> User:
        if not has_permission(user.role, permission):
            raise Forbidden("Your role does not allow this action.", details={"required": permission})
        return user

    return _dep


# ---------------------------------------------------------------------------
# Rate limiting (per-process sliding window; put a shared limiter such as the
# ingress / API gateway in front of multi-instance deployments).
# ---------------------------------------------------------------------------


class RateLimiter:
    def __init__(self) -> None:
        self._hits: dict[str, deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def hit(self, key: str, limit: int, window_s: float = 60.0) -> tuple[bool, int]:
        now = time.monotonic()
        with self._lock:
            q = self._hits[key]
            while q and now - q[0] > window_s:
                q.popleft()
            if len(q) >= limit:
                retry = int(window_s - (now - q[0])) + 1
                return False, retry
            q.append(now)
            return True, 0

    def reset(self) -> None:
        with self._lock:
            self._hits.clear()


limiter = RateLimiter()


def client_ip(request: Request) -> str:
    fwd = request.headers.get("x-forwarded-for")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def rate_limit(bucket: str, per_minute: int | None = None) -> Callable[[Request], None]:
    def _dep(request: Request) -> None:
        limit = per_minute or get_settings().rate_limit_per_minute
        ok, retry = limiter.hit(f"{bucket}:{client_ip(request)}", limit)
        if not ok:
            raise AppError(
                f"Too many requests. Please retry in {retry}s.", code="rate_limited", status_code=429,
                details={"retry_after_s": retry},
            )

    return _dep


def auth_rate_limit(request: Request) -> None:
    rate_limit("auth", get_settings().auth_rate_limit_per_minute)(request)


# ---------------------------------------------------------------------------
# Audit
# ---------------------------------------------------------------------------


def audit(
    db: Session,
    *,
    action: str,
    user: User | None,
    entity_type: str = "",
    entity_id: str = "",
    request: Request | None = None,
    details: dict[str, Any] | None = None,
    org_id: str | None = None,
) -> None:
    db.add(
        AuditLog(
            org_id=org_id or (user.org_id if user else None),
            user_id=user.id if user else None,
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            ip_address=client_ip(request) if request else "",
            details=details or {},
        )
    )
