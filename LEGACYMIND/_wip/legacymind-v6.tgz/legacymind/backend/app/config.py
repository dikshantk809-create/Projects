"""Application configuration.

All configuration comes from environment variables (optionally a `.env` file).
No secrets are hard-coded; every secret has an empty default and the app
reports what is missing through `/ready` and `/api/system/status`.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- Core -------------------------------------------------------------
    app_env: Literal["development", "test", "production"] = "development"
    app_name: str = "LegacyMind"
    app_version: str = "1.0.0"
    log_level: str = "INFO"
    log_json: bool = True
    log_file: str = ""  # optional path; also logs to this file (UTF-8)

    # Database: PostgreSQL in production (with pgvector). SQLite is supported for
    # local development and the automated test-suite.
    database_url: str = "sqlite:///./legacymind.db"
    db_pool_size: int = 5

    # Vector store: "pgvector" uses the Postgres extension; "numpy" stores vectors
    # as JSON and ranks them in-process (used for SQLite and small deployments).
    vector_backend: Literal["auto", "pgvector", "numpy"] = "auto"
    embedding_dim: int = 512

    # --- Security ---------------------------------------------------------
    secret_key: str = Field(default="", description="JWT signing key; REQUIRED in production")
    access_token_minutes: int = 60 * 12
    cookie_secure: bool = False
    cookie_samesite: Literal["lax", "strict", "none"] = "lax"
    cors_origins: str = "http://localhost:5173,http://localhost:8000"
    rate_limit_per_minute: int = 120
    auth_rate_limit_per_minute: int = 10
    allow_public_registration: bool = True

    # --- AI providers -----------------------------------------------------
    ai_provider: Literal["none", "openai", "anthropic", "ollama"] = "none"
    model_name: str = ""
    openai_api_key: str = ""
    openai_base_url: str = "https://api.openai.com/v1"
    anthropic_api_key: str = ""
    anthropic_base_url: str = "https://api.anthropic.com"
    ollama_base_url: str = "http://localhost:11434"

    embedding_provider: Literal["local", "openai"] = "local"
    embedding_model: str = "text-embedding-3-small"

    transcription_provider: Literal["none", "openai"] = "none"
    transcription_model: str = "whisper-1"

    ai_timeout_seconds: float = 45.0
    ai_max_retries: int = 2

    # --- Retrieval / grounding -------------------------------------------
    retrieval_top_k: int = 8
    groundedness_min_score: float = 0.34

    # --- Storage ----------------------------------------------------------
    storage_backend: Literal["local", "s3"] = "local"
    storage_local_path: str = "./storage"
    storage_endpoint: str = ""
    storage_bucket: str = "legacymind"
    storage_access_key: str = ""
    storage_secret_key: str = ""
    storage_region: str = "us-east-1"
    max_upload_mb: int = 100

    # --- Optional graph service -----------------------------------------
    neo4j_uri: str = ""
    neo4j_username: str = ""
    neo4j_password: str = ""

    # --- Demo -------------------------------------------------------------
    demo_mode: bool = True
    seed_demo_on_startup: bool = True

    # --- Frontend static serving (single-container deployments) ----------
    frontend_dist: str = ""

    @field_validator("log_level")
    @classmethod
    def _upper(cls, v: str) -> str:
        return v.upper()

    @property
    def is_production(self) -> bool:
        return self.app_env == "production"

    @property
    def is_sqlite(self) -> bool:
        return self.database_url.startswith("sqlite")

    @property
    def use_pgvector(self) -> bool:
        if self.vector_backend == "numpy":
            return False
        if self.vector_backend == "pgvector":
            return True
        return not self.is_sqlite

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def effective_secret_key(self) -> str:
        if self.secret_key:
            return self.secret_key
        if self.is_production:
            raise RuntimeError("SECRET_KEY must be set in production")
        # Development-only key: deterministic so sessions survive reloads.
        return "dev-only-insecure-key-change-me-0123456789abcdef"

    def config_problems(self) -> list[str]:
        """Human-readable configuration problems, surfaced on /ready."""
        problems: list[str] = []
        if self.is_production and not self.secret_key:
            problems.append("SECRET_KEY is not set")
        if self.is_production and len(self.secret_key) < 32:
            problems.append("SECRET_KEY should be at least 32 characters")
        if self.ai_provider == "openai" and not self.openai_api_key:
            problems.append("AI_PROVIDER=openai but OPENAI_API_KEY is empty")
        if self.ai_provider == "anthropic" and not self.anthropic_api_key:
            problems.append("AI_PROVIDER=anthropic but ANTHROPIC_API_KEY is empty")
        if self.embedding_provider == "openai" and not self.openai_api_key:
            problems.append("EMBEDDING_PROVIDER=openai but OPENAI_API_KEY is empty")
        if self.transcription_provider == "openai" and not self.openai_api_key:
            problems.append("TRANSCRIPTION_PROVIDER=openai but OPENAI_API_KEY is empty")
        if self.storage_backend == "s3" and not (self.storage_access_key and self.storage_secret_key):
            problems.append("STORAGE_BACKEND=s3 but storage credentials are empty")
        return problems


@lru_cache
def get_settings() -> Settings:
    return Settings()
