from __future__ import annotations

import copy
from datetime import datetime, timezone

from fastapi import APIRouter, BackgroundTasks, Depends, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..ai.harvest import (
    CATEGORY_LABELS,
    coverage_view,
    first_question,
    gaps,
    is_complete,
    new_state,
    next_question,
    score_answer,
)
from ..ai.pipeline import next_record_ref, run_pipeline
from ..db import get_db, utcnow
from ..deps import audit, rate_limit, require
from ..errors import AppError, NotFound
from ..models import Asset, HarvestSession, KnowledgeRecord, User
from ..serializers import iso
from ..validation import CleanText

router = APIRouter(prefix="/api/harvest", tags=["harvest"])


class StartIn(BaseModel):
    asset_id: str


class AnswerIn(BaseModel):
    text: CleanText = Field(min_length=1, max_length=5000)
    source: str = Field(default="typed", pattern="^(typed|voice)$")


def _out(s: HarvestSession) -> dict:
    state = s.state or {}
    current = next((t for t in reversed(s.turns) if t["role"] == "agent"), None)
    return {
        "id": s.id, "status": s.status, "agent_mode": s.agent_mode,
        "asset": {"id": s.asset.id, "asset_tag": s.asset.asset_tag, "name": s.asset.name},
        "turns": s.turns, "coverage": coverage_view(state) if state else [], "gaps": gaps(state) if state else [],
        "current_question": current if s.status == "active" else None,
        "record_id": s.record_id, "created_at": iso(s.created_at),
    }


def _get(db: Session, user: User, sid: str) -> HarvestSession:
    s = db.get(HarvestSession, sid)
    if s is None or s.org_id != user.org_id or (s.technician_id != user.id and user.role not in ("supervisor", "admin")):
        raise NotFound("Interview session not found.")
    return s


def _elapsed(s: HarvestSession) -> float:
    created = s.created_at if s.created_at.tzinfo else s.created_at.replace(tzinfo=timezone.utc)
    return round((datetime.now(timezone.utc) - created).total_seconds(), 1)


@router.post("/sessions", status_code=201)
def start(body: StartIn, request: Request, user: User = Depends(require("harvest:run")), db: Session = Depends(get_db)) -> dict:
    a = db.get(Asset, body.asset_id)
    if a is None or a.org_id != user.org_id:
        raise AppError("Unknown asset.", code="invalid_asset", status_code=422)
    state = new_state(f"{a.asset_tag} ({a.name})")
    q = first_question(state)
    state["asked"].append(q["id"])
    state["last_question_id"] = q["id"]
    state["last_category"] = q["category"]
    s = HarvestSession(org_id=user.org_id, asset_id=a.id, technician_id=user.id, state=state,
                       turns=[{"role": "agent", "text": q["text"], "category": q["category"], "reason": q["reason"], "t": 0.0}],
                       created_at=utcnow())
    db.add(s)
    db.flush()
    audit(db, action="harvest.start", user=user, entity_type="harvest_session", entity_id=s.id, request=request)
    db.commit()
    return _out(s)


@router.get("/sessions")
def sessions(user: User = Depends(require("harvest:run")), db: Session = Depends(get_db)) -> dict:
    stmt = select(HarvestSession).where(HarvestSession.org_id == user.org_id)
    if user.role not in ("supervisor", "admin"):
        stmt = stmt.where(HarvestSession.technician_id == user.id)
    rows = db.scalars(stmt.order_by(HarvestSession.created_at.desc()).limit(50)).all()
    return {"items": [{"id": s.id, "status": s.status, "asset": {"asset_tag": s.asset.asset_tag, "name": s.asset.name},
                       "coverage": coverage_view(s.state) if s.state else [], "turns": len(s.turns),
                       "created_at": iso(s.created_at), "record_id": s.record_id} for s in rows]}


@router.get("/sessions/{sid}")
def get_session(sid: str, user: User = Depends(require("harvest:run")), db: Session = Depends(get_db)) -> dict:
    return _out(_get(db, user, sid))


@router.post("/sessions/{sid}/answer", dependencies=[Depends(rate_limit("harvest", 60))])
def answer(sid: str, body: AnswerIn, user: User = Depends(require("harvest:run")), db: Session = Depends(get_db)) -> dict:
    s = _get(db, user, sid)
    if s.status != "active":
        raise AppError("This interview is already finished.", code="session_closed", status_code=409)
    state = copy.deepcopy(s.state)
    turns = list(s.turns)
    last_cat = state.get("last_category", "troubleshooting")
    turns.append({"role": "technician", "text": body.text, "source": body.source, "t": _elapsed(s)})
    found = score_answer(state, last_cat, state.get("last_question_id") or "", body.text)
    q, mode = next_question(state, turns, body.text, found, org_id=user.org_id)
    if q is not None:
        state["asked"].append(q["id"])
        state["last_question_id"] = q["id"]
        state["last_category"] = q["category"]
        turns.append({"role": "agent", "text": q["text"], "category": q["category"], "reason": q["reason"], "t": _elapsed(s)})
        if mode == "llm":
            s.agent_mode = "llm"
    s.state = state
    s.turns = turns
    s.coverage = {c["category"]: c["percent"] for c in coverage_view(state)}
    db.commit()
    out = _out(s)
    out["extracted_from_answer"] = {k: v for k, v in found.items() if v}
    out["complete"] = q is None or is_complete(state)
    return out


@router.post("/sessions/{sid}/finish")
def finish(sid: str, request: Request, background: BackgroundTasks, user: User = Depends(require("harvest:run")),
           db: Session = Depends(get_db)) -> dict:
    s = _get(db, user, sid)
    if s.status != "active":
        raise AppError("This interview is already finished.", code="session_closed", status_code=409)
    answers = [t for t in s.turns if t["role"] == "technician"]
    if not answers:
        raise AppError("Answer at least one question before finishing.", code="empty_interview", status_code=422)
    segments = []
    for i, t in enumerate(s.turns):
        nxt = s.turns[i + 1]["t"] if i + 1 < len(s.turns) else t["t"] + 5
        segments.append({"start": t["t"], "end": max(t["t"], nxt), "text": t["text"], "speaker": "AI interviewer" if t["role"] == "agent" else "technician"})
    record = KnowledgeRecord(
        org_id=user.org_id, ref=next_record_ref(db, user.org_id), title=f"Knowledge Harvest interview - {s.asset.asset_tag} {s.asset.name}",
        asset_id=s.asset_id, contributor_id=s.technician_id, source_type="interview", segments=segments,
        transcript="\n".join(f"{'Q' if x['role'] == 'agent' else 'A'}: {x['text']}" for x in s.turns),
        transcript_source=f"harvest-{s.agent_mode}", recorded_at=s.created_at, processing_status="queued",
        notes="Coverage: " + ", ".join(f"{CATEGORY_LABELS[k]} {v}%" for k, v in (s.coverage or {}).items()),
    )
    db.add(record)
    db.flush()
    s.status = "completed"
    s.record_id = record.id
    audit(db, action="harvest.finish", user=user, entity_type="harvest_session", entity_id=s.id, request=request,
          details={"record_id": record.id, "answers": len(answers)})
    db.commit()
    background.add_task(run_pipeline, record.id)
    return {**_out(s), "record_ref": record.ref}
