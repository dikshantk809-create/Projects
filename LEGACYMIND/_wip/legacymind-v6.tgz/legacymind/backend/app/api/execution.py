"""Guided procedure execution.

A technician opens an *approved* procedure on the shop floor and works through
it step by step. Execution is gated by safety: every approved safety warning
must be acknowledged and lockout/tagout confirmed before step 1 unlocks.
Completing an execution writes a maintenance event to the asset history, so
knowledge use is traceable just like knowledge capture.
"""

from __future__ import annotations

import copy
from typing import Any, Literal

from fastapi import APIRouter, Depends, Query, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db, utcnow
from ..deps import audit, require
from ..errors import AppError, Conflict, NotFound
from ..models import KnowledgeRecord, MaintenanceEvent, Procedure, ProcedureExecution, Recording, SafetyWarning, User
from ..serializers import iso, procedure_out, safety_out, user_brief
from ..validation import CleanText

router = APIRouter(prefix="/api/executions", tags=["execution"])


class StartIn(BaseModel):
    procedure_id: str
    safety_acknowledged: list[str] = Field(default_factory=list, max_length=50)
    lockout_confirmed: bool = False


class StepIn(BaseModel):
    done: bool
    note: CleanText = Field(default="", max_length=1000)


class CompleteIn(BaseModel):
    outcome: Literal["resolved", "not_resolved", "escalated"]
    notes: CleanText = Field(default="", max_length=4000)


def _safety(db: Session, p: Procedure) -> list[SafetyWarning]:
    return list(db.scalars(select(SafetyWarning).where(SafetyWarning.procedure_id == p.id, SafetyWarning.status == "approved")).all())


def _needs_lockout(p: Procedure, warnings: list[SafetyWarning]) -> bool:
    return p.risk_level in ("high", "critical") or any(w.severity == "danger" for w in warnings)


def _evidence(db: Session, p: Procedure) -> dict[int, dict[str, Any]]:
    """Per-step source evidence (quote, timestamp, technician, playable recording)."""
    out: dict[int, dict[str, Any]] = {}
    for st in p.steps or []:
        src = st.get("source") or {}
        rec = db.get(KnowledgeRecord, src.get("record_id")) if src.get("record_id") else None
        recording = db.scalar(select(Recording).where(Recording.record_id == rec.id)) if rec else None
        out[int(st.get("order", 0))] = {
            "quote": src.get("quote", ""), "start": src.get("start"), "end": src.get("end"),
            "edited_by": src.get("edited_by"),
            "record_ref": rec.ref if rec else None, "record_id": rec.id if rec else None,
            "technician": rec.contributor.full_name if rec and rec.contributor else None,
            "source_type": rec.source_type if rec else None, "is_synthetic": bool(rec and rec.is_synthetic),
            "recording_id": recording.id if recording else None, "playable_audio": bool(recording and recording.storage_key),
        }
    return out


def _out(db: Session, e: ProcedureExecution) -> dict[str, Any]:
    p = e.procedure
    ev = _evidence(db, p)
    warnings = _safety(db, p)
    steps = []
    states = {int(s["order"]): s for s in e.step_states or []}
    for st in sorted(p.steps or [], key=lambda s: s.get("order", 0)):
        o = int(st.get("order", 0))
        s = states.get(o, {})
        steps.append({"order": o, "text": st["text"], "component": st.get("component", ""), "done": bool(s.get("done")),
                      "done_at": s.get("at"), "note": s.get("note", ""), "evidence": ev.get(o)})
    done = sum(1 for s in steps if s["done"])
    return {
        "id": e.id, "status": e.status, "outcome": e.outcome, "notes": e.notes,
        "procedure": procedure_out(p), "safety_warnings": [safety_out(w) for w in warnings],
        "safety_acknowledged": e.safety_acknowledged, "steps": steps,
        "progress": {"done": done, "total": len(steps), "percent": int(100 * done / len(steps)) if steps else 0},
        "user": user_brief(e.user), "started_at": iso(e.created_at), "finished_at": iso(e.finished_at),
        "maintenance_event_id": e.maintenance_event_id,
        "version_changed": e.procedure_version != p.version,
    }


def _get(db: Session, user: User, eid: str) -> ProcedureExecution:
    e = db.get(ProcedureExecution, eid)
    if e is None or e.org_id != user.org_id:
        raise NotFound("Execution not found.")
    return e


@router.get("/preflight/{procedure_id}")
def preflight(procedure_id: str, user: User = Depends(require("assistant:use")), db: Session = Depends(get_db)) -> dict[str, Any]:
    """What must be acknowledged before a procedure can start."""
    p = db.get(Procedure, procedure_id)
    if p is None or p.org_id != user.org_id:
        p = db.scalar(select(Procedure).where(Procedure.org_id == user.org_id, Procedure.ref == procedure_id.upper()))
    if p is None or (user.role == "junior_technician" and p.status != "approved"):
        raise NotFound("Procedure not found.")
    warnings = _safety(db, p)
    return {"procedure": procedure_out(p), "safety_warnings": [safety_out(w) for w in warnings],
            "lockout_required": _needs_lockout(p, warnings), "executable": p.status == "approved",
            "reason": "" if p.status == "approved" else "Only supervisor-approved procedures can be executed."}


@router.post("", status_code=201)
def start(body: StartIn, request: Request, user: User = Depends(require("assistant:use")), db: Session = Depends(get_db)) -> dict[str, Any]:
    p = db.get(Procedure, body.procedure_id)
    if p is None or p.org_id != user.org_id:
        raise NotFound("Procedure not found.")
    if p.status != "approved":
        raise Conflict("Only supervisor-approved procedures can be executed.", code="procedure_not_approved")
    warnings = _safety(db, p)
    missing = [w.id for w in warnings if w.id not in set(body.safety_acknowledged)]
    if missing:
        raise AppError("Acknowledge every safety warning before starting.", code="safety_not_acknowledged", status_code=422,
                       details={"missing": missing})
    if _needs_lockout(p, warnings) and not body.lockout_confirmed:
        raise AppError("Confirm that the machine is stopped and locked out / tagged out before starting.",
                       code="lockout_not_confirmed", status_code=422)
    e = ProcedureExecution(
        org_id=user.org_id, procedure_id=p.id, asset_id=p.asset_id, user_id=user.id, procedure_version=p.version,
        safety_acknowledged=[w.id for w in warnings] + (["lockout_tagout"] if body.lockout_confirmed else []),
        step_states=[{"order": int(s.get("order", i + 1)), "done": False} for i, s in enumerate(p.steps or [])],
    )
    db.add(e)
    db.flush()
    audit(db, action="execution.start", user=user, entity_type="procedure", entity_id=p.id, request=request,
          details={"execution_id": e.id, "ref": p.ref, "lockout_confirmed": body.lockout_confirmed})
    db.commit()
    db.refresh(e)
    return _out(db, e)


@router.get("")
def list_executions(asset_id: str | None = None, status: str | None = None, limit: int = Query(default=30, ge=1, le=200),
                    user: User = Depends(require("assistant:use")), db: Session = Depends(get_db)) -> dict[str, Any]:
    stmt = select(ProcedureExecution).where(ProcedureExecution.org_id == user.org_id)
    if user.role in ("technician", "junior_technician"):
        stmt = stmt.where(ProcedureExecution.user_id == user.id)
    if asset_id:
        stmt = stmt.where(ProcedureExecution.asset_id == asset_id)
    if status:
        stmt = stmt.where(ProcedureExecution.status == status)
    rows = db.scalars(stmt.order_by(ProcedureExecution.created_at.desc()).limit(limit)).unique().all()
    return {"items": [{
        "id": e.id, "status": e.status, "outcome": e.outcome, "procedure": {"id": e.procedure.id, "ref": e.procedure.ref, "title": e.procedure.title},
        "asset_tag": e.procedure.asset.asset_tag if e.procedure.asset else None, "user": user_brief(e.user),
        "done": sum(1 for s in e.step_states or [] if s.get("done")), "total": len(e.step_states or []),
        "started_at": iso(e.created_at), "finished_at": iso(e.finished_at),
    } for e in rows]}


@router.get("/{eid}")
def get_execution(eid: str, user: User = Depends(require("assistant:use")), db: Session = Depends(get_db)) -> dict[str, Any]:
    return _out(db, _get(db, user, eid))


@router.patch("/{eid}/steps/{order}")
def set_step(eid: str, order: int, body: StepIn, user: User = Depends(require("assistant:use")), db: Session = Depends(get_db)) -> dict[str, Any]:
    e = _get(db, user, eid)
    if e.user_id != user.id:
        raise AppError("Only the technician running this procedure can update its steps.", code="not_owner", status_code=403)
    if e.status != "in_progress":
        raise Conflict("This execution is already finished.", code="execution_closed")
    states = copy.deepcopy(e.step_states or [])
    idx = next((i for i, s in enumerate(states) if int(s["order"]) == order), None)
    if idx is None:
        raise NotFound("Step not found.")
    if body.done and any(not s.get("done") for s in states[:idx]):
        raise AppError("Complete the previous steps first — steps must be followed in order.", code="step_out_of_order", status_code=422)
    if not body.done and any(s.get("done") for s in states[idx + 1:]):
        raise AppError("Un-check the later steps first.", code="step_out_of_order", status_code=422)
    states[idx].update(done=body.done, at=utcnow().isoformat() if body.done else None, note=body.note)
    e.step_states = states
    db.commit()
    return _out(db, e)


@router.post("/{eid}/complete")
def complete(eid: str, body: CompleteIn, request: Request, user: User = Depends(require("assistant:use")), db: Session = Depends(get_db)) -> dict[str, Any]:
    e = _get(db, user, eid)
    if e.user_id != user.id:
        raise AppError("Only the technician running this procedure can complete it.", code="not_owner", status_code=403)
    if e.status != "in_progress":
        raise Conflict("This execution is already finished.", code="execution_closed")
    done = sum(1 for s in e.step_states or [] if s.get("done"))
    total = len(e.step_states or [])
    if body.outcome == "resolved" and done < total:
        raise AppError("Mark every step as done before reporting the problem as resolved.", code="steps_incomplete", status_code=422)
    p = e.procedure
    e.status = "completed"
    e.outcome = body.outcome
    e.notes = body.notes
    e.finished_at = utcnow()
    if p.asset_id:
        label = {"resolved": "problem resolved", "not_resolved": "problem NOT resolved", "escalated": "escalated to supervisor"}[body.outcome]
        ev = MaintenanceEvent(
            org_id=user.org_id, asset_id=p.asset_id, occurred_on=e.finished_at.date(), event_type="corrective",
            summary=f"Guided procedure {p.ref} ({p.title}) via LegacyMind: {done}/{total} steps, {label}." + (f" Notes: {body.notes}" if body.notes else ""),
            technician_id=user.id,
        )
        db.add(ev)
        db.flush()
        e.maintenance_event_id = ev.id
    audit(db, action="execution.complete", user=user, entity_type="procedure", entity_id=p.id, request=request,
          details={"execution_id": e.id, "outcome": body.outcome, "steps_done": done, "steps_total": total})
    db.commit()
    return _out(db, e)


@router.post("/{eid}/abort")
def abort(eid: str, request: Request, user: User = Depends(require("assistant:use")), db: Session = Depends(get_db)) -> dict[str, Any]:
    e = _get(db, user, eid)
    if e.user_id != user.id and user.role not in ("supervisor", "admin"):
        raise AppError("You cannot abort this execution.", code="not_owner", status_code=403)
    if e.status != "in_progress":
        raise Conflict("This execution is already finished.", code="execution_closed")
    e.status = "aborted"
    e.finished_at = utcnow()
    audit(db, action="execution.abort", user=user, entity_type="procedure", entity_id=e.procedure_id, request=request,
          details={"execution_id": e.id})
    db.commit()
    return _out(db, e)
