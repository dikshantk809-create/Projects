"""Knowledge intelligence: global search, knowledge-at-risk and Knowledge Harvest suggestions.

* Knowledge at risk — the core LegacyMind question: which machines depend on a
  single expert (a "bus factor" of one), and which of those experts are the
  most senior (closest to retirement)?
* Harvest suggestions — turns coverage gaps, questions the assistant could not
  answer, and answers technicians marked "not resolved" into a concrete
  interview agenda: which machine, which expert, which questions.
"""

from __future__ import annotations

import re
from collections import defaultdict
from typing import Any

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import require
from ..models import AnswerFeedback, Asset, KnowledgeRecord, Message, Procedure, User
from ..serializers import record_brief
from .analytics import asset_coverage

router = APIRouter(prefix="/api", tags=["insights"])

SENIOR_YEARS = 20


# ---------------------------------------------------------------------------
# Global search (Ctrl+K)
# ---------------------------------------------------------------------------


@router.get("/search")
def search(q: str = Query(min_length=1, max_length=100), user: User = Depends(require("knowledge:read")),
           db: Session = Depends(get_db)) -> dict[str, Any]:
    like = f"%{q.strip().lower()}%"
    assets = db.scalars(select(Asset).where(Asset.org_id == user.org_id, or_(
        func.lower(Asset.asset_tag).like(like), func.lower(Asset.name).like(like), func.lower(Asset.location).like(like),
        func.lower(Asset.manufacturer).like(like))).order_by(Asset.asset_tag).limit(6)).all()
    rstmt = select(KnowledgeRecord).where(KnowledgeRecord.org_id == user.org_id, or_(
        func.lower(KnowledgeRecord.title).like(like), func.lower(KnowledgeRecord.ref).like(like),
        func.lower(KnowledgeRecord.transcript).like(like)))
    pstmt = select(Procedure).where(Procedure.org_id == user.org_id, or_(
        func.lower(Procedure.title).like(like), func.lower(Procedure.ref).like(like)))
    if user.role == "junior_technician":
        rstmt = rstmt.where(KnowledgeRecord.review_status == "approved")
        pstmt = pstmt.where(Procedure.status == "approved")
    else:
        pstmt = pstmt.where(Procedure.status.in_(("approved", "pending_review", "needs_changes")))
    records = db.scalars(rstmt.order_by(KnowledgeRecord.created_at.desc()).limit(6)).unique().all()
    procs = db.scalars(pstmt.order_by(Procedure.ref).limit(6)).unique().all()
    return {
        "assets": [{"id": a.id, "asset_tag": a.asset_tag, "name": a.name, "location": a.location, "status": a.status} for a in assets],
        "records": [record_brief(r) for r in records],
        "procedures": [{"id": p.id, "ref": p.ref, "title": p.title, "status": p.status, "risk_level": p.risk_level,
                        "asset_tag": p.asset.asset_tag if p.asset else None} for p in procs],
    }


# ---------------------------------------------------------------------------
# Knowledge at risk
# ---------------------------------------------------------------------------


def knowledge_risk(db: Session, org_id: str) -> dict[str, Any]:
    assets = db.scalars(select(Asset).where(Asset.org_id == org_id, Asset.status != "decommissioned").order_by(Asset.asset_tag)).all()
    users = {u.id: u for u in db.scalars(select(User).where(User.org_id == org_id)).all()}
    rows = db.execute(
        select(KnowledgeRecord.asset_id, KnowledgeRecord.contributor_id, func.count())
        .where(KnowledgeRecord.org_id == org_id, KnowledgeRecord.review_status == "approved", KnowledgeRecord.asset_id.is_not(None))
        .group_by(KnowledgeRecord.asset_id, KnowledgeRecord.contributor_id)
    ).all()
    by_asset: dict[str, dict[str, int]] = defaultdict(dict)
    for aid, uid, n in rows:
        if uid:
            by_asset[aid][uid] = int(n)

    out_assets = []
    sole: dict[str, list[str]] = defaultdict(list)
    for a in assets:
        contrib = by_asset.get(a.id, {})
        experts = sorted(({"id": uid, "name": users[uid].full_name, "title": users[uid].title,
                           "years_experience": users[uid].years_experience, "records": n}
                          for uid, n in contrib.items() if uid in users), key=lambda x: -x["records"])
        critical = a.criticality in ("high", "critical")
        senior_only = bool(experts) and all((e["years_experience"] or 0) >= SENIOR_YEARS for e in experts)
        if not experts:
            level, reason = ("high" if critical else "medium"), "No approved expert knowledge captured for this machine yet."
        elif len(experts) == 1:
            e = experts[0]
            sole[e["id"]].append(a.asset_tag)
            if critical or senior_only:
                level = "critical" if critical and senior_only else "high"
            else:
                level = "medium"
            reason = (f"All approved knowledge comes from one person ({e['name']}"
                      + (f", {e['years_experience']} yrs experience" if e["years_experience"] else "") + ").")
        elif senior_only:
            level, reason = "medium", "Knowledge comes only from senior technicians — capture it from them before they retire."
        else:
            level, reason = "low", f"Knowledge from {len(experts)} technicians."
        out_assets.append({"asset_id": a.id, "asset_tag": a.asset_tag, "name": a.name, "criticality": a.criticality,
                           "experts": experts, "expert_count": len(experts), "risk": level, "reason": reason})

    order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    out_assets.sort(key=lambda x: (order[x["risk"]], x["asset_tag"]))
    experts_out = []
    for uid, tags in sole.items():
        u = users[uid]
        experts_out.append({"id": uid, "name": u.full_name, "title": u.title, "years_experience": u.years_experience,
                            "sole_source_assets": sorted(tags), "senior": (u.years_experience or 0) >= SENIOR_YEARS})
    experts_out.sort(key=lambda x: (-len(x["sole_source_assets"]), -(x["years_experience"] or 0)))
    at_risk = sum(1 for a in out_assets if a["risk"] in ("critical", "high"))
    return {"assets": out_assets, "single_source_experts": experts_out, "assets_at_risk": at_risk,
            "method": "Distinct contributors of supervisor-approved knowledge per machine; senior = "
                      f"{SENIOR_YEARS}+ years of experience."}


@router.get("/insights/knowledge-risk")
def knowledge_risk_endpoint(user: User = Depends(require("knowledge:read")), db: Session = Depends(get_db)) -> dict[str, Any]:
    return knowledge_risk(db, user.org_id)


# ---------------------------------------------------------------------------
# Knowledge Harvest suggestions
# ---------------------------------------------------------------------------

_GAP_QUESTIONS = {
    "approved_procedures": "When {tag} misbehaves, what do you check first — and why?",
    "failure_modes": "What problems occur most frequently on {tag}, and what are the first symptoms?",
    "safety_warnings": "What safety precautions are specific to {tag} before anyone inspects it?",
    "approved_sources": "Walk me through how you troubleshoot {tag} from the moment it stops.",
}


def harvest_suggestions(db: Session, org_id: str) -> list[dict[str, Any]]:
    cov = {c["asset_id"]: c for c in asset_coverage(db, org_id)}
    risk = {r["asset_id"]: r for r in knowledge_risk(db, org_id)["assets"]}
    assets = db.scalars(select(Asset).where(Asset.org_id == org_id, Asset.status != "decommissioned")).all()
    by_tag = {a.asset_tag.upper(): a for a in assets}
    by_id = {a.id: a for a in assets}

    unanswered: dict[str, list[str]] = defaultdict(list)
    for m in db.scalars(select(Message).where(Message.org_id == org_id, Message.role == "assistant",
                                              Message.groundedness == "INSUFFICIENT")).all():
        q = (m.answer or {}).get("question", "")
        aid = m.asset_id
        if not aid:
            for t in re.findall(r"\b([A-Za-z]{1,4}-\d{1,4}[A-Za-z]?)\b", q):
                if t.upper() in by_tag:
                    aid = by_tag[t.upper()].id
                    break
        if aid and q and q not in unanswered[aid]:
            unanswered[aid].append(q)
    not_resolved: dict[str, list[str]] = defaultdict(list)
    for fb, content in db.execute(select(AnswerFeedback, Message.content).join(Message, Message.id == AnswerFeedback.message_id)
                                  .where(AnswerFeedback.org_id == org_id, AnswerFeedback.outcome.in_(("not_resolved", "wrong_answer")))).all():
        if fb.asset_id:
            q = (db.get(Message, fb.message_id).answer or {}).get("question") or content
            if q not in not_resolved[fb.asset_id]:
                not_resolved[fb.asset_id].append(q)

    users = db.scalars(select(User).where(User.org_id == org_id, User.is_active.is_(True),
                                          User.role.in_(("technician", "supervisor")))).all()
    most_senior = max(users, key=lambda u: u.years_experience or 0, default=None)

    out = []
    for aid, a in by_id.items():
        c = cov.get(aid, {})
        r = risk.get(aid, {})
        reasons: list[str] = []
        questions: list[str] = []
        score = 0.0
        if c.get("coverage", 0) < 80:
            reasons.append(f"Knowledge coverage {c.get('coverage', 0)}%")
            score += (80 - c.get("coverage", 0)) / 20
            for key, tmpl in _GAP_QUESTIONS.items():
                if not c.get(key):
                    questions.append(tmpl.format(tag=a.asset_tag))
        if r.get("risk") in ("critical", "high"):
            reasons.append(r["reason"])
            score += 3 if r["risk"] == "critical" else 2
        if unanswered.get(aid):
            reasons.append(f"{len(unanswered[aid])} question(s) the assistant could not answer")
            score += 1.5 * len(unanswered[aid])
            questions = [f"A technician asked: “{q}” — how would you handle it?" for q in unanswered[aid][:3]] + questions
        if not_resolved.get(aid):
            reasons.append(f"{len(not_resolved[aid])} answer(s) marked “did not fix the problem”")
            score += 2 * len(not_resolved[aid])
            questions = [f"The approved procedure did not fix: “{q}”. What else should be checked?" for q in not_resolved[aid][:3]] + questions
        if a.criticality in ("high", "critical"):
            score *= 1.3
        if not reasons:
            continue
        experts = r.get("experts") or []
        interviewee = experts[0] if experts else (
            {"id": most_senior.id, "name": most_senior.full_name, "title": most_senior.title, "years_experience": most_senior.years_experience}
            if most_senior else None)
        out.append({"asset_id": aid, "asset_tag": a.asset_tag, "name": a.name, "criticality": a.criticality,
                    "priority": round(score, 2), "reasons": reasons, "recommended_expert": interviewee,
                    "suggested_questions": list(dict.fromkeys(questions))[:6]})
    out.sort(key=lambda x: -x["priority"])
    return out


@router.get("/harvest/suggestions", tags=["harvest"])
def suggestions(user: User = Depends(require("harvest:run")), db: Session = Depends(get_db)) -> dict[str, Any]:
    return {"items": harvest_suggestions(db, user.org_id)}
