"""Supervisor review: approve / reject / edit AI-generated knowledge and resolve conflicts."""

from __future__ import annotations

from typing import Any, Literal

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..ai.conflicts import detect_conflicts_for
from ..ai.pipeline import reindex_procedure, sync_record_chunk_approval
from ..db import get_db, utcnow
from ..deps import audit, require
from ..errors import AppError, NotFound
from ..models import KnowledgeConflict, KnowledgeRecord, Procedure, Review, SafetyWarning, User
from ..serializers import conflict_out, iso, procedure_out, record_brief, safety_out, user_brief
from ..validation import CleanText

router = APIRouter(prefix="/api/reviews", tags=["reviews"])


class StepEdit(BaseModel):
    text: CleanText = Field(min_length=3, max_length=500)
    component: str = Field(default="", max_length=120)


class ProcedureEdits(BaseModel):
    title: CleanText | None = Field(default=None, min_length=3, max_length=300)
    steps: list[StepEdit] | None = Field(default=None, min_length=1, max_length=40)
    risk_level: Literal["low", "medium", "high", "critical"] | None = None
    symptoms: list[str] | None = Field(default=None, max_length=12)


class DecisionIn(BaseModel):
    decision: Literal["approve", "reject", "needs_changes"]
    comment: CleanText = Field(default="", max_length=2000)
    edits: ProcedureEdits | None = None


class ResolveIn(BaseModel):
    status: Literal["resolved", "dismissed"] = "resolved"
    preferred_procedure_id: str | None = None
    resolution: CleanText = Field(min_length=3, max_length=2000)


@router.get("/queue")
def queue(user: User = Depends(require("knowledge:review")), db: Session = Depends(get_db)) -> dict:
    procs = db.scalars(select(Procedure).where(Procedure.org_id == user.org_id, Procedure.status.in_(("pending_review", "needs_changes"))).order_by(Procedure.created_at.desc())).unique().all()
    records = db.scalars(select(KnowledgeRecord).where(KnowledgeRecord.org_id == user.org_id, KnowledgeRecord.review_status.in_(("pending", "needs_changes"))).order_by(KnowledgeRecord.created_at.desc())).unique().all()
    conflicts = db.scalars(select(KnowledgeConflict).where(KnowledgeConflict.org_id == user.org_id, KnowledgeConflict.status == "open")).unique().all()
    safety_by_proc: dict[str, list[dict[str, Any]]] = {}
    if procs:
        for w in db.scalars(select(SafetyWarning).where(SafetyWarning.procedure_id.in_([p.id for p in procs]))).all():
            safety_by_proc.setdefault(w.procedure_id or "", []).append(safety_out(w))
    recent = db.scalars(select(Review).where(Review.org_id == user.org_id).order_by(Review.created_at.desc()).limit(15)).all()
    return {
        "procedures": [{**procedure_out(p), "safety_warnings": safety_by_proc.get(p.id, [])} for p in procs],
        "records": [record_brief(r) for r in records],
        "conflicts": [conflict_out(c) for c in conflicts],
        "recent_reviews": [{"id": r.id, "target_type": r.target_type, "target_id": r.target_id, "decision": r.decision,
                            "comment": r.comment, "reviewer": user_brief(r.reviewer), "created_at": iso(r.created_at)} for r in recent],
    }


def _apply_procedure_decision(db: Session, p: Procedure, body: DecisionIn, user: User) -> dict[str, Any]:
    changes: dict[str, Any] = {}
    if body.edits:
        e = body.edits
        if e.title is not None:
            changes["title"] = [p.title, e.title]
            p.title = e.title
        if e.steps is not None:
            old = {s["text"]: s for s in p.steps}
            new_steps = []
            for i, st in enumerate(e.steps, start=1):
                prev = old.get(st.text)
                new_steps.append({
                    "order": i, "text": st.text, "component": st.component or (prev or {}).get("component", ""),
                    # edited steps keep their original evidence only when the text is unchanged
                    "source": (prev or {}).get("source") or {"record_id": p.record_id, "start": None, "end": None,
                                                              "quote": "Edited by supervisor", "edited_by": user.full_name},
                    "confidence": (prev or {}).get("confidence", 1.0),
                })
            changes["steps"] = {"before": len(p.steps), "after": len(new_steps)}
            p.steps = new_steps
        if e.risk_level is not None:
            changes["risk_level"] = [p.risk_level, e.risk_level]
            p.risk_level = e.risk_level
            p.requires_supervisor = e.risk_level in ("high", "critical")
        if e.symptoms is not None:
            p.symptoms = [s.strip().lower()[:200] for s in e.symptoms if s.strip()]
        if changes:
            p.version += 1
    if body.decision == "approve":
        p.status = "approved"
        p.approved_by_id = user.id
        p.approved_at = utcnow()
        for w in db.scalars(select(SafetyWarning).where(SafetyWarning.procedure_id == p.id)).all():
            if w.status != "rejected":
                w.status = "approved"
        # the supervisor verified the card against its source, so its source evidence becomes citable
        if p.record_id:
            rec = db.get(KnowledgeRecord, p.record_id)
            if rec and rec.review_status in ("pending", "needs_changes"):
                rec.review_status = "approved"
                for w in db.scalars(select(SafetyWarning).where(SafetyWarning.record_id == rec.id, SafetyWarning.status == "pending_review")).all():
                    w.status = "approved"
                sync_record_chunk_approval(db, rec)
    elif body.decision == "reject":
        p.status = "rejected"
        for w in db.scalars(select(SafetyWarning).where(SafetyWarning.procedure_id == p.id, SafetyWarning.status == "pending_review")).all():
            w.status = "rejected"
    else:
        p.status = "needs_changes"
    reindex_procedure(db, p)
    if p.status in ("approved", "pending_review"):
        detect_conflicts_for(db, p)
    return changes


@router.post("/procedures/{procedure_id}")
def review_procedure(procedure_id: str, body: DecisionIn, request: Request, user: User = Depends(require("knowledge:review")),
                     db: Session = Depends(get_db)) -> dict:
    p = db.get(Procedure, procedure_id)
    if p is None or p.org_id != user.org_id:
        raise NotFound("Procedure not found.")
    if body.decision == "reject" and not body.comment:
        raise AppError("Please give a reason when rejecting.", code="comment_required", status_code=422)
    changes = _apply_procedure_decision(db, p, body, user)
    db.add(Review(org_id=user.org_id, target_type="procedure", target_id=p.id, reviewer_id=user.id,
                  decision={"approve": "approved", "reject": "rejected", "needs_changes": "needs_changes"}[body.decision],
                  comment=body.comment, changes=changes))
    audit(db, action=f"review.procedure.{body.decision}", user=user, entity_type="procedure", entity_id=p.id, request=request,
          details={"ref": p.ref, "edited": bool(changes)})
    db.commit()
    return procedure_out(p)


@router.post("/records/{record_id}")
def review_record(record_id: str, body: DecisionIn, request: Request, user: User = Depends(require("knowledge:review")),
                  db: Session = Depends(get_db)) -> dict:
    r = db.get(KnowledgeRecord, record_id)
    if r is None or r.org_id != user.org_id:
        raise NotFound("Knowledge record not found.")
    if body.decision == "reject" and not body.comment:
        raise AppError("Please give a reason when rejecting.", code="comment_required", status_code=422)
    r.review_status = {"approve": "approved", "reject": "rejected", "needs_changes": "needs_changes"}[body.decision]
    cascade = 0
    for p in db.scalars(select(Procedure).where(Procedure.record_id == r.id, Procedure.status.in_(("pending_review", "needs_changes")))).all():
        _apply_procedure_decision(db, p, DecisionIn(decision=body.decision, comment=body.comment), user)
        cascade += 1
    for w in db.scalars(select(SafetyWarning).where(SafetyWarning.record_id == r.id, SafetyWarning.status == "pending_review")).all():
        w.status = "approved" if body.decision == "approve" else ("rejected" if body.decision == "reject" else w.status)
    sync_record_chunk_approval(db, r)
    db.add(Review(org_id=user.org_id, target_type="record", target_id=r.id, reviewer_id=user.id, decision=r.review_status,
                  comment=body.comment, changes={"procedures_updated": cascade}))
    audit(db, action=f"review.record.{body.decision}", user=user, entity_type="knowledge_record", entity_id=r.id, request=request)
    db.commit()
    return record_brief(r)


@router.post("/conflicts/{conflict_id}/resolve")
def resolve_conflict(conflict_id: str, body: ResolveIn, request: Request, user: User = Depends(require("conflicts:resolve")),
                     db: Session = Depends(get_db)) -> dict:
    c = db.get(KnowledgeConflict, conflict_id)
    if c is None or c.org_id != user.org_id:
        raise NotFound("Conflict not found.")
    if c.status != "open":
        raise AppError("Conflict is already closed.", code="conflict_closed", status_code=409)
    if body.preferred_procedure_id and body.preferred_procedure_id not in (c.procedure_a_id, c.procedure_b_id):
        raise AppError("Preferred procedure must be one of the two conflicting procedures.", code="invalid_choice", status_code=422)
    c.status = body.status
    c.resolution = body.resolution
    c.preferred_procedure_id = body.preferred_procedure_id
    c.resolved_by_id = user.id
    c.resolved_at = utcnow()
    if body.preferred_procedure_id:
        loser_id = c.procedure_b_id if body.preferred_procedure_id == c.procedure_a_id else c.procedure_a_id
        winner = db.get(Procedure, body.preferred_procedure_id)
        loser = db.get(Procedure, loser_id)
        if loser is not None:
            loser.status = "superseded"
            reindex_procedure(db, loser)
        if winner is not None and winner.status != "approved":
            winner.status = "approved"
            winner.approved_by_id = user.id
            winner.approved_at = utcnow()
            reindex_procedure(db, winner)
    db.add(Review(org_id=user.org_id, target_type="conflict", target_id=c.id, reviewer_id=user.id, decision="resolved",
                  comment=body.resolution, changes={"preferred": body.preferred_procedure_id}))
    audit(db, action="review.conflict.resolve", user=user, entity_type="conflict", entity_id=c.id, request=request)
    db.commit()
    return conflict_out(c)


@router.get("/stats")
def stats(user: User = Depends(require("knowledge:review")), db: Session = Depends(get_db)) -> dict:
    pending = db.scalar(select(func.count()).select_from(Procedure).where(Procedure.org_id == user.org_id, Procedure.status == "pending_review"))
    conflicts = db.scalar(select(func.count()).select_from(KnowledgeConflict).where(KnowledgeConflict.org_id == user.org_id, KnowledgeConflict.status == "open"))
    return {"pending_procedures": pending, "open_conflicts": conflicts}
