"""Knowledge graph API.

The graph is materialised from relational tables (PostgreSQL is the system of
record). ``/api/graph/cypher`` exports the same graph as Cypher for an
optional Neo4j replica; ``/api/graph/neo4j/sync`` pushes it when NEO4J_URI is
configured. The app never depends on Neo4j being available.
"""

from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, Depends, Query, Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import get_settings
from ..db import get_db
from ..deps import require
from ..errors import ServiceUnavailable
from ..models import (
    Asset,
    Component,
    FailureMode,
    FailureModeSymptom,
    KnowledgeConflict,
    KnowledgeRecord,
    Procedure,
    SafetyWarning,
    Symptom,
    User,
)

router = APIRouter(prefix="/api/graph", tags=["graph"])


def build_graph(db: Session, org_id: str, asset_id: str | None = None, include_pending: bool = True) -> dict[str, Any]:
    nodes: dict[str, dict[str, Any]] = {}
    edges: list[dict[str, Any]] = []

    def node(nid: str, ntype: str, label: str, **props: Any) -> str:
        if nid not in nodes:
            nodes[nid] = {"id": nid, "type": ntype, "label": label, **props}
        return nid

    def edge(a: str, b: str, rel: str) -> None:
        edges.append({"source": a, "target": b, "type": rel})

    astmt = select(Asset).where(Asset.org_id == org_id)
    if asset_id:
        astmt = astmt.where(Asset.id == asset_id)
    assets = db.scalars(astmt).all()
    statuses = ("approved", "pending_review") if include_pending else ("approved",)
    for a in assets:
        an = node(f"asset:{a.id}", "asset", f"{a.asset_tag} {a.name}", asset_tag=a.asset_tag, status=a.status)
        for c in db.scalars(select(Component).where(Component.asset_id == a.id)).all():
            edge(an, node(f"component:{c.id}", "component", c.name), "HAS_COMPONENT")
        fms = db.scalars(select(FailureMode).where(FailureMode.asset_id == a.id)).all()
        for fm in fms:
            fn = node(f"fm:{fm.id}", "failure_mode", fm.name, causes=fm.causes)
            edge(an, fn, "HAS_FAILURE_MODE")
            for sym in db.scalars(select(Symptom).join(FailureModeSymptom, FailureModeSymptom.symptom_id == Symptom.id).where(FailureModeSymptom.failure_mode_id == fm.id)).all():
                edge(fn, node(f"symptom:{sym.id}", "symptom", sym.name), "HAS_SYMPTOM")
        for p in db.scalars(select(Procedure).where(Procedure.asset_id == a.id, Procedure.status.in_(statuses))).all():
            pn = node(f"procedure:{p.id}", "procedure", f"{p.ref} {p.title}", status=p.status, risk=p.risk_level, ref=p.ref,
                      steps=[s["text"] for s in p.steps][:8])
            if p.failure_mode_id and f"fm:{p.failure_mode_id}" in nodes:
                edge(f"fm:{p.failure_mode_id}", pn, "RESOLVED_BY")
            else:
                edge(an, pn, "HAS_PROCEDURE")
                for sname in p.symptoms or []:
                    sym = db.scalar(select(Symptom).where(Symptom.org_id == org_id, Symptom.name == sname.lower()))
                    if sym:
                        edge(node(f"symptom:{sym.id}", "symptom", sym.name), pn, "INDICATES")
            for w in db.scalars(select(SafetyWarning).where(SafetyWarning.procedure_id == p.id, SafetyWarning.status != "rejected")).all():
                edge(pn, node(f"safety:{w.id}", "safety", w.text[:90], severity=w.severity, hazard=w.hazard_type), "REQUIRES_SAFETY")
            if p.record_id:
                r = db.get(KnowledgeRecord, p.record_id)
                if r is not None:
                    rn = node(f"record:{r.id}", "record", f"{r.ref} {r.title[:40]}", ref=r.ref, source_type=r.source_type)
                    edge(rn, pn, "SOURCE_OF")
                    if r.contributor:
                        edge(node(f"user:{r.contributor.id}", "technician", r.contributor.full_name, title=r.contributor.title), rn, "CONTRIBUTED")
    for c in db.scalars(select(KnowledgeConflict).where(KnowledgeConflict.org_id == org_id, KnowledgeConflict.status == "open")).all():
        a_id, b_id = f"procedure:{c.procedure_a_id}", f"procedure:{c.procedure_b_id}"
        if a_id in nodes and b_id in nodes:
            edge(a_id, b_id, "CONFLICTS_WITH")
    return {"nodes": list(nodes.values()), "edges": edges, "backend": "postgresql-relational",
            "neo4j_configured": bool(get_settings().neo4j_uri)}


@router.get("")
def graph(asset_id: str | None = None, include_pending: bool = Query(default=True), user: User = Depends(require("knowledge:read")),
          db: Session = Depends(get_db)) -> dict:
    if user.role == "junior_technician":
        include_pending = False
    return build_graph(db, user.org_id, asset_id, include_pending)


def to_cypher(g: dict[str, Any]) -> str:
    lines = ["// LegacyMind knowledge graph export (MERGE is idempotent)"]
    label = {"asset": "Asset", "component": "Component", "failure_mode": "FailureMode", "symptom": "Symptom",
             "procedure": "Procedure", "safety": "SafetyWarning", "record": "KnowledgeRecord", "technician": "Technician"}
    for n in g["nodes"]:
        props = {k: v for k, v in n.items() if k not in ("type",) and isinstance(v, (str, int, float, bool))}
        lines.append(f"MERGE (n:{label[n['type']]} {{id: {json.dumps(n['id'])}}}) SET n += {_cy(props)};")
    for e in g["edges"]:
        lines.append(f"MATCH (a {{id: {json.dumps(e['source'])}}}), (b {{id: {json.dumps(e['target'])}}}) MERGE (a)-[:{e['type']}]->(b);")
    return "\n".join(lines) + "\n"


def _cy(props: dict[str, Any]) -> str:
    return "{" + ", ".join(f"{k}: {json.dumps(v)}" for k, v in props.items()) + "}"


@router.get("/cypher")
def cypher(user: User = Depends(require("reports:export")), db: Session = Depends(get_db)) -> Response:
    return Response(to_cypher(build_graph(db, user.org_id, None, False)), media_type="text/plain",
                    headers={"Content-Disposition": 'attachment; filename="legacymind-graph.cypher"'})


@router.post("/neo4j/sync")
def neo4j_sync(user: User = Depends(require("org:manage")), db: Session = Depends(get_db)) -> dict:  # pragma: no cover - needs Neo4j
    s = get_settings()
    if not s.neo4j_uri:
        raise ServiceUnavailable("Neo4j is not configured (set NEO4J_URI). The built-in graph keeps working without it.")
    try:
        from neo4j import GraphDatabase  # type: ignore[import-not-found]
    except ImportError as exc:
        raise ServiceUnavailable("The 'neo4j' Python driver is not installed.") from exc
    statements = to_cypher(build_graph(db, user.org_id, None, False)).splitlines()[1:]
    try:
        with GraphDatabase.driver(s.neo4j_uri, auth=(s.neo4j_username, s.neo4j_password)) as driver, driver.session() as session:
            for st in statements:
                session.run(st)
    except Exception as exc:
        raise ServiceUnavailable(f"Neo4j sync failed: {type(exc).__name__}") from exc
    return {"ok": True, "statements": len(statements)}
