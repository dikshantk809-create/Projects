"""Authenticated media streaming (supports HTTP Range so players can seek to a cited timestamp)."""

from __future__ import annotations

import re

from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import require
from ..errors import NotFound
from ..models import Document, KnowledgeRecord, Recording, User
from ..services.storage import get_storage

router = APIRouter(prefix="/api/media", tags=["media"])


def _serve(data: bytes, mime: str, request: Request, filename: str, inline: bool = True) -> Response:
    headers = {
        "Accept-Ranges": "bytes",
        "Cache-Control": "private, max-age=600",
        "Content-Disposition": f'{"inline" if inline else "attachment"}; filename="{filename}"',
        "X-Content-Type-Options": "nosniff",
    }
    rng = request.headers.get("range")
    if rng:
        m = re.match(r"bytes=(\d*)-(\d*)", rng)
        if m:
            size = len(data)
            start = int(m.group(1)) if m.group(1) else max(0, size - int(m.group(2) or 0))
            end = int(m.group(2)) if m.group(1) and m.group(2) else size - 1
            end = min(end, size - 1)
            if start > end or start >= size:
                return Response(status_code=416, headers={"Content-Range": f"bytes */{size}"})
            headers["Content-Range"] = f"bytes {start}-{end}/{size}"
            return Response(data[start : end + 1], status_code=206, media_type=mime, headers=headers)
    return Response(data, media_type=mime, headers=headers)


@router.get("/recordings/{recording_id}")
def get_recording(recording_id: str, request: Request, user: User = Depends(require("knowledge:read")), db: Session = Depends(get_db)) -> Response:
    r = db.get(Recording, recording_id)
    if r is None or r.org_id != user.org_id or not r.storage_key:
        raise NotFound("Recording not found.")
    rec = db.get(KnowledgeRecord, r.record_id)
    if user.role == "junior_technician" and (rec is None or rec.review_status != "approved"):
        raise NotFound("Recording not found.")
    return _serve(get_storage().get(r.storage_key), r.mime_type or "application/octet-stream", request, r.filename)


@router.get("/documents/{document_id}")
def get_document(document_id: str, request: Request, user: User = Depends(require("knowledge:read")), db: Session = Depends(get_db)) -> Response:
    d = db.get(Document, document_id)
    if d is None or d.org_id != user.org_id:
        raise NotFound("Document not found.")
    inline = d.kind in ("image", "pdf", "txt")
    return _serve(get_storage().get(d.storage_key), d.mime_type or "application/octet-stream", request, d.filename, inline)
