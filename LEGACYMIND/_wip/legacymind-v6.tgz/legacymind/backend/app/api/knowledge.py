from __future__ import annotations

import json
from datetime import date, datetime, time, timezone

from fastapi import APIRouter, BackgroundTasks, Depends, File, Form, Query, Request, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from ..ai.pipeline import next_record_ref, run_pipeline
from ..ai.transcription import normalize_segments
from ..config import get_settings
from ..db import get_db, new_id
from ..deps import audit, rate_limit, require
from ..errors import AppError, Forbidden, NotFound
from ..models import (
    Asset,
    Document,
    FailureMode,
    KnowledgeRecord,
    KnowledgeSource,
    Procedure,
    Recording,
    SafetyWarning,
    User,
)
from ..serializers import procedure_out, record_brief, record_out, safety_out
from ..services.storage import get_storage, safe_filename, sha256, validate_upload
from ..validation import CleanText

router = APIRouter(prefix="/api/knowledge", tags=["knowledge"])

SOURCE_TYPES = ("audio", "video", "image", "document", "text", "interview")


def _visible_statuses(user: User) -> tuple[str, ...] | None:
    return ("approved",) if user.role == "junior_technician" else None


def get_record_or_404(db: Session, user: User, record_id: str) -> KnowledgeRecord:
    r = db.get(KnowledgeRecord, record_id)
    if r is None or r.org_id != user.org_id:
        r = db.scalar(select(KnowledgeRecord).where(KnowledgeRecord.org_id == user.org_id, KnowledgeRecord.ref == record_id.upper()))
    if r is None:
        raise NotFound("Knowledge record not found.")
    vis = _visible_statuses(user)
    if vis and r.review_status not in vis:
        raise NotFound("Knowledge record not found.")
    return r


@router.post("/records", status_code=201, dependencies=[Depends(rate_limit("capture", 30))])
async def create_record(
    request: Request,
    background: BackgroundTasks,
    title: str = Form(..., min_length=3, max_length=300),
    source_type: str = Form(...),
    asset_id: str | None = Form(default=None),
    notes: str = Form(default="", max_length=50000),
    segments: str = Form(default=""),
    transcript_source: str = Form(default="", max_length=40),
    duration_s: float | None = Form(default=None),
    image_category: str = Form(default="machine", pattern="^(machine|part|fault|wiring|control_panel|other)$"),
    files: list[UploadFile] = File(default_factory=list),
    user: User = Depends(require("knowledge:capture")),
    db: Session = Depends(get_db),
) -> dict:
    if source_type not in SOURCE_TYPES:
        raise AppError(f"source_type must be one of {', '.join(SOURCE_TYPES)}", code="invalid_source_type", status_code=422)
    asset = None
    if asset_id:
        asset = db.get(Asset, asset_id)
        if asset is None or asset.org_id != user.org_id:
            raise AppError("Unknown asset.", code="invalid_asset", status_code=422)
    if len(files) > 10:
        raise AppError("At most 10 files per record.", code="too_many_files", status_code=422)
    parsed_segments = []
    if segments:
        try:
            parsed_segments = normalize_segments(json.loads(segments))
        except json.JSONDecodeError as exc:
            raise AppError("segments must be valid JSON.", code="invalid_segments", status_code=422) from exc
    if not files and not notes.strip() and not parsed_segments:
        raise AppError("Add a recording, a file, or some notes.", code="empty_record", status_code=422)

    record = KnowledgeRecord(
        id=new_id(), org_id=user.org_id, ref=next_record_ref(db, user.org_id), title=title.strip(),
        asset_id=asset.id if asset else None, contributor_id=user.id, source_type=source_type,
        notes=notes.strip(), recorded_at=datetime.now(timezone.utc), processing_status="queued",
    )
    if parsed_segments:
        record.segments = parsed_segments
        record.transcript = " ".join(s["text"] for s in parsed_segments)
        record.transcript_source = (transcript_source or "browser_speech")[:40]
    db.add(record)
    db.flush()

    storage = get_storage()
    for f in files:
        data = await f.read()
        ext, kind = validate_upload(f.filename or "", f.content_type or "", data)
        key = f"{user.org_id}/records/{record.id}/{new_id()}{ext}"
        storage.put(key, data, f.content_type or "application/octet-stream")
        fname = safe_filename(f.filename or f"upload{ext}")
        if kind in ("audio", "video"):
            db.add(Recording(org_id=user.org_id, record_id=record.id, kind=kind, filename=fname,
                             mime_type=(f.content_type or "").split(";")[0], size_bytes=len(data), storage_key=key,
                             sha256=sha256(data), duration_s=duration_s))
        else:
            db.add(Document(org_id=user.org_id, record_id=record.id, asset_id=record.asset_id,
                            kind="image" if kind == "image" else ext.lstrip("."),
                            category=image_category if kind == "image" else "manual", filename=fname,
                            mime_type=(f.content_type or "").split(";")[0], size_bytes=len(data), storage_key=key,
                            sha256=sha256(data)))
    audit(db, action="knowledge.capture", user=user, entity_type="knowledge_record", entity_id=record.id,
          request=request, details={"source_type": source_type, "files": len(files)})
    db.commit()
    background.add_task(run_pipeline, record.id)
    return record_brief(record)


@router.get("/records")
def list_records(
    q: str | None = Query(default=None, max_length=200),
    asset_id: str | None = None,
    technician_id: str | None = None,
    department_id: str | None = None,
    failure_mode: str | None = Query(default=None, max_length=200),
    review_status: str | None = None,
    source_type: str | None = None,
    date_from: date | None = None,
    date_to: date | None = None,
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    user: User = Depends(require("knowledge:read")),
    db: Session = Depends(get_db),
) -> dict:
    stmt = select(KnowledgeRecord).where(KnowledgeRecord.org_id == user.org_id)
    vis = _visible_statuses(user)
    if vis:
        stmt = stmt.where(KnowledgeRecord.review_status.in_(vis))
    elif review_status:
        stmt = stmt.where(KnowledgeRecord.review_status == review_status)
    if asset_id:
        stmt = stmt.where(KnowledgeRecord.asset_id == asset_id)
    if technician_id:
        stmt = stmt.where(KnowledgeRecord.contributor_id == technician_id)
    if source_type:
        stmt = stmt.where(KnowledgeRecord.source_type == source_type)
    if department_id:
        stmt = stmt.join(Asset, Asset.id == KnowledgeRecord.asset_id).where(Asset.department_id == department_id)
    if failure_mode:
        rec_ids = select(KnowledgeSource.record_id).join(FailureMode, FailureMode.id == KnowledgeSource.entity_id).where(
            KnowledgeSource.entity_type == "failure_mode", func.lower(FailureMode.name).like(f"%{failure_mode.lower()}%"))
        stmt = stmt.where(KnowledgeRecord.id.in_(rec_ids))
    if date_from:
        stmt = stmt.where(KnowledgeRecord.created_at >= datetime.combine(date_from, time.min, tzinfo=timezone.utc))
    if date_to:
        stmt = stmt.where(KnowledgeRecord.created_at <= datetime.combine(date_to, time.max, tzinfo=timezone.utc))
    if q:
        like = f"%{q.lower()}%"
        stmt = stmt.where(or_(func.lower(KnowledgeRecord.title).like(like), func.lower(KnowledgeRecord.transcript).like(like),
                              func.lower(KnowledgeRecord.ref).like(like), func.lower(KnowledgeRecord.summary).like(like)))
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.scalars(stmt.order_by(KnowledgeRecord.created_at.desc()).limit(limit).offset(offset)).unique().all()
    return {"items": [record_brief(r) for r in rows], "total": total, "limit": limit, "offset": offset}


@router.get("/records/{record_id}")
def get_record(record_id: str, user: User = Depends(require("knowledge:read")), db: Session = Depends(get_db)) -> dict:
    r = get_record_or_404(db, user, record_id)
    procs = db.scalars(select(Procedure).where(Procedure.record_id == r.id).order_by(Procedure.ref)).all()
    safety = db.scalars(select(SafetyWarning).where(SafetyWarning.record_id == r.id)).all()
    return {**record_out(r), "procedures": [procedure_out(p) for p in procs], "safety_warnings": [safety_out(w) for w in safety]}


class TranscriptIn(BaseModel):
    transcript: CleanText = Field(min_length=10, max_length=100000)


@router.put("/records/{record_id}/transcript")
def set_transcript(record_id: str, body: TranscriptIn, request: Request, background: BackgroundTasks,
                   user: User = Depends(require("knowledge:capture")), db: Session = Depends(get_db)) -> dict:
    """Manually supply/correct a transcript (e.g. when no speech-to-text provider is configured)."""
    r = get_record_or_404(db, user, record_id)
    if r.contributor_id != user.id and user.role not in ("supervisor", "admin"):
        raise Forbidden("Only the contributor or a supervisor can edit this transcript.")
    from ..ai.transcription import segments_from_plain_text

    r.segments = segments_from_plain_text(body.transcript)
    r.transcript = body.transcript
    r.transcript_source = "manual"
    r.processing_status = "queued"
    _clear_derived(db, r)
    audit(db, action="knowledge.transcript_edit", user=user, entity_type="knowledge_record", entity_id=r.id, request=request)
    db.commit()
    background.add_task(run_pipeline, r.id)
    return record_brief(r)


def _clear_derived(db: Session, r: KnowledgeRecord) -> None:
    """Remove AI-derived entities of a record before reprocessing (approved procedures are kept)."""
    for p in db.scalars(select(Procedure).where(Procedure.record_id == r.id, Procedure.status != "approved")).all():
        db.delete(p)
    for w in db.scalars(select(SafetyWarning).where(SafetyWarning.record_id == r.id, SafetyWarning.status != "approved")).all():
        db.delete(w)
    db.query(KnowledgeSource).filter(KnowledgeSource.record_id == r.id).delete()
    db.flush()


@router.post("/records/{record_id}/reprocess")
def reprocess(record_id: str, request: Request, background: BackgroundTasks,
              user: User = Depends(require("knowledge:review")), db: Session = Depends(get_db)) -> dict:
    r = get_record_or_404(db, user, record_id)
    _clear_derived(db, r)
    r.processing_status = "queued"
    audit(db, action="knowledge.reprocess", user=user, entity_type="knowledge_record", entity_id=r.id, request=request)
    db.commit()
    background.add_task(run_pipeline, r.id)
    return record_brief(r)


@router.get("/procedures")
def list_procedures(
    asset_id: str | None = None,
    status: str | None = None,
    q: str | None = Query(default=None, max_length=200),
    user: User = Depends(require("knowledge:read")),
    db: Session = Depends(get_db),
) -> dict:
    stmt = select(Procedure).where(Procedure.org_id == user.org_id)
    if user.role == "junior_technician":
        stmt = stmt.where(Procedure.status == "approved")
    elif status:
        stmt = stmt.where(Procedure.status == status)
    if asset_id:
        stmt = stmt.where(Procedure.asset_id == asset_id)
    if q:
        like = f"%{q.lower()}%"
        stmt = stmt.where(or_(func.lower(Procedure.title).like(like), func.lower(Procedure.ref).like(like)))
    rows = db.scalars(stmt.order_by(Procedure.ref)).unique().all()
    return {"items": [procedure_out(p) for p in rows]}


@router.get("/procedures/{procedure_id}")
def get_procedure(procedure_id: str, user: User = Depends(require("knowledge:read")), db: Session = Depends(get_db)) -> dict:
    p = db.get(Procedure, procedure_id)
    if p is None or p.org_id != user.org_id:
        p = db.scalar(select(Procedure).where(Procedure.org_id == user.org_id, Procedure.ref == procedure_id.upper()))
    if p is None or (user.role == "junior_technician" and p.status != "approved"):
        raise NotFound("Procedure not found.")
    safety = db.scalars(select(SafetyWarning).where(SafetyWarning.procedure_id == p.id)).all()
    sources = db.scalars(select(KnowledgeSource).where(KnowledgeSource.entity_id == p.id)).all()
    rec = db.get(KnowledgeRecord, p.record_id) if p.record_id else None
    return {
        **procedure_out(p),
        "safety_warnings": [safety_out(w) for w in safety],
        "record": record_brief(rec) if rec else None,
        "traceability": [
            {"entity_type": s.entity_type, "record_id": s.record_id, "recording_id": s.recording_id, "document_id": s.document_id,
             "technician_id": s.technician_id, "start": s.start_s, "end": s.end_s, "quote": s.quote,
             "confidence": s.confidence, "ai_version": s.ai_version, "created_at": s.created_at.isoformat()}
            for s in sources
        ],
    }


@router.get("/facets")
def facets(user: User = Depends(require("knowledge:read")), db: Session = Depends(get_db)) -> dict:
    """Filter options for the knowledge library."""
    techs = db.execute(select(User.id, User.full_name).where(User.org_id == user.org_id).order_by(User.full_name)).all()
    fms = db.scalars(select(FailureMode.name).where(FailureMode.org_id == user.org_id).distinct().order_by(FailureMode.name)).all()
    from ..models import Department

    deps = db.execute(select(Department.id, Department.name).where(Department.org_id == user.org_id).order_by(Department.name)).all()
    assets = db.execute(select(Asset.id, Asset.asset_tag, Asset.name).where(Asset.org_id == user.org_id).order_by(Asset.asset_tag)).all()
    return {
        "technicians": [{"id": t[0], "name": t[1]} for t in techs],
        "failure_modes": list(fms),
        "departments": [{"id": d[0], "name": d[1]} for d in deps],
        "assets": [{"id": a[0], "asset_tag": a[1], "name": a[2]} for a in assets],
        "review_statuses": ["pending", "approved", "rejected", "needs_changes"],
        "source_types": list(SOURCE_TYPES),
        "max_upload_mb": get_settings().max_upload_mb,
    }
