from __future__ import annotations

from typing import Literal

from fastapi import APIRouter, Depends, Query, Request, Response
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..ai.documents import ocr_available
from ..ai.embeddings import get_embedder
from ..ai.llm import llm_configured, provider_label
from ..ai.transcription import transcription_available
from ..config import get_settings
from ..db import get_db
from ..deps import audit, get_current_user, require
from ..errors import AppError, Conflict, NotFound
from ..models import Asset, AuditLog, Department, Plant, User
from ..security import hash_password, password_problems
from ..serializers import iso, user_out
from ..validation import CleanText, Email

router = APIRouter(prefix="/api/admin", tags=["admin"])
Role = Literal["admin", "supervisor", "technician", "junior_technician"]


class UserIn(BaseModel):
    email: Email
    full_name: CleanText = Field(min_length=2, max_length=200)
    title: CleanText = Field(default="", max_length=120)
    role: Role = "technician"
    password: str = Field(min_length=10, max_length=200)
    department_id: str | None = None
    years_experience: int | None = Field(default=None, ge=0, le=60)


class UserPatch(BaseModel):
    full_name: CleanText | None = Field(default=None, min_length=2, max_length=200)
    title: CleanText | None = Field(default=None, max_length=120)
    role: Role | None = None
    is_active: bool | None = None
    department_id: str | None = None
    password: str | None = Field(default=None, min_length=10, max_length=200)


class DepartmentIn(BaseModel):
    name: CleanText = Field(min_length=2, max_length=120)
    plant_id: str | None = None


@router.get("/users")
def list_users(user: User = Depends(require("users:manage")), db: Session = Depends(get_db)) -> dict:
    rows = db.scalars(select(User).where(User.org_id == user.org_id).order_by(User.full_name)).all()
    return {"items": [user_out(u) for u in rows]}


@router.post("/users", status_code=201)
def create_user(body: UserIn, request: Request, user: User = Depends(require("users:manage")), db: Session = Depends(get_db)) -> dict:
    if problems := password_problems(body.password):
        raise AppError("Password must contain " + ", ".join(problems) + ".", code="weak_password", status_code=422)
    if db.scalar(select(User).where(func.lower(User.email) == body.email)):
        raise Conflict("An account with this email already exists.", code="email_taken")
    if body.department_id:
        d = db.get(Department, body.department_id)
        if d is None or d.org_id != user.org_id:
            raise AppError("Unknown department.", code="invalid_department", status_code=422)
    u = User(org_id=user.org_id, email=body.email, full_name=body.full_name, title=body.title, role=body.role,
             password_hash=hash_password(body.password), department_id=body.department_id, years_experience=body.years_experience)
    db.add(u)
    db.flush()
    audit(db, action="admin.user_create", user=user, entity_type="user", entity_id=u.id, request=request, details={"role": u.role})
    db.commit()
    return user_out(u)  # type: ignore[return-value]


@router.patch("/users/{user_id}")
def update_user(user_id: str, body: UserPatch, request: Request, user: User = Depends(require("users:manage")), db: Session = Depends(get_db)) -> dict:
    u = db.get(User, user_id)
    if u is None or u.org_id != user.org_id:
        raise NotFound("User not found.")
    changes = body.model_dump(exclude_unset=True)
    if u.id == user.id and (changes.get("role") not in (None, "admin") or changes.get("is_active") is False):
        raise AppError("You cannot demote or deactivate your own account.", code="self_lockout", status_code=422)
    if "password" in changes:
        pw = changes.pop("password")
        if problems := password_problems(pw):
            raise AppError("Password must contain " + ", ".join(problems) + ".", code="weak_password", status_code=422)
        u.password_hash = hash_password(pw)
        u.token_version += 1
    for k, v in changes.items():
        setattr(u, k, v)
    if "role" in changes or changes.get("is_active") is False:
        u.token_version += 1  # force re-login with new permissions
    audit(db, action="admin.user_update", user=user, entity_type="user", entity_id=u.id, request=request, details={"fields": sorted(body.model_dump(exclude_unset=True))})
    db.commit()
    return user_out(u)  # type: ignore[return-value]


@router.get("/departments")
def departments(user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> dict:
    rows = db.scalars(select(Department).where(Department.org_id == user.org_id).order_by(Department.name)).all()
    counts = dict(db.execute(select(Asset.department_id, func.count()).where(Asset.org_id == user.org_id).group_by(Asset.department_id)).all())
    return {"items": [{"id": d.id, "name": d.name, "plant_id": d.plant_id, "assets": counts.get(d.id, 0)} for d in rows]}


@router.post("/departments", status_code=201)
def create_department(body: DepartmentIn, request: Request, user: User = Depends(require("org:manage")), db: Session = Depends(get_db)) -> dict:
    if db.scalar(select(Department).where(Department.org_id == user.org_id, Department.name == body.name)):
        raise Conflict("Department already exists.")
    d = Department(org_id=user.org_id, name=body.name, plant_id=body.plant_id)
    db.add(d)
    db.flush()
    audit(db, action="admin.department_create", user=user, entity_type="department", entity_id=d.id, request=request)
    db.commit()
    return {"id": d.id, "name": d.name, "plant_id": d.plant_id, "assets": 0}


@router.delete("/departments/{dep_id}", status_code=204)
def delete_department(dep_id: str, request: Request, user: User = Depends(require("org:manage")), db: Session = Depends(get_db)) -> Response:
    d = db.get(Department, dep_id)
    if d is None or d.org_id != user.org_id:
        raise NotFound("Department not found.")
    if db.scalar(select(func.count()).select_from(Asset).where(Asset.department_id == d.id)):
        raise Conflict("Move this department's assets before deleting it.")
    db.delete(d)
    audit(db, action="admin.department_delete", user=user, entity_type="department", entity_id=dep_id, request=request)
    db.commit()
    return Response(status_code=204)


@router.get("/plants")
def plants(user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> dict:
    rows = db.scalars(select(Plant).where(Plant.org_id == user.org_id)).all()
    return {"items": [{"id": p.id, "name": p.name, "location": p.location} for p in rows]}


@router.get("/audit")
def audit_logs(limit: int = Query(default=100, ge=1, le=500), action: str | None = None,
               user: User = Depends(require("audit:read")), db: Session = Depends(get_db)) -> dict:
    stmt = select(AuditLog).where(AuditLog.org_id == user.org_id)
    if action:
        stmt = stmt.where(AuditLog.action.like(f"{action}%"))
    rows = db.scalars(stmt.order_by(AuditLog.created_at.desc()).limit(limit)).all()
    users = {u.id: u.full_name for u in db.scalars(select(User).where(User.org_id == user.org_id)).all()}
    return {"items": [{"id": r.id, "action": r.action, "user": users.get(r.user_id or "", "System"), "entity_type": r.entity_type,
                       "entity_id": r.entity_id, "ip_address": r.ip_address, "details": r.details, "created_at": iso(r.created_at)} for r in rows]}


@router.get("/system")
def system_status(user: User = Depends(get_current_user)) -> dict:
    """What AI capabilities are genuinely active in this deployment (shown in the UI)."""
    s = get_settings()
    return {
        "app_version": s.app_version,
        "environment": s.app_env,
        "llm": {"configured": llm_configured(), "provider": provider_label(),
                "mode": "LLM + verification" if llm_configured() else "Local rules (no LLM configured)"},
        "embeddings": {"provider": get_embedder().name},
        "transcription": {"server": transcription_available(), "provider": s.transcription_provider,
                          "browser_fallback": "Web Speech API (Chrome/Edge) during capture"},
        "ocr": {"available": ocr_available()},
        "vector_backend": "pgvector" if s.use_pgvector else "numpy (in-process)",
        "graph": {"primary": "PostgreSQL relational graph", "neo4j_configured": bool(s.neo4j_uri)},
        "storage": s.storage_backend,
        "demo_mode": s.demo_mode,
        "config_problems": s.config_problems() if user.role == "admin" else [],
    }
