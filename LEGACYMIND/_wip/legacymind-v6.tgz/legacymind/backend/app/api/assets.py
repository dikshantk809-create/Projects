from __future__ import annotations

import re
from datetime import date

from fastapi import APIRouter, Depends, File, Form, Query, Request, Response, UploadFile
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from ..ai.documents import extract_text
from ..db import get_db, new_id
from ..deps import audit, require
from ..errors import AppError, Conflict, NotFound
from ..models import (
    Asset,
    Component,
    Department,
    Document,
    FailureMode,
    FailureModeSymptom,
    KnowledgeRecord,
    MaintenanceEvent,
    Procedure,
    Recording,
    SafetyWarning,
    Symptom,
    User,
)
from ..serializers import (
    asset_out,
    document_out,
    event_out,
    procedure_out,
    record_brief,
    recording_out,
    safety_out,
)
from ..services.qrcode import qr_svg
from ..services.storage import get_storage, safe_filename, sha256, validate_upload
from ..validation import CleanText

router = APIRouter(prefix="/api/assets", tags=["assets"])

STATUSES = ("operational", "degraded", "down", "maintenance", "decommissioned")
CRITICALITY = ("low", "medium", "high", "critical")


class AssetIn(BaseModel):
    asset_tag: str = Field(min_length=2, max_length=40)
    name: CleanText = Field(min_length=2, max_length=200)
    machine_type: CleanText = Field(default="", max_length=120)
    manufacturer: CleanText = Field(default="", max_length=120)
    model: CleanText = Field(default="", max_length=120)
    serial_number: CleanText = Field(default="", max_length=120)
    department_id: str | None = None
    location: CleanText = Field(default="", max_length=200)
    installed_on: date | None = None
    status: str = "operational"
    criticality: str = "medium"
    description: CleanText = Field(default="", max_length=4000)

    @field_validator("asset_tag")
    @classmethod
    def _tag(cls, v: str) -> str:
        v = v.strip().upper()
        if not re.fullmatch(r"[A-Z0-9][A-Z0-9-]{1,39}", v):
            raise ValueError("use letters, digits and dashes, e.g. P-103")
        return v

    @field_validator("status")
    @classmethod
    def _status(cls, v: str) -> str:
        if v not in STATUSES:
            raise ValueError(f"must be one of {', '.join(STATUSES)}")
        return v

    @field_validator("criticality")
    @classmethod
    def _crit(cls, v: str) -> str:
        if v not in CRITICALITY:
            raise ValueError(f"must be one of {', '.join(CRITICALITY)}")
        return v


class AssetPatch(BaseModel):
    name: CleanText | None = Field(default=None, max_length=200)
    machine_type: CleanText | None = None
    manufacturer: CleanText | None = None
    model: CleanText | None = None
    serial_number: CleanText | None = None
    department_id: str | None = None
    location: CleanText | None = None
    installed_on: date | None = None
    status: str | None = None
    criticality: str | None = None
    description: CleanText | None = None

    @field_validator("status")
    @classmethod
    def _status(cls, v: str | None) -> str | None:
        if v is not None and v not in STATUSES:
            raise ValueError(f"must be one of {', '.join(STATUSES)}")
        return v

    @field_validator("criticality")
    @classmethod
    def _crit(cls, v: str | None) -> str | None:
        if v is not None and v not in CRITICALITY:
            raise ValueError(f"must be one of {', '.join(CRITICALITY)}")
        return v


class EventIn(BaseModel):
    occurred_on: date
    event_type: str = Field(default="corrective", pattern="^(corrective|preventive|inspection|breakdown|modification)$")
    summary: CleanText = Field(min_length=3, max_length=2000)
    downtime_hours: float | None = Field(default=None, ge=0, le=10000)


def get_asset_or_404(db: Session, user: User, asset_id: str) -> Asset:
    a = db.get(Asset, asset_id)
    if a is None or a.org_id != user.org_id:
        # also accept the human asset tag in URLs (QR codes / deep links)
        a = db.scalar(select(Asset).where(Asset.org_id == user.org_id, Asset.asset_tag == asset_id.upper()))
    if a is None:
        raise NotFound("Asset not found.")
    return a


def _check_department(db: Session, user: User, dep_id: str | None) -> None:
    if dep_id:
        d = db.get(Department, dep_id)
        if d is None or d.org_id != user.org_id:
            raise AppError("Unknown department.", code="invalid_department", status_code=422)


@router.get("")
def list_assets(
    q: str | None = Query(default=None, max_length=100),
    status: str | None = None,
    department_id: str | None = None,
    user: User = Depends(require("assets:read")),
    db: Session = Depends(get_db),
) -> dict:
    stmt = select(Asset).where(Asset.org_id == user.org_id)
    if q:
        like = f"%{q.lower()}%"
        stmt = stmt.where(or_(func.lower(Asset.name).like(like), func.lower(Asset.asset_tag).like(like),
                              func.lower(Asset.location).like(like), func.lower(Asset.manufacturer).like(like)))
    if status:
        stmt = stmt.where(Asset.status == status)
    if department_id:
        stmt = stmt.where(Asset.department_id == department_id)
    assets = db.scalars(stmt.order_by(Asset.asset_tag)).all()
    ids = [a.id for a in assets]
    counts = dict(db.execute(select(KnowledgeRecord.asset_id, func.count()).where(KnowledgeRecord.asset_id.in_(ids)).group_by(KnowledgeRecord.asset_id)).all()) if ids else {}
    approved = dict(db.execute(select(Procedure.asset_id, func.count()).where(Procedure.asset_id.in_(ids), Procedure.status == "approved").group_by(Procedure.asset_id)).all()) if ids else {}
    return {"items": [{**asset_out(a), "knowledge_count": counts.get(a.id, 0), "approved_procedures": approved.get(a.id, 0)} for a in assets]}


@router.post("", status_code=201)
def create_asset(body: AssetIn, request: Request, user: User = Depends(require("assets:write")), db: Session = Depends(get_db)) -> dict:
    if db.scalar(select(Asset).where(Asset.org_id == user.org_id, Asset.asset_tag == body.asset_tag)):
        raise Conflict(f"Asset {body.asset_tag} already exists.", code="asset_exists")
    _check_department(db, user, body.department_id)
    a = Asset(org_id=user.org_id, **body.model_dump())
    db.add(a)
    db.flush()
    audit(db, action="asset.create", user=user, entity_type="asset", entity_id=a.id, request=request, details={"tag": a.asset_tag})
    db.commit()
    return asset_out(a)


@router.get("/{asset_id}")
def get_asset(asset_id: str, user: User = Depends(require("assets:read")), db: Session = Depends(get_db)) -> dict:
    a = get_asset_or_404(db, user, asset_id)
    visible = ("approved",) if user.role == "junior_technician" else ("approved", "pending_review")
    procedures = db.scalars(select(Procedure).where(Procedure.asset_id == a.id, Procedure.status.in_(visible)).order_by(Procedure.ref)).all()
    records = db.scalars(select(KnowledgeRecord).where(KnowledgeRecord.asset_id == a.id).order_by(KnowledgeRecord.created_at.desc())).all()
    if user.role == "junior_technician":
        records = [r for r in records if r.review_status == "approved"]
    fms = db.scalars(select(FailureMode).where(FailureMode.asset_id == a.id)).all()
    fm_out = []
    for fm in fms:
        syms = db.scalars(select(Symptom.name).join(FailureModeSymptom, FailureModeSymptom.symptom_id == Symptom.id).where(FailureModeSymptom.failure_mode_id == fm.id)).all()
        fm_out.append({"id": fm.id, "name": fm.name, "causes": fm.causes, "symptoms": list(syms), "is_rare": fm.is_rare})
    rec_ids = [r.id for r in records]
    recordings = db.scalars(select(Recording).where(Recording.record_id.in_(rec_ids))).all() if rec_ids else []
    rec_by_id = {r.id: r for r in records}
    docs = db.scalars(select(Document).where(or_(Document.asset_id == a.id, Document.record_id.in_(rec_ids) if rec_ids else False))).all()
    events = db.scalars(select(MaintenanceEvent).where(MaintenanceEvent.asset_id == a.id).order_by(MaintenanceEvent.occurred_on.desc())).all()
    safety = db.scalars(select(SafetyWarning).where(SafetyWarning.asset_id == a.id, SafetyWarning.status == "approved")).all()
    comps = db.scalars(select(Component).where(Component.asset_id == a.id).order_by(Component.name)).all()
    return {
        "asset": asset_out(a),
        "components": [{"id": c.id, "name": c.name, "tag": c.tag} for c in comps],
        "procedures": [procedure_out(p) for p in procedures],
        "failure_modes": fm_out,
        "records": [record_brief(r) for r in records],
        "recordings": [{**recording_out(x), "record": record_brief(rec_by_id[x.record_id])} for x in recordings if x.record_id in rec_by_id],
        "documents": [document_out(d) for d in docs],
        "maintenance_history": [event_out(e) for e in events],
        "safety_warnings": [safety_out(w) for w in safety],
        "qr_url": f"/api/assets/{a.id}/qr.svg",
    }


@router.patch("/{asset_id}")
def update_asset(asset_id: str, body: AssetPatch, request: Request, user: User = Depends(require("assets:write")), db: Session = Depends(get_db)) -> dict:
    a = get_asset_or_404(db, user, asset_id)
    changes = body.model_dump(exclude_unset=True)
    if "department_id" in changes:
        _check_department(db, user, changes["department_id"])
    for k, v in changes.items():
        setattr(a, k, v)
    audit(db, action="asset.update", user=user, entity_type="asset", entity_id=a.id, request=request, details={"fields": sorted(changes)})
    db.commit()
    return asset_out(a)


@router.delete("/{asset_id}", status_code=204)
def delete_asset(asset_id: str, request: Request, user: User = Depends(require("assets:write")), db: Session = Depends(get_db)) -> Response:
    a = get_asset_or_404(db, user, asset_id)
    if db.scalar(select(func.count()).select_from(KnowledgeRecord).where(KnowledgeRecord.asset_id == a.id)):
        raise Conflict("This asset has captured knowledge. Set its status to 'decommissioned' instead of deleting it.")
    audit(db, action="asset.delete", user=user, entity_type="asset", entity_id=a.id, request=request, details={"tag": a.asset_tag})
    db.delete(a)
    db.commit()
    return Response(status_code=204)


@router.get("/{asset_id}/qr.svg")
def asset_qr(asset_id: str, request: Request, base_url: str | None = Query(default=None, max_length=200),
             user: User = Depends(require("assets:read")), db: Session = Depends(get_db)) -> Response:
    a = get_asset_or_404(db, user, asset_id)
    origin = base_url or request.headers.get("origin") or str(request.base_url).rstrip("/")
    if not re.fullmatch(r"https?://[A-Za-z0-9.:-]+(?:/[A-Za-z0-9._/-]*)?", origin):
        raise AppError("Invalid base_url.", code="invalid_base_url", status_code=422)
    svg = qr_svg(f"{origin.rstrip('/')}/app/assets/{a.asset_tag}")
    return Response(svg, media_type="image/svg+xml", headers={"Cache-Control": "private, max-age=3600"})


@router.post("/{asset_id}/events", status_code=201)
def add_event(asset_id: str, body: EventIn, request: Request, user: User = Depends(require("knowledge:capture")), db: Session = Depends(get_db)) -> dict:
    a = get_asset_or_404(db, user, asset_id)
    e = MaintenanceEvent(org_id=user.org_id, asset_id=a.id, technician_id=user.id, **body.model_dump())
    db.add(e)
    audit(db, action="asset.event", user=user, entity_type="asset", entity_id=a.id, request=request)
    db.commit()
    return event_out(e)


@router.post("/{asset_id}/documents", status_code=201)
async def upload_asset_document(
    asset_id: str,
    request: Request,
    file: UploadFile = File(...),
    category: str = Form(default="manual", pattern="^(manual|machine|part|fault|wiring|control_panel|other)$"),
    user: User = Depends(require("knowledge:capture")),
    db: Session = Depends(get_db),
) -> dict:
    a = get_asset_or_404(db, user, asset_id)
    data = await file.read()
    ext, kind = validate_upload(file.filename or "", file.content_type or "", data)
    if kind not in ("document", "image"):
        raise AppError("Only documents and images can be attached to an asset.", code="unsupported_file_type", status_code=415)
    key = f"{user.org_id}/assets/{a.id}/{new_id()}{ext}"
    get_storage().put(key, data, file.content_type or "application/octet-stream")
    text, method = extract_text(data, ext)
    d = Document(org_id=user.org_id, asset_id=a.id, kind="image" if kind == "image" else ext.lstrip("."), category=category,
                 filename=safe_filename(file.filename or "document" + ext), mime_type=file.content_type or "",
                 size_bytes=len(data), storage_key=key, sha256=sha256(data), extracted_text=text[:200000], extraction_method=method)
    db.add(d)
    audit(db, action="asset.document_upload", user=user, entity_type="asset", entity_id=a.id, request=request, details={"file": d.filename})
    db.commit()
    return document_out(d)
