"""Test fixtures.

Tests run against SQLite by default (fast, no services). Set
TEST_DATABASE_URL=postgresql://... to run the identical suite against
PostgreSQL + pgvector (CI does both).
"""

from __future__ import annotations

import os
import shutil
import tempfile
from collections.abc import Iterator
from pathlib import Path

import pytest

_TMP = Path(tempfile.mkdtemp(prefix="legacymind-tests-"))
os.environ["APP_ENV"] = "test"
os.environ["DATABASE_URL"] = os.environ.get("TEST_DATABASE_URL") or f"sqlite:///{_TMP / 'test.db'}"
os.environ["STORAGE_LOCAL_PATH"] = str(_TMP / "storage")
os.environ["SEED_DEMO_ON_STARTUP"] = "false"
os.environ["DEMO_MODE"] = "true"
os.environ["LOG_JSON"] = "false"
os.environ["LOG_LEVEL"] = "WARNING"
os.environ["AI_PROVIDER"] = "none"
os.environ["EMBEDDING_PROVIDER"] = "local"
os.environ["TRANSCRIPTION_PROVIDER"] = "none"
os.environ["SECRET_KEY"] = "test-secret-key-0123456789abcdef0123456789"
os.environ["RATE_LIMIT_PER_MINUTE"] = "100000"
os.environ["AUTH_RATE_LIMIT_PER_MINUTE"] = "100000"

from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy import text  # noqa: E402

from app.config import get_settings  # noqa: E402
from app.db import Base, get_engine, session_factory  # noqa: E402
from app.deps import limiter  # noqa: E402

DEMO_PASSWORD = "LegacyMind-Demo-2026"


def _reset_schema() -> None:
    engine = get_engine()
    if engine.dialect.name == "postgresql":
        with engine.begin() as conn:
            conn.execute(text("DROP SCHEMA public CASCADE; CREATE SCHEMA public;"))
    else:
        Base.metadata.drop_all(engine)
        with engine.begin() as conn:
            conn.execute(text("DROP TABLE IF EXISTS alembic_version"))
    from app.migrate import upgrade_to_head

    upgrade_to_head()


@pytest.fixture(scope="session", autouse=True)
def _database() -> Iterator[None]:
    get_settings.cache_clear()
    _reset_schema()
    yield
    get_engine().dispose()
    shutil.rmtree(_TMP, ignore_errors=True)


@pytest.fixture(scope="session")
def seeded(_database: None) -> str:
    """The synthetic NovaTech demo, built through the real pipeline. Returns org id."""
    from app.seed.demo_data import seed_demo

    db = session_factory()()
    try:
        return seed_demo(db).id
    finally:
        db.close()


@pytest.fixture()
def app():
    from app.main import create_app

    return create_app(bootstrap=False)


@pytest.fixture()
def client(app) -> Iterator[TestClient]:
    limiter.reset()
    with TestClient(app) as c:
        yield c


@pytest.fixture()
def db():
    s = session_factory()()
    try:
        yield s
    finally:
        s.close()


def login(client: TestClient, email: str, password: str = DEMO_PASSWORD) -> dict:
    r = client.post("/api/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, r.text
    return r.json()


@pytest.fixture()
def as_supervisor(client, seeded) -> TestClient:
    login(client, "amit.sharma@novatech.demo")
    return client


@pytest.fixture()
def as_junior(client, seeded) -> TestClient:
    login(client, "rahul.verma@novatech.demo")
    return client


@pytest.fixture()
def as_senior(client, seeded) -> TestClient:
    login(client, "rajesh.kumar@novatech.demo")
    return client


@pytest.fixture()
def as_admin(client, seeded) -> TestClient:
    login(client, "priya.nair@novatech.demo")
    return client


_counter = {"n": 0}


@pytest.fixture()
def fresh_org(client) -> dict:
    """A brand-new organization with its admin signed in."""
    _counter["n"] += 1
    n = _counter["n"]
    r = client.post("/api/auth/register", json={
        "organization_name": f"Test Works {n}", "plant_name": "Plant 1", "full_name": "Test Admin",
        "email": f"admin{n}@testworks.example", "password": "Str0ng-password-1",
    })
    assert r.status_code == 201, r.text
    return r.json()
