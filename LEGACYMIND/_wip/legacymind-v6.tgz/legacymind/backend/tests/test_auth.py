from app.deps import limiter


def test_register_login_me_logout(client, fresh_org):
    assert fresh_org["user"]["role"] == "admin"
    me = client.get("/api/auth/me")
    assert me.status_code == 200
    assert "users:manage" in me.json()["permissions"]
    assert client.post("/api/auth/logout").status_code == 200
    assert client.get("/api/auth/me").status_code == 401


def test_session_cookie_is_httponly(client, fresh_org):
    r = client.post("/api/auth/login", json={"email": fresh_org["user"]["email"], "password": "Str0ng-password-1"})
    cookie = r.headers["set-cookie"].lower()
    assert "httponly" in cookie and "samesite=lax" in cookie


def test_login_failures_are_generic(client, seeded):
    bad_pw = client.post("/api/auth/login", json={"email": "amit.sharma@novatech.demo", "password": "wrong-password"})
    no_user = client.post("/api/auth/login", json={"email": "nobody@novatech.demo", "password": "wrong-password"})
    assert bad_pw.status_code == no_user.status_code == 401
    assert bad_pw.json()["error"]["message"] == no_user.json()["error"]["message"]
    assert "error_id" in bad_pw.json()["error"]


def test_register_validation(client):
    r = client.post("/api/auth/register", json={"organization_name": "X Co", "full_name": "A B", "email": "not-an-email", "password": "Str0ng-password-1"})
    assert r.status_code == 422
    fields = {d["field"] for d in r.json()["error"]["details"]}
    assert "email" in fields
    weak = client.post("/api/auth/register", json={"organization_name": "X Co", "full_name": "A B", "email": "weak@x.example", "password": "aaaaaaaaaaaa"})
    assert weak.status_code == 422 and weak.json()["error"]["code"] == "weak_password"


def test_duplicate_email(client, fresh_org):
    email = fresh_org["user"]["email"]
    r = client.post("/api/auth/register", json={"organization_name": "Other", "full_name": "A B", "email": email, "password": "Str0ng-password-1"})
    assert r.status_code == 409


def test_protected_routes_require_auth(client, seeded):
    for path in ("/api/assets", "/api/knowledge/records", "/api/analytics/summary", "/api/reviews/queue", "/api/graph"):
        r = client.get(path)
        assert r.status_code == 401, path
        assert r.json()["error"]["code"] == "unauthorized"


def test_bearer_token_also_works(client, seeded):
    tok = client.post("/api/auth/login", json={"email": "amit.sharma@novatech.demo", "password": "LegacyMind-Demo-2026"}).json()["access_token"]
    client.cookies.clear()
    assert client.get("/api/auth/me", headers={"Authorization": f"Bearer {tok}"}).status_code == 200


def test_logout_all_revokes_tokens(client, fresh_org):
    tok = client.post("/api/auth/login", json={"email": fresh_org["user"]["email"], "password": "Str0ng-password-1"}).json()["access_token"]
    assert client.post("/api/auth/logout-all").status_code == 200
    client.cookies.clear()
    assert client.get("/api/auth/me", headers={"Authorization": f"Bearer {tok}"}).status_code == 401


def test_auth_rate_limit(client, monkeypatch):
    from app.config import get_settings

    monkeypatch.setattr(get_settings(), "auth_rate_limit_per_minute", 3)
    limiter.reset()
    codes = [client.post("/api/auth/login", json={"email": "x@y.example", "password": "zzzzzzzz"}).status_code for _ in range(5)]
    assert codes[:3] == [401, 401, 401]
    assert codes[3] == 429
    limiter.reset()


def test_role_permissions_enforced(as_junior):
    assert as_junior.get("/api/reviews/queue").status_code == 403
    assert as_junior.get("/api/admin/users").status_code == 403
    assert as_junior.post("/api/knowledge/records", data={"title": "x x x", "source_type": "text", "notes": "hello there"}).status_code == 403
    assert as_junior.get("/api/assets").status_code == 200
