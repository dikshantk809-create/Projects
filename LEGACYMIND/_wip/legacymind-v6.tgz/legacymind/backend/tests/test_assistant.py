"""Grounded answers: retrieval, citations, safety, refusal, asset scoping, conflicts."""

from app.ai.answer import INSUFFICIENT_MESSAGE, answer_question

Q_P103 = "Pump P-103 is making a grinding sound during startup. What should I check?"


def ask(client, q, **kw):
    r = client.post("/api/assistant/ask", json={"question": q, **kw})
    assert r.status_code == 200, r.text
    return r.json()["message"]["answer"]


def test_p103_grounded_answer(as_junior):
    a = ask(as_junior, Q_P103)
    assert a["status"] == "answered"
    assert a["machine"]["asset_tag"] == "P-103"
    assert a["groundedness"]["level"] in ("HIGH", "MEDIUM")
    texts = " ".join(s["text"] for s in a["steps"]).lower()
    assert "valve v-03" in texts and "blockage" in texts
    # every step cites evidence, every citation resolves
    ids = {e["id"] for e in a["evidence"]}
    assert all(s["citations"] and set(s["citations"]) <= ids for s in a["steps"])
    ev = next(e for e in a["evidence"] if e["kind"] == "procedure_step" and "V-03" in e["quote"])
    assert ev["record_ref"] == "LM-1042" and ev["technician"] == "Rajesh Kumar"
    assert ev["timestamp"] == "02:14-02:48"
    assert any("lockout" in s["text"].lower() for s in a["safety"])
    assert {"knowledge_record", "asset", "procedure"} <= {s["type"] for s in a["sources"]}
    assert a["procedure"]["requires_supervisor"] is True
    assert a["escalation"]["required"] is True, "high-risk procedure requires sign-off"


def test_unknown_asset_is_refused(as_junior):
    a = ask(as_junior, "How do I recalibrate the vision sensor on packaging line PK-09?")
    assert a["status"] == "insufficient"
    assert a["summary"] == INSUFFICIENT_MESSAGE
    assert a["steps"] == [] and a["escalation"]["required"]


def test_off_topic_question_is_refused(as_junior):
    a = ask(as_junior, "What is the capital of France?")
    assert a["status"] == "insufficient"


def test_asset_scoping_never_borrows_other_machines(as_junior):
    # CP-02 has no grinding knowledge; P-103's grinding procedure must not be used
    a = ask(as_junior, "CP-02 compressor is making a grinding sound during startup")
    refs = {e["record_ref"] for e in a["evidence"]}
    assert "LM-1042" not in refs
    assert a["machine"] is None or a["machine"]["asset_tag"] == "CP-02"


def test_pending_knowledge_is_not_citable(as_junior):
    # LM-1048 (HP-01 hissing, hose leak) is still pending review in the demo
    a = ask(as_junior, "HP-01 is hissing near the hose bundle")
    assert "LM-1048" not in {e["record_ref"] for e in a["evidence"]}


def test_conflict_is_surfaced_not_silently_resolved(db, seeded):
    # Approve the idler-first CV-04 procedure (LM-1047) in a scratch transaction to see the conflict path.
    from sqlalchemy import select

    from app.models import KnowledgeConflict, Procedure

    conflicts = db.scalars(select(KnowledgeConflict).where(KnowledgeConflict.org_id == seeded, KnowledgeConflict.status == "open")).all()
    assert conflicts, "demo must contain the CV-04 conflict (tail pulley vs idler rollers)"
    c = conflicts[0]
    a_first = c.procedure_a.steps
    assert c.procedure_a.asset_id == c.procedure_b.asset_id
    ans = answer_question(db, seeded, "CV-04 belt is mistracking, what should I check first?")
    assert ans["status"] == "answered"
    assert ans["conflicts"], "open conflicts must be surfaced in the answer"
    assert ans["groundedness"]["level"] != "HIGH"
    assert ans["escalation"]["required"]
    assert a_first and isinstance(db.get(Procedure, c.procedure_b_id), Procedure)


def test_context_asset_from_qr_page(as_junior):
    p103 = next(a for a in as_junior.get("/api/assets").json()["items"] if a["asset_tag"] == "P-103")
    a = ask(as_junior, "grinding noise when starting, what do I check?", asset_id=p103["id"])
    assert a["status"] == "answered" and a["machine"]["asset_tag"] == "P-103"


def test_llm_steps_are_verified(monkeypatch, db, seeded):
    """With an LLM configured, unsupported steps are removed and counted."""
    from app.ai import answer as answer_mod

    def fake_llm(system, user, **k):
        return {"answerable": True, "summary": "Check V-03.", "steps": [
            {"text": "Inspect Valve V-03", "evidence": ["E1", "E2", "E3"]},
            {"text": "Replace the entire pump with a new unit immediately", "evidence": ["E1"]},  # unsupported
            {"text": "Check the valve for blockage", "evidence": ["E99"]},  # bad citation
        ]}

    monkeypatch.setattr(answer_mod, "llm_configured", lambda: True)
    monkeypatch.setattr(answer_mod, "complete_json", fake_llm)
    ans = answer_question(db, seeded, Q_P103)
    texts = [s["text"] for s in ans["steps"]]
    assert "Inspect Valve V-03" in texts
    assert not any("entire pump" in t for t in texts)
    assert ans["unsupported_removed"] == 2
    assert ans["mode"].startswith("llm-grounded")


def test_conversation_history(as_junior):
    r = as_junior.post("/api/assistant/ask", json={"question": Q_P103}).json()
    conv = as_junior.get(f"/api/assistant/conversations/{r['conversation_id']}").json()
    assert [m["role"] for m in conv["messages"]][-2:] == ["user", "assistant"]
    assert any(c["id"] == r["conversation_id"] for c in as_junior.get("/api/assistant/conversations").json()["items"])
