"""Health, readiness, headers, error contract, demo mode, analytics, graph, admin."""


def test_health_and_ready(client):
    assert client.get("/health").json()["status"] == "ok"
    r = client.get("/ready")
    assert r.status_code == 200
    body = r.json()
    assert body["checks"] == {"database": "ok", "migrations": "ok", "storage": "ok"}


def test_security_headers(client):
    r = client.get("/health")
    for h in ("x-content-type-options", "x-frame-options", "referrer-policy", "content-security-policy", "x-request-id"):
        assert h in r.headers


def test_request_id_is_propagated_and_sanitised(client):
    assert client.get("/health", headers={"X-Request-ID": "abc-123"}).headers["x-request-id"] == "abc-123"
    assert client.get("/health", headers={"X-Request-ID": "<script>"}).headers["x-request-id"] == "script"


def test_error_contract_has_no_stack_traces(client, seeded):
    r = client.get("/api/does-not-exist")
    assert r.status_code == 404
    err = r.json()["error"]
    assert set(err) >= {"code", "message", "error_id"}
    assert "Traceback" not in r.text


def test_unhandled_exception_returns_reference(app, monkeypatch):
    from fastapi.testclient import TestClient

    @app.get("/api/boom")
    def boom():
        raise RuntimeError("secret internal detail")

    with TestClient(app, raise_server_exceptions=False) as c:
        r = c.get("/api/boom")
    assert r.status_code == 500
    assert "secret internal detail" not in r.text
    assert r.json()["error"]["error_id"] in r.json()["error"]["message"]


def test_oversized_body_rejected_early(client, monkeypatch):
    from app.config import get_settings

    r = client.post("/api/knowledge/records", headers={"content-length": str((get_settings().max_upload_mb + 5) * 1024 * 1024)}, content=b"")
    assert r.status_code == 413


def test_demo_launch(client, seeded):
    info = client.get("/api/demo").json()
    assert info["enabled"] and info["label"] == "Synthetic Demo Data"
    r = client.post("/api/demo/launch?persona=junior")
    assert r.status_code == 200 and r.json()["user"]["role"] == "junior_technician"
    assert r.json()["organization"]["is_demo"] is True
    assert client.post("/api/demo/launch?persona=root").status_code == 422


def test_demo_data_is_flagged_synthetic(as_supervisor):
    assets = as_supervisor.get("/api/assets").json()["items"]
    assert assets and all(a["is_synthetic"] for a in assets)
    recs = as_supervisor.get("/api/knowledge/records").json()["items"]
    assert recs and all(r["is_synthetic"] for r in recs)


def test_dashboard_summary(as_supervisor):
    s = as_supervisor.get("/api/analytics/summary").json()
    assert s["totals"]["assets"] == 5
    assert s["totals"]["approved_procedures"] >= 5
    assert s["totals"]["open_conflicts"] >= 1
    assert len(s["coverage"]) == 5 and s["recent_activity"]


def test_analytics_detail_and_export(as_supervisor):
    d = as_supervisor.get("/api/analytics/detail").json()
    assert d["technician_contribution"] and d["most_common_failures"]
    assert "INSUFFICIENT" in d["groundedness_distribution"], "the PK-09 demo question is an escalation"
    csv = as_supervisor.get("/api/analytics/export.csv")
    assert csv.status_code == 200 and csv.text.startswith("ref,title")


def test_graph_and_cypher(as_admin):
    g = as_admin.get("/api/graph").json()
    types = {n["type"] for n in g["nodes"]}
    assert {"asset", "failure_mode", "symptom", "procedure", "safety", "record", "technician"} <= types
    rels = {e["type"] for e in g["edges"]}
    assert {"HAS_FAILURE_MODE", "HAS_SYMPTOM", "RESOLVED_BY", "REQUIRES_SAFETY", "SOURCE_OF"} <= rels
    cy = as_admin.get("/api/graph/cypher")
    assert cy.status_code == 200 and "MERGE (n:Asset" in cy.text
    assert as_admin.post("/api/graph/neo4j/sync").status_code == 503, "Neo4j optional: clear 503 when not configured"


def test_junior_graph_excludes_pending(as_junior):
    g = as_junior.get("/api/graph").json()
    assert all(n.get("status") in (None, "approved") for n in g["nodes"] if n["type"] == "procedure")


def test_admin_user_management(as_admin):
    r = as_admin.post("/api/admin/users", json={"email": "new.tech@novatech.demo", "full_name": "New Tech", "role": "technician", "password": "Str0ng-password-9"})
    assert r.status_code == 201
    uid = r.json()["id"]
    assert as_admin.patch(f"/api/admin/users/{uid}", json={"role": "junior_technician"}).json()["role"] == "junior_technician"
    me = as_admin.get("/api/auth/me").json()["user"]["id"]
    assert as_admin.patch(f"/api/admin/users/{me}", json={"role": "technician"}).json()["error"]["code"] == "self_lockout"
    audit = as_admin.get("/api/admin/audit?action=admin").json()["items"]
    assert any(a["action"] == "admin.user_create" for a in audit)


def test_system_status_is_honest(as_admin):
    s = as_admin.get("/api/admin/system").json()
    assert s["llm"]["configured"] is False and s["llm"]["provider"] == "local-rules"
    assert s["embeddings"]["provider"] == "local-hash-v1"
    assert s["transcription"]["server"] is False
