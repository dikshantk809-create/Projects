import time


def _asset(client):
    return client.post("/api/assets", json={"asset_tag": "HX-1", "name": "Heat Exchanger", "criticality": "high"}).json()["id"]


def test_harvest_interview_flow(client, fresh_org):
    aid = _asset(client)
    s = client.post("/api/harvest/sessions", json={"asset_id": aid}).json()
    assert s["status"] == "active" and s["current_question"]["text"].startswith("What problems occur most frequently")
    assert all(c["percent"] == 0 for c in s["coverage"])

    s = client.post(f"/api/harvest/sessions/{s['id']}/answer", json={"text": "Valve blockage."}).json()
    assert "symptoms" in s["current_question"]["text"].lower(), "failure mode without symptoms -> ask for symptoms"

    s = client.post(f"/api/harvest/sessions/{s['id']}/answer", json={"text": "Pressure drops and the pump becomes noisy."}).json()
    q3 = s["current_question"]["text"].lower()
    assert "check first" in q3 or "inexperienced" in q3

    s = client.post(f"/api/harvest/sessions/{s['id']}/answer", json={"text": "They normally replace the pump, but that's unnecessary."}).json()
    assert s["current_question"]["text"] == "What should they check instead?"

    s = client.post(f"/api/harvest/sessions/{s['id']}/answer", json={"text": "First isolate the exchanger and apply lockout/tagout. Then inspect the inlet valve for blockage and clean the strainer."}).json()
    cov = {c["category"]: c["percent"] for c in s["coverage"]}
    assert cov["failure_modes"] > 0 and cov["troubleshooting"] > 0 and cov["safety"] > 0
    assert s["gaps"], "coverage gaps are reported"

    done = client.post(f"/api/harvest/sessions/{s['id']}/finish").json()
    assert done["status"] == "completed" and done["record_ref"].startswith("LM-")
    for _ in range(50):
        rec = client.get(f"/api/knowledge/records/{done['record_ref']}").json()
        if rec["processing_status"] == "processed":
            break
        time.sleep(0.1)
    assert rec["source_type"] == "interview" and rec["asset"]["id"] == aid
    assert rec["procedures"], "the interview becomes a procedure card for review"
    assert client.post(f"/api/harvest/sessions/{s['id']}/answer", json={"text": "more"}).status_code == 409


def test_cannot_finish_empty_interview(client, fresh_org):
    aid = client.post("/api/assets", json={"asset_tag": "HX-2", "name": "HX"}).json()["id"]
    s = client.post("/api/harvest/sessions", json={"asset_id": aid}).json()
    assert client.post(f"/api/harvest/sessions/{s['id']}/finish").json()["error"]["code"] == "empty_interview"
