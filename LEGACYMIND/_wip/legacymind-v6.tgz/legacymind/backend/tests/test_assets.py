import io

import numpy as np
import pytest


def _asset(client, tag="PX-1", **kw):
    body = {"asset_tag": tag, "name": "Test Pump", "manufacturer": "Acme", "status": "operational", "criticality": "high", **kw}
    return client.post("/api/assets", json=body)


def test_asset_crud_and_validation(client, fresh_org):
    r = _asset(client, "p-9")
    assert r.status_code == 201 and r.json()["asset_tag"] == "P-9"
    assert _asset(client, "P-9").status_code == 409
    bad = _asset(client, "bad tag!")
    assert bad.status_code == 422 and bad.json()["error"]["details"][0]["field"] == "asset_tag"
    assert _asset(client, "P-10", status="exploded").status_code == 422
    aid = r.json()["id"]
    assert client.patch(f"/api/assets/{aid}", json={"status": "degraded"}).json()["status"] == "degraded"
    detail = client.get("/api/assets/P-9").json()  # tag works as id (QR deep links)
    assert detail["asset"]["id"] == aid
    assert client.delete(f"/api/assets/{aid}").status_code == 204
    assert client.get(f"/api/assets/{aid}").status_code == 404


def test_org_isolation(client, fresh_org, seeded):
    aid = _asset(client, "ISO-1").json()["id"]
    client.post("/api/auth/login", json={"email": "amit.sharma@novatech.demo", "password": "LegacyMind-Demo-2026"})
    assert client.get(f"/api/assets/{aid}").status_code == 404
    tags = [a["asset_tag"] for a in client.get("/api/assets").json()["items"]]
    assert "ISO-1" not in tags and "P-103" in tags


def test_qr_code_decodes_to_asset_page(as_supervisor):
    cv2 = pytest.importorskip("cv2")
    r = as_supervisor.get("/api/assets/P-103/qr.svg", params={"base_url": "https://legacymind.example"})
    assert r.status_code == 200 and r.headers["content-type"].startswith("image/svg+xml")
    img = _rasterize_svg_qr(r.text)
    data, _, _ = cv2.QRCodeDetector().detectAndDecode(img)
    assert data == "https://legacymind.example/app/assets/P-103"


def test_qr_rejects_bad_base_url(as_supervisor):
    r = as_supervisor.get("/api/assets/P-103/qr.svg", params={"base_url": "javascript:alert(1)"})
    assert r.status_code == 422


def _rasterize_svg_qr(svg: str) -> "np.ndarray":
    """Rasterise our QR SVG (viewBox in modules, one path of unit squares) without an SVG library."""
    import re

    vb = re.search(r'viewBox="0 0 (\d+) (\d+)"', svg)
    assert vb, "QR svg must declare a viewBox"
    n = int(vb.group(1))
    scale = 10
    img = np.full((n * scale, n * scale), 255, dtype=np.uint8)
    path = re.search(r'<path[^>]* d="([^"]+)"', svg).group(1)
    for x, y in re.findall(r"M(\d+),(\d+)h1v1h-1z", path):
        x, y = int(x), int(y)
        img[y * scale:(y + 1) * scale, x * scale:(x + 1) * scale] = 0
    return img


def test_document_upload_validation(client, fresh_org):
    aid = _asset(client, "DOC-1").json()["id"]
    ok = client.post(f"/api/assets/{aid}/documents", files={"file": ("manual.txt", b"Relief valve setting 160 bar.", "text/plain")}, data={"category": "manual"})
    assert ok.status_code == 201 and ok.json()["extraction_method"] == "utf8"
    fake_pdf = client.post(f"/api/assets/{aid}/documents", files={"file": ("x.pdf", b"not a pdf", "application/pdf")})
    assert fake_pdf.status_code == 415 and fake_pdf.json()["error"]["code"] == "invalid_file_content"
    exe = client.post(f"/api/assets/{aid}/documents", files={"file": ("x.exe", b"MZ....", "application/octet-stream")})
    assert exe.status_code == 415
    mime = client.post(f"/api/assets/{aid}/documents", files={"file": ("a.png", b"\x89PNG....", "application/pdf")})
    assert mime.status_code == 415 and mime.json()["error"]["code"] == "mime_mismatch"
    traversal = client.post(f"/api/assets/{aid}/documents", files={"file": ("../../etc/passwd.txt", b"hello world", "text/plain")})
    assert traversal.status_code == 201 and "/" not in traversal.json()["filename"]


def test_pdf_and_docx_text_extraction(client, fresh_org):
    reportlab = pytest.importorskip("reportlab")  # noqa: F841
    from docx import Document as Docx
    from reportlab.pdfgen import canvas

    aid = _asset(client, "DOC-2").json()["id"]
    buf = io.BytesIO()
    c = canvas.Canvas(buf)
    c.drawString(72, 720, "Compressor manual: clean the cooler fins monthly.")
    c.save()
    r = client.post(f"/api/assets/{aid}/documents", files={"file": ("m.pdf", buf.getvalue(), "application/pdf")})
    assert r.status_code == 201 and "cooler fins" in r.json()["text_preview"]
    d = Docx()
    d.add_paragraph("Check the belt tension before restarting.")
    b2 = io.BytesIO()
    d.save(b2)
    r2 = client.post(f"/api/assets/{aid}/documents", files={"file": ("w.docx", b2.getvalue(), "application/vnd.openxmlformats-officedocument.wordprocessingml.document")})
    assert r2.status_code == 201 and "belt tension" in r2.json()["text_preview"]


def test_upload_size_limit(client, fresh_org, monkeypatch):
    from app.config import get_settings

    monkeypatch.setattr(get_settings(), "max_upload_mb", 1)
    aid = _asset(client, "BIG-1").json()["id"]
    r = client.post(f"/api/assets/{aid}/documents", files={"file": ("big.txt", b"a" * (1024 * 1024 + 10), "text/plain")})
    assert r.status_code == 413


def test_maintenance_event(client, fresh_org):
    aid = _asset(client, "EV-1").json()["id"]
    r = client.post(f"/api/assets/{aid}/events", json={"occurred_on": "2026-09-01", "event_type": "corrective", "summary": "Replaced seal kit", "downtime_hours": 2})
    assert r.status_code == 201
    assert client.get(f"/api/assets/{aid}").json()["maintenance_history"][0]["summary"] == "Replaced seal kit"
