"""LegacyMind AI evaluation runner.

Runs the golden datasets against the *real* system and writes measured results:

    cd backend
    python -m eval.run_eval                 # uses a throwaway SQLite DB
    python -m eval.run_eval --json out.json --md out.md

Two suites:

1. Extraction (golden_extraction.json): held-out transcripts with hand-labelled
   gold entities and steps -> precision / recall / F1 per entity type,
   procedure-step recall/precision, safety detection.
2. Grounded QA (golden_qa.json): questions over the synthetic NovaTech plant,
   including unanswerable ones -> retrieval recall@k, answer accuracy, refusal
   accuracy, citation accuracy, hallucination rate, safety recall, conflict
   surfacing, groundedness calibration and latency.

Nothing here is hard-coded: every number is computed from system output.
"""

from __future__ import annotations

import argparse
import json
import os
import statistics
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent


def _setup_env() -> None:
    if os.environ.get("EVAL_USE_CURRENT_DB") == "1":
        return
    tmp = Path(tempfile.mkdtemp(prefix="legacymind-eval-"))
    os.environ.setdefault("APP_ENV", "test")
    os.environ["DATABASE_URL"] = f"sqlite:///{tmp / 'eval.db'}"
    os.environ["STORAGE_LOCAL_PATH"] = str(tmp / "storage")
    os.environ.setdefault("LOG_LEVEL", "WARNING")
    os.environ.setdefault("LOG_JSON", "false")


def _match(a: str, b: str, thr: float = 0.6) -> bool:
    from app.ai.text import token_overlap

    a_l, b_l = a.lower().strip(), b.lower().strip()
    if not a_l or not b_l:
        return False
    if a_l in b_l or b_l in a_l:
        return True
    return token_overlap(a, b) >= thr or token_overlap(b, a) >= thr


def _prf(pred: list[str], gold: list[str], thr: float = 0.6) -> tuple[int, int, int]:
    """Return (true positives, n_pred, n_gold) with fuzzy one-to-one matching."""
    used: set[int] = set()
    tp = 0
    for g in gold:
        for i, p in enumerate(pred):
            if i not in used and _match(p, g, thr):
                used.add(i)
                tp += 1
                break
    return tp, len(pred), len(gold)


def _f(tp: int, npred: int, ngold: int) -> dict[str, float]:
    p = tp / npred if npred else (1.0 if not ngold else 0.0)
    r = tp / ngold if ngold else 1.0
    f1 = 2 * p * r / (p + r) if (p + r) else 0.0
    return {"precision": round(p, 3), "recall": round(r, 3), "f1": round(f1, 3), "tp": tp, "pred": npred, "gold": ngold}


# ---------------------------------------------------------------------------
# Extraction
# ---------------------------------------------------------------------------


def run_extraction() -> dict[str, Any]:
    from app.ai.extraction import extract_knowledge

    data = json.loads((HERE / "golden_extraction.json").read_text(encoding="utf-8"))
    totals: dict[str, list[int]] = {k: [0, 0, 0] for k in ("asset_tags", "symptoms", "failure_modes", "components", "tools", "steps")}
    safety_hits = 0
    per_case = []
    method = ""
    for case in data["cases"]:
        ex = extract_knowledge(case["segments"], set(case["assets"]), case["assets"])
        method = ex.method
        pred = {
            "asset_tags": ex.asset_tags,
            "symptoms": [s["name"] for s in ex.symptoms],
            "failure_modes": [f["name"] for f in ex.failure_modes],
            "components": [c["name"] for c in ex.components],
            "tools": [t["name"] for t in ex.tools],
            "steps": [s["text"] for p in ex.procedures for s in p["steps"]],
        }
        row: dict[str, Any] = {"id": case["id"]}
        for k in totals:
            tp, npred, ngold = _prf(pred[k], case["gold"][k], 0.5 if k == "steps" else 0.6)
            totals[k][0] += tp
            totals[k][1] += npred
            totals[k][2] += ngold
            row[k] = f"{tp}/{ngold}"
        ok_safety = len(ex.safety) >= case["gold"]["safety_count"]
        safety_hits += ok_safety
        row["safety_detected"] = ok_safety
        per_case.append(row)
    metrics = {k: _f(*v) for k, v in totals.items()}
    return {
        "method": method,
        "n_cases": len(data["cases"]),
        "entity_metrics": metrics,
        "safety_detection_rate": round(safety_hits / len(data["cases"]), 3),
        "per_case": per_case,
    }


# ---------------------------------------------------------------------------
# Grounded QA
# ---------------------------------------------------------------------------


def run_qa() -> dict[str, Any]:
    from app.ai.answer import answer_question
    from app.ai.retrieval import retrieve
    from app.ai.text import token_overlap
    from app.db import session_factory
    from app.migrate import upgrade_to_head
    from app.models import KnowledgeRecord
    from app.seed.demo_data import seed_demo

    upgrade_to_head()
    db = session_factory()()
    org = seed_demo(db)
    data = json.loads((HERE / "golden_qa.json").read_text(encoding="utf-8"))
    rec_ref = {r.id: r.ref for r in db.query(KnowledgeRecord).filter(KnowledgeRecord.org_id == org.id).all()}

    rows = []
    lat: list[float] = []
    ans_ok = ans_n = ref_ok = ref_n = 0
    retr_hit = retr_n = 0
    cites_total = cites_ok = 0
    steps_total = steps_unsupported = 0
    safety_ok = safety_n = conflict_ok = conflict_n = 0
    answered_unanswerable = 0
    g_ans: list[float] = []
    g_un: list[float] = []
    for case in data["cases"]:
        q = case["question"]
        t0 = time.perf_counter()
        a = answer_question(db, org.id, q)
        lat.append((time.perf_counter() - t0) * 1000)
        res = retrieve(db, org.id, q)
        hit_refs = [rec_ref.get(h.record_id or "", "") for h in res.hits]
        row: dict[str, Any] = {"id": case["id"], "question": q, "status": a["status"], "groundedness": a["groundedness"]["level"],
                               "score": a["groundedness"]["score"], "cited": sorted({e["record_ref"] for e in a["evidence"]})}
        ev_by_id = {e["id"]: e for e in a["evidence"]}
        # hallucination: every generated step must be supported by at least one cited quote
        for st in a["steps"]:
            steps_total += 1
            quotes = [ev_by_id[c]["quote"] for c in st["citations"] if c in ev_by_id]
            if not quotes or max(token_overlap(st["text"], qq) for qq in quotes) < 0.5:
                steps_unsupported += 1
        if case["answerable"]:
            ans_n += 1
            retr_n += 1
            g_ans.append(a["groundedness"]["score"])
            retr = any(r in hit_refs[:8] for r in case["expect_records"])
            retr_hit += retr
            step_text = " ".join(s["text"] for s in a["steps"]).lower()
            correct = (a["status"] == "answered" and (a["machine"] or {}).get("asset_tag") == case["asset"]
                       and all(t.lower() in step_text for t in case["expect_step_terms"]))
            ans_ok += correct
            for e in a["evidence"]:
                cites_total += 1
                cites_ok += e["record_ref"] in case["expect_records"] or e["kind"] == "safety"
            if case.get("expect_safety_terms"):
                safety_n += 1
                stext = " ".join(s["text"] for s in a["safety"]).lower()
                safety_ok += all(t.lower() in stext for t in case["expect_safety_terms"])
            if case.get("expect_conflict"):
                conflict_n += 1
                conflict_ok += bool(a["conflicts"])
            row.update(retrieval_hit=retr, correct=correct)
        else:
            ref_n += 1
            g_un.append(a["groundedness"]["score"])
            refused = a["status"] == "insufficient"
            ref_ok += refused
            answered_unanswerable += not refused
            row.update(correct=refused, reason=case["reason"])
        rows.append(row)
    db.close()

    def pct(n: int, d: int) -> float:
        return round(n / d, 3) if d else 0.0

    return {
        "n_cases": len(data["cases"]), "n_answerable": ans_n, "n_unanswerable": ref_n,
        "retrieval_recall_at_8": pct(retr_hit, retr_n),
        "answer_accuracy": pct(ans_ok, ans_n),
        "refusal_accuracy": pct(ref_ok, ref_n),
        "citation_accuracy": pct(cites_ok, cites_total),
        "unsupported_step_rate": pct(steps_unsupported, steps_total),
        "hallucination_rate": pct(steps_unsupported + answered_unanswerable, steps_total + ref_n),
        "safety_recall": pct(safety_ok, safety_n),
        "conflict_surfacing": pct(conflict_ok, conflict_n),
        "groundedness_mean_answerable": round(statistics.mean(g_ans), 3) if g_ans else None,
        "groundedness_mean_unanswerable": round(statistics.mean(g_un), 3) if g_un else None,
        "latency_ms_p50": round(statistics.median(lat), 1),
        "latency_ms_p95": round(sorted(lat)[max(0, int(len(lat) * 0.95) - 1)], 1),
        "per_case": rows,
    }


def to_markdown(r: dict[str, Any]) -> str:
    ex, qa, env = r["extraction"], r["qa"], r["environment"]
    lines = [
        f"_Measured {env['timestamp']} · LLM: `{env['llm']}` · embeddings: `{env['embedder']}` · database: `{env['database']}`_",
        "",
        "### Grounded question answering",
        "",
        "| Metric | Value | Definition |",
        "|---|---|---|",
        f"| Retrieval recall@8 | {qa['retrieval_recall_at_8']:.0%} | Answerable questions whose expected source record is in the top-8 fused hits |",
        f"| Answer accuracy | {qa['answer_accuracy']:.0%} | Answered, correct machine, and all expected key terms present in the steps |",
        f"| Refusal accuracy | {qa['refusal_accuracy']:.0%} | Unanswerable questions correctly answered with “insufficient verified knowledge” |",
        f"| Citation accuracy | {qa['citation_accuracy']:.0%} | Evidence items that come from the expected source record (or are safety evidence) |",
        f"| Unsupported-step rate | {qa['unsupported_step_rate']:.0%} | Answer steps whose cited quotes do not lexically support them (≥50% token overlap) |",
        f"| Hallucination rate | {qa['hallucination_rate']:.0%} | (Unsupported steps + unanswerable questions that were answered) / (steps + unanswerable questions) |",
        f"| Safety recall | {qa['safety_recall']:.0%} | Answers that include the expected safety warning |",
        f"| Conflict surfacing | {qa['conflict_surfacing']:.0%} | Questions on a conflicted procedure where the conflict is shown |",
        f"| Mean groundedness score | {qa['groundedness_mean_answerable']} vs {qa['groundedness_mean_unanswerable']} | Answerable vs unanswerable questions |",
        f"| Latency p50 / p95 | {qa['latency_ms_p50']} ms / {qa['latency_ms_p95']} ms | End-to-end `answer_question` on the eval machine |",
        "",
        f"{qa['n_cases']} questions ({qa['n_answerable']} answerable, {qa['n_unanswerable']} unanswerable).",
        "",
        "| Case | Question | Result | Groundedness | Cited |",
        "|---|---|---|---|---|",
    ]
    for row in qa["per_case"]:
        lines.append(f"| {row['id']} | {row['question']} | {'✅' if row['correct'] else '❌'} {row['status']} | {row['groundedness']} ({row['score']}) | {', '.join(row['cited']) or '—'} |")
    lines += [
        "",
        f"### Knowledge extraction (`{ex['method']}`, {ex['n_cases']} held-out transcripts)",
        "",
        "| Entity | Precision | Recall | F1 | TP / predicted / gold |",
        "|---|---|---|---|---|",
    ]
    for k, m in ex["entity_metrics"].items():
        lines.append(f"| {k.replace('_', ' ')} | {m['precision']:.2f} | {m['recall']:.2f} | {m['f1']:.2f} | {m['tp']} / {m['pred']} / {m['gold']} |")
    lines += ["", f"Safety statement detected in {ex['safety_detection_rate']:.0%} of transcripts."]
    return "\n".join(lines) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", default=str(HERE / "results.json"))
    ap.add_argument("--md", default=str(HERE / "results.md"))
    ap.add_argument("--suite", choices=["all", "extraction", "qa"], default="all")
    args = ap.parse_args()
    _setup_env()
    sys.path.insert(0, str(HERE.parent))
    from app.ai.embeddings import get_embedder
    from app.ai.llm import provider_label
    from app.config import get_settings

    out: dict[str, Any] = {"environment": {
        "timestamp": time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime()), "llm": provider_label(), "embedder": get_embedder().name,
        "database": get_settings().database_url.split(":", 1)[0],
    }}
    if args.suite in ("all", "extraction"):
        out["extraction"] = run_extraction()
    if args.suite in ("all", "qa"):
        out["qa"] = run_qa()
    Path(args.json).write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
    if args.suite == "all":
        Path(args.md).write_text(to_markdown(out), encoding="utf-8")
    print(json.dumps({k: v for k, v in out.get("qa", {}).items() if k != "per_case"}, indent=2))
    if "extraction" in out:
        print(json.dumps(out["extraction"]["entity_metrics"], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
