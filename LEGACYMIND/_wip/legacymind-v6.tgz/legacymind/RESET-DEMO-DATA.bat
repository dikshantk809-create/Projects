@echo off
title LegacyMind - Reset demo data
cd /d "%~dp0backend"
echo This deletes the local LegacyMind database and uploaded files (demo data is rebuilt on next start).
set /p OK=Type YES to continue: 
if /i not "%OK%"=="YES" exit /b 0
if exist legacymind.db del /q legacymind.db
if exist legacymind.db-wal del /q legacymind.db-wal
if exist legacymind.db-shm del /q legacymind.db-shm
if exist storage rmdir /s /q storage
echo Done. Run START-LEGACYMIND.bat again.
pause
