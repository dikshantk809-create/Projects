import js from "@eslint/js";
import globals from "globals";
import reactHooks from "eslint-plugin-react-hooks";
import tseslint from "typescript-eslint";

export default tseslint.config(
  { ignores: ["dist"] },
  {
    extends: [js.configs.recommended, ...tseslint.configs.recommended],
    files: ["**/*.{ts,tsx}"],
    languageOptions: { ecmaVersion: 2022, globals: globals.browser },
    plugins: { "react-hooks": reactHooks },
    rules: {
      ...reactHooks.configs.recommended.rules,
      "@typescript-eslint/no-explicit-any": "off",
      // An effect must return nothing or a cleanup function. Expression bodies like
      // useEffect(() => el.scrollIntoView()) return whatever the call returns (a Promise in
      // recent Chromium) and crash React on unmount.
      "no-restricted-syntax": ["error", {
        selector: "CallExpression[callee.name='useEffect'] > ArrowFunctionExpression[expression=true] > CallExpression",
        message: "Use a block body in useEffect: the arrow must not return a call's result.",
      }, {
        selector: "CallExpression[callee.name='useEffect'] > ArrowFunctionExpression[expression=true] > ChainExpression",
        message: "Use a block body in useEffect: the arrow must not return a call's result.",
      }],
    },
  },
);
