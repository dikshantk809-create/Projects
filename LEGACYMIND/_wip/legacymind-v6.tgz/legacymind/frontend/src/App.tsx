import { lazy, Suspense, type ReactNode } from "react";
import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import { AppLayout } from "./components/Layout";
import { ErrorState, Loading } from "./components/ui";
import { useAuth } from "./lib/auth";
import { Landing } from "./pages/Landing";
import { Login, Register } from "./pages/Auth";
import { NotFound } from "./pages/NotFound";

const Dashboard = lazy(() => import("./pages/Dashboard"));
const Assets = lazy(() => import("./pages/Assets"));
const AssetDetail = lazy(() => import("./pages/AssetDetail"));
const Capture = lazy(() => import("./pages/Capture"));
const Library = lazy(() => import("./pages/Library"));
const RecordDetail = lazy(() => import("./pages/RecordDetail"));
const Assistant = lazy(() => import("./pages/Assistant"));
const Harvest = lazy(() => import("./pages/Harvest"));
const Graph = lazy(() => import("./pages/Graph"));
const Review = lazy(() => import("./pages/Review"));
const Analytics = lazy(() => import("./pages/Analytics"));
const Admin = lazy(() => import("./pages/Admin"));
const DemoLaunch = lazy(() => import("./pages/DemoLaunch"));
const Execute = lazy(() => import("./pages/Execute"));
const PrintProcedure = lazy(() => import("./pages/PrintProcedure"));

function Protected({ children, perm }: { children: ReactNode; perm?: string }) {
  const { session, loading, error, can, refresh } = useAuth();
  const loc = useLocation();
  if (loading) return <Loading label="Connecting to LegacyMind…" />;
  if (error) return <div className="content"><ErrorState error={error} onRetry={() => void refresh()} /></div>;
  if (!session) return <Navigate to={`/login?next=${encodeURIComponent(loc.pathname + loc.search)}`} replace />;
  if (perm && !can(perm)) {
    return (
      <div className="panel"><div className="empty"><h3>Not available for your role</h3><p>Your role does not include access to this area. Ask your plant administrator if you need it.</p></div></div>
    );
  }
  return <>{children}</>;
}

const page = (el: ReactNode, perm?: string) => (
  <Protected perm={perm}><Suspense fallback={<Loading />}>{el}</Suspense></Protected>
);

export function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/demo" element={<Suspense fallback={<Loading />}><DemoLaunch /></Suspense>} />
      <Route path="/app" element={<Protected><AppLayout /></Protected>}>
        <Route index element={page(<Dashboard />)} />
        <Route path="assets" element={page(<Assets />, "assets:read")} />
        <Route path="assets/:assetId" element={page(<AssetDetail />, "assets:read")} />
        <Route path="capture" element={page(<Capture />, "knowledge:capture")} />
        <Route path="library" element={page(<Library />, "knowledge:read")} />
        <Route path="library/:recordId" element={page(<RecordDetail />, "knowledge:read")} />
        <Route path="assistant" element={page(<Assistant />, "assistant:use")} />
        <Route path="harvest" element={page(<Harvest />, "harvest:run")} />
        <Route path="graph" element={page(<Graph />, "knowledge:read")} />
        <Route path="review" element={page(<Review />, "knowledge:review")} />
        <Route path="analytics" element={page(<Analytics />, "analytics:read")} />
        <Route path="admin" element={page(<Admin />, "users:manage")} />
        <Route path="execute/:procedureId" element={page(<Execute />, "assistant:use")} />
        <Route path="print/procedure/:procedureId" element={page(<PrintProcedure />, "knowledge:read")} />
        <Route path="*" element={<NotFound inApp />} />
      </Route>
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
