import { ApiError, qs, request } from "../lib/api";

function mockFetch(...responses: (Response | Error)[]) {
  const fn = vi.fn();
  responses.forEach((r) => (r instanceof Error ? fn.mockRejectedValueOnce(r) : fn.mockResolvedValueOnce(r)));
  vi.stubGlobal("fetch", fn);
  return fn;
}
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });

afterEach(() => vi.unstubAllGlobals());

describe("api client", () => {
  it("returns parsed JSON", async () => {
    mockFetch(json({ ok: 1 }));
    await expect(request("/api/x")).resolves.toEqual({ ok: 1 });
  });

  it("maps the backend error contract to ApiError with error id", async () => {
    mockFetch(json({ error: { code: "not_found", message: "Asset not found.", error_id: "abc123" } }, 404));
    const err = (await request("/api/x").catch((e) => e)) as ApiError;
    expect(err).toBeInstanceOf(ApiError);
    expect(err.status).toBe(404);
    expect(err.message).toBe("Asset not found.");
    expect(err.errorId).toBe("abc123");
  });

  it("retries idempotent GETs on gateway errors", async () => {
    const f = mockFetch(new Response("", { status: 503 }), json({ ok: true }));
    await expect(request("/api/x", { retries: 1 })).resolves.toEqual({ ok: true });
    expect(f).toHaveBeenCalledTimes(2);
  });

  it("never retries writes", async () => {
    const f = mockFetch(new Response("", { status: 503 }));
    await expect(request("/api/x", { method: "POST", body: {} })).rejects.toBeInstanceOf(ApiError);
    expect(f).toHaveBeenCalledTimes(1);
  });

  it("reports network failures in plain language", async () => {
    mockFetch(new TypeError("Failed to fetch"));
    const err = (await request("/api/x", { retries: 0 }).catch((e) => e)) as ApiError;
    expect(err.code).toBe("network");
    expect(err.message).toMatch(/offline/);
  });

  it("builds query strings without empty values", () => {
    expect(qs({ a: "1", b: "", c: undefined, d: 0 })).toBe("?a=1&d=0");
    expect(qs({})).toBe("");
  });
});
