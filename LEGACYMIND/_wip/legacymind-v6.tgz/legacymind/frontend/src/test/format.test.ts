import { cls, fmtBytes, fmtTs, initials, titleCase } from "../lib/format";

describe("format helpers", () => {
  it("formats timestamps as mm:ss", () => {
    expect(fmtTs(134)).toBe("02:14");
    expect(fmtTs(0)).toBe("00:00");
    expect(fmtTs(null)).toBe("--:--");
  });
  it("formats bytes", () => {
    expect(fmtBytes(512)).toBe("512 B");
    expect(fmtBytes(2048)).toBe("2.0 KB");
    expect(fmtBytes(5 * 1024 * 1024)).toBe("5.0 MB");
  });
  it("misc", () => {
    expect(initials("Rajesh Kumar")).toBe("RK");
    expect(titleCase("pending_review")).toBe("Pending Review");
    expect(cls("a", false, null, "b")).toBe("a b");
  });
});
