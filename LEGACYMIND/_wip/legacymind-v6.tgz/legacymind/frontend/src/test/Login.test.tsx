import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter, Route, Routes } from "react-router-dom";
import { AuthProvider } from "../lib/auth";
import { Login } from "../pages/Auth";

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });

afterEach(() => vi.unstubAllGlobals());

describe("Login", () => {
  it("shows the server's error message on bad credentials", async () => {
    vi.stubGlobal("fetch", vi.fn(async (url: string) => {
      if (url === "/api/auth/me") return json({ error: { code: "unauthorized", message: "Please sign in", error_id: "e1" } }, 401);
      return json({ error: { code: "invalid_credentials", message: "Incorrect email or password.", error_id: "e2" } }, 401);
    }));
    render(<MemoryRouter initialEntries={["/login"]}><AuthProvider><Routes><Route path="/login" element={<Login />} /></Routes></AuthProvider></MemoryRouter>);
    await userEvent.type(screen.getByLabelText("Email"), "a@b.example");
    await userEvent.type(screen.getByLabelText("Password"), "nope");
    await userEvent.click(screen.getByRole("button", { name: /Sign in/ }));
    await waitFor(() => expect(screen.getByRole("alert")).toHaveTextContent("Incorrect email or password."));
  });

  it("signs in and redirects to the requested page", async () => {
    const session = { user: { id: "u", full_name: "Amit Sharma", role: "supervisor" }, organization: { id: "o", name: "N", is_demo: true }, permissions: [] };
    let signedIn = false;
    vi.stubGlobal("fetch", vi.fn(async (url: string) => {
      if (url === "/api/auth/login") { signedIn = true; return json(session); }
      if (url === "/api/auth/me") return signedIn ? json(session) : json({ error: { code: "unauthorized", message: "x", error_id: "e" } }, 401);
      return json({});
    }));
    render(
      <MemoryRouter initialEntries={["/login?next=/app/assets"]}>
        <AuthProvider><Routes><Route path="/login" element={<Login />} /><Route path="/app/assets" element={<div>ASSETS PAGE</div>} /></Routes></AuthProvider>
      </MemoryRouter>,
    );
    await userEvent.type(screen.getByLabelText("Email"), "amit.sharma@novatech.demo");
    await userEvent.type(screen.getByLabelText("Password"), "LegacyMind-Demo-2026");
    await userEvent.click(screen.getByRole("button", { name: /Sign in/ }));
    await waitFor(() => expect(screen.getByText("ASSETS PAGE")).toBeInTheDocument());
  });
});
