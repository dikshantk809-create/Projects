import { answerToSpeech } from "../lib/speech";

describe("answerToSpeech", () => {
  it("reads summary, numbered steps, safety and escalation", () => {
    const text = answerToSpeech({
      status: "answered", summary: "Approved procedure PR-103-01.",
      steps: [{ text: "Stop the pump" }, { text: "Inspect Valve V-03" }],
      safety: [{ text: "High-pressure hydraulic system." }],
      escalation: { required: true, reason: "Supervisor sign-off required." },
    });
    expect(text).toContain("Step 1. Stop the pump.");
    expect(text).toContain("Step 2. Inspect Valve V-03.");
    expect(text).toContain("Safety. High-pressure hydraulic system.");
    expect(text).toContain("Supervisor sign-off required.");
  });
  it("reads only the refusal when evidence is insufficient", () => {
    expect(answerToSpeech({ status: "insufficient", summary: "I could not find sufficient verified plant knowledge.", steps: [], safety: [], escalation: { required: true, reason: "x" } }))
      .toBe("I could not find sufficient verified plant knowledge.");
  });
});
