export function LogoMark({ size = 28 }: { size?: number }) {
  return (
    <svg className="brand-mark" width={size} height={size} viewBox="0 0 32 32" aria-hidden>
      <rect x="0.5" y="0.5" width="31" height="31" rx="7.5" fill="#12161b" stroke="#2c3540" />
      <path d="M9 8v16h15" fill="none" stroke="#35d0ff" strokeWidth="2.6" strokeLinecap="square" />
      <circle cx="20" cy="13" r="3" fill="#35d0ff" />
      <path d="M20 13 L14 19" stroke="#35d0ff" strokeWidth="1.4" opacity="0.6" />
      <circle cx="14" cy="19" r="1.6" fill="#a9b4bf" />
    </svg>
  );
}

export function Brand({ sub = true }: { sub?: boolean }) {
  return (
    <>
      <LogoMark />
      <div>
        <div className="brand-name">LEGACYMIND</div>
        {sub && <div className="brand-sub">Knowledge Intelligence</div>}
      </div>
    </>
  );
}
