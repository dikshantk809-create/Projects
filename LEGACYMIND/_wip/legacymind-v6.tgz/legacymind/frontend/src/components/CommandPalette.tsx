import { BookOpen, ClipboardList, Factory, Search } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, qs } from "../lib/api";
import { cls } from "../lib/format";
import { useDebounced } from "../lib/hooks";
import type { RecordBrief } from "../lib/types";
import { StatusBadge } from "./ui";

interface Results {
  assets: { id: string; asset_tag: string; name: string; location: string; status: string }[];
  records: RecordBrief[];
  procedures: { id: string; ref: string; title: string; status: string; risk_level: string; asset_tag: string | null }[];
}
interface Item { key: string; group: string; icon: JSX.Element; title: string; sub: string; href: string; status?: string }

/** Ctrl/⌘+K global search across machines, knowledge records and procedures. */
export function CommandPalette({ open, onClose }: { open: boolean; onClose: () => void }) {
  const nav = useNavigate();
  const [q, setQ] = useState("");
  const dq = useDebounced(q, 180);
  const [res, setRes] = useState<Results | null>(null);
  const [loading, setLoading] = useState(false);
  const [active, setActive] = useState(0);
  const input = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open) {
      setQ("");
      setRes(null);
      setTimeout(() => input.current?.focus(), 10);
    }
  }, [open]);

  useEffect(() => {
    if (!open || !dq.trim()) {
      setRes(null);
      return;
    }
    const ctrl = new AbortController();
    setLoading(true);
    api.get<Results>(`/api/search${qs({ q: dq.trim() })}`, { signal: ctrl.signal })
      .then((r) => { setRes(r); setActive(0); })
      .catch(() => undefined)
      .finally(() => setLoading(false));
    return () => ctrl.abort();
  }, [dq, open]);

  const items: Item[] = useMemo(() => {
    if (!res) return [];
    return [
      ...res.assets.map((a) => ({ key: `a${a.id}`, group: "Machines", icon: <Factory size={15} />, title: `${a.asset_tag} · ${a.name}`, sub: a.location, href: `/app/assets/${a.asset_tag}`, status: a.status })),
      ...res.procedures.map((p) => ({ key: `p${p.id}`, group: "Procedures", icon: <ClipboardList size={15} />, title: `${p.ref} · ${p.title}`, sub: p.asset_tag ?? "", href: p.status === "approved" ? `/app/execute/${p.id}` : `/app/library?procedure=${p.ref}`, status: p.status })),
      ...res.records.map((r) => ({ key: `r${r.id}`, group: "Knowledge records", icon: <BookOpen size={15} />, title: `${r.ref} · ${r.title}`, sub: `${r.contributor?.full_name ?? ""} ${r.asset ? `· ${r.asset.asset_tag}` : ""}`, href: `/app/library/${r.ref}`, status: r.review_status })),
    ];
  }, [res]);

  if (!open) return null;
  const go = (it: Item) => { onClose(); nav(it.href); };
  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === "Escape") onClose();
    else if (e.key === "ArrowDown") { e.preventDefault(); setActive((a) => Math.min(items.length - 1, a + 1)); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setActive((a) => Math.max(0, a - 1)); }
    else if (e.key === "Enter" && items[active]) go(items[active]!);
    else if (e.key === "Enter" && q.trim()) { onClose(); nav(`/app/assistant?q=${encodeURIComponent(q.trim())}`); }
  };

  let lastGroup = "";
  return (
    <div className="modal-back" style={{ alignItems: "start", paddingTop: "12vh" }} onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="panel modal" role="dialog" aria-label="Search LegacyMind" style={{ width: "min(640px, 100%)" }} onKeyDown={onKey}>
        <div className="search" style={{ padding: 12, borderBottom: "1px solid var(--line)" }}>
          <Search style={{ left: 23, top: 23 }} />
          <input ref={input} className="input" style={{ height: 44, fontSize: 15, paddingLeft: 38 }} placeholder="Search machines, procedures, recordings… (Enter on no match asks the assistant)"
            value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search" />
        </div>
        <div style={{ maxHeight: "55vh", overflow: "auto", padding: 6 }}>
          {!q.trim() && <div className="small faint" style={{ padding: 14 }}>Try “P-103”, “V-03”, “belt”, “LM-1042” or “PR-103”. <span className="mono">↑ ↓</span> to move, <span className="mono">Enter</span> to open, <span className="mono">Esc</span> to close.</div>}
          {q.trim() && loading && !res && <div className="loading"><div className="spinner" /></div>}
          {q.trim() && res && !items.length && <div className="small faint" style={{ padding: 14 }}>No matches. Press Enter to ask the assistant “{q.trim()}”.</div>}
          {items.map((it, i) => {
            const header = it.group !== lastGroup ? it.group : null;
            lastGroup = it.group;
            return (
              <div key={it.key}>
                {header && <div className="nav-label" style={{ padding: "10px 10px 4px" }}>{header}</div>}
                <button className={cls("list-item")} onMouseEnter={() => setActive(i)} onClick={() => go(it)}
                  style={{ width: "100%", border: 0, borderRadius: 6, cursor: "pointer", color: "inherit", textAlign: "left", background: i === active ? "var(--panel-3)" : "transparent", alignItems: "center" }}>
                  <span className="faint">{it.icon}</span>
                  <span style={{ flex: 1, minWidth: 0 }}><div className="ellipsis">{it.title}</div><div className="tiny faint ellipsis">{it.sub}</div></span>
                  {it.status && <StatusBadge status={it.status} />}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
