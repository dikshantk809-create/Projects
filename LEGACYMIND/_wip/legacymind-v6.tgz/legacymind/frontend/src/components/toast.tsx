import { CheckCircle2, XCircle } from "lucide-react";
import { createContext, useCallback, useContext, useState, type ReactNode } from "react";
import type { ApiError } from "../lib/api";

interface Toast { id: number; tone: "ok" | "error"; text: string; ref?: string }
interface ToastCtx { ok: (text: string) => void; error: (e: unknown, fallback?: string) => void }

const Ctx = createContext<ToastCtx | null>(null);
let seq = 0;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);
  const push = useCallback((t: Omit<Toast, "id">) => {
    const id = ++seq;
    setItems((xs) => [...xs.slice(-3), { ...t, id }]);
    setTimeout(() => setItems((xs) => xs.filter((x) => x.id !== id)), t.tone === "error" ? 7000 : 3500);
  }, []);
  const value: ToastCtx = {
    ok: (text) => push({ tone: "ok", text }),
    error: (e, fallback = "Something went wrong.") => {
      const err = e as ApiError;
      push({ tone: "error", text: err?.message || fallback, ref: err?.errorId });
    },
  };
  return (
    <Ctx.Provider value={value}>
      {children}
      <div className="toasts" aria-live="polite">
        {items.map((t) => (
          <div key={t.id} className={`toast ${t.tone}`} role={t.tone === "error" ? "alert" : "status"}>
            {t.tone === "ok" ? <CheckCircle2 /> : <XCircle />}
            <div className="stack-sm" style={{ gap: 2 }}>
              <span>{t.text}</span>
              {t.ref && <span className="ref">Reference: {t.ref}</span>}
            </div>
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

export function useToast(): ToastCtx {
  const c = useContext(Ctx);
  if (!c) throw new Error("useToast outside ToastProvider");
  return c;
}
