import { Component, type ErrorInfo, type ReactNode } from "react";

interface State { error: Error | null; ref: string }

/** Last-resort boundary: never show a stack trace, give the user a reference and a way out. */
export class ErrorBoundary extends Component<{ children: ReactNode }, State> {
  state: State = { error: null, ref: "" };

  static getDerivedStateFromError(error: Error): State {
    return { error, ref: Math.random().toString(16).slice(2, 10) };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("[LegacyMind] UI error", this.state.ref, error, info.componentStack);
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 24 }}>
        <div className="panel" style={{ maxWidth: 480, padding: 28 }}>
          <div className="eyebrow">Interface error</div>
          <h1 style={{ fontSize: 22 }}>This screen failed to load</h1>
          <p className="muted mt-8">Your data is safe. Reload the page to continue. If it keeps happening, report reference <span className="mono">{this.state.ref}</span>.</p>
          <div className="row mt-16">
            <button className="btn primary" onClick={() => window.location.reload()}>Reload</button>
            <a className="btn" href="/app">Go to dashboard</a>
          </div>
        </div>
      </div>
    );
  }
}
