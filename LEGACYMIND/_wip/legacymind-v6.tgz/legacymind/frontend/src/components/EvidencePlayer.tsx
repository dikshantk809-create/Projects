import { FileText, Pause, Play, Volume2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { fmtTs } from "../lib/format";

/**
 * Plays the cited slice of an expert recording.
 *  - Real recordings: streams the audio/video from the API (HTTP range) and plays start→end.
 *  - Synthetic demo records have transcripts but no real audio; we read the cited
 *    transcript segment aloud with the browser's speech synthesis and label it clearly.
 *  - Text/document sources have nothing to play.
 */
export function EvidencePlayer({ recordingId, playable, start, end, quote, synthetic, sourceType }: {
  recordingId: string | null; playable: boolean; start: number | null; end: number | null; quote: string; synthetic: boolean; sourceType: string;
}) {
  const [playing, setPlaying] = useState(false);
  const [pos, setPos] = useState<number | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => () => {
    audioRef.current?.pause();
    if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
  }, []);

  const isMedia = sourceType === "audio" || sourceType === "video" || sourceType === "interview";
  if (!isMedia) {
    return <span className="badge"><FileText />Written source — no recording</span>;
  }

  if (recordingId && playable) {
    const toggle = () => {
      let el = audioRef.current;
      if (!el) {
        el = new Audio(`/api/media/recordings/${recordingId}`);
        audioRef.current = el;
        el.addEventListener("timeupdate", () => {
          setPos(el!.currentTime);
          if (end !== null && el!.currentTime >= end) {
            el!.pause();
            setPlaying(false);
          }
        });
        el.addEventListener("ended", () => setPlaying(false));
        el.addEventListener("error", () => setPlaying(false));
      }
      if (playing) {
        el.pause();
        setPlaying(false);
        return;
      }
      if (start !== null && (el.currentTime < start || (end !== null && el.currentTime >= end))) el.currentTime = start;
      void el.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
    };
    return (
      <button className="btn sm" onClick={toggle} aria-label={playing ? "Pause source" : "Play source"}>
        {playing ? <Pause /> : <Play />}
        {playing ? `Playing ${fmtTs(pos)}` : `Play source ${start !== null ? fmtTs(start) : ""}`}
      </button>
    );
  }

  const canSpeak = typeof window !== "undefined" && "speechSynthesis" in window;
  if (synthetic && canSpeak) {
    const speak = () => {
      const s = window.speechSynthesis;
      if (playing) {
        s.cancel();
        setPlaying(false);
        return;
      }
      s.cancel();
      const u = new SpeechSynthesisUtterance(quote);
      u.rate = 0.98;
      u.onend = () => setPlaying(false);
      u.onerror = () => setPlaying(false);
      setPlaying(true);
      s.speak(u);
    };
    return (
      <span className="row" style={{ gap: 8, flexWrap: "wrap" }}>
        <button className="btn sm" onClick={speak} aria-label="Play synthetic voice of source segment">
          {playing ? <Pause /> : <Volume2 />}
          {playing ? "Stop" : `Play source ${start !== null ? fmtTs(start) : ""}`}
        </button>
        <span className="tiny faint">Synthetic demo: transcript read by browser voice (no real audio exists)</span>
      </span>
    );
  }
  return <span className="badge">Transcript only — audio not stored</span>;
}
