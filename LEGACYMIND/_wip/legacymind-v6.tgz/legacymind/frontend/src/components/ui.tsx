import { AlertTriangle, FlaskConical, Inbox, RefreshCw, X } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import type { ApiError } from "../lib/api";
import { cls, titleCase } from "../lib/format";
import type { GroundLevel } from "../lib/types";

export function Panel({ title, sub, actions, children, className, tight, id }: {
  title?: ReactNode; sub?: ReactNode; actions?: ReactNode; children: ReactNode; className?: string; tight?: boolean; id?: string;
}) {
  return (
    <section className={cls("panel", className)} id={id}>
      {(title || actions) && (
        <header className="panel-head">
          <div className="stack-sm" style={{ gap: 2, minWidth: 0 }}>
            {title && <h2>{title}</h2>}
            {sub && <div className="sub">{sub}</div>}
          </div>
          <div className="spacer" />
          {actions}
        </header>
      )}
      <div className={cls("panel-body", tight && "tight")}>{children}</div>
    </section>
  );
}

export function Stat({ label, value, foot, icon, tone }: { label: string; value: ReactNode; foot?: ReactNode; icon?: ReactNode; tone?: "hl" | "w" }) {
  return (
    <div className={cls("panel stat", tone)}>
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}</div>
      {foot && <div className="stat-foot">{foot}</div>}
      {icon && <div className="tick">{icon}</div>}
    </div>
  );
}

type Tone = "ok" | "warn" | "danger" | "info" | "accent" | "synthetic" | undefined;
export function Badge({ tone, children, title }: { tone?: Tone; children: ReactNode; title?: string }) {
  return <span className={cls("badge", tone)} title={title}>{children}</span>;
}

export function SyntheticBadge() {
  return (
    <Badge tone="synthetic" title="Fictional demo content — not a real industrial record">
      <FlaskConical /> SYNTHETIC DEMO DATA
    </Badge>
  );
}

const STATUS_TONE: Record<string, Tone> = {
  approved: "ok", processed: "ok", operational: "ok", resolved: "ok", completed: "ok",
  pending: "warn", pending_review: "warn", needs_changes: "warn", queued: "info", processing: "accent", degraded: "warn",
  maintenance: "info", needs_transcript: "warn", open: "warn", active: "accent",
  rejected: "danger", failed: "danger", down: "danger", superseded: undefined, decommissioned: undefined, dismissed: undefined,
};
export function StatusBadge({ status }: { status: string }) {
  const label = status === "pending_review" ? "Pending review" : status === "needs_transcript" ? "Needs transcript" : titleCase(status);
  return <Badge tone={STATUS_TONE[status]}>{label}</Badge>;
}

const RISK_TONE: Record<string, Tone> = { low: undefined, medium: "info", high: "warn", critical: "danger" };
export function RiskBadge({ risk }: { risk: string }) {
  return <Badge tone={RISK_TONE[risk]}>{titleCase(risk)} risk</Badge>;
}

const LEVEL_BARS: Record<GroundLevel, number> = { HIGH: 4, MEDIUM: 3, LOW: 2, INSUFFICIENT: 0 };
export function GroundBadge({ level, score }: { level: GroundLevel; score?: number }) {
  const on = LEVEL_BARS[level];
  return (
    <span className={cls("ground", level)} title="Groundedness: how strongly the answer is supported by approved plant evidence">
      <span className="ground-bars" aria-hidden>
        {[0, 1, 2, 3].map((i) => <i key={i} className={i < on ? "on" : ""} />)}
      </span>
      GROUNDEDNESS: {level}
      {score !== undefined && level !== "INSUFFICIENT" && <span style={{ opacity: 0.7 }}>{Math.round(score * 100)}</span>}
    </span>
  );
}

export function Meter({ value, tone }: { value: number; tone?: "warn" | "ok" | "danger" }) {
  const v = Math.max(0, Math.min(100, value));
  return <div className={cls("meter", tone)} role="meter" aria-valuenow={v} aria-valuemin={0} aria-valuemax={100}><span style={{ width: `${v}%` }} /></div>;
}

export function coverageTone(v: number): "ok" | "warn" | "danger" | undefined {
  if (v >= 80) return "ok";
  if (v >= 40) return undefined;
  if (v >= 20) return "warn";
  return "danger";
}

export function Loading({ label = "Loading…" }: { label?: string }) {
  return <div className="loading" role="status"><div className="spinner" />{label}</div>;
}

export function Skeleton({ h = 16, w = "100%" }: { h?: number; w?: number | string }) {
  return <div className="skeleton" style={{ height: h, width: w }} />;
}

export function Empty({ icon, title, children, action }: { icon?: ReactNode; title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="empty">
      {icon ?? <Inbox />}
      <h3>{title}</h3>
      {children && <p style={{ maxWidth: 440 }}>{children}</p>}
      {action}
    </div>
  );
}

export function ErrorState({ error, onRetry }: { error: ApiError | Error | null; onRetry?: () => void }) {
  if (!error) return null;
  const e = error as ApiError;
  return (
    <div className="error-box" role="alert">
      <AlertTriangle />
      <div className="stack-sm" style={{ flex: 1 }}>
        <strong>{e.message || "Something went wrong."}</strong>
        {e.errorId && <span className="mono tiny faint">Reference: {e.errorId}</span>}
      </div>
      {onRetry && <button className="btn sm" onClick={onRetry}><RefreshCw />Retry</button>}
    </div>
  );
}

export function Modal({ title, onClose, children, footer }: { title: string; onClose: () => void; children: ReactNode; footer?: ReactNode }) {
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [onClose]);
  return (
    <div className="modal-back" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="panel modal" role="dialog" aria-modal="true" aria-label={title}>
        <header className="panel-head">
          <h2>{title}</h2>
          <div className="spacer" />
          <button className="btn ghost icon" onClick={onClose} aria-label="Close"><X /></button>
        </header>
        <div className="panel-body">{children}</div>
        {footer && <div className="panel-body row" style={{ borderTop: "1px solid var(--line)", justifyContent: "flex-end" }}>{footer}</div>}
      </div>
    </div>
  );
}

export function Field({ label, hint, error, children, htmlFor }: { label: string; hint?: ReactNode; error?: string; children: ReactNode; htmlFor?: string }) {
  return (
    <div className="field">
      <label htmlFor={htmlFor}>{label}</label>
      {children}
      {error ? <span className="err-text">{error}</span> : hint ? <span className="hint">{hint}</span> : null}
    </div>
  );
}

export function PageHead({ eyebrow, title, children, actions }: { eyebrow?: string; title: string; children?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="page-head">
      <div>
        {eyebrow && <div className="eyebrow">{eyebrow}</div>}
        <h1>{title}</h1>
        {children && <p>{children}</p>}
      </div>
      {actions && <div className="row-wrap">{actions}</div>}
    </div>
  );
}
