import { AlertOctagon, AlertTriangle, BadgeCheck, ClipboardCheck, FileAudio, GitCompareArrows, Info, Mic, Printer, ShieldAlert, ThumbsDown, ThumbsUp, Volume2, VolumeX, Wrench } from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../lib/api";
import { cls, fmtDate } from "../lib/format";
import { answerToSpeech, speak, speechSupported, stopSpeaking } from "../lib/speech";
import type { Answer, ChatMessage, FeedbackOutcome } from "../lib/types";
import { useToast } from "./toast";
import { EvidencePlayer } from "./EvidencePlayer";
import { Badge, GroundBadge, RiskBadge } from "./ui";

export function AnswerCard({ a, messageId, feedback }: { a: Answer; messageId?: string; feedback?: ChatMessage["feedback"] }) {
  const [focus, setFocus] = useState<string | null>(null);
  const insufficient = a.status === "insufficient";
  const jump = (sid: string) => {
    setFocus(sid);
    document.getElementById(`ev-${a.question.length}-${sid}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  return (
    <article className={cls("panel answer rise", insufficient ? "danger" : a.conflicts.length ? "warn" : "accent")} aria-label="Assistant answer">
      <header className="answer-head">
        {insufficient ? <AlertOctagon style={{ color: "var(--danger)" }} /> : <Wrench style={{ color: "var(--accent)" }} />}
        <h3 style={{ fontSize: 15 }}>{insufficient ? "Insufficient verified knowledge" : "Troubleshooting Recommendation"}</h3>
        <div className="spacer" />
        <GroundBadge level={a.groundedness.level} score={a.groundedness.score} />
      </header>

      {(a.machine || a.reported_symptom) && (
        <div className="answer-section">
          <dl className="kv">
            {a.machine && (
              <>
                <dt>Machine</dt>
                <dd><Link to={`/app/assets/${a.machine.asset_tag}`}><span className="tag">{a.machine.asset_tag}</span> {a.machine.name}</Link> <span className="faint small">· {a.machine.location}</span></dd>
              </>
            )}
            {a.reported_symptom && (<><dt>Reported symptom</dt><dd style={{ textTransform: "capitalize" }}>{a.reported_symptom}</dd></>)}
            {a.procedure && (
              <>
                <dt>Procedure</dt>
                <dd className="row-wrap">
                  <span className="mono">{a.procedure.ref}</span> {a.procedure.title} <RiskBadge risk={a.procedure.risk_level} />
                  {a.procedure.status === "approved" && <Badge tone="ok"><BadgeCheck />Approved{a.procedure.approved_by ? ` by ${a.procedure.approved_by}` : ""}</Badge>}
                </dd>
              </>
            )}
          </dl>
        </div>
      )}

      {insufficient ? (
        <div className="answer-section stack">
          <div className="notice danger"><AlertOctagon /><div><strong>{a.summary}</strong><div className="small mt-8">{a.groundedness.explanation}</div></div></div>
          {a.related_other_assets.length > 0 && (
            <div className="small muted">Related knowledge exists for <em>other</em> machines, but LegacyMind will not apply it to this asset without verification.</div>
          )}
        </div>
      ) : (
        <>
          {a.conflicts.map((c) => (
            <div className="answer-section" key={c.id}>
              <div className="conflict-box">
                <div className="row" style={{ color: "var(--warn)", fontWeight: 600 }}><GitCompareArrows size={18} /> KNOWLEDGE CONFLICT</div>
                <p className="small mt-8" style={{ color: "#ffe2a8" }}>Two technicians provided different troubleshooting procedures. LegacyMind will not silently choose one.</p>
                <div className="conflict-sides">
                  {[c.procedure_a, c.procedure_b].map((s, i) => (
                    <div key={s.procedure_id}>
                      <div className="row small"><strong>Procedure {i === 0 ? "A" : "B"}</strong><span className="mono faint">{s.ref}</span><Badge>{s.status.replace("_", " ")}</Badge></div>
                      <div className="tiny faint mt-8">Source: {s.author ?? "Unknown"}</div>
                      <ol className="small mt-8" style={{ paddingLeft: 18, margin: "8px 0 0" }}>{s.first_steps.map((t) => <li key={t}>{t}</li>)}</ol>
                    </div>
                  ))}
                </div>
                <div className="small mt-12"><strong>Recommended action:</strong> {c.recommended_action}</div>
              </div>
            </div>
          ))}

          <div className="answer-section">
            <h4>Recommended checks <span className="faint" style={{ letterSpacing: 0, textTransform: "none", fontFamily: "var(--font)" }}>· {a.summary}</span></h4>
            {a.steps.length ? (
              <ol className="steps">
                {a.steps.map((s) => (
                  <li key={s.order}>
                    <span>{s.text}</span>
                    <span className="row cites" style={{ gap: 4 }}>
                      {s.citations.map((c) => <button key={c} className="cite" onClick={() => jump(c)} aria-label={`Show source ${c}`}>{c}</button>)}
                    </span>
                  </li>
                ))}
              </ol>
            ) : (
              <p className="muted small">No approved step-by-step procedure matches. The relevant approved expert excerpts are quoted in Evidence below.</p>
            )}
            {a.procedure && (a.procedure.tools.length > 0 || a.procedure.parts.length > 0) && (
              <div className="row-wrap mt-12 small">
                {a.procedure.tools.length > 0 && <><span className="faint">Tools:</span>{a.procedure.tools.map((t) => <Badge key={t}>{t}</Badge>)}</>}
                {a.procedure.parts.length > 0 && <><span className="faint">Parts:</span>{a.procedure.parts.map((t) => <Badge key={t}>{t}</Badge>)}</>}
              </div>
            )}
            {a.unsupported_removed > 0 && (
              <div className="notice info mt-12"><Info />{a.unsupported_removed} AI-suggested step(s) were removed because the cited evidence did not support them.</div>
            )}
          </div>
        </>
      )}

      <div className="answer-section">
        <h4><ShieldAlert size={13} /> Safety</h4>
        <div className="stack-sm">
          {a.safety.map((s) => (
            <div key={s.text} className={cls("safety-card", s.severity === "danger" && "danger")}>
              <AlertTriangle />
              <div style={{ flex: 1 }}>{s.text}</div>
              {s.citation && <button className="cite" onClick={() => jump(s.citation!)}>{s.citation}</button>}
            </div>
          ))}
          <div className="notice"><Info /><span>{a.policy_notice}</span></div>
        </div>
      </div>

      {a.escalation.required && (
        <div className="answer-section">
          <div className="notice warn"><ShieldAlert /><div><strong>{insufficient ? "Ask your supervisor" : "Supervisor review required"}</strong><div className="small mt-8">{a.escalation.reason}</div></div></div>
        </div>
      )}

      {a.evidence.length > 0 && (
        <div className="answer-section">
          <h4><FileAudio size={13} /> Evidence</h4>
          <div className="stack-sm">
            {a.evidence.map((ev) => (
              <div key={ev.id} id={`ev-${a.question.length}-${ev.id}`} className={cls("evidence", focus === ev.id && "focus")}>
                <div className="row-wrap small">
                  <span className="cite" style={{ cursor: "default" }}>{ev.id}</span>
                  {ev.source_type === "audio" || ev.source_type === "video" || ev.source_type === "interview" ? <Mic size={14} className="faint" /> : null}
                  <strong>{ev.technician ?? "Unknown contributor"}</strong>
                  {ev.technician_title && <span className="faint">{ev.technician_title}</span>}
                  <span className="faint">· Recorded {fmtDate(ev.recorded_at)}</span>
                  {ev.timestamp && <span className="mono" style={{ color: "var(--accent)" }}>{ev.timestamp}</span>}
                  {ev.is_synthetic && <Badge tone="synthetic">SYNTHETIC</Badge>}
                </div>
                <div className="quote">“{ev.quote}”</div>
                <div className="row-wrap mt-12">
                  <EvidencePlayer recordingId={ev.recording_id} playable={ev.playable_audio} start={ev.start} end={ev.end} quote={ev.quote}
                    synthetic={ev.is_synthetic} sourceType={ev.source_type} />
                  <Link className="btn sm ghost" to={`/app/library/${ev.record_ref}${ev.start !== null ? `?t=${Math.floor(ev.start)}` : ""}`}>Open {ev.record_ref}</Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {!insufficient && <AnswerActions a={a} messageId={messageId} feedback={feedback} />}

      <div className="answer-section row-wrap small">
        <span className="faint">Sources:</span>
        {a.sources.map((s) => (
          <Link key={`${s.type}-${s.ref}`} className="badge" to={s.type === "asset" ? `/app/assets/${s.ref}` : s.type === "procedure" ? `/app/library?procedure=${s.ref}` : `/app/library/${s.ref}`}>
            {s.type === "knowledge_record" ? "Knowledge Record" : s.type === "asset" ? "Asset" : "Procedure"} {s.ref}
          </Link>
        ))}
        <div className="spacer" />
        <span className="tiny faint mono" title={a.groundedness.explanation}>mode: {a.mode} · {a.retrieval.embedder} · {a.retrieval.backend}</span>
      </div>
    </article>
  );
}

const OUTCOME_LABEL: Record<FeedbackOutcome, string> = {
  resolved: "Fixed it", partially: "Partly helped", not_resolved: "Didn't fix it", wrong_answer: "Wrong answer",
};

function AnswerActions({ a, messageId, feedback }: { a: Answer; messageId?: string; feedback?: ChatMessage["feedback"] }) {
  const toast = useToast();
  const [fb, setFb] = useState(feedback?.outcome ?? null);
  const [speaking, setSpeaking] = useState(false);
  const send = async (outcome: FeedbackOutcome) => {
    if (!messageId) return;
    try {
      await api.post(`/api/assistant/messages/${messageId}/feedback`, { outcome });
      setFb(outcome);
      toast.ok(outcome === "resolved" ? "Thanks — logged as resolved" : "Thanks — flagged for the next Knowledge Harvest");
    } catch (e) {
      toast.error(e);
    }
  };
  const toggleSpeak = () => {
    if (speaking) {
      stopSpeaking();
      setSpeaking(false);
    } else if (speak(answerToSpeech(a), () => setSpeaking(false))) setSpeaking(true);
  };
  return (
    <div className="answer-section row-wrap">
      {a.procedure?.status === "approved" && (
        <Link className="btn primary sm" to={`/app/execute/${a.procedure.id}`}><ClipboardCheck />Start guided procedure</Link>
      )}
      {a.procedure && <Link className="btn sm ghost" to={`/app/print/procedure/${a.procedure.id}`}><Printer />Print card</Link>}
      {speechSupported() && <button className="btn sm ghost" onClick={toggleSpeak}>{speaking ? <VolumeX /> : <Volume2 />}{speaking ? "Stop" : "Read aloud"}</button>}
      <div className="spacer" />
      {messageId && (
        <span className="row" style={{ gap: 6 }}>
          <span className="small faint">Did this fix it?</span>
          {fb ? <span className="badge ok">{OUTCOME_LABEL[fb]}</span> : (
            <>
              <button className="btn sm ok" onClick={() => void send("resolved")} aria-label="Yes, it fixed the problem"><ThumbsUp />Yes</button>
              <button className="btn sm" onClick={() => void send("not_resolved")} aria-label="No, it did not fix the problem"><ThumbsDown />No</button>
            </>
          )}
        </span>
      )}
    </div>
  );
}
