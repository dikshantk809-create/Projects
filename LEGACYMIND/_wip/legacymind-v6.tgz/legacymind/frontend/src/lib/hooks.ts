import { useCallback, useEffect, useRef, useState } from "react";
import { ApiError, api } from "./api";

export interface Resource<T> {
  data: T | undefined;
  error: ApiError | null;
  loading: boolean;
  reload: () => Promise<void>;
  setData: (d: T | ((prev: T | undefined) => T)) => void;
}

/** Fetch a GET endpoint with loading/error state; optional polling while `pollWhile(data)` is true. */
export function useApi<T>(path: string | null, opts: { pollMs?: number; pollWhile?: (d: T) => boolean } = {}): Resource<T> {
  const [data, setData] = useState<T | undefined>(undefined);
  const [error, setError] = useState<ApiError | null>(null);
  const [loading, setLoading] = useState<boolean>(!!path);
  const ctrlRef = useRef<AbortController | null>(null);
  const { pollMs, pollWhile } = opts;
  const pollWhileRef = useRef(pollWhile);
  pollWhileRef.current = pollWhile;

  const load = useCallback(
    async (quiet = false) => {
      if (!path) return;
      ctrlRef.current?.abort();
      const ctrl = new AbortController();
      ctrlRef.current = ctrl;
      if (!quiet) setLoading(true);
      try {
        const d = await api.get<T>(path, { signal: ctrl.signal });
        if (!ctrl.signal.aborted) {
          setData(d);
          setError(null);
        }
      } catch (e) {
        if (!ctrl.signal.aborted && (e as ApiError).code !== "aborted") setError(e as ApiError);
      } finally {
        if (!ctrl.signal.aborted) setLoading(false);
      }
    },
    [path],
  );

  useEffect(() => {
    setData(undefined);
    void load();
    return () => ctrlRef.current?.abort();
  }, [load]);

  useEffect(() => {
    if (!pollMs || data === undefined) return;
    if (pollWhileRef.current && !pollWhileRef.current(data)) return;
    const t = setTimeout(() => void load(true), pollMs);
    return () => clearTimeout(t);
  }, [data, pollMs, load]);

  return { data, error, loading, reload: () => load(true), setData: setData as Resource<T>["setData"] };
}

export function useDebounced<T>(value: T, ms = 300): T {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), ms);
    return () => clearTimeout(t);
  }, [value, ms]);
  return v;
}

export function useOnline(): boolean {
  const [online, setOnline] = useState(typeof navigator === "undefined" ? true : navigator.onLine);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);
  return online;
}
