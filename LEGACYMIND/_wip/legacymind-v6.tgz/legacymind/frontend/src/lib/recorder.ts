// Browser capture helpers: MediaRecorder + optional live speech recognition.
// Speech recognition (Web Speech API) is only available in Chromium-based
// browsers; when missing, recordings are still captured and the server (Whisper)
// or a typed transcript supplies the text.

import type { Segment } from "./types";

type SR = {
  continuous: boolean; interimResults: boolean; lang: string;
  onresult: ((e: any) => void) | null; onerror: ((e: any) => void) | null; onend: (() => void) | null;
  start: () => void; stop: () => void; abort: () => void;
};

export function speechRecognitionSupported(): boolean {
  const w = window as any;
  return !!(w.SpeechRecognition || w.webkitSpeechRecognition);
}

export function mediaRecorderSupported(): boolean {
  return typeof window !== "undefined" && "MediaRecorder" in window && !!navigator.mediaDevices?.getUserMedia;
}

export function pickMime(kind: "audio" | "video"): string {
  const opts = kind === "audio"
    ? ["audio/webm;codecs=opus", "audio/webm", "audio/ogg;codecs=opus", "audio/mp4"]
    : ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm", "video/mp4"];
  for (const m of opts) if ((window as any).MediaRecorder?.isTypeSupported?.(m)) return m;
  return "";
}

export class LiveTranscriber {
  private rec: SR | null = null;
  private t0 = 0;
  private uttStart: number | null = null;
  private stopped = false;
  segments: Segment[] = [];
  onUpdate: (finals: Segment[], interim: string) => void = () => {};
  onError: (msg: string) => void = () => {};

  constructor(private lang = "en-IN") {}

  start(t0: number) {
    const w = window as any;
    const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Ctor) return false;
    this.t0 = t0;
    this.stopped = false;
    const rec: SR = new Ctor();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = this.lang;
    rec.onresult = (e: any) => {
      const now = (performance.now() - this.t0) / 1000;
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const r = e.results[i];
        const text = String(r[0]?.transcript ?? "").trim();
        if (this.uttStart === null) this.uttStart = Math.max(0, now - Math.min(8, text.split(/\s+/).length * 0.4));
        if (r.isFinal) {
          if (text) this.segments.push({ start: round(this.uttStart ?? now), end: round(now), text: capitalize(text) });
          this.uttStart = null;
        } else interim += text + " ";
      }
      this.onUpdate([...this.segments], interim.trim());
    };
    rec.onerror = (e: any) => {
      if (e?.error === "no-speech" || e?.error === "aborted") return;
      this.onError(e?.error === "not-allowed" ? "Microphone permission denied for speech recognition." : `Speech recognition error: ${e?.error ?? "unknown"}`);
    };
    // Chrome ends recognition after silences; restart until explicitly stopped.
    rec.onend = () => {
      if (!this.stopped) {
        try { rec.start(); } catch { /* already started */ }
      }
    };
    try {
      rec.start();
    } catch {
      return false;
    }
    this.rec = rec;
    return true;
  }

  stop() {
    this.stopped = true;
    try { this.rec?.stop(); } catch { /* noop */ }
    this.rec = null;
  }
}

const round = (n: number) => Math.round(n * 100) / 100;
const capitalize = (s: string) => (s ? s[0]!.toUpperCase() + s.slice(1) + (/[.!?]$/.test(s) ? "" : ".") : s);
