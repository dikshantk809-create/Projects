// Minimal, typed API client. Same-origin `/api` + httpOnly session cookie;
// every failure becomes an ApiError with a user-friendly message and error ID.

import type { ApiErrorBody } from "./types";

export class ApiError extends Error {
  status: number;
  code: string;
  errorId?: string;
  details?: unknown;
  constructor(status: number, code: string, message: string, errorId?: string, details?: unknown) {
    super(message);
    this.status = status;
    this.code = code;
    this.errorId = errorId;
    this.details = details;
  }
}

type Json = Record<string, unknown> | unknown[];

const DEFAULT_TIMEOUT = 30_000;
let unauthorizedHandler: (() => void) | null = null;
export function onUnauthorized(fn: () => void) {
  unauthorizedHandler = fn;
}

async function parseError(res: Response): Promise<ApiError> {
  let body: Partial<ApiErrorBody> | null = null;
  try {
    body = (await res.json()) as ApiErrorBody;
  } catch {
    /* non-JSON error (proxy, gateway) */
  }
  const e = body?.error;
  if (e) return new ApiError(res.status, e.code, e.message, e.error_id, e.details);
  const generic: Record<number, string> = {
    413: "That upload is too large.",
    429: "Too many requests — please wait a moment and try again.",
    502: "The LegacyMind server is unreachable right now.",
    503: "The LegacyMind server is temporarily unavailable.",
    504: "The server took too long to respond.",
  };
  return new ApiError(res.status, "http_error", generic[res.status] ?? `Request failed (${res.status}).`);
}

export interface RequestOpts {
  method?: string;
  body?: Json | FormData;
  timeout?: number;
  retries?: number;
  signal?: AbortSignal;
}

export async function request<T>(path: string, opts: RequestOpts = {}): Promise<T> {
  const { method = "GET", body, timeout = DEFAULT_TIMEOUT, signal } = opts;
  // Idempotent reads are retried on network errors / 502-504; writes never are.
  const retries = opts.retries ?? (method === "GET" ? 2 : 0);
  const headers: Record<string, string> = { "X-Requested-With": "legacymind" };
  let payload: BodyInit | undefined;
  if (body instanceof FormData) payload = body;
  else if (body !== undefined) {
    headers["Content-Type"] = "application/json";
    payload = JSON.stringify(body);
  }

  for (let attempt = 0; ; attempt++) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeout);
    const onAbort = () => ctrl.abort();
    signal?.addEventListener("abort", onAbort);
    try {
      const res = await fetch(path, { method, headers, body: payload, credentials: "same-origin", signal: ctrl.signal });
      if (res.ok) {
        if (res.status === 204) return undefined as T;
        const ct = res.headers.get("content-type") ?? "";
        return (ct.includes("application/json") ? await res.json() : await res.text()) as T;
      }
      if ([502, 503, 504].includes(res.status) && attempt < retries) {
        await sleep(400 * 2 ** attempt);
        continue;
      }
      const err = await parseError(res);
      if (res.status === 401 && !path.startsWith("/api/auth/")) unauthorizedHandler?.();
      throw err;
    } catch (e) {
      if (e instanceof ApiError) throw e;
      if (signal?.aborted) throw new ApiError(0, "aborted", "Request cancelled.");
      if (attempt < retries) {
        await sleep(400 * 2 ** attempt);
        continue;
      }
      const timedOut = (e as Error)?.name === "AbortError";
      throw new ApiError(
        0,
        timedOut ? "timeout" : "network",
        timedOut ? "The request timed out. Check your connection and try again." : "Cannot reach LegacyMind. You may be offline.",
      );
    } finally {
      clearTimeout(timer);
      signal?.removeEventListener("abort", onAbort);
    }
  }
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export const api = {
  get: <T>(p: string, o?: RequestOpts) => request<T>(p, { ...o, method: "GET" }),
  post: <T>(p: string, body?: Json | FormData, o?: RequestOpts) => request<T>(p, { ...o, method: "POST", body }),
  put: <T>(p: string, body?: Json, o?: RequestOpts) => request<T>(p, { ...o, method: "PUT", body }),
  patch: <T>(p: string, body?: Json, o?: RequestOpts) => request<T>(p, { ...o, method: "PATCH", body }),
  del: <T>(p: string, o?: RequestOpts) => request<T>(p, { ...o, method: "DELETE" }),
};

export function qs(params: Record<string, string | number | boolean | null | undefined>): string {
  const u = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== "") u.set(k, String(v));
  const s = u.toString();
  return s ? `?${s}` : "";
}
