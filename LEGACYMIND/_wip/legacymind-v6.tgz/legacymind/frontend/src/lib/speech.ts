// Text-to-speech for hands-free use on the shop floor (Web Speech API, runs in the browser).

export function speechSupported(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

export function speak(text: string, onEnd?: () => void): boolean {
  if (!speechSupported() || !text.trim()) return false;
  const s = window.speechSynthesis;
  s.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.rate = 1;
  u.lang = "en-IN";
  u.onend = () => onEnd?.();
  u.onerror = () => onEnd?.();
  s.speak(u);
  return true;
}

export function stopSpeaking(): void {
  if (speechSupported()) window.speechSynthesis.cancel();
}

/** A spoken version of a grounded answer: summary, steps, then safety. */
export function answerToSpeech(a: { status: string; summary: string; steps: { text: string }[]; safety: { text: string }[]; escalation: { required: boolean; reason: string } }): string {
  if (a.status !== "answered") return a.summary;
  const parts = [a.summary];
  a.steps.forEach((s, i) => parts.push(`Step ${i + 1}. ${s.text}.`));
  if (a.safety.length) parts.push(`Safety. ${a.safety.map((s) => s.text).join(" ")}`);
  if (a.escalation.required) parts.push(`Note. ${a.escalation.reason}`);
  return parts.join(" ");
}
