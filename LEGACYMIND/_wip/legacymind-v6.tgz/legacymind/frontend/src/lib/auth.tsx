import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { ApiError, api, onUnauthorized } from "./api";
import type { Session } from "./types";

interface AuthCtx {
  session: Session | null;
  loading: boolean;
  error: ApiError | null;
  can: (perm: string) => boolean;
  login: (email: string, password: string) => Promise<Session>;
  register: (body: { organization_name: string; plant_name: string; full_name: string; email: string; password: string }) => Promise<Session>;
  launchDemo: (persona: string) => Promise<Session>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
}

const Ctx = createContext<AuthCtx | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<ApiError | null>(null);

  const refresh = useCallback(async () => {
    try {
      const s = await api.get<Session>("/api/auth/me", { retries: 1 });
      setSession(s);
      setError(null);
    } catch (e) {
      const err = e as ApiError;
      setSession(null);
      // 401 simply means "not signed in"; anything else is a real problem worth showing.
      setError(err.status === 401 ? null : err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
    onUnauthorized(() => setSession(null));
  }, [refresh]);

  const afterAuth = useCallback(async () => {
    const s = await api.get<Session>("/api/auth/me");
    setSession(s);
    return s;
  }, []);

  const value = useMemo<AuthCtx>(
    () => ({
      session,
      loading,
      error,
      can: (perm) => !!session?.permissions?.includes(perm),
      login: async (email, password) => {
        await api.post("/api/auth/login", { email, password });
        return afterAuth();
      },
      register: async (body) => {
        await api.post("/api/auth/register", body);
        return afterAuth();
      },
      launchDemo: async (persona) => {
        await api.post(`/api/demo/launch?persona=${encodeURIComponent(persona)}`, undefined, { timeout: 90_000 });
        return afterAuth();
      },
      logout: async () => {
        try {
          await api.post("/api/auth/logout");
        } finally {
          setSession(null);
        }
      },
      refresh,
    }),
    [session, loading, error, afterAuth, refresh],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthCtx {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAuth outside AuthProvider");
  return c;
}
