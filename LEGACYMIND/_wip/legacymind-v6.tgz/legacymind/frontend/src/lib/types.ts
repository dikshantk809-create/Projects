// Shapes returned by the LegacyMind API (see backend/app/serializers.py & ai/answer.py)

export type Role = "admin" | "supervisor" | "technician" | "junior_technician";

export interface User {
  id: string;
  email: string;
  full_name: string;
  title: string;
  role: Role;
  department_id: string | null;
  is_active: boolean;
  years_experience: number | null;
  last_login_at: string | null;
  created_at: string | null;
}

export interface Session {
  user: User;
  organization: { id: string; name: string; is_demo: boolean } | null;
  permissions?: string[];
}

export interface AssetRef { id: string; asset_tag: string; name: string }

export interface Asset extends AssetRef {
  machine_type: string;
  manufacturer: string;
  model: string;
  serial_number: string;
  department: string | null;
  department_id: string | null;
  plant_id: string | null;
  location: string;
  installed_on: string | null;
  status: "operational" | "degraded" | "down" | "maintenance" | "decommissioned";
  criticality: "low" | "medium" | "high" | "critical";
  description: string;
  is_synthetic: boolean;
  created_at: string | null;
  knowledge_count?: number;
  approved_procedures?: number;
}

export interface UserBrief { id: string; full_name: string; title: string; role: Role }

export interface Segment { start: number | null; end: number | null; text: string; speaker?: string }

export interface Stage { name: string; status: "pending" | "done" | "skipped" | "failed" | "running"; detail: string; at?: string }

export interface RecordingOut {
  id: string; kind: "audio" | "video"; filename: string; mime_type: string; size_bytes: number;
  duration_s: number | null; has_file: boolean; is_synthetic: boolean; url: string | null;
}

export interface DocumentOut {
  id: string; kind: string; category: string; filename: string; mime_type: string; size_bytes: number;
  extraction_method: string; text_preview: string; url: string; created_at: string | null;
}

export interface RecordBrief {
  id: string; ref: string; title: string; source_type: string; asset: AssetRef | null; contributor: UserBrief | null;
  processing_status: "queued" | "processing" | "processed" | "failed" | "needs_transcript";
  review_status: "pending" | "approved" | "rejected" | "needs_changes";
  recorded_at: string | null; created_at: string | null; is_synthetic: boolean; summary: string;
  ai_version: string; transcript_source: string;
}

export interface ExtractionItem { name?: string; text?: string; quote: string; start: number | null; end: number | null; confidence: number; [k: string]: unknown }

export interface Extraction {
  method: string;
  asset_tags: string[];
  components: ExtractionItem[];
  symptoms: ExtractionItem[];
  failure_modes: ExtractionItem[];
  causes: ExtractionItem[];
  procedures: { title: string; symptoms: string[]; steps: ExtractionItem[]; confidence: number }[];
  tools: ExtractionItem[];
  parts: ExtractionItem[];
  safety: ExtractionItem[];
  misconceptions: ExtractionItem[];
  summary: string;
  dropped_unverified: number;
}

export interface Step {
  order: number; text: string; component?: string; confidence?: number;
  source?: { record_id: string | null; start: number | null; end: number | null; quote: string; edited_by?: string };
}

export interface SafetyOut { id: string; text: string; hazard_type: string; severity: "info" | "warning" | "danger"; status: string; procedure_id: string | null; record_id: string | null; asset_id: string | null }

export interface Procedure {
  id: string; ref: string; title: string; asset: AssetRef | null; failure_mode: { id: string; name: string } | null;
  record_id: string | null; symptoms: string[]; steps: Step[]; tools: string[]; parts: string[];
  risk_level: "low" | "medium" | "high" | "critical"; requires_supervisor: boolean;
  status: "draft" | "pending_review" | "approved" | "rejected" | "superseded" | "needs_changes";
  confidence: number; author: UserBrief | null; approved_by: UserBrief | null; approved_at: string | null;
  version: number; ai_version: string; is_synthetic: boolean; created_at: string | null;
  safety_warnings?: SafetyOut[];
}

export interface RecordFull extends RecordBrief {
  transcript: string; segments: Segment[]; processing_stages: Stage[]; processing_error: string | null;
  extraction: Partial<Extraction>; notes: string; recordings: RecordingOut[]; documents: DocumentOut[];
  procedures: Procedure[]; safety_warnings: SafetyOut[];
}

export interface Evidence {
  id: string; kind: string; record_id: string; record_ref: string; title: string; source_type: string;
  technician: string | null; technician_title: string | null; recorded_at: string; start: number | null; end: number | null;
  timestamp: string | null; quote: string; recording_id: string | null; playable_audio: boolean; is_synthetic: boolean;
  review_status: string; ai_version: string;
}

export type GroundLevel = "HIGH" | "MEDIUM" | "LOW" | "INSUFFICIENT";

export interface ConflictSide { procedure_id: string; ref: string; title: string; status: string; author: string | null; first_steps: string[] }

export interface Answer {
  status: "answered" | "insufficient";
  mode: string;
  question: string;
  machine: { id: string; asset_tag: string; name: string; location: string; status: string; criticality: string } | null;
  reported_symptom: string | null;
  summary: string;
  steps: { order: number; text: string; citations: string[] }[];
  safety: { text: string; severity: string; hazard_type: string; citation: string | null }[];
  policy_notice: string;
  evidence: Evidence[];
  sources: { type: string; ref: string; id: string }[];
  procedure: { id: string; ref: string; title: string; risk_level: string; requires_supervisor: boolean; status: string; approved_by: string | null; approved_at: string | null; tools: string[]; parts: string[] } | null;
  groundedness: { level: GroundLevel; score: number; components: Record<string, number>; explanation: string };
  conflicts: { id: string; type: string; description: string; procedure_a: ConflictSide; procedure_b: ConflictSide; recommended_action: string }[];
  escalation: { required: boolean; reason: string; message: string };
  related_other_assets: { chunk_type: string; asset_id: string; excerpt: string }[];
  unsupported_removed: number;
  retrieval: { backend: string; embedder: string; hits: { chunk_id: string; type: string; fused: number; vector: number; bm25: number; graph: number }[] };
}

export type FeedbackOutcome = "resolved" | "partially" | "not_resolved" | "wrong_answer";
export interface ChatMessage { id: string; role: "user" | "assistant"; content: string; answer: Answer | null; groundedness: GroundLevel | null; escalated: boolean; created_at: string | null; feedback?: { outcome: FeedbackOutcome; comment: string } | null }

export interface Conflict {
  id: string; asset_id: string | null; conflict_type: string; description: string; status: "open" | "resolved" | "dismissed";
  resolution: string; preferred_procedure_id: string | null; procedure_a: Procedure; procedure_b: Procedure;
  detected_by: string; created_at: string | null; resolved_at: string | null;
}

export interface CoverageRow { asset_id: string; asset_tag: string; name: string; criticality: string; coverage: number; approved_procedures: number; failure_modes: number; safety_warnings: number; approved_sources: number }

export interface RiskAsset { asset_id: string; asset_tag: string; name: string; criticality: string; experts: { id: string; name: string; title: string; years_experience: number | null; records: number }[]; expert_count: number; risk: "critical" | "high" | "medium" | "low"; reason: string }
export interface RiskExpert { id: string; name: string; title: string; years_experience: number | null; sole_source_assets: string[]; senior: boolean }

export interface Summary {
  knowledge_risk: { assets_at_risk: number; assets: RiskAsset[]; single_source_experts: RiskExpert[] };
  totals: { assets: number; knowledge_records: number; approved_procedures: number; pending_reviews: number; open_conflicts: number; safety_warnings: number };
  coverage: CoverageRow[];
  average_coverage: number;
  alerts: { severity: "danger" | "warning" | "info"; kind: string; message: string; link: string }[];
  recent_activity: { id: string; actor: string; action: string; entity_type: string; entity_id: string; at: string | null }[];
}

export interface HarvestTurn { role: "agent" | "technician"; text: string; category?: string; reason?: string; source?: string; t: number }
export interface CoverageItem { category: string; label: string; percent: number }
export interface HarvestSession {
  id: string; status: "active" | "completed" | "abandoned"; agent_mode: string; asset: AssetRef; turns: HarvestTurn[];
  coverage: CoverageItem[]; gaps: string[]; current_question: HarvestTurn & { id?: string } | null; record_id: string | null;
  created_at: string | null; extracted_from_answer?: Record<string, unknown>; complete?: boolean; record_ref?: string;
}

export interface GraphNode { id: string; type: "asset" | "component" | "failure_mode" | "symptom" | "procedure" | "safety" | "record" | "technician"; label: string; [k: string]: unknown }
export interface GraphEdge { source: string; target: string; type: string }
export interface GraphData { nodes: GraphNode[]; edges: GraphEdge[]; backend: string; neo4j_configured: boolean }

export interface SystemStatus {
  app_version: string; environment: string;
  llm: { configured: boolean; provider: string; mode: string };
  embeddings: { provider: string };
  transcription: { server: boolean; provider: string; browser_fallback: string };
  ocr: { available: boolean };
  vector_backend: string;
  graph: { primary: string; neo4j_configured: boolean };
  storage: string; demo_mode: boolean; config_problems: string[];
}

export interface ApiErrorBody { error: { code: string; message: string; error_id: string; request_id?: string; details?: unknown } }
