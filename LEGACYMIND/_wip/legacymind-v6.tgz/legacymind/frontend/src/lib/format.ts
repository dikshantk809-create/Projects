export function fmtTs(t: number | null | undefined): string {
  if (t === null || t === undefined || Number.isNaN(t)) return "--:--";
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function fmtDate(iso: string | null | undefined, withTime = false): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    ...(withTime ? { hour: "2-digit", minute: "2-digit" } : {}),
  });
}

export function timeAgo(iso: string | null | undefined): string {
  if (!iso) return "";
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 60) return "just now";
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  if (diff < 86400 * 30) return `${Math.floor(diff / 86400)}d ago`;
  return fmtDate(iso);
}

export function fmtBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

export function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]!.toUpperCase())
    .join("");
}

export const ROLE_LABEL: Record<string, string> = {
  admin: "Plant Administrator",
  supervisor: "Maintenance Supervisor",
  technician: "Technician",
  junior_technician: "Junior Technician",
};

export const STAGE_LABEL: Record<string, string> = {
  preprocessing: "Preprocessing",
  transcription: "Speech transcription",
  entity_extraction: "Entity extraction",
  procedure_extraction: "Procedure extraction",
  failure_mode_extraction: "Failure-mode extraction",
  safety_extraction: "Safety extraction",
  machine_mapping: "Machine mapping",
  knowledge_structuring: "Knowledge structuring",
  indexing: "Vector + keyword indexing",
  conflict_detection: "Conflict detection",
};

export const SOURCE_LABEL: Record<string, string> = {
  audio: "Audio recording",
  video: "Video recording",
  image: "Images",
  document: "Document",
  text: "Text notes",
  interview: "Knowledge Harvest interview",
};

export function titleCase(s: string): string {
  return s.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

export function cls(...parts: (string | false | null | undefined)[]): string {
  return parts.filter(Boolean).join(" ");
}
