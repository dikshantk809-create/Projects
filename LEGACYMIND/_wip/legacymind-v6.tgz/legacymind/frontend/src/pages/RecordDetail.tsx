import { AlertTriangle, Check, CheckCircle2, CircleDashed, FileText, Loader2, RefreshCw, SkipForward, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { ProcedureCard } from "../components/ProcedureCard";
import { useToast } from "../components/toast";
import { Badge, Empty, ErrorState, Loading, PageHead, Panel, StatusBadge, SyntheticBadge } from "../components/ui";
import { api } from "../lib/api";
import { useAuth } from "../lib/auth";
import { SOURCE_LABEL, STAGE_LABEL, cls, fmtBytes, fmtDate, fmtTs, titleCase } from "../lib/format";
import { useApi } from "../lib/hooks";
import type { ExtractionItem, RecordFull, Segment, Stage } from "../lib/types";

const PROCESSING = ["queued", "processing"];
type Tab = "transcript" | "extraction" | "procedures" | "sources";

export default function RecordDetail() {
  const { recordId = "" } = useParams();
  const [params] = useSearchParams();
  const { can } = useAuth();
  const toast = useToast();
  const { data: r, error, loading, reload } = useApi<RecordFull>(`/api/knowledge/records/${encodeURIComponent(recordId)}`, {
    pollMs: 1500, pollWhile: (d) => PROCESSING.includes(d.processing_status),
  });
  const [tab, setTab] = useState<Tab>((params.get("tab") as Tab) || "transcript");
  const [busy, setBusy] = useState(false);
  const t = params.get("t") ? Number(params.get("t")) : null;

  if (loading && !r) return <Loading />;
  if (error) return <ErrorState error={error} onRetry={() => void reload()} />;
  if (!r) return null;

  const decide = async (decision: "approve" | "reject") => {
    const comment = decision === "reject" ? window.prompt("Reason for rejecting this record?") ?? "" : "Approved after review.";
    if (decision === "reject" && !comment.trim()) return;
    setBusy(true);
    try {
      await api.post(`/api/reviews/records/${r.id}`, { decision, comment });
      toast.ok(decision === "approve" ? `${r.ref} approved — now citable by the assistant` : `${r.ref} rejected`);
      await reload();
    } catch (e) {
      toast.error(e);
    } finally {
      setBusy(false);
    }
  };
  const reprocess = async () => {
    setBusy(true);
    try {
      await api.post(`/api/knowledge/records/${r.id}/reprocess`);
      toast.ok("Reprocessing started");
      await reload();
    } catch (e) {
      toast.error(e);
    } finally {
      setBusy(false);
    }
  };

  const ex = r.extraction ?? {};
  const processing = PROCESSING.includes(r.processing_status);
  return (
    <div className="stack" style={{ gap: 20 }}>
      <PageHead eyebrow={`${r.ref} · ${SOURCE_LABEL[r.source_type] ?? r.source_type}`} title={r.title}
        actions={
          <>
            {can("knowledge:review") && r.review_status !== "approved" && r.processing_status === "processed" && (
              <><button className="btn ok" disabled={busy} onClick={() => void decide("approve")}><Check />Approve record</button><button className="btn bad" disabled={busy} onClick={() => void decide("reject")}><X />Reject</button></>
            )}
            {can("knowledge:review") && !processing && <button className="btn" disabled={busy} onClick={() => void reprocess()}><RefreshCw />Reprocess</button>}
          </>
        }>
        <span className="row-wrap" style={{ marginTop: 4 }}>
          {r.asset ? <Link to={`/app/assets/${r.asset.asset_tag}`}><span className="tag">{r.asset.asset_tag}</span> {r.asset.name}</Link> : <Badge tone="warn">No machine mapped</Badge>}
          <span className="faint">· {r.contributor?.full_name} ({r.contributor?.title}) · {fmtDate(r.recorded_at, true)}</span>
          <StatusBadge status={r.processing_status} /><StatusBadge status={r.review_status} />
          {r.is_synthetic && <SyntheticBadge />}
        </span>
      </PageHead>

      {r.processing_status === "failed" && <div className="notice danger"><AlertTriangle />Processing failed: {r.processing_error}. A supervisor can reprocess the record.</div>}
      {r.processing_status === "needs_transcript" && <TranscriptForm id={r.id} onSaved={() => void reload()} />}

      <div className="split">
        <div>
          <div className="tabs" role="tablist">
            {([["transcript", "Transcript", r.segments.length], ["extraction", "AI extraction", (ex.symptoms?.length ?? 0) + (ex.components?.length ?? 0) + (ex.safety?.length ?? 0)], ["procedures", "Procedure cards", r.procedures.length], ["sources", "Source files", r.recordings.length + r.documents.length]] as [Tab, string, number][]).map(([k, l, n]) => (
              <button key={k} role="tab" aria-selected={tab === k} className={cls("tab", tab === k && "active")} onClick={() => setTab(k)}>{l}<span className="n">{n}</span></button>
            ))}
          </div>
          {tab === "transcript" && <Transcript r={r} highlight={t} />}
          {tab === "extraction" && <ExtractionView r={r} />}
          {tab === "procedures" && (r.procedures.length ? <div className="stack">{r.procedures.map((p, i) => <ProcedureCard key={p.id} p={p} defaultOpen={i === 0} />)}</div> : <Panel><Empty title={processing ? "Processing…" : "No procedure extracted"}>{processing ? "Procedure cards appear here when extraction finishes." : "The AI did not find step-by-step instructions in this record."}</Empty></Panel>)}
          {tab === "sources" && <Sources r={r} />}
        </div>
        <div className="stack">
          <Panel title="AI processing pipeline" sub={r.ai_version ? <>Extractor: <span className="mono">{r.ai_version}</span></> : undefined}>
            <Pipeline stages={r.processing_stages} status={r.processing_status} />
          </Panel>
          <Panel title="Traceability">
            <dl className="kv small">
              <dt>Knowledge record</dt><dd className="mono">{r.ref}</dd>
              <dt>Technician</dt><dd>{r.contributor?.full_name ?? "—"}</dd>
              <dt>Recorded</dt><dd>{fmtDate(r.recorded_at, true)}</dd>
              <dt>Asset</dt><dd>{r.asset?.asset_tag ?? "—"}</dd>
              <dt>Transcript source</dt><dd className="mono">{r.transcript_source || "—"}</dd>
              <dt>AI version</dt><dd className="mono">{r.ai_version || "—"}</dd>
              <dt>Approval</dt><dd><StatusBadge status={r.review_status} /></dd>
            </dl>
          </Panel>
        </div>
      </div>
    </div>
  );
}

function Pipeline({ stages, status }: { stages: Stage[]; status: string }) {
  const names = Object.keys(STAGE_LABEL);
  const byName = new Map(stages.map((s) => [s.name, s]));
  const firstPending = names.find((n) => !byName.get(n) || byName.get(n)!.status === "pending");
  return (
    <div className="pipeline">
      {names.map((n) => {
        const s = byName.get(n);
        let st: Stage["status"] = s?.status ?? "pending";
        if (status === "processing" && n === firstPending) st = "running";
        if (status === "failed" && n === firstPending) st = "failed";
        return (
          <div key={n} className={cls("stage", st)}>
            <div className="stage-icon">{st === "done" ? <Check /> : st === "skipped" ? <SkipForward /> : st === "failed" ? <X /> : st === "running" ? null : <CircleDashed style={{ opacity: 0.4 }} />}</div>
            <div>
              <div className="stage-name">{STAGE_LABEL[n]}</div>
              {s?.detail && <div className="stage-detail">{s.detail}</div>}
            </div>
          </div>
        );
      })}
      {status === "queued" && <div className="small faint row"><Loader2 size={14} className="spin" />Queued…</div>}
      {status === "processed" && <div className="small row" style={{ color: "var(--ok)" }}><CheckCircle2 size={14} />Processed — awaiting supervisor review</div>}
    </div>
  );
}

function Transcript({ r, highlight }: { r: RecordFull; highlight: number | null }) {
  const audio = useRef<HTMLAudioElement>(null);
  const rec = r.recordings.find((x) => x.has_file);
  const [now, setNow] = useState<number | null>(null);
  const ents = useMemo(() => entityTerms(r), [r]);
  useEffect(() => {
    if (highlight === null) return;
    const el = document.querySelector(`[data-start="${highlightIndex(r.segments, highlight)}"]`);
    el?.scrollIntoView({ block: "center" });
  }, [highlight, r.segments]);

  if (!r.segments.length) {
    return <Panel><Empty icon={<FileText />} title="No transcript yet">{PROCESSING.includes(r.processing_status) ? "Transcription is running…" : "No text has been captured for this record."}</Empty></Panel>;
  }
  const seek = (s: Segment) => {
    if (!audio.current || s.start === null) return;
    audio.current.currentTime = s.start;
    void audio.current.play();
  };
  const hi = highlight !== null ? highlightIndex(r.segments, highlight) : -1;
  return (
    <Panel tight title={r.source_type === "interview" ? "Interview transcript" : "Transcript"} sub={<span className="row-wrap"><span><mark className="ent symptom">symptom</mark></span><span><mark className="ent component">component</mark></span><span><mark className="ent safety">safety</mark></span></span>}
      actions={rec ? <audio ref={audio} src={`/api/media/recordings/${rec.id}`} controls preload="metadata" onTimeUpdate={(e) => setNow(e.currentTarget.currentTime)} style={{ height: 32, maxWidth: 300 }} /> : r.is_synthetic ? <Badge tone="synthetic">Synthetic transcript · no audio</Badge> : undefined}>
      <div className="transcript" style={{ padding: 8 }}>
        {r.segments.map((s, i) => {
          const active = now !== null && s.start !== null && s.end !== null && now >= s.start && now < s.end;
          return (
            <div key={i} data-start={i} className={cls("seg-line", (active || i === hi) && "hl")} onClick={() => seek(s)} style={{ cursor: rec ? "pointer" : "default" }}>
              <span className="ts">{s.start !== null ? fmtTs(s.start) : "¶"}{s.speaker && <div className="who">{s.speaker === "technician" ? "Tech" : "AI"}</div>}</span>
              <span>{highlightEntities(s.text, ents)}</span>
            </div>
          );
        })}
      </div>
    </Panel>
  );
}

function highlightIndex(segs: Segment[], t: number): number {
  const i = segs.findIndex((s) => s.start !== null && s.end !== null && t >= s.start && t < s.end);
  return i >= 0 ? i : segs.findIndex((s) => s.start !== null && s.start >= t);
}

function entityTerms(r: RecordFull): { term: string; kind: string }[] {
  const ex = r.extraction ?? {};
  const out: { term: string; kind: string }[] = [];
  (ex.symptoms ?? []).forEach((s) => s.name && out.push({ term: String(s.name), kind: "symptom" }));
  (ex.components ?? []).forEach((c) => c.name && out.push({ term: String(c.name), kind: "component" }));
  ["lockout/tagout", "lockout", "high-pressure", "never", "bleed off the pressure", "isolate"].forEach((t) => out.push({ term: t, kind: "safety" }));
  return out.filter((x) => x.term.length > 2).sort((a, b) => b.term.length - a.term.length);
}

function highlightEntities(text: string, ents: { term: string; kind: string }[]) {
  if (!ents.length) return text;
  const esc = ents.map((e) => e.term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
  const re = new RegExp(`(${esc.join("|")})`, "gi");
  const parts = text.split(re);
  return parts.map((p, i) => {
    const e = ents.find((x) => x.term.toLowerCase() === p.toLowerCase());
    return e ? <mark key={i} className={`ent ${e.kind}`}>{p}</mark> : <span key={i}>{p}</span>;
  });
}

function ExtractionView({ r }: { r: RecordFull }) {
  const ex = r.extraction ?? {};
  if (!ex.method) return <Panel><Empty title="Extraction not run yet" /></Panel>;
  const groups: [string, ExtractionItem[] | undefined, string?][] = [
    ["Machines mapped", (ex.asset_tags ?? []).map((t) => ({ name: t, quote: "", start: null, end: null, confidence: 1 }))],
    ["Components", ex.components],
    ["Symptoms", ex.symptoms, "warn"],
    ["Failure modes", ex.failure_modes, "info"],
    ["Causes", ex.causes],
    ["Tools", ex.tools],
    ["Parts", ex.parts],
    ["Common mistakes", ex.misconceptions, "danger"],
  ];
  return (
    <div className="stack">
      <div className="notice"><CheckCircle2 style={{ color: "var(--ok)" }} /><span>Extractor <span className="mono">{ex.method}</span>. Every item below is linked to the exact sentence it came from{ex.method?.startsWith("rules") ? " (rule-based mode: literal spans of the transcript only)" : ""}.{ex.dropped_unverified ? ` ${ex.dropped_unverified} LLM item(s) were discarded because their quote could not be found in the transcript.` : ""}</span></div>
      {ex.summary && <Panel title="Summary"><p className="muted">{ex.summary}</p></Panel>}
      <div className="grid g-2">
        {groups.map(([label, items, tone]) => (
          <Panel key={label} title={label} sub={`${items?.length ?? 0} found`}>
            {!items?.length ? <span className="small faint">None</span> : (
              <div className="stack-sm">
                {items.map((it, i) => (
                  <div key={i} className="small">
                    <Badge tone={tone as never}>{String(it.name)}</Badge>
                    {it.quote && <div className="faint tiny mt-8">“{it.quote}”{it.start !== null && <span className="mono" style={{ color: "var(--accent)" }}> {fmtTs(it.start)}</span>}</div>}
                  </div>
                ))}
              </div>
            )}
          </Panel>
        ))}
      </div>
      <Panel title="Safety statements" sub={`${ex.safety?.length ?? 0} found`}>
        {!ex.safety?.length ? <span className="small faint">None stated</span> : (
          <div className="stack-sm">{ex.safety.map((s, i) => <div key={i} className={cls("safety-card small", s.severity === "danger" && "danger")}><AlertTriangle />{String(s.text)}<span className="spacer" /><Badge>{titleCase(String(s.hazard_type ?? "general"))}</Badge></div>)}</div>
        )}
      </Panel>
    </div>
  );
}

function Sources({ r }: { r: RecordFull }) {
  if (!r.recordings.length && !r.documents.length) return <Panel><Empty title="No files">{r.source_type === "text" || r.source_type === "interview" ? "This record was captured as text." : "No files attached."}</Empty></Panel>;
  return (
    <Panel tight>
      {r.recordings.map((x) => (
        <div key={x.id} className="list-item">
          <div style={{ flex: 1 }}>
            <div className="row-wrap"><strong>{x.filename}</strong><Badge>{x.kind}</Badge>{x.is_synthetic && <Badge tone="synthetic">SYNTHETIC · no media file</Badge>}</div>
            <div className="small faint">{x.mime_type} · {fmtBytes(x.size_bytes)}{x.duration_s ? ` · ${fmtTs(x.duration_s)}` : ""}</div>
            {x.has_file && x.kind === "video" && <video src={x.url!} controls className="video-preview mt-12" />}
            {x.has_file && x.kind === "audio" && <audio src={x.url!} controls className="mt-12" style={{ width: "100%" }} />}
          </div>
        </div>
      ))}
      {r.documents.map((d) => (
        <div key={d.id} className="list-item">
          {d.kind === "image" ? <img src={d.url} alt={d.filename} style={{ width: 96, height: 72, objectFit: "cover", borderRadius: 6, border: "1px solid var(--line)" }} /> : <FileText size={18} className="faint" />}
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="row-wrap"><a href={d.url} target="_blank" rel="noreferrer"><strong>{d.filename}</strong></a><Badge>{titleCase(d.category || d.kind)}</Badge></div>
            <div className="small faint">{fmtBytes(d.size_bytes)} · text: {d.extraction_method || "pending"}</div>
            {d.text_preview && <div className="small muted mt-8" style={{ whiteSpace: "pre-wrap" }}>{d.text_preview}</div>}
          </div>
        </div>
      ))}
    </Panel>
  );
}

function TranscriptForm({ id, onSaved }: { id: string; onSaved: () => void }) {
  const toast = useToast();
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const save = async () => {
    setBusy(true);
    try {
      await api.put(`/api/knowledge/records/${id}/transcript`, { transcript: text });
      toast.ok("Transcript saved — processing restarted");
      onSaved();
    } catch (e) {
      toast.error(e);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Panel className="warn" title="Transcript needed" sub="No speech-to-text was available for this recording. Type or paste what was said; LegacyMind never invents a transcript.">
      <textarea className="textarea" value={text} onChange={(e) => setText(e.target.value)} placeholder="Type what the technician said…" />
      <div className="row mt-12" style={{ justifyContent: "flex-end" }}><button className="btn primary" disabled={busy || text.trim().length < 10} onClick={() => void save()}>Save transcript & process</button></div>
    </Panel>
  );
}
