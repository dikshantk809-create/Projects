import { AudioLines, Camera, FileText, FileUp, Image as ImageIcon, Info, Mic, RotateCcw, Send, Square, Trash2, Video, X } from "lucide-react";
import { useCallback, useEffect, useRef, useState, type DragEvent } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useToast } from "../components/toast";
import { ErrorState, Field, PageHead, Panel } from "../components/ui";
import { ApiError, api } from "../lib/api";
import { cls, fmtBytes, fmtTs } from "../lib/format";
import { useApi } from "../lib/hooks";
import { LiveTranscriber, mediaRecorderSupported, pickMime, speechRecognitionSupported } from "../lib/recorder";
import type { Asset, RecordBrief, Segment, SystemStatus } from "../lib/types";

type Mode = "audio" | "video" | "image" | "document" | "text";
const MAX_SECONDS = { audio: 20 * 60, video: 5 * 60 };

export default function Capture() {
  const [params] = useSearchParams();
  const nav = useNavigate();
  const toast = useToast();
  const assets = useApi<{ items: Asset[] }>("/api/assets");
  const sys = useApi<SystemStatus>("/api/admin/system");
  const facets = useApi<{ max_upload_mb: number }>("/api/knowledge/facets");
  const [mode, setMode] = useState<Mode>("audio");
  const [assetId, setAssetId] = useState(params.get("asset") ?? "");
  const [title, setTitle] = useState("");
  const [notes, setNotes] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [imageCategory, setImageCategory] = useState("machine");
  const [media, setMedia] = useState<{ blob: Blob; url: string; duration: number; kind: "audio" | "video" } | null>(null);
  const [segments, setSegments] = useState<Segment[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);
  const maxMb = facets.data?.max_upload_mb ?? 100;

  useEffect(() => {
    const a = assets.data?.items.find((x) => x.id === assetId);
    if (a && !title) setTitle(`${a.asset_tag} ${a.name} — `);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [assetId, assets.data]);

  const reset = () => {
    if (media) URL.revokeObjectURL(media.url);
    setMedia(null);
    setSegments([]);
    setFiles([]);
    setNotes("");
    setError(null);
  };

  const switchMode = (m: Mode) => {
    if (m === mode) return;
    reset();
    setMode(m);
  };

  const hasContent = !!media || files.length > 0 || notes.trim().length > 0 || segments.length > 0;

  const submit = async () => {
    setError(null);
    const tooBig = [...files, ...(media ? [new File([media.blob], "rec")] : [])].find((f) => f.size > maxMb * 1024 * 1024);
    if (tooBig) {
      setError(new ApiError(413, "file_too_large", `A file exceeds the ${maxMb} MB upload limit.`));
      return;
    }
    const fd = new FormData();
    fd.append("title", title.trim() || "Untitled knowledge capture");
    fd.append("source_type", mode === "image" ? "image" : mode);
    if (assetId) fd.append("asset_id", assetId);
    fd.append("notes", notes);
    if (segments.length) {
      fd.append("segments", JSON.stringify(segments));
      fd.append("transcript_source", "browser_speech");
    }
    if (media) {
      const ext = media.blob.type.includes("mp4") ? "mp4" : media.blob.type.includes("ogg") ? "ogg" : "webm";
      fd.append("files", new File([media.blob], `${mode}-capture.${ext}`, { type: media.blob.type.split(";")[0] }));
      fd.append("duration_s", String(Math.round(media.duration)));
    }
    files.forEach((f) => fd.append("files", f));
    if (mode === "image") fd.append("image_category", imageCategory);
    setBusy(true);
    try {
      const rec = await api.post<RecordBrief>("/api/knowledge/records", fd, { timeout: 180_000 });
      toast.ok(`Captured as ${rec.ref} — AI processing started`);
      nav(`/app/library/${rec.ref}`);
    } catch (e) {
      setError(e as ApiError);
    } finally {
      setBusy(false);
    }
  };

  const serverStt = sys.data?.transcription.server;
  const browserStt = speechRecognitionSupported();

  return (
    <div className="stack" style={{ gap: 20 }}>
      <PageHead eyebrow="Zero-friction capture" title="Knowledge Capture">
        Talk while you work. Record audio or a short video, snap photos, upload manuals or type notes — LegacyMind transcribes, extracts and structures it for supervisor review.
      </PageHead>

      <div className="split">
        <div className="stack">
          <Panel>
            <div className="grid g-2">
              <Field label="Machine / asset" hint="Leave empty to let the AI map it from what you say (e.g. “pump P-103”).">
                <select className="select" value={assetId} onChange={(e) => setAssetId(e.target.value)} aria-label="Asset">
                  <option value="">Auto-detect from content</option>
                  {assets.data?.items.map((a) => <option key={a.id} value={a.id}>{a.asset_tag} · {a.name}</option>)}
                </select>
              </Field>
              <Field label="Title"><input className="input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. P-103 startup grinding — what I check first" maxLength={300} /></Field>
            </div>
            <div className="seg mt-16" role="tablist" aria-label="Capture type">
              {([["audio", <AudioLines key="i" />, "Audio"], ["video", <Video key="i" />, "Video"], ["image", <ImageIcon key="i" />, "Images"], ["document", <FileUp key="i" />, "Document"], ["text", <FileText key="i" />, "Text notes"]] as [Mode, JSX.Element, string][]).map(([m, ic, l]) => (
                <button key={m} role="tab" aria-selected={mode === m} className={mode === m ? "on" : ""} onClick={() => switchMode(m)}>{ic}{l}</button>
              ))}
            </div>
          </Panel>

          {(mode === "audio" || mode === "video") && (
            <MediaCapture key={mode} kind={mode} media={media} segments={segments} browserStt={browserStt}
              onDone={(m, segs) => { setMedia(m); setSegments(segs); }}
              onDiscard={() => { if (media) URL.revokeObjectURL(media.url); setMedia(null); setSegments([]); }}
              onUpload={(f) => setFiles([f])} uploaded={files[0]} onClearUpload={() => setFiles([])} />
          )}

          {mode === "image" && (
            <Panel title="Machine, part, fault, wiring or control-panel images">
              <div className="stack">
                <Field label="Image type">
                  <select className="select" value={imageCategory} onChange={(e) => setImageCategory(e.target.value)}>
                    {[["machine", "Machine image"], ["part", "Part image"], ["fault", "Fault image"], ["wiring", "Wiring image"], ["control_panel", "Control panel image"], ["other", "Other"]].map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                  </select>
                </Field>
                <DropZone accept=".png,.jpg,.jpeg,.webp" multiple label="Drop images or click to choose (PNG, JPG, WebP)" onFiles={(fs) => setFiles((x) => [...x, ...fs].slice(0, 10))} capture />
                <FileList files={files} onRemove={(i) => setFiles(files.filter((_, j) => j !== i))} />
                <div className="notice"><Info /><span>{sys.data?.ocr.available ? "Text in images (labels, panel readouts) is extracted with OCR." : "OCR is not installed on this server: images are stored as evidence but not read."} Describe what the photo shows below — that description is what the AI structures.</span></div>
              </div>
            </Panel>
          )}

          {mode === "document" && (
            <Panel title="Manuals, work instructions, reports">
              <div className="stack">
                <DropZone accept=".pdf,.docx,.txt" multiple label="Drop PDF, DOCX or TXT files, or click to choose" onFiles={(fs) => setFiles((x) => [...x, ...fs].slice(0, 10))} />
                <FileList files={files} onRemove={(i) => setFiles(files.filter((_, j) => j !== i))} />
              </div>
            </Panel>
          )}

          {(mode !== "audio" && mode !== "video") || media || files.length ? (
            <Panel title={mode === "text" ? "Your notes" : "Notes (optional)"} sub={mode === "text" ? "Write it the way you would explain it to a new technician." : "Add context the AI should know."}>
              <textarea className="textarea" style={{ minHeight: mode === "text" ? 220 : 110 }} value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={50000}
                placeholder={mode === "text" ? "Whenever pump P-103 produces a grinding sound during startup, first inspect valve V-03. If pressure is below the normal range, check the valve for blockage…" : ""} />
            </Panel>
          ) : null}

          {error && <ErrorState error={error} />}
          <div className="row" style={{ justifyContent: "flex-end" }}>
            <button className="btn ghost" onClick={reset} disabled={busy || !hasContent}><RotateCcw />Clear</button>
            <button className="btn primary lg" onClick={() => void submit()} disabled={busy || !hasContent}>{busy ? <><div className="spinner" />Uploading…</> : <><Send />Submit for AI processing</>}</button>
          </div>
        </div>

        <div className="stack">
          <Panel title="What happens next">
            <ol className="small muted" style={{ margin: 0, paddingLeft: 18, lineHeight: 1.9 }}>
              <li>Transcription with timestamps</li>
              <li>Extraction: machine, components, symptoms, failure modes, causes, steps, tools, parts, safety</li>
              <li>Mapping to the asset registry</li>
              <li>Procedure cards + knowledge graph update</li>
              <li>Indexing for hybrid search</li>
              <li>Conflict check against other technicians’ procedures</li>
              <li><strong style={{ color: "var(--text)" }}>Supervisor review</strong> — nothing is used in answers until approved</li>
            </ol>
          </Panel>
          <Panel title="Capture capabilities on this device">
            <div className="stack-sm small">
              <Cap ok={mediaRecorderSupported()} label="Audio / video recording" />
              <Cap ok={browserStt} label="Live speech-to-text in browser" note={browserStt ? "Web Speech API" : "Use Chrome or Edge"} />
              <Cap ok={!!serverStt} label="Server transcription (Whisper)" note={serverStt ? sys.data?.transcription.provider : "Not configured — a typed transcript can be added later"} />
              <Cap ok={!!sys.data?.llm.configured} label="LLM extraction" note={sys.data?.llm.configured ? sys.data.llm.provider : "Local rules extractor (literal quotes only)"} />
              <div className="faint tiny mt-8">Upload limit: {maxMb} MB per file</div>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}

function Cap({ ok, label, note }: { ok: boolean; label: string; note?: string }) {
  return (
    <div className="row" style={{ alignItems: "flex-start" }}>
      <span className={cls("dot", ok ? "ok" : "idle")} style={{ marginTop: 6 }} />
      <div><div>{label}</div>{note && <div className="tiny faint">{note}</div>}</div>
    </div>
  );
}

function MediaCapture({ kind, media, segments, browserStt, onDone, onDiscard, onUpload, uploaded, onClearUpload }: {
  kind: "audio" | "video"; media: { blob: Blob; url: string; duration: number } | null; segments: Segment[]; browserStt: boolean;
  onDone: (m: { blob: Blob; url: string; duration: number; kind: "audio" | "video" }, segs: Segment[]) => void; onDiscard: () => void;
  onUpload: (f: File) => void; uploaded?: File; onClearUpload: () => void;
}) {
  const [live, setLive] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [finals, setFinals] = useState<Segment[]>([]);
  const [interim, setInterim] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [lang, setLang] = useState("en-IN");
  const recRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const sttRef = useRef<LiveTranscriber | null>(null);
  const t0Ref = useRef(0);
  const chunks = useRef<Blob[]>([]);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const rafRef = useRef(0);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const cleanup = useCallback(() => {
    cancelAnimationFrame(rafRef.current);
    sttRef.current?.stop();
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    void audioCtxRef.current?.close().catch(() => undefined);
    audioCtxRef.current = null;
  }, []);
  useEffect(() => cleanup, [cleanup]);

  useEffect(() => {
    if (!live) return;
    const t = setInterval(() => {
      const s = (performance.now() - t0Ref.current) / 1000;
      setElapsed(s);
      if (s >= MAX_SECONDS[kind]) stop();
    }, 250);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [live]);

  const drawWave = (analyser: AnalyserNode) => {
    const c = canvasRef.current;
    if (!c) return;
    const ctx = c.getContext("2d")!;
    const buf = new Uint8Array(analyser.fftSize);
    const loop = () => {
      analyser.getByteTimeDomainData(buf);
      const w = (c.width = c.clientWidth * devicePixelRatio);
      const h = (c.height = c.clientHeight * devicePixelRatio);
      ctx.clearRect(0, 0, w, h);
      const bars = 64;
      const step = Math.floor(buf.length / bars);
      for (let i = 0; i < bars; i++) {
        let peak = 0;
        for (let j = 0; j < step; j++) peak = Math.max(peak, Math.abs(buf[i * step + j]! - 128));
        const bh = Math.max(2 * devicePixelRatio, (peak / 128) * h * 0.95);
        ctx.fillStyle = `rgba(53, 208, 255, ${0.35 + (peak / 128) * 0.65})`;
        const bw = (w / bars) * 0.6;
        ctx.fillRect(i * (w / bars) + bw * 0.3, (h - bh) / 2, bw, bh);
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    loop();
  };

  const start = async () => {
    setErr(null);
    if (!mediaRecorderSupported()) {
      setErr("This browser cannot record media. Upload a recording file instead.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia(kind === "video" ? { audio: true, video: { width: 1280, height: 720, facingMode: "environment" } } : { audio: { echoCancellation: true, noiseSuppression: true } });
      streamRef.current = stream;
      if (kind === "video" && videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.muted = true;
        void videoRef.current.play();
      }
      const ctx = new AudioContext();
      audioCtxRef.current = ctx;
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 1024;
      ctx.createMediaStreamSource(stream).connect(analyser);
      drawWave(analyser);
      const mime = pickMime(kind);
      const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
      chunks.current = [];
      rec.ondataavailable = (e) => e.data.size && chunks.current.push(e.data);
      rec.onstop = () => {
        const blob = new Blob(chunks.current, { type: rec.mimeType || (kind === "audio" ? "audio/webm" : "video/webm") });
        const duration = (performance.now() - t0Ref.current) / 1000;
        const segs = sttRef.current?.segments ?? [];
        cleanup();
        onDone({ blob, url: URL.createObjectURL(blob), duration, kind }, segs);
      };
      t0Ref.current = performance.now();
      rec.start(1000);
      recRef.current = rec;
      setFinals([]);
      setInterim("");
      setElapsed(0);
      setLive(true);
      if (browserStt) {
        const stt = new LiveTranscriber(lang);
        stt.onUpdate = (f, i) => { setFinals(f); setInterim(i); };
        stt.onError = (m) => setErr(m);
        stt.start(t0Ref.current);
        sttRef.current = stt;
      }
    } catch (e) {
      cleanup();
      const name = (e as Error).name;
      setErr(name === "NotAllowedError" ? `Permission to use the ${kind === "video" ? "camera/microphone" : "microphone"} was denied. Allow it in your browser settings.` : name === "NotFoundError" ? `No ${kind === "video" ? "camera" : "microphone"} found on this device.` : "Could not start recording on this device.");
    }
  };

  const stop = () => {
    setLive(false);
    sttRef.current?.stop();
    if (recRef.current && recRef.current.state !== "inactive") recRef.current.stop();
  };

  if (uploaded) {
    return (
      <Panel title={`Uploaded ${kind} file`}>
        <div className="file-row"><FileUp size={16} /><span style={{ flex: 1 }}>{uploaded.name}</span><span className="mono small faint">{fmtBytes(uploaded.size)}</span><button className="btn ghost icon sm" onClick={onClearUpload} aria-label="Remove"><X /></button></div>
        <p className="small faint mt-12">The server transcribes uploaded recordings when Whisper is configured; otherwise you can add the transcript on the record page after submitting.</p>
      </Panel>
    );
  }

  if (media) {
    return (
      <Panel title={`Review your ${kind} (${fmtTs(media.duration)})`} actions={<button className="btn sm ghost" onClick={onDiscard}><Trash2 />Discard & re-record</button>}>
        <div className="stack">
          {kind === "video" ? <video className="video-preview" src={media.url} controls /> : <audio src={media.url} controls style={{ width: "100%" }} />}
          <div>
            <div className="label">Live transcript ({segments.length} segment{segments.length === 1 ? "" : "s"})</div>
            {segments.length ? (
              <div className="transcript mt-8">{segments.map((s, i) => <div key={i} className="seg-line"><span className="ts">{fmtTs(s.start)}</span><span>{s.text}</span></div>)}</div>
            ) : (
              <p className="small faint mt-8">No live transcript was captured{browserStt ? "" : " (browser speech recognition unavailable)"}. The server will transcribe if Whisper is configured; otherwise add the transcript on the record page.</p>
            )}
          </div>
        </div>
      </Panel>
    );
  }

  return (
    <Panel>
      <div className="recorder">
        {kind === "video" && <video ref={videoRef} className="video-preview" playsInline muted style={{ display: live ? "block" : "none" }} />}
        {live ? <span className="rec-live"><span className="dot danger" /> RECORDING</span> : <span className="rec-live" style={{ color: "var(--text-3)" }}>READY · max {MAX_SECONDS[kind] / 60} min</span>}
        <div className="rec-time">{fmtTs(elapsed)}</div>
        <canvas ref={canvasRef} className="wave" aria-hidden />
        <button className={cls("rec-btn", live && "live")} onClick={() => (live ? stop() : void start())} aria-label={live ? "Stop recording" : "Start recording"}>
          <span className="core" />
        </button>
        <div className="row small">{live ? <><Square size={14} />Tap to stop</> : <>{kind === "video" ? <Camera size={14} /> : <Mic size={14} />}[ START RECORDING ]</>}</div>
        {browserStt && !live && (
          <select className="select" style={{ width: 200, height: 32 }} value={lang} onChange={(e) => setLang(e.target.value)} aria-label="Speech language">
            <option value="en-IN">English (India)</option><option value="en-US">English (US)</option><option value="en-GB">English (UK)</option><option value="hi-IN">Hindi (India)</option>
          </select>
        )}
        {live && (
          <div className="live-transcript" aria-live="polite">
            {finals.slice(-4).map((s, i) => <span key={i}>{s.text} </span>)}
            <span className="interim">{interim}</span>
            {!finals.length && !interim && <span className="faint">{browserStt ? "Start talking — the transcript appears here…" : "Live transcript unavailable in this browser; audio is still recorded."}</span>}
          </div>
        )}
        {err && <div className="notice warn" style={{ maxWidth: 560 }}><Info />{err}</div>}
      </div>
      {!live && (
        <div className="row mt-12" style={{ justifyContent: "center" }}>
          <span className="small faint">or</span>
          <button className="btn sm" onClick={() => fileRef.current?.click()}><FileUp />Upload an existing {kind} file</button>
          <input ref={fileRef} hidden type="file" accept={kind === "audio" ? ".webm,.ogg,.mp3,.wav,.m4a" : ".mp4,.webm,.mov"} onChange={(e) => e.target.files?.[0] && onUpload(e.target.files[0])} />
        </div>
      )}
    </Panel>
  );
}

function DropZone({ accept, multiple, label, onFiles, capture }: { accept: string; multiple?: boolean; label: string; onFiles: (f: File[]) => void; capture?: boolean }) {
  const ref = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);
  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    setOver(false);
    onFiles(Array.from(e.dataTransfer.files));
  };
  return (
    <div className={cls("dropzone", over && "over")} onClick={() => ref.current?.click()} onDragOver={(e) => { e.preventDefault(); setOver(true); }} onDragLeave={() => setOver(false)} onDrop={onDrop}
      role="button" tabIndex={0} onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && ref.current?.click()}>
      <FileUp style={{ margin: "0 auto 8px", color: "var(--text-3)" }} />
      <div>{label}</div>
      <input ref={ref} hidden type="file" accept={accept} multiple={multiple} {...(capture ? { capture: "environment" as const } : {})} onChange={(e) => { onFiles(Array.from(e.target.files ?? [])); e.target.value = ""; }} />
    </div>
  );
}

function FileList({ files, onRemove }: { files: File[]; onRemove: (i: number) => void }) {
  if (!files.length) return null;
  return (
    <div className="stack-sm">
      {files.map((f, i) => (
        <div key={`${f.name}-${i}`} className="file-row">
          {f.type.startsWith("image/") ? <img src={URL.createObjectURL(f)} alt="" style={{ width: 40, height: 40, objectFit: "cover", borderRadius: 4 }} /> : <FileText size={16} />}
          <span style={{ flex: 1 }} className="ellipsis">{f.name}</span>
          <span className="mono small faint">{fmtBytes(f.size)}</span>
          <button className="btn ghost icon sm" onClick={() => onRemove(i)} aria-label={`Remove ${f.name}`}><X /></button>
        </div>
      ))}
    </div>
  );
}
