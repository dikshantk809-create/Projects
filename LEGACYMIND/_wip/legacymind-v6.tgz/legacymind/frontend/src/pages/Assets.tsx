import { Factory, Plus, Search } from "lucide-react";
import { useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useToast } from "../components/toast";
import { Badge, Empty, ErrorState, Field, Loading, Modal, PageHead, Panel, StatusBadge, SyntheticBadge } from "../components/ui";
import { ApiError, api, qs } from "../lib/api";
import { useAuth } from "../lib/auth";
import { cls } from "../lib/format";
import { useApi, useDebounced } from "../lib/hooks";
import type { Asset } from "../lib/types";

const STATUS = ["operational", "degraded", "down", "maintenance", "decommissioned"];

export default function Assets() {
  const { can } = useAuth();
  const nav = useNavigate();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const dq = useDebounced(q);
  const { data, error, loading, reload } = useApi<{ items: Asset[] }>(`/api/assets${qs({ q: dq, status })}`);
  const [creating, setCreating] = useState(false);
  const items = data?.items ?? [];
  const synthetic = items.some((a) => a.is_synthetic);

  return (
    <div className="stack" style={{ gap: 20 }}>
      <PageHead eyebrow="Industrial asset registry" title="Assets" actions={can("assets:write") && <button className="btn primary" onClick={() => setCreating(true)}><Plus />Register asset</button>}>
        Every machine has a QR code. Scan it on the shop floor to open its procedures, failure modes and expert recordings.
      </PageHead>
      <div className="row-wrap">
        <div className="search" style={{ flex: "1 1 280px", maxWidth: 420 }}>
          <Search />
          <input className="input" placeholder="Search by tag, name, location, manufacturer…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search assets" />
        </div>
        <select className="select" style={{ width: 180 }} value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Filter by status">
          <option value="">All statuses</option>
          {STATUS.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <div className="spacer" />
        {synthetic && <SyntheticBadge />}
      </div>
      {error && <ErrorState error={error} onRetry={() => void reload()} />}
      <Panel tight>
        {loading && !data ? <Loading /> : items.length === 0 ? (
          <Empty icon={<Factory />} title={q || status ? "No assets match" : "No assets registered"}
            action={can("assets:write") && !q ? <button className="btn" onClick={() => setCreating(true)}><Plus />Register the first asset</button> : undefined}>
            {q || status ? "Try a different search or filter." : "Register the machines in your plant to link knowledge to them."}
          </Empty>
        ) : (
          <div className="table-wrap">
            <table className="table">
              <thead><tr><th>Asset ID</th><th>Machine</th><th>Manufacturer / model</th><th>Department</th><th>Location</th><th>Status</th><th>Knowledge</th></tr></thead>
              <tbody>
                {items.map((a) => (
                  <tr key={a.id} className="click" onClick={() => nav(`/app/assets/${a.asset_tag}`)}>
                    <td><Link to={`/app/assets/${a.asset_tag}`} onClick={(e) => e.stopPropagation()}><span className="tag">{a.asset_tag}</span></Link></td>
                    <td><div style={{ fontWeight: 500 }}>{a.name}</div><div className="tiny faint">{a.machine_type}</div></td>
                    <td className="muted">{a.manufacturer} <span className="faint">{a.model}</span></td>
                    <td className="muted">{a.department ?? "—"}</td>
                    <td className="muted">{a.location}</td>
                    <td><span className="row"><span className={cls("dot", a.status === "operational" ? "ok" : a.status === "down" ? "danger" : a.status === "degraded" ? "warn" : "idle")} /><StatusBadge status={a.status} /></span></td>
                    <td className="small"><span className="mono">{a.knowledge_count ?? 0}</span> <span className="faint">records ·</span> <span className="mono">{a.approved_procedures ?? 0}</span> <span className="faint">approved</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
      {creating && <CreateAsset onClose={() => setCreating(false)} onCreated={(a) => { setCreating(false); nav(`/app/assets/${a.asset_tag}`); }} />}
    </div>
  );
}

function CreateAsset({ onClose, onCreated }: { onClose: () => void; onCreated: (a: Asset) => void }) {
  const toast = useToast();
  const deps = useApi<{ items: { id: string; name: string }[] }>("/api/admin/departments");
  const [f, setF] = useState({ asset_tag: "", name: "", machine_type: "", manufacturer: "", model: "", serial_number: "", department_id: "", location: "", installed_on: "", status: "operational", criticality: "medium", description: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => setF({ ...f, [k]: e.target.value });
  const fieldErr = (n: string) => ((error?.details as { field: string; message: string }[] | undefined) ?? []).find((d) => d.field === n)?.message;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const body = { ...f, department_id: f.department_id || null, installed_on: f.installed_on || null };
      const a = await api.post<Asset>("/api/assets", body);
      toast.ok(`Asset ${a.asset_tag} registered`);
      onCreated(a);
    } catch (err) {
      setError(err as ApiError);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal title="Register asset" onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>Cancel</button><button className="btn primary" form="asset-form" disabled={busy || !f.asset_tag || !f.name}>{busy ? "Saving…" : "Register asset"}</button></>}>
      <form id="asset-form" className="stack" onSubmit={submit}>
        {error && !error.details && <ErrorState error={error} />}
        <div className="grid g-2">
          <Field label="Asset ID *" hint="e.g. P-103" error={fieldErr("asset_tag")}><input className="input mono" value={f.asset_tag} onChange={set("asset_tag")} required /></Field>
          <Field label="Machine name *" error={fieldErr("name")}><input className="input" value={f.name} onChange={set("name")} required /></Field>
          <Field label="Machine type"><input className="input" value={f.machine_type} onChange={set("machine_type")} /></Field>
          <Field label="Manufacturer"><input className="input" value={f.manufacturer} onChange={set("manufacturer")} /></Field>
          <Field label="Model"><input className="input" value={f.model} onChange={set("model")} /></Field>
          <Field label="Serial number"><input className="input" value={f.serial_number} onChange={set("serial_number")} /></Field>
          <Field label="Department">
            <select className="select" value={f.department_id} onChange={set("department_id")}>
              <option value="">—</option>
              {deps.data?.items.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </Field>
          <Field label="Location" hint="Plant / line / cell"><input className="input" value={f.location} onChange={set("location")} /></Field>
          <Field label="Installation date" error={fieldErr("installed_on")}><input className="input" type="date" value={f.installed_on} onChange={set("installed_on")} /></Field>
          <Field label="Status"><select className="select" value={f.status} onChange={set("status")}>{STATUS.map((s) => <option key={s}>{s}</option>)}</select></Field>
          <Field label="Criticality"><select className="select" value={f.criticality} onChange={set("criticality")}>{["low", "medium", "high", "critical"].map((s) => <option key={s}>{s}</option>)}</select></Field>
        </div>
        <Field label="Description"><textarea className="textarea" value={f.description} onChange={set("description")} /></Field>
        <Badge>Asset tags are used to map recordings to machines automatically (e.g. “pump P-103”).</Badge>
      </form>
    </Modal>
  );
}
