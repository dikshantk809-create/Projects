import { AlertTriangle, BadgeCheck, CheckCircle2, ClipboardCheck, Flag, Lock, Printer, Quote, ShieldAlert, XCircle } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useNavigate, useParams, useSearchParams } from "react-router-dom";
import { EvidencePlayer } from "../components/EvidencePlayer";
import { useToast } from "../components/toast";
import { Badge, ErrorState, Loading, Meter, PageHead, Panel, RiskBadge, StatusBadge } from "../components/ui";
import { ApiError, api } from "../lib/api";
import { cls, fmtDate, fmtTs } from "../lib/format";
import { speak, stopSpeaking } from "../lib/speech";
import type { Procedure, SafetyOut } from "../lib/types";

interface Preflight { procedure: Procedure; safety_warnings: SafetyOut[]; lockout_required: boolean; executable: boolean; reason: string }
interface ExecStep {
  order: number; text: string; component: string; done: boolean; done_at: string | null; note: string;
  evidence: { quote: string; start: number | null; end: number | null; record_ref: string | null; technician: string | null; source_type: string | null; is_synthetic: boolean; recording_id: string | null; playable_audio: boolean; edited_by?: string } | null;
}
export interface Execution {
  id: string; status: "in_progress" | "completed" | "aborted"; outcome: string; notes: string; procedure: Procedure; safety_warnings: SafetyOut[];
  steps: ExecStep[]; progress: { done: number; total: number; percent: number }; started_at: string; finished_at: string | null;
  maintenance_event_id: string | null; version_changed: boolean; safety_acknowledged: string[];
}

/** /app/execute/:procedureId            -> safety gate, then start
 *  /app/execute/:procedureId?run=<id>   -> resume an execution */
export default function Execute() {
  const { procedureId = "" } = useParams();
  const [params, setParams] = useSearchParams();
  const runId = params.get("run");
  const [pre, setPre] = useState<Preflight | null>(null);
  const [ex, setEx] = useState<Execution | null>(null);
  const [error, setError] = useState<ApiError | null>(null);

  useEffect(() => {
    setError(null);
    if (runId) api.get<Execution>(`/api/executions/${runId}`).then(setEx).catch((e) => setError(e as ApiError));
    else api.get<Preflight>(`/api/executions/preflight/${encodeURIComponent(procedureId)}`).then(setPre).catch((e) => setError(e as ApiError));
  }, [procedureId, runId]);
  useEffect(() => () => stopSpeaking(), []);

  if (error) return <ErrorState error={error} />;
  if (ex) return <Runner ex={ex} setEx={setEx} />;
  if (!pre) return <Loading />;
  return <SafetyGate pre={pre} onStarted={(e) => { setEx(e); setParams({ run: e.id }, { replace: true }); }} />;
}

function SafetyGate({ pre, onStarted }: { pre: Preflight; onStarted: (e: Execution) => void }) {
  const [acked, setAcked] = useState<Set<string>>(new Set());
  const [lockout, setLockout] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);
  const p = pre.procedure;
  const allAcked = pre.safety_warnings.every((w) => acked.has(w.id)) && (!pre.lockout_required || lockout);
  const toggle = (id: string) => setAcked((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });

  const start = async () => {
    setBusy(true);
    setError(null);
    try {
      onStarted(await api.post<Execution>("/api/executions", { procedure_id: p.id, safety_acknowledged: [...acked], lockout_confirmed: lockout }));
    } catch (e) {
      setError(e as ApiError);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="stack" style={{ gap: 20, maxWidth: 920 }}>
      <PageHead eyebrow={`Guided procedure · ${p.ref}`} title={p.title} actions={<Link className="btn ghost" to={`/app/print/procedure/${p.id}`}><Printer />Print card</Link>}>
        <span className="row-wrap">{p.asset && <Link to={`/app/assets/${p.asset.asset_tag}`}><span className="tag">{p.asset.asset_tag}</span> {p.asset.name}</Link>}<RiskBadge risk={p.risk_level} /><StatusBadge status={p.status} />{p.approved_by && <Badge tone="ok"><BadgeCheck />Approved by {p.approved_by.full_name}</Badge>}</span>
      </PageHead>
      {!pre.executable && <div className="notice warn"><AlertTriangle />{pre.reason}</div>}
      <Panel className="warn" title={<span className="row"><ShieldAlert size={16} style={{ color: "var(--warn)" }} />Safety check — required before step 1</span>}
        sub="Read each warning from the approved expert knowledge and confirm it. LegacyMind supports, but never replaces, your plant's permit-to-work and supervisor sign-off.">
        <div className="stack-sm">
          {pre.safety_warnings.length === 0 && <div className="small muted">No machine-specific warnings are recorded for this procedure. Follow your plant's standard isolation procedure.</div>}
          {pre.safety_warnings.map((w) => (
            <label key={w.id} className={cls("safety-card", w.severity === "danger" && "danger")} style={{ cursor: "pointer" }}>
              <input type="checkbox" checked={acked.has(w.id)} onChange={() => toggle(w.id)} aria-label={`Acknowledge: ${w.text}`} style={{ marginTop: 3 }} />
              <AlertTriangle />
              <span style={{ flex: 1 }}>{w.text}</span>
            </label>
          ))}
          {pre.lockout_required && (
            <label className="panel" style={{ padding: 12, display: "flex", gap: 10, alignItems: "center", cursor: "pointer", background: "var(--bg-2)" }}>
              <input type="checkbox" checked={lockout} onChange={(e) => setLockout(e.target.checked)} aria-label="Confirm lockout/tagout" />
              <Lock size={16} style={{ color: "var(--warn)" }} />
              <span><strong>I confirm the machine is stopped, isolated and locked out / tagged out</strong><span className="small faint"> — required for {p.risk_level}-risk procedures and danger-level hazards.</span></span>
            </label>
          )}
        </div>
      </Panel>
      <Panel title={`${p.steps.length} steps`} sub="Preview — steps unlock one at a time once you start">
        <ol className="steps">{p.steps.map((s) => <li key={s.order}><span className="muted">{s.text}</span><span /></li>)}</ol>
      </Panel>
      {error && <ErrorState error={error} />}
      <div className="row" style={{ justifyContent: "flex-end" }}>
        <button className="btn primary lg" disabled={!pre.executable || !allAcked || busy} onClick={() => void start()}><ClipboardCheck />{busy ? "Starting…" : "Start procedure"}</button>
      </div>
    </div>
  );
}

function Runner({ ex, setEx }: { ex: Execution; setEx: (e: Execution) => void }) {
  const toast = useToast();
  const nav = useNavigate();
  const [busy, setBusy] = useState(false);
  const [notes, setNotes] = useState(ex.notes);
  const p = ex.procedure;
  const current = ex.steps.find((s) => !s.done);
  const running = ex.status === "in_progress";

  const setStep = async (order: number, done: boolean) => {
    setBusy(true);
    try {
      setEx(await api.patch<Execution>(`/api/executions/${ex.id}/steps/${order}`, { done }));
    } catch (e) {
      toast.error(e);
    } finally {
      setBusy(false);
    }
  };
  const finish = async (outcome: "resolved" | "not_resolved" | "escalated") => {
    setBusy(true);
    try {
      const r = await api.post<Execution>(`/api/executions/${ex.id}/complete`, { outcome, notes });
      setEx(r);
      toast.ok(outcome === "resolved" ? "Logged to maintenance history — problem resolved" : "Logged to maintenance history");
    } catch (e) {
      toast.error(e);
    } finally {
      setBusy(false);
    }
  };
  const abort = async () => {
    setBusy(true);
    try {
      setEx(await api.post<Execution>(`/api/executions/${ex.id}/abort`));
    } catch (e) {
      toast.error(e);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="split">
      <div className="stack" style={{ gap: 16 }}>
        <PageHead eyebrow={`Guided procedure · ${p.ref}${p.asset ? ` · ${p.asset.asset_tag}` : ""}`} title={p.title}
          actions={running ? <button className="btn ghost" disabled={busy} onClick={() => void abort()}><XCircle />Abort</button> : <button className="btn" onClick={() => nav(p.asset ? `/app/assets/${p.asset.asset_tag}` : "/app")}>Back to machine</button>} />
        {ex.version_changed && <div className="notice warn"><AlertTriangle />This procedure was edited by a supervisor after you started. Re-check the steps.</div>}
        <div className="panel" style={{ padding: 16 }}>
          <div className="row"><strong>Progress</strong><div className="spacer" /><span className="mono small">{ex.progress.done} / {ex.progress.total} steps</span></div>
          <div className="mt-8"><Meter value={ex.progress.percent} tone={ex.progress.percent === 100 ? "ok" : undefined} /></div>
        </div>
        <div className="stack-sm">
          {ex.steps.map((s) => {
            const isCurrent = running && current?.order === s.order;
            const locked = running && !s.done && !isCurrent;
            return (
              <div key={s.order} className={cls("panel", isCurrent && "accent")} style={{ padding: 16, opacity: locked ? 0.55 : 1, background: s.done ? "var(--bg-2)" : undefined }}>
                <div className="row" style={{ alignItems: "flex-start" }}>
                  <button className={cls("btn icon", s.done ? "ok" : isCurrent ? "primary" : "")} disabled={!running || busy || locked || (s.done && ex.steps.some((x) => x.order > s.order && x.done))}
                    onClick={() => void setStep(s.order, !s.done)} aria-label={s.done ? `Mark step ${s.order} not done` : `Mark step ${s.order} done`}>
                    {s.done ? <CheckCircle2 /> : <span className="mono">{s.order}</span>}
                  </button>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 16, fontWeight: isCurrent ? 600 : 500, textDecoration: s.done ? "line-through" : undefined, textDecorationColor: "var(--text-3)" }}>{s.text}</div>
                    {s.done && s.done_at && <div className="tiny faint mt-8">Done {fmtDate(s.done_at, true)}</div>}
                    {s.evidence?.quote && (isCurrent || !running) && (
                      <div className="mt-12 small">
                        <div className="row faint" style={{ alignItems: "flex-start" }}><Quote size={12} style={{ marginTop: 4, flex: "none" }} /><span>“{s.evidence.quote}”</span></div>
                        <div className="row-wrap mt-8 tiny faint">
                          {s.evidence.technician && <span>{s.evidence.technician}</span>}
                          {s.evidence.record_ref && <Link to={`/app/library/${s.evidence.record_ref}`}>{s.evidence.record_ref}</Link>}
                          {s.evidence.start !== null && <span className="mono" style={{ color: "var(--accent)" }}>{fmtTs(s.evidence.start)}–{fmtTs(s.evidence.end)}</span>}
                          {s.evidence.edited_by && <em>edited by {s.evidence.edited_by}</em>}
                          {s.evidence.source_type && <EvidencePlayer recordingId={s.evidence.recording_id} playable={s.evidence.playable_audio} start={s.evidence.start} end={s.evidence.end}
                            quote={s.evidence.quote} synthetic={s.evidence.is_synthetic} sourceType={s.evidence.source_type} />}
                        </div>
                      </div>
                    )}
                    {isCurrent && <button className="btn ghost sm mt-8" onClick={() => speak(s.text)}>Read step aloud</button>}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      <div className="stack" style={{ position: "sticky", top: 72 }}>
        {running ? (
          <Panel title={<span className="row"><Flag size={15} />Finish</span>} sub="Your result is written to this machine's maintenance history">
            <div className="stack-sm">
              <textarea className="textarea" style={{ minHeight: 90 }} placeholder="What did you find? (optional)" value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={4000} aria-label="Notes" />
              <button className="btn ok" disabled={busy || ex.progress.done < ex.progress.total} onClick={() => void finish("resolved")}><CheckCircle2 />Problem resolved</button>
              <button className="btn" disabled={busy} onClick={() => void finish("not_resolved")}>Not resolved</button>
              <button className="btn bad" disabled={busy} onClick={() => void finish("escalated")}><ShieldAlert />Escalate to supervisor</button>
              <span className="tiny faint">“Resolved” unlocks after every step is done. “Not resolved” answers feed the next Knowledge Harvest.</span>
            </div>
          </Panel>
        ) : (
          <Panel className={ex.outcome === "resolved" ? "accent" : "warn"} title={ex.status === "aborted" ? "Execution aborted" : "Execution complete"}>
            <div className="stack-sm small">
              <div><StatusBadge status={ex.status} /> {ex.outcome && <Badge tone={ex.outcome === "resolved" ? "ok" : "warn"}>{ex.outcome.replace("_", " ")}</Badge>}</div>
              <div className="faint">Finished {fmtDate(ex.finished_at, true)}</div>
              {ex.maintenance_event_id && <div>Logged to <Link to={`/app/assets/${p.asset?.asset_tag}`}>{p.asset?.asset_tag} maintenance history</Link>.</div>}
              {ex.notes && <div className="muted">“{ex.notes}”</div>}
            </div>
          </Panel>
        )}
        <Panel title="Safety acknowledged">
          <div className="stack-sm small">
            {ex.safety_warnings.map((w) => <div key={w.id} className="row" style={{ alignItems: "flex-start" }}><CheckCircle2 size={14} style={{ color: "var(--ok)", flex: "none", marginTop: 3 }} />{w.text}</div>)}
            {ex.safety_acknowledged.includes("lockout_tagout") && <div className="row"><Lock size={14} style={{ color: "var(--ok)" }} />Lockout / tagout confirmed at start</div>}
          </div>
        </Panel>
      </div>
    </div>
  );
}
