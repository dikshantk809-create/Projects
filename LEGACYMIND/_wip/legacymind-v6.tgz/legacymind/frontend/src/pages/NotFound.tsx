import { Link } from "react-router-dom";

export function NotFound({ inApp = false }: { inApp?: boolean }) {
  return (
    <div style={{ minHeight: inApp ? 400 : "100vh", display: "grid", placeItems: "center", padding: 24 }}>
      <div className="empty">
        <div className="mono" style={{ fontSize: 44, color: "var(--accent)" }}>404</div>
        <h3>Page not found</h3>
        <p>This page doesn’t exist or has moved.</p>
        <Link className="btn" to={inApp ? "/app" : "/"}>{inApp ? "Back to dashboard" : "Back to home"}</Link>
      </div>
    </div>
  );
}
