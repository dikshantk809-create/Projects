import { Plus, Trash2 } from "lucide-react";
import { useState, type FormEvent } from "react";
import { useToast } from "../components/toast";
import { Badge, Empty, ErrorState, Field, Loading, Modal, PageHead, Panel } from "../components/ui";
import { ApiError, api, qs } from "../lib/api";
import { useAuth } from "../lib/auth";
import { ROLE_LABEL, cls, fmtDate, timeAgo } from "../lib/format";
import { useApi } from "../lib/hooks";
import type { Role, SystemStatus, User } from "../lib/types";

type Tab = "users" | "departments" | "audit" | "system";

export default function Admin() {
  const [tab, setTab] = useState<Tab>("users");
  return (
    <div className="stack" style={{ gap: 20 }}>
      <PageHead eyebrow="Plant administration" title="Administration">Users, roles, departments, the audit trail and which AI capabilities are active in this deployment.</PageHead>
      <div className="tabs" role="tablist">
        {([["users", "Users & roles"], ["departments", "Departments"], ["audit", "Audit log"], ["system", "System status"]] as [Tab, string][]).map(([k, l]) => (
          <button key={k} role="tab" aria-selected={tab === k} className={cls("tab", tab === k && "active")} onClick={() => setTab(k)}>{l}</button>
        ))}
      </div>
      {tab === "users" && <Users />}
      {tab === "departments" && <Departments />}
      {tab === "audit" && <Audit />}
      {tab === "system" && <System />}
    </div>
  );
}

const ROLES: Role[] = ["admin", "supervisor", "technician", "junior_technician"];

function Users() {
  const { session } = useAuth();
  const toast = useToast();
  const { data, error, loading, reload } = useApi<{ items: User[] }>("/api/admin/users");
  const deps = useApi<{ items: { id: string; name: string }[] }>("/api/admin/departments");
  const [creating, setCreating] = useState(false);
  const update = async (u: User, patch: Partial<User>) => {
    try {
      await api.patch(`/api/admin/users/${u.id}`, patch);
      toast.ok(`${u.full_name} updated`);
      void reload();
    } catch (e) {
      toast.error(e);
    }
  };
  if (loading && !data) return <Loading />;
  return (
    <Panel tight title="Users" actions={<button className="btn primary sm" onClick={() => setCreating(true)}><Plus />Add user</button>}>
      {error && <div className="panel-body"><ErrorState error={error} onRetry={() => void reload()} /></div>}
      <div className="table-wrap">
        <table className="table">
          <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Department</th><th>Experience</th><th>Last login</th><th>Status</th></tr></thead>
          <tbody>{data?.items.map((u) => (
            <tr key={u.id}>
              <td><div style={{ fontWeight: 500 }}>{u.full_name}</div><div className="tiny faint">{u.title}</div></td>
              <td className="small muted">{u.email}</td>
              <td>
                <select className="select" style={{ height: 32, width: 190 }} value={u.role} disabled={u.id === session?.user.id} onChange={(e) => void update(u, { role: e.target.value as Role })} aria-label={`Role for ${u.full_name}`}>
                  {ROLES.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
                </select>
              </td>
              <td className="small">{deps.data?.items.find((d) => d.id === u.department_id)?.name ?? "—"}</td>
              <td className="mono small">{u.years_experience != null ? `${u.years_experience} yrs` : "—"}</td>
              <td className="small faint">{u.last_login_at ? timeAgo(u.last_login_at) : "never"}</td>
              <td>
                <button className={cls("btn sm", u.is_active ? "ok" : "bad")} disabled={u.id === session?.user.id} onClick={() => void update(u, { is_active: !u.is_active })}>{u.is_active ? "Active" : "Disabled"}</button>
              </td>
            </tr>
          ))}</tbody>
        </table>
      </div>
      {creating && <CreateUser deps={deps.data?.items ?? []} onClose={() => setCreating(false)} onCreated={() => { setCreating(false); void reload(); }} />}
    </Panel>
  );
}

function CreateUser({ deps, onClose, onCreated }: { deps: { id: string; name: string }[]; onClose: () => void; onCreated: () => void }) {
  const toast = useToast();
  const [f, setF] = useState({ full_name: "", email: "", title: "", role: "technician", department_id: "", years_experience: "", password: "" });
  const [err, setErr] = useState<ApiError | null>(null);
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    try {
      await api.post("/api/admin/users", { ...f, department_id: f.department_id || null, years_experience: f.years_experience ? Number(f.years_experience) : null });
      toast.ok(`${f.full_name} added`);
      onCreated();
    } catch (x) {
      setErr(x as ApiError);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Modal title="Add user" onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>Cancel</button><button className="btn primary" form="user-form" disabled={busy}>Create user</button></>}>
      <form id="user-form" className="stack" onSubmit={submit}>
        {err && <ErrorState error={err} />}
        <div className="grid g-2">
          <Field label="Full name"><input className="input" value={f.full_name} onChange={set("full_name")} required /></Field>
          <Field label="Email"><input className="input" type="email" value={f.email} onChange={set("email")} required /></Field>
          <Field label="Job title"><input className="input" value={f.title} onChange={set("title")} /></Field>
          <Field label="Role"><select className="select" value={f.role} onChange={set("role")}>{ROLES.map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}</select></Field>
          <Field label="Department"><select className="select" value={f.department_id} onChange={set("department_id")}><option value="">—</option>{deps.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></Field>
          <Field label="Years of experience"><input className="input" type="number" min={0} max={60} value={f.years_experience} onChange={set("years_experience")} /></Field>
        </div>
        <Field label="Temporary password" hint="10+ characters with a letter and a number. Share it securely."><input className="input" type="password" value={f.password} onChange={set("password")} required autoComplete="new-password" /></Field>
      </form>
    </Modal>
  );
}

function Departments() {
  const toast = useToast();
  const { data, reload } = useApi<{ items: { id: string; name: string; assets: number }[] }>("/api/admin/departments");
  const [name, setName] = useState("");
  const add = async (e: FormEvent) => {
    e.preventDefault();
    try {
      await api.post("/api/admin/departments", { name });
      setName("");
      toast.ok("Department added");
      void reload();
    } catch (x) {
      toast.error(x);
    }
  };
  const del = async (id: string) => {
    try {
      await api.del(`/api/admin/departments/${id}`);
      toast.ok("Department removed");
      void reload();
    } catch (x) {
      toast.error(x);
    }
  };
  return (
    <Panel tight title="Departments" actions={
      <form className="row" onSubmit={add}><input className="input" style={{ height: 32, width: 220 }} placeholder="New department" value={name} onChange={(e) => setName(e.target.value)} aria-label="Department name" /><button className="btn sm" disabled={name.trim().length < 2}><Plus />Add</button></form>
    }>
      {!data?.items.length ? <Empty title="No departments" /> : (
        <table className="table"><thead><tr><th>Department</th><th>Assets</th><th /></tr></thead>
          <tbody>{data.items.map((d) => <tr key={d.id}><td>{d.name}</td><td className="mono">{d.assets}</td><td style={{ textAlign: "right" }}><button className="btn ghost sm" disabled={d.assets > 0} title={d.assets ? "Move this department's assets first" : "Delete"} onClick={() => void del(d.id)}><Trash2 /></button></td></tr>)}</tbody>
        </table>
      )}
    </Panel>
  );
}

function Audit() {
  const [action, setAction] = useState("");
  const { data, loading } = useApi<{ items: { id: string; action: string; user: string; entity_type: string; entity_id: string; ip_address: string; details: Record<string, unknown>; created_at: string }[] }>(`/api/admin/audit${qs({ action, limit: 200 })}`);
  return (
    <Panel tight title="Audit log" sub="Every security-relevant and knowledge-changing action" actions={
      <select className="select" style={{ height: 32, width: 200 }} value={action} onChange={(e) => setAction(e.target.value)} aria-label="Filter actions">
        <option value="">All actions</option><option value="auth">Authentication</option><option value="knowledge">Knowledge capture</option><option value="review">Reviews</option><option value="assistant">Assistant</option><option value="admin">Administration</option><option value="asset">Assets</option><option value="harvest">Harvest</option>
      </select>
    }>
      {loading && !data ? <Loading /> : !data?.items.length ? <Empty title="No entries" /> : (
        <div className="table-wrap"><table className="table">
          <thead><tr><th>Time</th><th>User</th><th>Action</th><th>Entity</th><th>IP</th><th>Details</th></tr></thead>
          <tbody>{data.items.map((r) => (
            <tr key={r.id}><td className="small nowrap faint">{fmtDate(r.created_at, true)}</td><td className="small">{r.user}</td><td><span className="mono small">{r.action}</span></td><td className="small faint">{r.entity_type}</td><td className="mono tiny faint">{r.ip_address}</td><td className="mono tiny faint ellipsis" style={{ maxWidth: 280 }}>{JSON.stringify(r.details)}</td></tr>
          ))}</tbody>
        </table></div>
      )}
    </Panel>
  );
}

function System() {
  const { data, error } = useApi<SystemStatus>("/api/admin/system");
  const ready = useApi<{ status: string; checks: Record<string, string>; config_warnings: string[] }>("/ready");
  if (error) return <ErrorState error={error} />;
  if (!data) return <Loading />;
  const row = (label: string, value: string, ok: boolean, note?: string) => (
    <tr><td>{label}</td><td><Badge tone={ok ? "ok" : "warn"}>{value}</Badge></td><td className="small faint">{note}</td></tr>
  );
  return (
    <div className="grid g-2">
      <Panel tight title="AI capabilities in this deployment" sub="Nothing here is simulated: a capability shows as active only when it is configured">
        <table className="table"><tbody>
          {row("LLM", data.llm.configured ? data.llm.provider : "Not configured", data.llm.configured, data.llm.mode)}
          {row("Embeddings", data.embeddings.provider, true, data.embeddings.provider.startsWith("local") ? "Offline hashing embeddings (lexical similarity)" : "Semantic embeddings")}
          {row("Server transcription", data.transcription.server ? data.transcription.provider : "Not configured", data.transcription.server, data.transcription.browser_fallback)}
          {row("OCR", data.ocr.available ? "Tesseract" : "Not installed", data.ocr.available)}
          {row("Vector search", data.vector_backend, true)}
          {row("Knowledge graph", data.graph.primary, true, data.graph.neo4j_configured ? "Neo4j replica configured" : "Neo4j optional (not configured)")}
          {row("Object storage", data.storage, true)}
        </tbody></table>
      </Panel>
      <div className="stack">
        <Panel title="Readiness">
          {ready.data ? (
            <div className="stack-sm small">
              <div><Badge tone={ready.data.status === "ready" ? "ok" : "danger"}>{ready.data.status}</Badge> <span className="faint">v{data.app_version} · {data.environment}</span></div>
              {Object.entries(ready.data.checks).map(([k, v]) => <div key={k} className="row"><span className={cls("dot", v === "ok" ? "ok" : "danger")} />{k}: <span className="mono">{v}</span></div>)}
            </div>
          ) : <Loading />}
        </Panel>
        <Panel title="Configuration warnings">
          {data.config_problems.length ? <ul className="small" style={{ margin: 0, paddingLeft: 18 }}>{data.config_problems.map((p) => <li key={p}>{p}</li>)}</ul> : <span className="small faint">None — configuration is consistent.</span>}
        </Panel>
      </div>
    </div>
  );
}
