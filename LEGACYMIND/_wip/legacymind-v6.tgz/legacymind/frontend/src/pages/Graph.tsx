import { Download, Maximize2, Network } from "lucide-react";
import { useEffect, useMemo, useRef, useState, type PointerEvent as RPointerEvent, type WheelEvent } from "react";
import { useSearchParams } from "react-router-dom";
import { Badge, Empty, ErrorState, Loading, PageHead, Panel } from "../components/ui";
import { qs } from "../lib/api";
import { useAuth } from "../lib/auth";
import { titleCase } from "../lib/format";
import { useApi } from "../lib/hooks";
import type { Asset, GraphData, GraphNode } from "../lib/types";

const COLOR: Record<string, string> = {
  asset: "#35d0ff", component: "#7fa7c9", failure_mode: "#ff8a5b", symptom: "#ffb224", procedure: "#37c98a",
  safety: "#ff5b5b", record: "#a98bff", technician: "#c9d3dc",
};
const RADIUS: Record<string, number> = { asset: 16, failure_mode: 11, procedure: 11, symptom: 8, component: 7, safety: 8, record: 8, technician: 8 };
const LABEL: Record<string, string> = { asset: "Machine", component: "Component", failure_mode: "Failure mode", symptom: "Symptom", procedure: "Procedure", safety: "Safety warning", record: "Knowledge record", technician: "Technician" };

interface SimNode extends GraphNode { x: number; y: number; vx: number; vy: number; fixed?: boolean }

export default function Graph() {
  const [params, setParams] = useSearchParams();
  const { can } = useAuth();
  const assets = useApi<{ items: Asset[] }>("/api/assets");
  const tag = params.get("asset") ?? "";
  const asset = assets.data?.items.find((a) => a.asset_tag === tag || a.id === tag);
  const [pending, setPending] = useState(true);
  const path = assets.data ? `/api/graph${qs({ asset_id: asset?.id, include_pending: pending })}` : null;
  const { data, error, loading, reload } = useApi<GraphData>(path);

  return (
    <div className="stack" style={{ gap: 20 }}>
      <PageHead eyebrow="Knowledge graph" title="Machine → Failure → Procedure → Safety"
        actions={can("reports:export") && <a className="btn" href="/api/graph/cypher"><Download />Export Cypher (Neo4j)</a>}>
        The structured knowledge extracted from recordings, as a graph. Stored relationally in PostgreSQL{data?.neo4j_configured ? " and replicated to Neo4j" : "; Neo4j is an optional replica"}.
      </PageHead>
      <Panel tight title={
        <span className="row-wrap">
          <select className="select" style={{ width: 240, height: 32 }} value={asset?.asset_tag ?? ""} onChange={(e) => setParams(e.target.value ? { asset: e.target.value } : {})} aria-label="Machine">
            <option value="">Whole plant</option>
            {assets.data?.items.map((a) => <option key={a.id} value={a.asset_tag}>{a.asset_tag} · {a.name}</option>)}
          </select>
          <label className="row small muted" style={{ fontWeight: 400 }}><input type="checkbox" checked={pending} onChange={(e) => setPending(e.target.checked)} /> include pending review</label>
        </span>
      } actions={data && <span className="small faint mono">{data.nodes.length} nodes · {data.edges.length} edges · {data.backend}</span>}>
        {error && <div className="panel-body"><ErrorState error={error} onRetry={() => void reload()} /></div>}
        {loading && !data ? <Loading label="Building graph…" /> : data && data.nodes.length === 0 ? <Empty icon={<Network />} title="The graph is empty">Capture and process knowledge to grow the graph.</Empty> : data ? <GraphCanvas key={path} data={data} /> : null}
      </Panel>
    </div>
  );
}

function GraphCanvas({ data }: { data: GraphData }) {
  const W = 1200;
  const H = 640;
  const nodesRef = useRef<SimNode[]>([]);
  const [, force] = useState(0);
  const [view, setView] = useState({ x: 0, y: 0, k: 1 });
  const [sel, setSel] = useState<SimNode | null>(null);
  const drag = useRef<{ node?: SimNode; panX?: number; panY?: number; ox?: number; oy?: number; moved?: boolean } | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  const adj = useMemo(() => {
    const m = new Map<string, Set<string>>();
    data.edges.forEach((e) => {
      if (!m.has(e.source)) m.set(e.source, new Set());
      if (!m.has(e.target)) m.set(e.target, new Set());
      m.get(e.source)!.add(e.target);
      m.get(e.target)!.add(e.source);
    });
    return m;
  }, [data]);

  useEffect(() => {
    const assets = data.nodes.filter((n) => n.type === "asset");
    const anchor = new Map<string, { x: number; y: number }>();
    assets.forEach((a, i) => {
      const ang = (i / Math.max(1, assets.length)) * Math.PI * 2;
      const r = assets.length > 1 ? 260 : 0;
      anchor.set(a.id, { x: W / 2 + Math.cos(ang) * r, y: H / 2 + Math.sin(ang) * r * 0.75 });
    });
    nodesRef.current = data.nodes.map((n) => {
      const a = anchor.get(n.id);
      return { ...n, x: (a?.x ?? W / 2) + (Math.random() - 0.5) * 200, y: (a?.y ?? H / 2) + (Math.random() - 0.5) * 200, vx: 0, vy: 0 };
    });
    const idx = new Map(nodesRef.current.map((n, i) => [n.id, i]));
    const links = data.edges.map((e) => [idx.get(e.source)!, idx.get(e.target)!] as const).filter(([a, b]) => a !== undefined && b !== undefined);
    let alpha = 1;
    let raf = 0;
    const tick = () => {
      const ns = nodesRef.current;
      for (let i = 0; i < ns.length; i++) {
        for (let j = i + 1; j < ns.length; j++) {
          const a = ns[i]!, b = ns[j]!;
          let dx = b.x - a.x, dy = b.y - a.y;
          let d2 = dx * dx + dy * dy;
          if (d2 < 1) { dx = Math.random(); dy = Math.random(); d2 = 1; }
          const f = (1800 / d2) * alpha;
          const d = Math.sqrt(d2);
          a.vx -= (dx / d) * f; a.vy -= (dy / d) * f; b.vx += (dx / d) * f; b.vy += (dy / d) * f;
        }
      }
      for (const [ia, ib] of links) {
        const a = ns[ia]!, b = ns[ib]!;
        const dx = b.x - a.x, dy = b.y - a.y;
        const d = Math.sqrt(dx * dx + dy * dy) || 1;
        const target = a.type === "asset" || b.type === "asset" ? 90 : 62;
        const f = ((d - target) / d) * 0.06 * alpha;
        a.vx += dx * f; a.vy += dy * f; b.vx -= dx * f; b.vy -= dy * f;
      }
      for (const n of ns) {
        n.vx += (W / 2 - n.x) * 0.002 * alpha;
        n.vy += (H / 2 - n.y) * 0.002 * alpha;
        if (!n.fixed) { n.x += n.vx; n.y += n.vy; }
        n.vx *= 0.6; n.vy *= 0.6;
      }
      alpha *= 0.985;
      force((x) => x + 1);
      if (alpha > 0.02) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [data]);

  const toWorld = (cx: number, cy: number) => {
    const r = svgRef.current!.getBoundingClientRect();
    const sx = ((cx - r.left) / r.width) * W;
    const sy = ((cy - r.top) / r.height) * H;
    return { x: (sx - view.x) / view.k, y: (sy - view.y) / view.k };
  };
  const onDown = (e: RPointerEvent, node?: SimNode) => {
    e.stopPropagation();
    (e.target as Element).setPointerCapture?.(e.pointerId);
    drag.current = node ? { node, moved: false } : { panX: view.x, panY: view.y, ox: e.clientX, oy: e.clientY, moved: false };
    if (node) node.fixed = true;
  };
  const onMove = (e: RPointerEvent) => {
    const d = drag.current;
    if (!d) return;
    d.moved = true;
    if (d.node) {
      const p = toWorld(e.clientX, e.clientY);
      d.node.x = p.x; d.node.y = p.y;
      force((x) => x + 1);
    } else if (d.ox !== undefined) {
      const r = svgRef.current!.getBoundingClientRect();
      setView((v) => ({ ...v, x: d.panX! + ((e.clientX - d.ox!) / r.width) * W, y: d.panY! + ((e.clientY - d.oy!) / r.height) * H }));
    }
  };
  const onUp = () => {
    const d = drag.current;
    if (d?.node && !d.moved) setSel(d.node);
    if (d && !d.node && !d.moved) setSel(null);
    drag.current = null;
  };
  const onWheel = (e: WheelEvent) => {
    const r = svgRef.current!.getBoundingClientRect();
    const sx = ((e.clientX - r.left) / r.width) * W;
    const sy = ((e.clientY - r.top) / r.height) * H;
    const k = Math.min(3, Math.max(0.3, view.k * (e.deltaY < 0 ? 1.12 : 0.89)));
    setView((v) => ({ k, x: sx - ((sx - v.x) * k) / v.k, y: sy - ((sy - v.y) * k) / v.k }));
  };

  const ns = nodesRef.current;
  const byId = new Map(ns.map((n) => [n.id, n]));
  const hl = sel ? adj.get(sel.id) : null;
  const types = Array.from(new Set(data.nodes.map((n) => n.type)));

  return (
    <div className="graph-wrap">
      <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} onPointerDown={(e) => onDown(e)} onPointerMove={onMove} onPointerUp={onUp} onWheel={onWheel} role="img" aria-label="Knowledge graph">
        <defs>
          <marker id="arr" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#3a4552" /></marker>
        </defs>
        <g transform={`translate(${view.x},${view.y}) scale(${view.k})`}>
          {data.edges.map((e, i) => {
            const a = byId.get(e.source), b = byId.get(e.target);
            if (!a || !b) return null;
            const on = sel && (sel.id === a.id || sel.id === b.id);
            const conflict = e.type === "CONFLICTS_WITH";
            return <line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={conflict ? "#ffb224" : on ? "#35d0ff" : "#2c3540"} strokeWidth={conflict ? 2 : on ? 1.6 : 1} strokeDasharray={conflict ? "5 4" : undefined} opacity={sel && !on ? 0.25 : 0.9} markerEnd="url(#arr)" />;
          })}
          {ns.map((n) => {
            const r = RADIUS[n.type] ?? 8;
            const dim = sel && sel.id !== n.id && !hl?.has(n.id);
            return (
              <g key={n.id} className="graph-node" transform={`translate(${n.x},${n.y})`} opacity={dim ? 0.2 : 1} onPointerDown={(e) => onDown(e, n)} style={{ cursor: "pointer" }}>
                <circle r={r + 4} fill={COLOR[n.type]} opacity={sel?.id === n.id ? 0.25 : 0} />
                <circle r={r} fill="#0e1216" stroke={COLOR[n.type]} strokeWidth={n.type === "asset" ? 2.5 : 1.6} />
                {n.type === "asset" && <circle r={r - 6} fill={COLOR.asset} />}
                {(n.type === "asset" || n.type === "failure_mode" || n.type === "procedure" || view.k > 1.3 || sel?.id === n.id) && (
                  <text x={r + 5} y={4} style={{ fontWeight: n.type === "asset" ? 600 : 400, fill: n.type === "asset" ? "#e7ecf1" : undefined }}>{n.label.length > 40 ? n.label.slice(0, 38) + "…" : n.label}</text>
                )}
              </g>
            );
          })}
        </g>
      </svg>
      <div className="graph-legend">
        {types.map((t) => <span key={t}><i style={{ background: COLOR[t] }} />{LABEL[t] ?? t}</span>)}
        <span><i style={{ background: "transparent", border: "1.5px dashed #ffb224", borderRadius: 2 }} />Conflict</span>
      </div>
      <button className="btn sm" style={{ position: "absolute", left: 12, bottom: 12 }} onClick={() => setView({ x: 0, y: 0, k: 1 })}><Maximize2 />Reset view</button>
      {sel && (
        <div className="panel graph-inspector rise">
          <div className="panel-head"><span className="dot" style={{ background: COLOR[sel.type] }} /><strong className="small">{LABEL[sel.type]}</strong><div className="spacer" /><button className="btn ghost sm" onClick={() => setSel(null)}>Close</button></div>
          <div className="panel-body stack-sm small">
            <strong>{sel.label}</strong>
            {Object.entries(sel).filter(([k]) => !["id", "type", "label", "x", "y", "vx", "vy", "fixed"].includes(k)).map(([k, v]) => (
              <div key={k}>
                <span className="faint">{titleCase(k)}: </span>
                {Array.isArray(v) ? <ol style={{ margin: "4px 0 0", paddingLeft: 18 }}>{v.map((x) => <li key={String(x)}>{String(x)}</li>)}</ol> : <Badge>{String(v)}</Badge>}
              </div>
            ))}
            <div className="faint">{hl?.size ?? 0} connected node(s)</div>
          </div>
        </div>
      )}
    </div>
  );
}
