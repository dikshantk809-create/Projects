import { Bot, FileText, Mic, Printer, Sparkles, Upload, Wrench } from "lucide-react";
import { useRef, useState, type FormEvent } from "react";
import { Link, useParams } from "react-router-dom";
import { EvidencePlayer } from "../components/EvidencePlayer";
import { ProcedureCard } from "../components/ProcedureCard";
import { useToast } from "../components/toast";
import { Badge, Empty, ErrorState, Field, Loading, Modal, PageHead, Panel, StatusBadge, SyntheticBadge } from "../components/ui";
import { ApiError, api } from "../lib/api";
import { useAuth } from "../lib/auth";
import { cls, fmtBytes, fmtDate, fmtTs, titleCase } from "../lib/format";
import { useApi } from "../lib/hooks";
import type { Asset, DocumentOut, Procedure, RecordBrief, RecordingOut, SafetyOut } from "../lib/types";

interface AssetPage {
  asset: Asset;
  components: { id: string; name: string; tag: string }[];
  procedures: Procedure[];
  failure_modes: { id: string; name: string; causes: string[]; symptoms: string[]; is_rare: boolean }[];
  records: RecordBrief[];
  recordings: (RecordingOut & { record: RecordBrief })[];
  documents: DocumentOut[];
  maintenance_history: { id: string; occurred_on: string; event_type: string; summary: string; downtime_hours: number | null }[];
  safety_warnings: SafetyOut[];
  qr_url: string;
}

type Tab = "procedures" | "failures" | "recordings" | "documents" | "history";

export default function AssetDetail() {
  const { assetId = "" } = useParams();
  const { can } = useAuth();
  const { data, error, loading, reload } = useApi<AssetPage>(`/api/assets/${encodeURIComponent(assetId)}`);
  const [tab, setTab] = useState<Tab>("procedures");
  const [qrOpen, setQrOpen] = useState(false);

  if (loading && !data) return <Loading />;
  if (error) return <ErrorState error={error} onRetry={() => void reload()} />;
  if (!data) return null;
  const a = data.asset;
  const qrSrc = `${data.qr_url}?base_url=${encodeURIComponent(window.location.origin)}`;
  const tabs: [Tab, string, number][] = [
    ["procedures", "Procedures", data.procedures.length],
    ["failures", "Known failure modes", data.failure_modes.length],
    ["recordings", "Expert recordings", data.recordings.length + data.records.filter((r) => r.source_type === "interview").length],
    ["documents", "Documents", data.documents.length],
    ["history", "Maintenance history", data.maintenance_history.length],
  ];

  return (
    <div className="stack" style={{ gap: 20 }}>
      <PageHead eyebrow={`Asset · ${a.department ?? "Unassigned"}`} title={`${a.asset_tag} · ${a.name}`}
        actions={
          <>
            {can("assistant:use") && <Link className="btn primary" to={`/app/assistant?asset=${a.id}`}><Bot />Ask about this machine</Link>}
            {can("knowledge:capture") && <Link className="btn" to={`/app/capture?asset=${a.id}`}><Mic />Capture knowledge</Link>}
            {can("harvest:run") && <Link className="btn" to={`/app/harvest?asset=${a.id}`}><Sparkles />Harvest interview</Link>}
          </>
        }>
        {a.description}
      </PageHead>

      <div className="split">
        <Panel title="Machine information" actions={a.is_synthetic ? <SyntheticBadge /> : undefined}>
          <div className="row" style={{ alignItems: "flex-start", gap: 24, flexWrap: "wrap" }}>
            <dl className="kv" style={{ flex: "1 1 320px" }}>
              <dt>Asset ID</dt><dd><span className="tag">{a.asset_tag}</span></dd>
              <dt>Machine</dt><dd>{a.name} <span className="faint">· {a.machine_type}</span></dd>
              <dt>Manufacturer</dt><dd>{a.manufacturer || "—"}</dd>
              <dt>Model</dt><dd className="mono">{a.model || "—"}</dd>
              <dt>Serial number</dt><dd className="mono">{a.serial_number || "—"}</dd>
              <dt>Department</dt><dd>{a.department ?? "—"}</dd>
              <dt>Location</dt><dd>{a.location || "—"}</dd>
              <dt>Installed</dt><dd>{fmtDate(a.installed_on)}</dd>
              <dt>Status</dt><dd className="row"><span className={cls("dot", a.status === "operational" ? "ok" : a.status === "down" ? "danger" : a.status === "degraded" ? "warn" : "idle")} /><StatusBadge status={a.status} /></dd>
              <dt>Criticality</dt><dd><Badge tone={a.criticality === "critical" ? "danger" : a.criticality === "high" ? "warn" : undefined}>{a.criticality}</Badge></dd>
              {data.components.length > 0 && (<><dt>Components</dt><dd className="row-wrap">{data.components.map((c) => <Badge key={c.id}>{c.name}</Badge>)}</dd></>)}
            </dl>
            <div className="stack-sm" style={{ alignItems: "center" }}>
              <div className="qr-box"><img src={qrSrc} alt={`QR code for ${a.asset_tag}`} /></div>
              <span className="tiny faint">Scan to open this page</span>
              <button className="btn sm" onClick={() => setQrOpen(true)}><Printer />Print label</button>
            </div>
          </div>
        </Panel>
        <Panel title="Approved safety warnings" sub="Pulled from supervisor-approved knowledge" tight>
          {data.safety_warnings.length === 0 ? <Empty title="No approved safety warnings yet">Capture and approve knowledge for this machine to populate safety guidance.</Empty> : (
            <div className="panel-body stack-sm">
              {data.safety_warnings.map((w) => <div key={w.id} className={cls("safety-card small", w.severity === "danger" && "danger")}><Wrench size={16} />{w.text}</div>)}
            </div>
          )}
        </Panel>
      </div>

      <div>
        <div className="tabs" role="tablist">
          {tabs.map(([k, l, n]) => <button key={k} role="tab" aria-selected={tab === k} className={cls("tab", tab === k && "active")} onClick={() => setTab(k)}>{l}<span className="n">{n}</span></button>)}
        </div>
        {tab === "procedures" && (
          data.procedures.length === 0 ? <Panel><Empty title="No procedures yet">Record a senior technician explaining how they troubleshoot this machine — LegacyMind will turn it into a procedure card for review.</Empty></Panel> :
            <div className="stack">{data.procedures.map((p, i) => <ProcedureCard key={p.id} p={p} defaultOpen={i === 0} />)}</div>
        )}
        {tab === "failures" && (
          <Panel tight>
            {data.failure_modes.length === 0 ? <Empty title="No failure modes captured" /> : (
              <table className="table">
                <thead><tr><th>Failure mode</th><th>Symptoms</th><th>Causes (as stated by technicians)</th></tr></thead>
                <tbody>{data.failure_modes.map((f) => (
                  <tr key={f.id}><td style={{ fontWeight: 500, textTransform: "capitalize" }}>{f.name}</td><td className="row-wrap">{f.symptoms.map((s) => <Badge key={s} tone="warn">{s}</Badge>)}</td><td className="small muted">{f.causes.join("; ") || "—"}</td></tr>
                ))}</tbody>
              </table>
            )}
          </Panel>
        )}
        {tab === "recordings" && <Recordings data={data} />}
        {tab === "documents" && <Documents asset={a} docs={data.documents} onUploaded={() => void reload()} />}
        {tab === "history" && <History asset={a} events={data.maintenance_history} onAdded={() => void reload()} />}
      </div>

      {qrOpen && (
        <Modal title="QR label" onClose={() => setQrOpen(false)} footer={<button className="btn primary" onClick={() => window.print()}><Printer />Print</button>}>
          <div className="stack" style={{ alignItems: "center", background: "#fff", color: "#000", padding: 24, borderRadius: 8 }}>
            <img src={qrSrc} alt="" style={{ width: 220, height: 220 }} />
            <div style={{ fontFamily: "var(--mono)", fontSize: 22, fontWeight: 600 }}>{a.asset_tag}</div>
            <div>{a.name} · {a.location}</div>
            <div style={{ fontSize: 11 }}>Scan with LegacyMind for procedures and expert knowledge</div>
          </div>
        </Modal>
      )}
    </div>
  );
}

function Recordings({ data }: { data: AssetPage }) {
  const media = data.records.filter((r) => ["audio", "video", "interview"].includes(r.source_type));
  if (!media.length) return <Panel><Empty icon={<Mic />} title="No expert recordings yet" /></Panel>;
  return (
    <Panel tight>
      {media.map((r) => {
        const rec = data.recordings.find((x) => x.record.id === r.id);
        return (
          <div key={r.id} className="list-item">
            <Mic size={16} className="faint" style={{ marginTop: 3 }} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="row-wrap"><Link to={`/app/library/${r.ref}`}><strong>{r.title}</strong></Link><span className="mono tiny faint">{r.ref}</span>{r.is_synthetic && <SyntheticBadge />}<StatusBadge status={r.review_status} /></div>
              <div className="small faint">{r.contributor?.full_name} · {fmtDate(r.recorded_at)} · {titleCase(r.source_type)}{rec?.duration_s ? ` · ${fmtTs(rec.duration_s)}` : ""}</div>
            </div>
            <EvidencePlayer recordingId={rec?.id ?? null} playable={!!rec?.has_file} start={0} end={null} quote={r.summary} synthetic={r.is_synthetic} sourceType={r.source_type} />
          </div>
        );
      })}
    </Panel>
  );
}

function Documents({ asset, docs, onUploaded }: { asset: Asset; docs: DocumentOut[]; onUploaded: () => void }) {
  const { can } = useAuth();
  const toast = useToast();
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [category, setCategory] = useState("manual");
  const upload = async (file: File) => {
    const fd = new FormData();
    fd.append("file", file);
    fd.append("category", category);
    setBusy(true);
    try {
      await api.post(`/api/assets/${asset.id}/documents`, fd, { timeout: 120_000 });
      toast.ok(`${file.name} uploaded`);
      onUploaded();
    } catch (e) {
      toast.error(e);
    } finally {
      setBusy(false);
      if (input.current) input.current.value = "";
    }
  };
  return (
    <Panel tight actions={can("knowledge:capture") && (
      <div className="row">
        <select className="select" style={{ width: 160, height: 32 }} value={category} onChange={(e) => setCategory(e.target.value)} aria-label="Document category">
          {["manual", "machine", "part", "fault", "wiring", "control_panel", "other"].map((c) => <option key={c} value={c}>{titleCase(c)}</option>)}
        </select>
        <button className="btn sm" disabled={busy} onClick={() => input.current?.click()}><Upload />{busy ? "Uploading…" : "Upload"}</button>
        <input ref={input} type="file" hidden accept=".pdf,.docx,.txt,.png,.jpg,.jpeg,.webp" onChange={(e) => e.target.files?.[0] && void upload(e.target.files[0])} />
      </div>
    )} title="Associated documents">
      {docs.length === 0 ? <Empty icon={<FileText />} title="No documents">Upload manuals, wiring diagrams, fault photos or control-panel images.</Empty> : (
        <table className="table">
          <thead><tr><th>File</th><th>Category</th><th>Size</th><th>Text extraction</th><th>Added</th></tr></thead>
          <tbody>{docs.map((d) => (
            <tr key={d.id}>
              <td><a href={d.url} target="_blank" rel="noreferrer">{d.filename}</a></td>
              <td><Badge>{titleCase(d.category || d.kind)}</Badge></td>
              <td className="mono small">{fmtBytes(d.size_bytes)}</td>
              <td className="small muted">{d.extraction_method === "ocr-unavailable" ? "Stored (OCR not installed)" : d.extraction_method || "—"}</td>
              <td className="small faint">{fmtDate(d.created_at)}</td>
            </tr>
          ))}</tbody>
        </table>
      )}
    </Panel>
  );
}

function History({ asset, events, onAdded }: { asset: Asset; events: AssetPage["maintenance_history"]; onAdded: () => void }) {
  const { can } = useAuth();
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ occurred_on: new Date().toISOString().slice(0, 10), event_type: "corrective", summary: "", downtime_hours: "" });
  const [err, setErr] = useState<ApiError | null>(null);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    try {
      await api.post(`/api/assets/${asset.id}/events`, { ...f, downtime_hours: f.downtime_hours ? Number(f.downtime_hours) : null });
      toast.ok("Maintenance event logged");
      setOpen(false);
      onAdded();
    } catch (x) {
      setErr(x as ApiError);
    }
  };
  return (
    <Panel tight title="Maintenance history" actions={can("knowledge:capture") && <button className="btn sm" onClick={() => setOpen(true)}>Log event</button>}>
      {events.length === 0 ? <Empty title="No maintenance events" /> : (
        <table className="table">
          <thead><tr><th>Date</th><th>Type</th><th>Summary</th><th>Downtime</th></tr></thead>
          <tbody>{events.map((e) => (
            <tr key={e.id}><td className="mono small nowrap">{e.occurred_on}</td><td><Badge tone={e.event_type === "breakdown" ? "danger" : e.event_type === "corrective" ? "warn" : "info"}>{e.event_type}</Badge></td><td>{e.summary}</td><td className="mono small">{e.downtime_hours ?? "—"} h</td></tr>
          ))}</tbody>
        </table>
      )}
      {open && (
        <Modal title={`Log event · ${asset.asset_tag}`} onClose={() => setOpen(false)} footer={<><button className="btn ghost" onClick={() => setOpen(false)}>Cancel</button><button className="btn primary" form="ev-form" disabled={f.summary.length < 3}>Save</button></>}>
          <form id="ev-form" className="stack" onSubmit={submit}>
            {err && <ErrorState error={err} />}
            <div className="grid g-2">
              <Field label="Date"><input className="input" type="date" value={f.occurred_on} onChange={(e) => setF({ ...f, occurred_on: e.target.value })} /></Field>
              <Field label="Type"><select className="select" value={f.event_type} onChange={(e) => setF({ ...f, event_type: e.target.value })}>{["corrective", "preventive", "inspection", "breakdown", "modification"].map((t) => <option key={t}>{t}</option>)}</select></Field>
            </div>
            <Field label="Summary"><textarea className="textarea" value={f.summary} onChange={(e) => setF({ ...f, summary: e.target.value })} /></Field>
            <Field label="Downtime (hours)"><input className="input" type="number" min={0} step={0.5} value={f.downtime_hours} onChange={(e) => setF({ ...f, downtime_hours: e.target.value })} /></Field>
          </form>
        </Modal>
      )}
    </Panel>
  );
}
