import { BookOpen, Search } from "lucide-react";
import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { ProcedureCard } from "../components/ProcedureCard";
import { Badge, Empty, ErrorState, Loading, PageHead, Panel, StatusBadge } from "../components/ui";
import { qs } from "../lib/api";
import { useAuth } from "../lib/auth";
import { SOURCE_LABEL, cls, fmtDate, titleCase } from "../lib/format";
import { useApi, useDebounced } from "../lib/hooks";
import type { Procedure, RecordBrief } from "../lib/types";

interface Facets {
  technicians: { id: string; name: string }[]; failure_modes: string[]; departments: { id: string; name: string }[];
  assets: { id: string; asset_tag: string; name: string }[]; review_statuses: string[]; source_types: string[];
}

export default function Library() {
  const [params, setParams] = useSearchParams();
  const tab = params.get("procedure") || params.get("tab") === "procedures" ? "procedures" : "records";
  return (
    <div className="stack" style={{ gap: 20 }}>
      <PageHead eyebrow="Knowledge base" title="Knowledge Library">
        Every captured recording, document, note and interview — and the procedure cards the AI structured from them.
      </PageHead>
      <div className="tabs" role="tablist">
        <button role="tab" aria-selected={tab === "records"} className={cls("tab", tab === "records" && "active")} onClick={() => setParams({})}>Knowledge records</button>
        <button role="tab" aria-selected={tab === "procedures"} className={cls("tab", tab === "procedures" && "active")} onClick={() => setParams({ tab: "procedures" })}>Procedure cards</button>
      </div>
      {tab === "records" ? <Records /> : <Procedures initial={params.get("procedure") ?? ""} />}
    </div>
  );
}

function Records() {
  const { session } = useAuth();
  const nav = useNavigate();
  const facets = useApi<Facets>("/api/knowledge/facets");
  const [f, setF] = useState({ q: "", asset_id: "", technician_id: "", failure_mode: "", department_id: "", review_status: "", source_type: "", date_from: "", date_to: "" });
  const dq = useDebounced(f.q);
  const dfm = useDebounced(f.failure_mode);
  const { data, error, loading, reload } = useApi<{ items: RecordBrief[]; total: number }>(`/api/knowledge/records${qs({ ...f, q: dq, failure_mode: dfm, limit: 100 })}`);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setF({ ...f, [k]: e.target.value });
  const junior = session?.user.role === "junior_technician";
  const active = Object.entries(f).filter(([k, v]) => v && k !== "q").length;

  return (
    <div className="stack">
      <Panel>
        <div className="grid g-4">
          <div className="search" style={{ gridColumn: "span 2" }}><Search /><input className="input" placeholder="Search titles, transcripts, record IDs…" value={f.q} onChange={set("q")} aria-label="Search knowledge" /></div>
          <select className="select" value={f.asset_id} onChange={set("asset_id")} aria-label="Machine"><option value="">All machines</option>{facets.data?.assets.map((a) => <option key={a.id} value={a.id}>{a.asset_tag} · {a.name}</option>)}</select>
          <select className="select" value={f.technician_id} onChange={set("technician_id")} aria-label="Technician"><option value="">All technicians</option>{facets.data?.technicians.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select>
          <input className="input" list="fm-list" placeholder="Failure mode…" value={f.failure_mode} onChange={set("failure_mode")} aria-label="Failure mode" />
          <datalist id="fm-list">{facets.data?.failure_modes.map((m) => <option key={m} value={m} />)}</datalist>
          <select className="select" value={f.department_id} onChange={set("department_id")} aria-label="Department"><option value="">All departments</option>{facets.data?.departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select>
          {!junior && <select className="select" value={f.review_status} onChange={set("review_status")} aria-label="Approval status"><option value="">Any approval status</option>{facets.data?.review_statuses.map((s) => <option key={s} value={s}>{titleCase(s)}</option>)}</select>}
          <select className="select" value={f.source_type} onChange={set("source_type")} aria-label="Source type"><option value="">All source types</option>{facets.data?.source_types.map((s) => <option key={s} value={s}>{SOURCE_LABEL[s] ?? s}</option>)}</select>
          <input className="input" type="date" value={f.date_from} onChange={set("date_from")} aria-label="From date" />
          <input className="input" type="date" value={f.date_to} onChange={set("date_to")} aria-label="To date" />
        </div>
        {(active > 0 || f.q) && <div className="row mt-12 small"><span className="faint">{data?.total ?? 0} result(s)</span><button className="btn ghost sm" onClick={() => setF({ q: "", asset_id: "", technician_id: "", failure_mode: "", department_id: "", review_status: "", source_type: "", date_from: "", date_to: "" })}>Clear filters</button></div>}
      </Panel>
      {error && <ErrorState error={error} onRetry={() => void reload()} />}
      <Panel tight>
        {loading && !data ? <Loading /> : !data?.items.length ? (
          <Empty icon={<BookOpen />} title="No knowledge records found">{active || f.q ? "Try widening your filters." : "Capture the first piece of knowledge from the Knowledge Capture page."}</Empty>
        ) : (
          <div className="table-wrap">
            <table className="table">
              <thead><tr><th>Record</th><th>Title</th><th>Machine</th><th>Contributor</th><th>Source</th><th>Recorded</th><th>Processing</th><th>Approval</th></tr></thead>
              <tbody>
                {data.items.map((r) => (
                  <tr key={r.id} className="click" onClick={() => nav(`/app/library/${r.ref}`)}>
                    <td className="mono small"><Link to={`/app/library/${r.ref}`} onClick={(e) => e.stopPropagation()}>{r.ref}</Link></td>
                    <td><div style={{ fontWeight: 500 }}>{r.title}</div>{r.is_synthetic && <span className="badge synthetic" style={{ marginTop: 4 }}>SYNTHETIC</span>}</td>
                    <td>{r.asset ? <span className="tag">{r.asset.asset_tag}</span> : <span className="faint small">unmapped</span>}</td>
                    <td className="small">{r.contributor?.full_name ?? "—"}</td>
                    <td><Badge>{SOURCE_LABEL[r.source_type] ?? r.source_type}</Badge></td>
                    <td className="small faint nowrap">{fmtDate(r.recorded_at)}</td>
                    <td><StatusBadge status={r.processing_status} /></td>
                    <td><StatusBadge status={r.review_status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </div>
  );
}

function Procedures({ initial }: { initial: string }) {
  const [q, setQ] = useState(initial);
  const dq = useDebounced(q);
  const { data, error, loading, reload } = useApi<{ items: Procedure[] }>(`/api/knowledge/procedures${qs({ q: dq })}`);
  return (
    <div className="stack">
      <div className="search" style={{ maxWidth: 420 }}><Search /><input className="input" placeholder="Search procedures by title or ID (e.g. PR-103-01)…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search procedures" /></div>
      {error && <ErrorState error={error} onRetry={() => void reload()} />}
      {loading && !data ? <Loading /> : !data?.items.length ? <Panel><Empty title="No procedure cards match" /></Panel> : (
        <div className="stack">{data.items.map((p) => <ProcedureCard key={p.id} p={p} defaultOpen={!!initial && p.ref === initial} />)}</div>
      )}
    </div>
  );
}
