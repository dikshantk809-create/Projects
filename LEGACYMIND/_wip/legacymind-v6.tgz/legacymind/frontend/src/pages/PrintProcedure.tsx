import { Printer } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";
import { ErrorState, Loading } from "../components/ui";
import { fmtDate, fmtTs } from "../lib/format";
import { useApi } from "../lib/hooks";
import type { Procedure, RecordBrief, SafetyOut } from "../lib/types";

type Full = Procedure & { safety_warnings: SafetyOut[]; record: RecordBrief | null };

/** A printable A4 procedure card to laminate and hang on the machine (with its QR code). */
export default function PrintProcedure() {
  const { procedureId = "" } = useParams();
  const nav = useNavigate();
  const { data: p, error, loading } = useApi<Full>(`/api/knowledge/procedures/${encodeURIComponent(procedureId)}`);
  if (loading && !p) return <Loading />;
  if (error) return <ErrorState error={error} />;
  if (!p) return null;
  const qr = p.asset ? `/api/assets/${p.asset.id}/qr.svg?base_url=${encodeURIComponent(window.location.origin)}` : null;
  return (
    <div className="stack">
      <div className="row no-print">
        <button className="btn ghost" onClick={() => nav(-1)}>Back</button>
        <div className="spacer" />
        <button className="btn primary" onClick={() => window.print()}><Printer />Print</button>
      </div>
      <article className="print-card">
        <header className="print-head">
          <div>
            <div className="print-eyebrow">LEGACYMIND · MAINTENANCE PROCEDURE CARD {p.is_synthetic ? "· SYNTHETIC DEMO DATA" : ""}</div>
            <h1>{p.title}</h1>
            <div className="print-meta">
              <span><b>{p.ref}</b> v{p.version}</span>
              {p.asset && <span>Machine: <b>{p.asset.asset_tag}</b> {p.asset.name}</span>}
              <span>Risk: <b>{p.risk_level.toUpperCase()}</b></span>
              <span>Status: <b>{p.status.replace("_", " ")}</b></span>
            </div>
          </div>
          {qr && <img src={qr} alt="" className="print-qr" />}
        </header>
        {p.status !== "approved" && <div className="print-warn">NOT APPROVED — do not use until a supervisor approves this procedure.</div>}
        {p.symptoms.length > 0 && <p><b>Symptoms:</b> {p.symptoms.join(", ")}</p>}
        {p.safety_warnings.filter((w) => w.status === "approved").length > 0 && (
          <section className="print-safety">
            <h2>⚠ SAFETY — before you start</h2>
            <ul>{p.safety_warnings.filter((w) => w.status === "approved").map((w) => <li key={w.id}>{w.text}</li>)}</ul>
            <p>Follow your plant's approved lockout/tagout and permit-to-work procedure.</p>
          </section>
        )}
        <section>
          <h2>Steps</h2>
          <ol className="print-steps">
            {p.steps.map((s) => (
              <li key={s.order}>
                <span className="box" />
                <div>{s.text}{s.source?.start !== null && s.source?.start !== undefined && <span className="print-src"> [source {fmtTs(s.source.start)}]</span>}</div>
              </li>
            ))}
          </ol>
        </section>
        {(p.tools.length > 0 || p.parts.length > 0) && <p>{p.tools.length > 0 && <><b>Tools:</b> {p.tools.join(", ")}. </>}{p.parts.length > 0 && <><b>Parts:</b> {p.parts.join(", ")}.</>}</p>}
        <footer className="print-foot">
          <span>Source: {p.record ? `${p.record.ref} — ${p.record.contributor?.full_name ?? ""}, recorded ${fmtDate(p.record.recorded_at)}` : "—"}</span>
          <span>Approved by: {p.approved_by ? `${p.approved_by.full_name}, ${fmtDate(p.approved_at)}` : "—"}</span>
          <span>Printed {fmtDate(new Date().toISOString(), true)} · scan the QR code for the latest version and the expert's recording</span>
        </footer>
      </article>
    </div>
  );
}
