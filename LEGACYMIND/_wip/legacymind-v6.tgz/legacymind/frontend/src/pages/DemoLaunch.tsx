import { ArrowRight, ClipboardCheck, FlaskConical, HardHat, Mic, UserCog } from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Brand } from "../components/Logo";
import { ErrorState, Loading } from "../components/ui";
import { ApiError, api } from "../lib/api";
import { useAuth } from "../lib/auth";

interface DemoInfo { enabled: boolean; factory?: string; personas?: { key: string; email: string; full_name: string; title: string; role: string }[] }

const ICON: Record<string, ReactNode> = { senior: <Mic />, supervisor: <ClipboardCheck />, junior: <HardHat />, admin: <UserCog /> };
const WHY: Record<string, string> = {
  supervisor: "Recommended for judges — sees the whole story: capture, AI extraction, graph, assistant, review and conflicts.",
  junior: "Ask troubleshooting questions and get grounded answers with the expert’s original recording.",
  senior: "Record knowledge and run a Knowledge Harvest interview.",
  admin: "Assets, users, departments, analytics and audit log.",
};

export default function DemoLaunch() {
  const { launchDemo } = useAuth();
  const nav = useNavigate();
  const [info, setInfo] = useState<DemoInfo | null>(null);
  const [error, setError] = useState<ApiError | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => {
    api.get<DemoInfo>("/api/demo").then(setInfo).catch((e) => setError(e as ApiError));
  }, []);

  const go = async (persona: string) => {
    setBusy(persona);
    setError(null);
    try {
      await launchDemo(persona);
      nav(persona === "junior" ? "/app/assistant?tour=1" : "/app?tour=1", { replace: true });
    } catch (e) {
      setError(e as ApiError);
      setBusy(null);
    }
  };

  const order = ["supervisor", "junior", "senior", "admin"];
  return (
    <div style={{ minHeight: "100vh", padding: "40px 20px" }}>
      <div style={{ maxWidth: 860, margin: "0 auto" }} className="stack">
        <Link to="/" className="brand" style={{ padding: 0 }}><Brand /></Link>
        <div className="mt-16">
          <div className="eyebrow">Launch Demo</div>
          <h1 style={{ fontSize: 32 }}>NovaTech Manufacturing Plant</h1>
          <p className="muted mt-8">A fictional plant with a hydraulic press, pump, CNC machine, conveyor and compressor — and three technicians. Choose who you want to be.</p>
        </div>
        <div className="notice"><FlaskConical style={{ color: "#c9a7ff" }} /><span><strong>Synthetic Demo Data.</strong> Every person, machine, recording and maintenance record in this demo is fictional and labelled as such. Demo recordings have transcripts but no real audio; playback uses your browser’s synthetic voice.</span></div>
        {error && <ErrorState error={error} />}
        {!info && !error && <Loading />}
        {info && !info.enabled && <ErrorState error={new ApiError(404, "demo_disabled", "Demo mode is disabled on this deployment.")} />}
        {info?.enabled && (
          <div className="grid g-2">
            {order.map((k) => {
              const p = info.personas?.find((x) => x.key === k);
              if (!p) return null;
              return (
                <button key={k} className="persona" disabled={!!busy} onClick={() => void go(k)} style={k === "supervisor" ? { borderColor: "var(--accent-line)" } : undefined}>
                  <div className="avatar" style={{ width: 40, height: 40, color: "var(--accent)" }}>{ICON[k]}</div>
                  <div style={{ flex: 1 }}>
                    <div className="row"><strong>{p.full_name}</strong>{k === "supervisor" && <span className="badge accent">Start here</span>}</div>
                    <div className="small faint">{p.title}</div>
                    <div className="small muted mt-8">{WHY[k]}</div>
                  </div>
                  {busy === k ? <div className="spinner" /> : <ArrowRight className="faint" />}
                </button>
              );
            })}
          </div>
        )}
        {busy && <p className="small faint">Preparing the synthetic factory (first launch runs the real extraction pipeline over the demo recordings)…</p>}
      </div>
    </div>
  );
}
