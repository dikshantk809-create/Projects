import {
  ArrowRight, AudioLines, BadgeCheck, Brain, ClipboardCheck, Database, FileSearch, GitCompareArrows, HardHat, Lock, Network, PlayCircle,
  QrCode, ScanSearch, ServerCog, ShieldCheck, Sparkles, UserCog, Users,
} from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Brand } from "../components/Logo";
import { useAuth } from "../lib/auth";

const FLOW = [
  ["01", "Capture", "Voice, video, photos, manuals and notes recorded on the shop floor."],
  ["02", "Transcribe", "Speech-to-text with timestamps so every fact points back to the second it was said."],
  ["03", "Extract", "Machines, components, symptoms, failure modes, steps, tools, parts and safety warnings."],
  ["04", "Structure", "Procedure cards and a knowledge graph linked to the plant asset registry."],
  ["05", "Review", "Supervisors approve, edit or reject — and resolve conflicting procedures."],
  ["06", "Retrieve", "Hybrid vector + keyword + graph search over approved knowledge only."],
  ["07", "Answer", "Grounded steps with citations, source playback, safety and escalation."],
];

const CAPS = [
  [<AudioLines key="i" />, "Zero-friction capture", "Technicians talk while they work. No forms, no documentation backlog — the AI does the structuring."],
  [<Sparkles key="i" />, "Knowledge Harvest interviews", "An AI interviewer asks follow-ups (“what would a junior check first?”) and tracks coverage gaps per machine."],
  [<Network key="i" />, "Industrial knowledge graph", "Machine → component → failure mode → symptom → procedure → safety, queryable and exportable to Neo4j."],
  [<FileSearch key="i" />, "Hybrid grounded retrieval", "Semantic vectors, exact tag matching (P-103, V-03) and graph traversal fused with reciprocal-rank fusion."],
  [<BadgeCheck key="i" />, "Evidence on every answer", "Technician, recording date and timestamp for each step. One click plays the original expert explanation."],
  [<GitCompareArrows key="i" />, "Conflict detection", "When two experts disagree, LegacyMind flags it for supervisor review instead of silently choosing."],
];

export function Landing() {
  const { session } = useAuth();
  const nav = useNavigate();
  return (
    <div>
      <nav className="pub-nav">
        <Link to="/" className="brand" style={{ padding: 0 }}><Brand sub={false} /></Link>
        <div className="links">
          <a href="#problem">Problem</a><a href="#how">How it works</a><a href="#capabilities">Capabilities</a>
          <a href="#architecture">Architecture</a><a href="#security">Security</a><a href="#roi">ROI</a><a href="#faq">FAQ</a>
        </div>
        <div className="spacer" />
        {session ? (
          <Link className="btn primary sm" to="/app">Open console <ArrowRight /></Link>
        ) : (
          <>
            <Link className="btn ghost sm" to="/login">Sign in</Link>
            <Link className="btn primary sm" to="/demo">Launch Demo</Link>
          </>
        )}
      </nav>

      <header className="hero">
        <div className="hero-inner">
          <div>
            <div className="eyebrow">Industrial tribal-knowledge capture</div>
            <h1>Your Factory Has 30 Years of Knowledge. <em>Don’t Let It Retire.</em></h1>
            <p className="lead">LegacyMind captures expert maintenance knowledge and turns it into a searchable industrial AI brain — with every answer traced back to the technician who said it.</p>
            <div className="hero-ctas">
              <button className="btn primary lg" onClick={() => nav(session ? "/app/capture" : "/login?next=/app/capture")}>Start Knowledge Capture <ArrowRight /></button>
              <Link className="btn lg" to="/demo"><PlayCircle /> Explore Demo</Link>
            </div>
            <div className="hero-meta">
              <span><span className="dot ok" /> Source-grounded answers</span>
              <span><span className="dot ok" /> Human-in-the-loop approval</span>
              <span><span className="dot ok" /> Cloud or on-prem design</span>
            </div>
          </div>
          <HeroConsole />
        </div>
      </header>

      <section className="section" id="problem">
        <div className="section-inner">
          <div className="eyebrow">The problem</div>
          <h2 className="big">When a senior technician retires, the plant loses knowledge nobody wrote down.</h2>
          <p className="lead">The sound a pump makes before a valve blocks. Which check to do first. The mistake every new technician makes. This knowledge lives in people, not in CMMS systems — and it walks out of the gate on their last day.</p>
          <div className="grid g-3 mt-24">
            <div className="panel feature"><div className="ic"><Users /></div><h3>Undocumented expertise</h3><p>Troubleshooting know-how is tacit: learned by ear and by feel over decades, rarely captured in manuals.</p></div>
            <div className="panel feature"><div className="ic"><ClipboardCheck /></div><h3>Documentation never happens</h3><p>Writing procedures competes with keeping machines running. Technicians talk; they don’t write reports.</p></div>
            <div className="panel feature"><div className="ic"><HardHat /></div><h3>Juniors guess — and replace parts</h3><p>Without the expert’s shortcut, diagnosis takes longer and good parts get replaced “just in case”.</p></div>
          </div>
        </div>
      </section>

      <section className="section" id="how">
        <div className="section-inner">
          <div className="eyebrow">How it works</div>
          <h2 className="big">Talk → Work → Record → AI structures the knowledge. Then: Ask → Retrieve → Verify → Learn.</h2>
          <div className="flow">
            {FLOW.map(([n, t, d]) => (
              <div key={n} className="flow-step"><div className="n">{n}</div><h4>{t}</h4><p>{d}</p></div>
            ))}
          </div>
        </div>
      </section>

      <section className="section" id="capabilities">
        <div className="section-inner">
          <div className="eyebrow">AI capabilities</div>
          <h2 className="big">A genuine knowledge system — not a chatbot over PDFs.</h2>
          <div className="grid g-3 mt-24">
            {CAPS.map(([ic, t, d]) => (
              <div key={t as string} className="panel feature"><div className="ic">{ic}</div><h3>{t}</h3><p>{d}</p></div>
            ))}
          </div>
          <div className="notice mt-24" style={{ maxWidth: 900 }}>
            <ShieldCheck style={{ color: "var(--ok)" }} />
            <span>LegacyMind prefers <strong>“I don’t have enough verified information”</strong> over a confident guess. Questions about a named machine are answered only from that machine’s approved knowledge, safety warnings come from the database (never generated), and unsupported AI steps are removed before you see them.</span>
          </div>
        </div>
      </section>

      <section className="section" id="workflow">
        <div className="section-inner">
          <div className="eyebrow">Industrial workflow</div>
          <h2 className="big">Built around the four people who keep a plant running.</h2>
          <div className="grid g-4 mt-24">
            {[
              [<AudioLines key="i" />, "Senior technician", "Records knowledge by voice, uploads photos and manuals, answers Knowledge Harvest interviews."],
              [<QrCode key="i" />, "Junior technician", "Scans a machine’s QR code, asks what to check, watches the expert’s original explanation."],
              [<ClipboardCheck key="i" />, "Maintenance supervisor", "Approves AI-generated procedure cards, resolves conflicts, signs off high-risk procedures."],
              [<UserCog key="i" />, "Plant administrator", "Manages assets, users, departments and permissions; tracks knowledge coverage and risk."],
            ].map(([ic, t, d]) => (
              <div key={t as string} className="panel feature"><div className="ic">{ic}</div><h3>{t}</h3><p>{d}</p></div>
            ))}
          </div>
        </div>
      </section>

      <section className="section" id="architecture">
        <div className="section-inner">
          <div className="eyebrow">Architecture</div>
          <h2 className="big">Production architecture, deployable in the cloud or inside the factory network.</h2>
          <div className="grid g-2 mt-24">
            <div className="arch">{`  Capture UI (React)          QR scan → Asset page
        │ audio/video/images/docs/notes
        ▼
  FastAPI ─ auth · RBAC · audit · rate limits
        │
  Processing pipeline (10 tracked stages)
   transcribe → extract entities → procedures
   → failure modes → safety → machine mapping
   → structure → index → conflict detection
        │
  PostgreSQL ─┬─ relational knowledge graph
              ├─ pgvector embeddings
              └─ audit + traceability
        │
  Hybrid retrieval  vector + BM25 + graph (RRF)
        │
  Grounded answer   verified citations · safety
                    groundedness · escalation`}</div>
            <div className="stack">
              {[
                [<ServerCog key="i" />, "Cloud mode (implemented)", "API + PostgreSQL/pgvector + S3-compatible storage. LLM via OpenAI or Anthropic, configured by environment variables."],
                [<Lock key="i" />, "On-prem / edge mode (designed)", "Same containers on a local server with Ollama as the local model and offline embeddings. Documented; not yet validated on plant hardware."],
                [<Database key="i" />, "Graph without fragility", "The knowledge graph lives in PostgreSQL. Neo4j is an optional replica — the app works when it is absent."],
                [<Brain key="i" />, "Honest fallbacks", "Without an API key, LegacyMind runs a clearly labelled local rules mode instead of pretending an LLM answered."],
              ].map(([ic, t, d]) => (
                <div key={t as string} className="panel feature" style={{ padding: 16 }}><div className="row"><div className="ic" style={{ margin: 0 }}>{ic}</div><h3>{t}</h3></div><p>{d}</p></div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section" id="demo">
        <div className="section-inner" style={{ display: "grid", gap: 24, gridTemplateColumns: "minmax(0,1fr) auto", alignItems: "center" }}>
          <div>
            <div className="eyebrow">Two-minute demo</div>
            <h2 className="big">Walk through NovaTech Manufacturing Plant.</h2>
            <p className="lead">A fictional factory with five machines and three technicians. Ask as a junior, review as a supervisor, record as the senior expert. <strong>All demo content is synthetic and labelled as such.</strong></p>
          </div>
          <Link to="/demo" className="btn primary lg"><PlayCircle /> Launch Demo</Link>
        </div>
      </section>

      <section className="section" id="security">
        <div className="section-inner">
          <div className="eyebrow">Security</div>
          <h2 className="big">Industrial knowledge is sensitive. It is treated that way.</h2>
          <div className="grid g-3 mt-24">
            {[
              ["Role-based access", "Four roles with explicit permissions. Junior technicians only ever see supervisor-approved knowledge."],
              ["Secure sessions", "scrypt password hashing, signed short-lived sessions in httpOnly cookies, server-side revocation."],
              ["Full audit trail", "Every capture, approval, edit, conflict resolution and assistant question is logged with user and time."],
              ["Validated uploads", "Type allow-list, magic-byte checks, size limits and sanitised filenames on every file."],
              ["Hardened API", "Security headers, CSP, CORS allow-list, rate limiting and error IDs instead of stack traces."],
              ["Your keys, your data", "Secrets only via environment variables. Run fully on-prem with a local model when data cannot leave the site."],
            ].map(([t, d]) => (
              <div key={t} className="panel feature"><div className="ic"><Lock /></div><h3>{t}</h3><p>{d}</p></div>
            ))}
          </div>
        </div>
      </section>

      <section className="section" id="roi"><div className="section-inner"><Roi /></div></section>

      <section className="section faq" id="faq">
        <div className="section-inner">
          <div className="eyebrow">FAQ</div>
          <h2 className="big">Questions plant managers ask.</h2>
          <div className="mt-24">
            {[
              ["Does LegacyMind replace our technicians?", "No. It makes an experienced technician’s knowledge available to the next generation, with that technician credited on every answer. Supervisors stay in control of what becomes approved knowledge."],
              ["What happens when the AI doesn’t know?", "It says so. If no approved evidence supports an answer — or the question is about a machine with no captured knowledge — LegacyMind answers “I could not find sufficient verified plant knowledge” and escalates to the maintenance supervisor."],
              ["Can it invent a maintenance procedure?", "Answers are built from approved procedure cards or from LLM output that must cite evidence and is checked against it; unsupported steps are removed. Safety warnings are pulled from approved records, never generated."],
              ["Do we need an OpenAI or Anthropic account?", "No. Without a key the system runs a labelled local mode (rule-based extraction and extractive answers). Adding a key improves extraction recall and answer fluency; the grounding checks stay the same. Ollama is supported for on-prem models."],
              ["Can it run without internet?", "The architecture supports an on-prem deployment with a local model and offline embeddings. This is designed and documented; it has not yet been validated on factory hardware."],
              ["Is the demo data real?", "No. NovaTech Manufacturing Plant, its machines and its people are fictional and labelled “Synthetic Demo Data” throughout the product."],
            ].map(([q, a]) => (
              <details key={q}><summary>{q}</summary><p>{a}</p></details>
            ))}
          </div>
        </div>
      </section>

      <footer className="footer">
        <div className="section-inner row-wrap" style={{ justifyContent: "space-between" }}>
          <div className="row"><Brand sub={false} /></div>
          <div>“Capture the experience. Preserve the knowledge. Empower the next technician.”</div>
          <div className="row-wrap"><Link to="/login">Sign in</Link><Link to="/register">Create workspace</Link><a href="/api/docs">API docs</a></div>
        </div>
      </footer>
    </div>
  );
}

function HeroConsole() {
  const lines = [
    { who: "REC", text: "“Whenever Pump P-103 produces a grinding sound during startup, first inspect Valve V-03…”" },
    { who: "AI", text: "Extracted → asset P-103 · symptom: grinding sound during startup · component: Valve V-03 · failure mode: valve blockage" },
    { who: "Q", text: "Pump P-103 is making a grinding sound during startup. What should I check?" },
  ];
  const [n, setN] = useState(0);
  useEffect(() => {
    if (n >= lines.length) return;
    const t = setTimeout(() => setN((x) => x + 1), n === 0 ? 400 : 1100);
    return () => clearTimeout(t);
  }, [n, lines.length]);
  return (
    <div className="hero-console" aria-label="Product preview">
      <div className="console-bar"><i /><i /><i /><span style={{ marginLeft: 8 }}>legacymind · NovaTech (synthetic) · P-103</span></div>
      <div style={{ padding: 18 }} className="stack">
        {lines.slice(0, n).map((l) => (
          <div key={l.who} className="row rise" style={{ alignItems: "flex-start" }}>
            <span className="tag" style={{ minWidth: 38, textAlign: "center" }}>{l.who}</span>
            <span className={l.who === "AI" ? "muted small" : "small"}>{l.text}</span>
          </div>
        ))}
        {n >= lines.length && (
          <div className="panel accent rise" style={{ padding: 14 }}>
            <div className="row small"><strong>Recommended checks</strong><div className="spacer" /><span className="ground HIGH">GROUNDEDNESS: HIGH</span></div>
            <ol className="small" style={{ margin: "10px 0 0", paddingLeft: 18, color: "var(--text-2)" }}>
              <li>Stop the pump and apply lockout/tagout</li>
              <li>Inspect Valve V-03</li>
              <li>If pressure is below the normal range, check the valve for blockage</li>
            </ol>
            <div className="safety-card mt-12 small"><ScanSearch size={16} />High-pressure hydraulic system — bleed off the accumulator first.</div>
            <div className="tiny faint mt-8 mono">SOURCE · Rajesh Kumar · 14 Aug 2026 · 02:14–02:48 · LM-1042</div>
          </div>
        )}
      </div>
    </div>
  );
}

function Roi() {
  const [experts, setExperts] = useState(6);
  const [hoursSaved, setHoursSaved] = useState(2);
  const [incidents, setIncidents] = useState(20);
  const [rate, setRate] = useState(40000);
  const monthly = incidents * hoursSaved * rate;
  const num = (v: string) => Math.max(0, Number(v) || 0);
  return (
    <div className="grid g-2" style={{ alignItems: "center" }}>
      <div>
        <div className="eyebrow">ROI model</div>
        <h2 className="big">Estimate the value with your own numbers.</h2>
        <p className="lead">We don’t quote invented savings. Enter your plant’s figures — the calculation is simple and transparent: incidents per month × diagnosis hours saved per incident × cost of one hour of downtime.</p>
        <p className="small faint mt-12">Illustrative calculator. The defaults are placeholders, not measured results.</p>
      </div>
      <div className="panel" style={{ padding: 20 }}>
        <div className="grid g-2">
          <label className="field"><span className="label">Retiring experts (next 5 yrs)</span><input className="input" type="number" min={0} value={experts} onChange={(e) => setExperts(num(e.target.value))} /></label>
          <label className="field"><span className="label">Breakdowns / month</span><input className="input" type="number" min={0} value={incidents} onChange={(e) => setIncidents(num(e.target.value))} /></label>
          <label className="field"><span className="label">Diagnosis hours saved / breakdown</span><input className="input" type="number" min={0} step={0.5} value={hoursSaved} onChange={(e) => setHoursSaved(num(e.target.value))} /></label>
          <label className="field"><span className="label">Downtime cost / hour (₹)</span><input className="input" type="number" min={0} step={1000} value={rate} onChange={(e) => setRate(num(e.target.value))} /></label>
        </div>
        <div className="mt-16 stat-label">Estimated downtime value recovered / month</div>
        <div className="big-num">₹{monthly.toLocaleString("en-IN")}</div>
        <div className="small muted">Plus {experts} expert{experts === 1 ? "" : "s"}’ knowledge preserved before retirement — not priced here.</div>
      </div>
    </div>
  );
}
