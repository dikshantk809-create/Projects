import { Check, ClipboardCheck, GitCompareArrows, Pencil, Plus, Trash2, X } from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";
import { ProcedureCard } from "../components/ProcedureCard";
import { useToast } from "../components/toast";
import { Badge, Empty, ErrorState, Field, Loading, Modal, PageHead, Panel, RiskBadge, StatusBadge } from "../components/ui";
import { api } from "../lib/api";
import { cls, fmtDate, timeAgo } from "../lib/format";
import { useApi } from "../lib/hooks";
import type { Conflict, Procedure, RecordBrief } from "../lib/types";

interface Queue {
  procedures: Procedure[];
  records: RecordBrief[];
  conflicts: Conflict[];
  recent_reviews: { id: string; target_type: string; decision: string; comment: string; reviewer: { full_name: string } | null; created_at: string }[];
}
type Tab = "procedures" | "conflicts" | "records" | "history";

export default function Review() {
  const { data, error, loading, reload } = useApi<Queue>("/api/reviews/queue");
  const [tab, setTab] = useState<Tab>("procedures");
  if (loading && !data) return <Loading />;
  const tabs: [Tab, string, number][] = [
    ["procedures", "Procedure cards", data?.procedures.length ?? 0],
    ["conflicts", "Knowledge conflicts", data?.conflicts.length ?? 0],
    ["records", "Knowledge records", data?.records.length ?? 0],
    ["history", "Recent decisions", data?.recent_reviews.length ?? 0],
  ];
  return (
    <div className="stack" style={{ gap: 20 }}>
      <PageHead eyebrow="Human in the loop" title="Supervisor Review">
        Nothing the AI extracts is used to answer technicians until a supervisor approves it. High-risk procedures require sign-off; conflicting procedures are never silently resolved.
      </PageHead>
      {error && <ErrorState error={error} onRetry={() => void reload()} />}
      <div className="tabs" role="tablist">
        {tabs.map(([k, l, n]) => <button key={k} role="tab" aria-selected={tab === k} className={cls("tab", tab === k && "active")} onClick={() => setTab(k)}>{l}<span className={cls("n")} style={n && k !== "history" ? { color: "var(--warn)" } : undefined}>{n}</span></button>)}
      </div>
      {data && tab === "procedures" && (data.procedures.length ? <div className="stack">{data.procedures.map((p) => <ProcedureReview key={p.id} p={p} onDone={() => void reload()} />)}</div> : <Panel><Empty icon={<ClipboardCheck />} title="All procedure cards reviewed" /></Panel>)}
      {data && tab === "conflicts" && (data.conflicts.length ? <div className="stack">{data.conflicts.map((c) => <ConflictReview key={c.id} c={c} onDone={() => void reload()} />)}</div> : <Panel><Empty icon={<GitCompareArrows />} title="No open conflicts" /></Panel>)}
      {data && tab === "records" && <RecordsQueue records={data.records} />}
      {data && tab === "history" && (
        <Panel tight>
          {!data.recent_reviews.length ? <Empty title="No decisions yet" /> : (
            <table className="table">
              <thead><tr><th>When</th><th>Reviewer</th><th>Target</th><th>Decision</th><th>Comment</th></tr></thead>
              <tbody>{data.recent_reviews.map((r) => (
                <tr key={r.id}><td className="small faint nowrap">{timeAgo(r.created_at)}</td><td>{r.reviewer?.full_name}</td><td><Badge>{r.target_type}</Badge></td><td><StatusBadge status={r.decision} /></td><td className="small muted">{r.comment}</td></tr>
              ))}</tbody>
            </table>
          )}
        </Panel>
      )}
    </div>
  );
}

function ProcedureReview({ p, onDone }: { p: Procedure; onDone: () => void }) {
  const toast = useToast();
  const [editing, setEditing] = useState(false);
  const [comment, setComment] = useState("");
  const [busy, setBusy] = useState(false);
  const decide = async (decision: "approve" | "reject" | "needs_changes", edits?: unknown) => {
    if (decision === "reject" && !comment.trim()) {
      toast.error({ message: "Add a comment explaining why the procedure is rejected." });
      return;
    }
    setBusy(true);
    try {
      await api.post(`/api/reviews/procedures/${p.id}`, { decision, comment, edits });
      toast.ok(decision === "approve" ? `${p.ref} approved — now used by the assistant` : decision === "reject" ? `${p.ref} rejected` : `${p.ref} sent back for changes`);
      onDone();
    } catch (e) {
      toast.error(e);
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <ProcedureCard p={p} defaultOpen actions={
        <div className="stack-sm" style={{ borderTop: "1px solid var(--line)", paddingTop: 12 }}>
          {p.requires_supervisor && <div className="notice warn small"><ClipboardCheck />{p.risk_level}-risk procedure — your approval is the required sign-off before technicians can follow it.</div>}
          <input className="input" placeholder="Review comment (required when rejecting)" value={comment} onChange={(e) => setComment(e.target.value)} maxLength={2000} aria-label="Review comment" />
          <div className="row-wrap">
            <button className="btn ok" disabled={busy} onClick={() => void decide("approve")}><Check />Approve</button>
            <button className="btn" disabled={busy} onClick={() => setEditing(true)}><Pencil />Edit & approve</button>
            <button className="btn" disabled={busy} onClick={() => void decide("needs_changes")}>Needs changes</button>
            <button className="btn bad" disabled={busy} onClick={() => void decide("reject")}><X />Reject</button>
            <div className="spacer" />
            {p.record_id && <Link className="btn ghost sm" to={`/app/library/${p.record_id}`}>Check against source →</Link>}
          </div>
        </div>
      } />
      {editing && <EditProcedure p={p} busy={busy} onClose={() => setEditing(false)} onSave={(edits) => void decide("approve", edits).then(() => setEditing(false))} />}
    </>
  );
}

function EditProcedure({ p, busy, onClose, onSave }: { p: Procedure; busy: boolean; onClose: () => void; onSave: (e: unknown) => void }) {
  const [title, setTitle] = useState(p.title);
  const [risk, setRisk] = useState(p.risk_level);
  const [steps, setSteps] = useState(p.steps.map((s) => ({ text: s.text, component: s.component ?? "" })));
  const move = (i: number, d: number) => {
    const j = i + d;
    if (j < 0 || j >= steps.length) return;
    const n = [...steps];
    [n[i], n[j]] = [n[j]!, n[i]!];
    setSteps(n);
  };
  return (
    <Modal title={`Edit ${p.ref}`} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>Cancel</button><button className="btn ok" disabled={busy || steps.some((s) => s.text.trim().length < 3)} onClick={() => onSave({ title, risk_level: risk, steps })}><Check />Save & approve</button></>}>
      <div className="stack">
        <Field label="Title"><input className="input" value={title} onChange={(e) => setTitle(e.target.value)} /></Field>
        <Field label="Risk level"><select className="select" value={risk} onChange={(e) => setRisk(e.target.value as Procedure["risk_level"])}>{["low", "medium", "high", "critical"].map((r) => <option key={r}>{r}</option>)}</select></Field>
        <div className="label">Steps</div>
        {steps.map((s, i) => (
          <div key={i} className="row">
            <span className="tag">{i + 1}</span>
            <input className="input" value={s.text} onChange={(e) => setSteps(steps.map((x, j) => (j === i ? { ...x, text: e.target.value } : x)))} aria-label={`Step ${i + 1}`} />
            <button className="btn ghost icon sm" onClick={() => move(i, -1)} aria-label="Move up">↑</button>
            <button className="btn ghost icon sm" onClick={() => move(i, 1)} aria-label="Move down">↓</button>
            <button className="btn ghost icon sm" onClick={() => setSteps(steps.filter((_, j) => j !== i))} aria-label="Remove step" disabled={steps.length <= 1}><Trash2 /></button>
          </div>
        ))}
        <div><button className="btn sm" onClick={() => setSteps([...steps, { text: "", component: "" }])}><Plus />Add step</button></div>
        <p className="hint">Unchanged steps keep their link to the original recording. Edited or new steps are marked “edited by supervisor” in the evidence trail.</p>
      </div>
    </Modal>
  );
}

function ConflictReview({ c, onDone }: { c: Conflict; onDone: () => void }) {
  const toast = useToast();
  const [preferred, setPreferred] = useState<string>("");
  const [resolution, setResolution] = useState("");
  const [busy, setBusy] = useState(false);
  const resolve = async (status: "resolved" | "dismissed") => {
    setBusy(true);
    try {
      await api.post(`/api/reviews/conflicts/${c.id}/resolve`, { status, preferred_procedure_id: preferred || null, resolution });
      toast.ok(status === "resolved" ? "Conflict resolved" : "Conflict dismissed");
      onDone();
    } catch (e) {
      toast.error(e);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Panel className="warn" title={<span className="row" style={{ color: "var(--warn)" }}><GitCompareArrows size={16} />⚠ KNOWLEDGE CONFLICT</span>} sub={`${c.procedure_a.asset?.asset_tag ?? ""} · detected ${fmtDate(c.created_at)} by ${c.detected_by}`}>
      <div className="stack">
        <p>{c.description}</p>
        <div className="grid g-2">
          {[c.procedure_a, c.procedure_b].map((p, i) => (
            <label key={p.id} className={cls("panel", preferred === p.id && "accent")} style={{ padding: 14, cursor: "pointer", background: "var(--bg-2)" }}>
              <div className="row"><input type="radio" name={`pref-${c.id}`} checked={preferred === p.id} onChange={() => setPreferred(p.id)} /><strong>Procedure {i === 0 ? "A" : "B"}</strong><span className="mono small faint">{p.ref}</span><StatusBadge status={p.status} /><RiskBadge risk={p.risk_level} /></div>
              <div className="small faint mt-8">Source: {p.author?.full_name ?? "—"}{p.author?.title ? ` (${p.author.title})` : ""}</div>
              <ol className="small mt-8" style={{ paddingLeft: 18, margin: "8px 0 0" }}>{p.steps.map((s) => <li key={s.order}>{s.text}</li>)}</ol>
            </label>
          ))}
        </div>
        <Field label="Resolution note (visible in the audit trail)"><textarea className="textarea" style={{ minHeight: 70 }} value={resolution} onChange={(e) => setResolution(e.target.value)} placeholder="e.g. Verified on CV-04: check tail pulley alignment first; idler inspection is step 3." /></Field>
        <div className="row-wrap">
          <button className="btn ok" disabled={busy || resolution.trim().length < 3} onClick={() => void resolve("resolved")}><Check />{preferred ? "Resolve — keep selected procedure" : "Resolve without choosing"}</button>
          <button className="btn" disabled={busy || resolution.trim().length < 3} onClick={() => void resolve("dismissed")}>Dismiss (not a real conflict)</button>
          <span className="small faint">Choosing a procedure approves it and marks the other as superseded.</span>
        </div>
      </div>
    </Panel>
  );
}

function RecordsQueue({ records }: { records: RecordBrief[] }) {
  if (!records.length) return <Panel><Empty title="No records awaiting review" /></Panel>;
  return (
    <Panel tight>
      <table className="table">
        <thead><tr><th>Record</th><th>Title</th><th>Machine</th><th>Contributor</th><th>Processing</th><th>Captured</th></tr></thead>
        <tbody>{records.map((r) => (
          <tr key={r.id}>
            <td className="mono small"><Link to={`/app/library/${r.ref}`}>{r.ref}</Link></td>
            <td>{r.title}</td>
            <td>{r.asset ? <span className="tag">{r.asset.asset_tag}</span> : <Badge tone="warn">unmapped</Badge>}</td>
            <td className="small">{r.contributor?.full_name}</td>
            <td><StatusBadge status={r.processing_status} /></td>
            <td className="small faint">{timeAgo(r.created_at)}</td>
          </tr>
        ))}</tbody>
      </table>
    </Panel>
  );
}
