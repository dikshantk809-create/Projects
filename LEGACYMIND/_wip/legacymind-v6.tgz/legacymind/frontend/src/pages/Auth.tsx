import { ArrowRight, FlaskConical } from "lucide-react";
import { useState, type FormEvent } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { Brand } from "../components/Logo";
import { ErrorState, Field } from "../components/ui";
import type { ApiError } from "../lib/api";
import { useAuth } from "../lib/auth";

function safeNext(next: string | null): string {
  return next && next.startsWith("/app") && !next.startsWith("//") ? next : "/app";
}

function AuthSide() {
  return (
    <aside className="auth-side">
      <Link to="/" className="brand" style={{ padding: 0 }}><Brand /></Link>
      <div>
        <div className="eyebrow">Capture the experience</div>
        <h1 style={{ fontSize: 34, maxWidth: 460 }}>Preserve the knowledge. Empower the next technician.</h1>
        <p className="muted mt-12" style={{ maxWidth: 440 }}>Every answer LegacyMind gives is traced to an approved expert source — with the technician, the date and the exact moment in the recording.</p>
      </div>
      <div className="mono tiny faint">LEGACYMIND · INDUSTRIAL KNOWLEDGE INTELLIGENCE</div>
    </aside>
  );
}

export function Login() {
  const { login } = useAuth();
  const nav = useNavigate();
  const [params] = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await login(email.trim(), password);
      nav(safeNext(params.get("next")), { replace: true });
    } catch (err) {
      setError(err as ApiError);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth-wrap">
      <AuthSide />
      <div className="auth-form">
        <form className="auth-card stack" onSubmit={submit} noValidate>
          <div>
            <h1>Sign in</h1>
            <p className="muted mt-8">Use your plant account.</p>
          </div>
          {error && <ErrorState error={error} />}
          <Field label="Email" htmlFor="email">
            <input id="email" className="input" type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Field label="Password" htmlFor="password">
            <input id="password" className="input" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
          </Field>
          <button className="btn primary lg" disabled={busy || !email || !password} type="submit">{busy ? "Signing in…" : "Sign in"} <ArrowRight /></button>
          <div className="notice"><FlaskConical style={{ color: "#c9a7ff" }} /><span>Evaluating LegacyMind? <Link to="/demo">Launch the synthetic demo</Link> — no account needed.</span></div>
          <p className="small muted">New plant? <Link to="/register">Create a workspace</Link></p>
        </form>
      </div>
    </div>
  );
}

export function Register() {
  const { register } = useAuth();
  const nav = useNavigate();
  const [f, setF] = useState({ organization_name: "", plant_name: "Main Plant", full_name: "", email: "", password: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  const pwOk = f.password.length >= 10 && /[A-Za-z]/.test(f.password) && /\d/.test(f.password);
  const fieldErr = (name: string) =>
    ((error?.details as { field: string; message: string }[] | undefined) ?? []).find((d) => d.field === name)?.message;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await register({ ...f, email: f.email.trim() });
      nav("/app", { replace: true });
    } catch (err) {
      setError(err as ApiError);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth-wrap">
      <AuthSide />
      <div className="auth-form">
        <form className="auth-card stack" onSubmit={submit} noValidate>
          <div>
            <h1>Create a plant workspace</h1>
            <p className="muted mt-8">You’ll be the plant administrator and can invite technicians and supervisors.</p>
          </div>
          {error && <ErrorState error={error} />}
          <Field label="Organization" htmlFor="org" error={fieldErr("organization_name")}><input id="org" className="input" required value={f.organization_name} onChange={set("organization_name")} placeholder="Acme Components Pvt Ltd" /></Field>
          <Field label="Plant name" htmlFor="plant" error={fieldErr("plant_name")}><input id="plant" className="input" required value={f.plant_name} onChange={set("plant_name")} /></Field>
          <Field label="Your full name" htmlFor="name" error={fieldErr("full_name")}><input id="name" className="input" required value={f.full_name} onChange={set("full_name")} autoComplete="name" /></Field>
          <Field label="Work email" htmlFor="remail" error={fieldErr("email")}><input id="remail" className="input" type="email" required value={f.email} onChange={set("email")} autoComplete="email" /></Field>
          <Field label="Password" htmlFor="rpw" hint="At least 10 characters with a letter and a number." error={f.password && !pwOk ? "Needs 10+ characters including a letter and a number." : fieldErr("password")}>
            <input id="rpw" className="input" type="password" required value={f.password} onChange={set("password")} autoComplete="new-password" />
          </Field>
          <button className="btn primary lg" type="submit" disabled={busy || !pwOk || !f.organization_name || !f.full_name || !f.email}>{busy ? "Creating…" : "Create workspace"} <ArrowRight /></button>
          <p className="small muted">Already have an account? <Link to="/login">Sign in</Link></p>
        </form>
      </div>
    </div>
  );
}
