# Deploying LegacyMind

Three supported topologies. All use the same images and environment variables (full list: [`.env.example`](.env.example)).

| Topology | Best for | Pieces |
|---|---|---|
| **A. Docker Compose** | local, demo laptop, on-prem server | `postgres` (pgvector) → `backend` → `frontend` (nginx) |
| **B. Single container + managed Postgres** | simplest cloud deploy (Render/Railway/Fly) | root `Dockerfile` (API serves the built UI) + managed PostgreSQL |
| **C. Vercel + API host** | the spec's preferred split | Vercel (UI) → Render/Railway/AWS (API) → managed PostgreSQL → S3-compatible storage |

Always check readiness after a deploy: `GET /ready` must return `{"status":"ready"}` with `database`, `migrations` and `storage` all `ok`.

---

## Prerequisites

- PostgreSQL **16+ with the `vector` extension available** (Render, Neon, Supabase, AWS RDS and Railway's pgvector template all provide it). The first migration runs `CREATE EXTENSION IF NOT EXISTS vector`; the database user needs permission to do that once (or create it yourself).
- A generated secret: `python -c "import secrets; print(secrets.token_urlsafe(48))"`.
- Optional: an OpenAI or Anthropic API key; an S3-compatible bucket.

## Production environment variables (minimum)

```bash
APP_ENV=production
SECRET_KEY=<48+ random chars>
DATABASE_URL=postgresql://USER:PASSWORD@HOST:5432/DBNAME      # postgres:// also accepted
COOKIE_SECURE=true                                             # HTTPS only
DEMO_MODE=true|false        # true seeds the synthetic NovaTech plant; set DEMO_PASSWORD if public
ALLOW_PUBLIC_REGISTRATION=true|false
```

Optional: `AI_PROVIDER`, `OPENAI_API_KEY` / `ANTHROPIC_API_KEY`, `MODEL_NAME`, `TRANSCRIPTION_PROVIDER=openai`, `EMBEDDING_PROVIDER=openai`, `STORAGE_BACKEND=s3` + `STORAGE_ENDPOINT/BUCKET/ACCESS_KEY/SECRET_KEY/REGION`, `NEO4J_URI/USERNAME/PASSWORD`, `CORS_ORIGINS` (only for cross-origin setups).

> **Changing `EMBEDDING_PROVIDER` or `EMBEDDING_DIM` after data exists** requires re-embedding: run *Reprocess* on records (supervisor) or re-seed. Both providers use the same 512-dim column by default.

Migrations run automatically at startup under a PostgreSQL advisory lock (safe with several replicas). To run them manually: `cd backend && alembic upgrade head`.

---

## A. Docker Compose (local / on-prem)

```bash
cp .env.example .env          # set SECRET_KEY; AI keys optional
docker compose up --build -d
docker compose ps             # wait for backend "healthy"
open http://localhost:8080
```

- Data persists in the `pgdata` and `storage` volumes.
- Optional profiles: `--profile graph` (Neo4j at :7474, then set `NEO4J_URI=bolt://neo4j:7687` and use *Graph → Export/Sync*), `--profile s3` (MinIO; set `STORAGE_BACKEND=s3`, `STORAGE_ENDPOINT=http://minio:9000`, create the bucket in the console at :9001), `--profile local-llm` (Ollama; `docker compose exec ollama ollama pull llama3.1:8b`, then `AI_PROVIDER=ollama`, `OLLAMA_BASE_URL=http://ollama:11434`).
- Put TLS in front (Caddy/Traefik/nginx) and set `COOKIE_SECURE=true` for any network deployment.

## B. Single container on Render (Blueprint)

1. Push the repository to GitHub.
2. Render → **New → Blueprint** → select the repo. `render.yaml` creates:
   - `legacymind-db` (managed PostgreSQL),
   - `legacymind` web service built from the root `Dockerfile`, with a generated `SECRET_KEY`, `DATABASE_URL` wired from the database, `COOKIE_SECURE=true`, health check `/ready`, and a 5 GB disk at `/data/storage` for uploads.
3. In the service's **Environment**, set `DEMO_PASSWORD` (and optionally `AI_PROVIDER` + key).
4. Deploy. First boot runs migrations and (if `DEMO_MODE=true`) seeds the demo; this takes ~20–40 s.
5. Verify: `curl https://<service>.onrender.com/ready`.

Railway / Fly.io: same image (`Dockerfile` at the root), attach a Postgres with pgvector, set the variables above, expose port `$PORT` (the image honours it), health check `/ready`, mount a volume at `/data/storage` **or** use `STORAGE_BACKEND=s3` (recommended — container disks are ephemeral on many platforms).

## C. Vercel (UI) + API host

1. Deploy the API as in **B** (any container host), note its URL, e.g. `https://legacymind-api.onrender.com`.
2. Edit `frontend/vercel.json` and replace `REPLACE-WITH-YOUR-BACKEND-HOST` with that host (both rewrites).
3. Vercel → **New Project** → import the repo → **Root Directory: `frontend`** → framework Vite (auto) → Deploy.
4. Because Vercel rewrites `/api/*` to the API, the browser stays same-origin: session cookies work with `SameSite=Lax` and no CORS configuration is needed.
5. Verify: open the Vercel URL → **Launch Demo**; `https://<vercel-app>/ready` proxies to the API.

## Storage (S3-compatible)

```bash
STORAGE_BACKEND=s3
STORAGE_ENDPOINT=https://<accountid>.r2.cloudflarestorage.com   # empty for AWS S3
STORAGE_BUCKET=legacymind
STORAGE_ACCESS_KEY=...
STORAGE_SECRET_KEY=...
STORAGE_REGION=auto                                              # or your AWS region
```

The bucket should be **private**; media is streamed through the API with authorization and HTTP range support.

## CI/CD

`.github/workflows/ci.yml` runs on every PR and push to `main`: backend lint (ruff) → type check (mypy) → tests on SQLite → tests on PostgreSQL + pgvector → AI evaluation (artifact) → frontend lint/typecheck/tests/build → Playwright E2E → Docker builds → **deploy**.

The deploy job runs only on `main` and **only if** the repository secret `RENDER_DEPLOY_HOOK` is set (Render → service → Settings → Deploy Hook). Set the repository variable `APP_URL` to have CI wait until `/ready` succeeds; the job fails if the new version never becomes ready. Without the secret, the job prints that nothing was deployed. Vercel deploys the UI through its own Git integration.

## Operations

- **Logs:** JSON lines on stdout with `request_id`; search by the `error_id` users see in error messages.
- **Backups:** PostgreSQL (daily snapshots) + the storage volume/bucket.
- **Scaling:** stateless API (sessions are signed tokens); scale horizontally once storage is S3 and a shared rate limiter sits at the ingress. Heavy processing can be moved to a worker by replacing `BackgroundTasks` with a queue around `run_pipeline`.
- **Rotating `SECRET_KEY`** signs everyone out.

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `/ready` → `migrations: pending` | Another replica is migrating, or migrations failed — check logs for `alembic`. |
| `permission denied to create extension "vector"` | Run `CREATE EXTENSION vector;` once as a superuser, or use a provider with pgvector enabled. |
| Login works but you are immediately signed out | HTTPS/cookie mismatch: `COOKIE_SECURE=true` requires HTTPS; behind Vercel make sure `/api` is rewritten (same origin). |
| “AI: local rules mode” shown although a key is set | `AI_PROVIDER` not set to `openai`/`anthropic`, or key empty — see *Administration → System status → Configuration warnings*. |
| Recordings upload but stay `needs_transcript` | No server STT configured and the browser didn't provide speech recognition — add `TRANSCRIPTION_PROVIDER=openai` or type the transcript on the record page. |
| Upload rejected with 413 | Raise `MAX_UPLOAD_MB` (and your proxy's body limit, e.g. nginx `client_max_body_size`). |
