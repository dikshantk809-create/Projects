# Contributing

## Setup

```bash
cd backend && python -m venv .venv && . .venv/bin/activate && pip install -r requirements-dev.txt
cd frontend && npm install
cd e2e && npm install && npx playwright install chromium
```

## Before opening a pull request

```bash
cd backend
ruff check app tests eval        # lint
mypy app                         # type check
pytest -q                        # tests (SQLite); CI also runs them on PostgreSQL + pgvector
python -m eval.run_eval          # AI evaluation — attach the diff of eval/results.md if AI code changed

cd ../frontend
npm run lint && npm run typecheck && npm test && npm run build
```

CI runs: lint → type check → unit/API tests (SQLite and PostgreSQL) → AI evaluation → frontend build → Playwright E2E → Docker builds → deploy (main only, when secrets exist).

## Rules of the codebase

1. **Never fabricate.** No invented transcripts, citations, test results or deployment claims. If a capability is not configured, say so in the UI and in `/api/admin/system`.
2. **Every AI output is traceable.** New extracted entities need a `knowledge_sources` row (record, timestamps, quote, AI version).
3. **Only approved knowledge answers questions.** Retrieval must filter on `approved`.
4. **Safety text is never generated** by an LLM in answers.
5. **Schema changes need a migration**: `alembic revision --autogenerate -m "..."`, review it, and test upgrade on SQLite and PostgreSQL.
6. **Errors are user-friendly** and carry an error ID; no stack traces in responses.
7. **Demo data is synthetic and labelled** (`is_synthetic=True`).
8. Keep the golden evaluation sets honest: do not tune extractors against `eval/golden_*.json`; add new held-out cases instead.

## Commit style

Short imperative subject (`Add conflict detection for shared failure modes`), body explaining *why*.
