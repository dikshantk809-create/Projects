# PUT THIS ON THE RASPBERRY PI

This one folder is the whole rover: the code that drives it **and** the website
you open on your phone. They are not two programs. When the Pi is running, the
website is already there — nothing else to install, no cloud account, no
server anywhere else.

---

## 1. Get the folder onto the Pi

Unzip it, then copy the `AR750_Rover` folder across. From your own computer:

```bash
scp -r AR750_Rover pi@ar750.local:~/
```

Or put it on a USB stick and copy it into `/home/pi/` on the Pi. Either way you
want to end up with `/home/pi/AR750_Rover`.

## 2. Install it, once

On the Pi:

```bash
cd ~/AR750_Rover
bash install.sh
```

That takes about ten minutes on a fresh Pi. It installs Python packages,
pigpio, the I²C tools and the camera support, and it turns on the pigpio
service that the ESCs and the servo need. It is safe to run again later — it
never touches your settings, your password or your saved data, which all live
in `data/`.

## 3. Start it

```bash
python3 -m ar750.main
```

It prints something like:

```
  website     : http://192.168.1.42:8080
  FIRST TIME: sign in with   admin / agrirover
```

Type that address into your phone or laptop. **Both have to be on the same
wifi.** Sign in with `admin` / `agrirover`; it makes you change both straight
away, and from then on the username and password live on the website. You
change them on the Settings page. You never edit any code to do it.

Try it with no hardware connected first:

```bash
python3 -m ar750.main --sim
```

Everything works, the numbers are invented, nothing moves.

## 4. Make it start by itself

`install.sh` has already set this up for you — on a Pi it writes the systemd
service and enables it, so the rover comes up on its own every time you switch
it on. To start it now without rebooting:

```bash
sudo systemctl start ar750
```

Check on it with `systemctl status ar750`, and read what it has been saying
with `journalctl -u ar750 -f`. If you would rather it did *not* start by
itself while you are still building: `sudo systemctl disable ar750`.

---

## Before the first drive

In this order, with the rover **on blocks and the wheels off the ground**:

```bash
python3 scripts/bench.py wheels     # both axles, on blocks
python3 scripts/bench.py steering   # protractor on a front wheel
python3 scripts/bench.py rc         # check your channel map
python3 scripts/bench.py probe      # nothing underneath it
python3 scripts/bench.py boom       # do this BEFORE you buy nozzles
python3 scripts/bench.py adc        # battery and soil readings
```

`bench.py boom` is the important one. With the nozzles listed in the config it
will tell you the boom would put down about thirteen times what a vegetable
crop wants, and what size nozzle you actually need. Sheet 9 of the circuit
diagram explains why.

---

## What is where

| Folder | What is in it |
|---|---|
| `ar750/main.py` | the thing you run |
| `ar750/config.yaml` | **every number you might want to change**, in one file |
| `ar750/web/` | the website — `server.py` and `static/` |
| `ar750/hw/` | the wheels, steering, boom, probe, sensors, camera, remote |
| `ar750/ai/` | row following, plant decisions, missions, treatments |
| `docs/` | wiring, remote access, and how to train the plant model |
| `scripts/bench.py` | the calibration tools |
| `tests/` | 107 checks. `python3 tests/test_decisions.py` |
| `data/` | your password, database, photos and logs. Back this up |

**Pin numbers live in `config.yaml`, not in the code.** If you move a wire,
change that file. The circuit diagram was printed from that same file, so the
paper and the machine agree.

---

## Reaching it when you are not at home

`docs/REMOTE_ACCESS.md`. Short version: install Tailscale on the Pi and on your
phone, and use the address it gives you. **Do not forward a port on your
router** — that puts a machine that can drive itself and spray chemicals on the
open internet behind one password.

---

## Two things that are true and worth knowing

**There is no trained AI model in here.** Until you train one on your own
plants, the rover photographs every plant and logs it as "not checked". It will
not invent a disease it has not been taught to see.
`docs/TRAINING_THE_MODEL.md` walks through making one.

**There are no wheel encoders on the machine yet**, so the distance shown on
the dashboard is worked out from what the motors were told to do, and it
drifts. The dashboard says so rather than pretending. The code already supports
encoders — fitting them is the cheapest worthwhile upgrade on the rover.
