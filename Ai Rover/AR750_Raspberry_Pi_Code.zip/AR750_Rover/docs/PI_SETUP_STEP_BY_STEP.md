# PUTTING THE CODE ON THE RASPBERRY PI — every step

You are on Windows. This assumes nothing except that you have the Pi, a
microSD card, a card reader, and a 5 V supply for it.

You do **not** need the rover built. Do all of this on your desk first, with
the Pi sitting next to the laptop and nothing wired to it.

---

## What you need in your hand

| | |
|---|---|
| Raspberry Pi 4 | any RAM size |
| microSD card | 32 GB, class 10 |
| card reader | most laptops have a slot; otherwise a USB one |
| USB-C power supply | the official 5 V 3 A one, or your buck converter later |
| your wifi name and password | the Pi joins the same wifi as this laptop |

---

## STEP 1 — Put the operating system on the card

1. On this laptop, download **Raspberry Pi Imager** from
   <https://www.raspberrypi.com/software/> and install it.
2. Put the microSD card in the reader.
3. Open Imager and choose:
   - **Device** → Raspberry Pi 4
   - **Operating System** → Raspberry Pi OS (64-bit)
   - **Storage** → your card. *Check the size — it wipes whatever you pick.*
4. Click **Next**. It asks **"Would you like to apply OS customisation
   settings?"** → click **EDIT SETTINGS**. **Do not skip this.** It is what
   makes the next steps possible.

   On the **General** tab:
   - Set hostname: `ar750`
   - Set username and password: username `pi`, and a password you will
     remember. *Write it down.*
   - Configure wireless LAN: your wifi name and password
   - Wireless LAN country: `IN`
   - Set locale settings: your timezone

   On the **Services** tab:
   - Tick **Enable SSH** → **Use password authentication**

5. Save, then **Yes** to apply, then **Yes** to erase. It takes 5–10 minutes.

---

## STEP 2 — Start the Pi

1. Card out of the laptop, into the Pi.
2. Power in. The green light will flicker.
3. Wait **three minutes** the first time. It is resizing itself and joining
   your wifi. Nothing to watch.

---

## STEP 3 — Talk to it from your laptop

Open **PowerShell** on Windows (press Start, type `powershell`, Enter) and:

```powershell
ssh pi@ar750.local
```

First time it asks `Are you sure you want to continue connecting?` → type
`yes` and Enter. Then your password. *Nothing appears while you type the
password — that is normal, keep typing and press Enter.*

You should land on a line like `pi@ar750:~ $`. **You are now on the Pi.**

**If `ar750.local` does not work:** your router may not do `.local` names.
Log into your router's page and find the device called `ar750` to get its IP
(something like `192.168.1.42`), then use `ssh pi@192.168.1.42` instead — and
use that IP everywhere below in place of `ar750.local`.

Type `exit` to come back to your own laptop.

---

## STEP 4 — Copy the code across

Unzip `AR750_Raspberry_Pi_Code.zip` somewhere easy first — say your Desktop.
You will get a folder called **`AR750_Rover`**.

Back in PowerShell **on your own laptop** (not on the Pi — type `exit` if you
are still on it):

```powershell
cd "$env:USERPROFILE\Desktop"
scp -r ".\AR750_Rover" pi@ar750.local:~/
```

It will list every file as it goes and takes a minute or two. `scp` is
already part of Windows — nothing to install.

**If you unzipped it somewhere else**, put that path in instead. The easy
way: type `scp -r "` then drag the `AR750_Rover` folder from Explorer onto
the PowerShell window — it pastes the path for you — then type
`" pi@ar750.local:~/` and Enter.

---

## STEP 5 — Install it

Get back on the Pi and run the installer:

```powershell
ssh pi@ar750.local
```

```bash
cd ~/AR750_Rover
bash install.sh
```

**About ten minutes.** It installs Python packages, pigpio, the I2C tools,
turns I2C on, sets the rover to start by itself at boot, and finishes by
running the 132 tests. You want to see `132 passed, 0 failed` at the end.

It is safe to run again any time. It never touches your data or password.

---

## STEP 6 — Try it with no hardware at all

Still on the Pi:

```bash
python3 -m ar750.main --sim
```

It prints something like:

```
  website     : http://192.168.1.42:8080
  FIRST TIME: sign in with   admin / agrirover
```

Type that address into your phone or your laptop browser. **Both have to be
on the same wifi.** Sign in with `admin` / `agrirover` — it makes you change
both straight away, and from then on the username and password live on the
website. You never edit any code to change them.

Click around. Put it in AUTO, press **Start the row**, watch it work. Nothing
moves, because nothing is wired — that is the point of `--sim`.

Press **Ctrl+C** on the Pi to stop it.

---

## STEP 7 — Make it start on its own

`install.sh` already set this up. To start it now without rebooting:

```bash
sudo systemctl start ar750
```

Useful afterwards:

```bash
systemctl status ar750        # is it running?
journalctl -u ar750 -f        # what is it saying? Ctrl+C to stop watching
sudo systemctl stop ar750     # stop it
sudo systemctl disable ar750  # stop it starting at boot while you build
```

**Note:** the service runs the real thing, not `--sim`. While you are still
building, `sudo systemctl disable ar750` and run it by hand instead.

---

## STEP 8 — Once the electronics are wired

Wire it following the circuit diagram, then, **with the rover on blocks and
all four wheels off the ground**, in this order:

```bash
cd ~/AR750_Rover
python3 scripts/bench.py wheels     # on blocks. Note the min_duty it finds
python3 scripts/bench.py steering   # protractor on a front wheel
python3 scripts/bench.py rc         # check your remote's channel map
python3 scripts/bench.py probe      # nothing underneath the spike
python3 scripts/bench.py boom       # BEFORE you buy nozzles
python3 scripts/bench.py adc        # battery and soil readings
```

Then edit the settings the tests told you to:

```bash
nano ~/AR750_Rover/ar750/config.yaml
```

`Ctrl+O`, Enter to save; `Ctrl+X` to leave.

The ones you will actually change:

| Setting | Why |
|---|---|
| `drive.hbridge.min_duty` | the percentage `bench.py wheels` found |
| `drive.invert_front` / `invert_rear` | if an axle ran backwards |
| `safety.battery.chemistry` and `cells`/`warn_v`/`stop_v` | match the pack you bought |
| `boom.ml_per_min_per_nozzle` | catch one nozzle in a jug for a minute |
| `cameras.front.height_mm` and `pitch_deg` | measure them once it is built |

---

## WHEN IT GOES WRONG

**`ssh: Could not resolve hostname ar750.local`**
The Pi is not on the network yet, or your router does not do `.local`. Wait
three minutes after power-on. Then find its IP on your router's page and use
that instead.

**`Permission denied (publickey,password)`**
Wrong password, or you did not tick Enable SSH in Step 1. Reflash the card
and do the OS customisation properly this time.

**The website address it prints does not open**
Your phone is on mobile data, or on a different wifi. Both devices must be
on the same network.

**`sudo: apt-get: command not found`, or install.sh fails**
You flashed the wrong image. It must be Raspberry Pi OS, not Ubuntu or
anything else.

**Everything installs but nothing moves when you test the wheels**
The R_EN and L_EN pins on the BTS7960 boards are not tied to 3.3 V. This is
the fault everybody hits first. Sheet 4 of the circuit diagram.

---

## REACHING IT FROM OUTSIDE YOUR HOUSE

`docs/REMOTE_ACCESS.md` inside the same folder. Short version: install
Tailscale on the Pi and on your phone, and use the address it gives you.

**Do not forward a port on your router.** That puts a machine which can drive
itself and spray chemicals on the open internet behind one password.
