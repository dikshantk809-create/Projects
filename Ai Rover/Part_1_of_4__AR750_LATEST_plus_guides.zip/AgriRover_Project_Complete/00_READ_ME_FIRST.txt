==============================================================================
  AGRICULTURAL ROVER PROJECT - EVERYTHING, IN ONE PLACE
==============================================================================

  Put together 16 September 2026
  361 files, 73 MB

  Three rovers were designed over this project. They are three
  different machines, not three versions of one, and their parts do
  not interchange:

     MK2     the original, with a 6 axis arm - folder 3
     MK3     two motors, skid steer, arm and gripper - folder 2
     AR-750  four wheel drive, steering, spray boom - folder 1  <-- LATEST

  The software in folder 1 matches the AR-750 and only the AR-750.
  The software in folder 2 matches the MK3 and only the MK3.


------------------------------------------------------------------------------
  1 AR750 LATEST DESIGN
  THE ONE YOU ARE BUILDING
------------------------------------------------------------------------------
  The AR-750: four wheel drive, Ackermann steering, a 700 mm spray boom and
  a lead screw soil probe. Everything in here came out of
  AR-750_Rover_Complete_Assembly.f3d, measured, not estimated. If you only
  open one folder, open this one.

  AR750_Cutting_Templates_1to1_PRINT_THESE.pdf  
        42 pages. Every flat part at exactly 1:1. Print at 100%, glue to the
        plate, centre punch, drill, cut. Traced from the f3d model.

  AR750_DXF_for_laser_cutting  [folder, 22 files]
        22 DXF files, one per part, in millimetres. Hand these to a laser or
        water jet cutter. R12 format, which every cutter's software reads.

  AR750_Model_Data/full_model_spec.json  
        Every component and every body in the assembly with its bounding box,
        volume and material. This is where the wheelbase, track, tank size,
        camera height and gear ratios in the software came from.

  AR750_Model_Data/part_outlines_exact.json  
        The exact traced outline of every flat part: outer edge and every
        hole, in millimetres, straight out of the CAD. This is what the
        templates and the DXFs were generated from.

  AR750_Rover_Software  [folder, 52 files]
        The complete rover software: the brain, the website, the wiring guide
        and the tests. Copy this whole folder to the Raspberry Pi and run
        'bash install.sh'. 107 tests pass with no hardware attached.

  AR750_Website_Preview_open_in_a_browser.html  
        The rover's website as one file, running on invented data. Double
        click it to see exactly what the console looks like, with no rover
        needed.


------------------------------------------------------------------------------
  2 MK3 DESIGN earlier
  AN EARLIER, DIFFERENT MACHINE
------------------------------------------------------------------------------
  The MK3: two motors, skid steer, a robot arm with a gripper. It is NOT the
  AR-750 and the parts do not interchange. Kept in full because a lot of
  work went into it and the drawings are good.

  MK3_DXF_for_laser_cutting  [folder, 3 files]
        The MK3 deck plates as DXF, for a laser cutter.

  MK3_Drawings_and_Print_Sheets/MK3_All_Parts_2D_Drawings_with_dimensions.pdf  
        54 pages. Every individual part drawn third angle with its dimensions
        and its name.

  MK3_Drawings_and_Print_Sheets/MK3_Body_Panel_Cutout_Sheets.pdf  
        9 pages. The body panels laid out the way an RC plane kit does it, to
        cut from flat sheet.

  MK3_Drawings_and_Print_Sheets/MK3_Build_Manual_step_by_step.pdf  
        18 pages. What to do after the chassis, stage by stage, with a tick
        box on each step.

  MK3_Drawings_and_Print_Sheets/MK3_Chassis_Only_Build_Pack.pdf  
        15 pages. Just the chassis: templates, a setting out table and a hole
        schedule, for getting the frame right first.

  MK3_Drawings_and_Print_Sheets/MK3_Cutting_Templates_1to1_A4_PRINT_THESE.pdf  
        13 pages at 1:1. Print, tape to the plate, drill through the crosses.

  MK3_Drawings_and_Print_Sheets/MK3_Design_Basis_why_every_number.pdf  
        Where each dimension and each choice came from.

  MK3_Drawings_and_Print_Sheets/MK3_Fab_A_Deck_Plate_Template_1to1.pdf  
        The deck plate on its own, at 1:1.

  MK3_Drawings_and_Print_Sheets/MK3_Fab_B_Dimensioned_Drawings.pdf  
        Dimensioned fabrication drawings.

  MK3_Drawings_and_Print_Sheets/MK3_Fab_C_Drilling_Schedule_every_hole.pdf  
        Every hole with its diameter and position.

  MK3_Drawings_and_Print_Sheets/MK3_Fab_C_Frame_Strips_1to1.pdf  
        The frame strips at 1:1.

  MK3_Drawings_and_Print_Sheets/MK3_Fab_D_Wiring_Diagram.pdf  
        How the electrics go together.

  MK3_Drawings_and_Print_Sheets/MK3_Fab_E_Spray_Pipe_Diagram.pdf  
        How the spray plumbing goes together.

  MK3_Drawings_and_Print_Sheets/MK3_Fab_F_Sheet_Index.pdf  
        An index of the fabrication sheets.

  MK3_Drawings_and_Print_Sheets/MK3_General_Arrangement_Blueprint_A2_one_big_sheet.pdf  
        The aircraft style general arrangement drawing, all views on one A2
        sheet with dimensions.

  MK3_Drawings_and_Print_Sheets/MK3_General_Arrangement_Blueprint_A4_tiles_to_tape.pdf  
        The same drawing split across A4 sheets with overlaps, for a home
        printer.

  MK3_Drawings_and_Print_Sheets/MK3_Labelled_Diagram_which_part_is_which.pdf  
        12 A3 pages. The rover in 3D and in 2D with every part labelled, so
        you can tell what you are looking at.

  MK3_Drawings_and_Print_Sheets/MK3_Materials_and_Shopping_List.pdf  
        What to buy and how much of it.

  MK3_Drawings_and_Print_Sheets/MK3_Revision_2_Report.pdf  
        What changed at revision 2 and why.

  MK3_Drawings_and_Print_Sheets/MK3_Revision_3_Report.pdf  
        What changed at revision 3 and why.

  MK3_Drawings_and_Print_Sheets/MK3_Revision_4_Report.pdf  
        What changed at revision 4 and why.

  MK3_Parts_Lists_and_Data/MK3_BOM.csv  
        The parts list.

  MK3_Parts_Lists_and_Data/MK3_BOM_Rev3.csv  
        The parts list at revision 3.

  MK3_Parts_Lists_and_Data/MK3_BOM_Rev4.csv  
        The parts list at revision 4.

  MK3_Parts_Lists_and_Data/arm_geom.json  
        The MK3 arm's link geometry.

  MK3_Parts_Lists_and_Data/asbuilt_mass.json  
        Mass of the model as built.

  MK3_Parts_Lists_and_Data/holes.json  
        Every fixing hole on the MK3 with its position, diameter and what it
        is for. 92 of them.

  MK3_Parts_Lists_and_Data/sheets.json  
        Which drawing sheet covers which part.

  MK3_Renders_and_Views  [folder, 46 files]
        Rendered views of the MK3 from every angle, used to build the
        drawings.

  MK3_Rover_Software_older_version  [folder, 50 files]
        The MK3 software. Superseded by the AR-750 software in folder 1 - that
        one matches the latest design. Kept because the MK3 is a different
        machine and this is what runs it.


------------------------------------------------------------------------------
  3 MK2 DESIGN original
  THE ORIGINAL
------------------------------------------------------------------------------
  The MK2, where the project started. Reports, drawings, the 3D printed part
  catalogue, all 65 STL files ready to print, a photo of every part, and the
  arm movement animations.

  MK2_Arm_Movement_Animations  [folder, 9 files]
        Short animations of the arm moving: base yaw, shoulder, elbow, wrist,
        gripper, soil probe, boom fold, and the full stow to pluck sequence.

  MK2_Part_Photos  [folder, 65 files]
        A rendered picture of every printed part, named after the part, so you
        can tell which STL is which without opening them.

  MK2_Parts_Lists/AgriculturalRoverMK2_Actuator_Schedule.csv  
        Every motor and servo on the MK2.

  MK2_Parts_Lists/AgriculturalRoverMK2_BOM.csv  
        The MK2 parts list.

  MK2_Parts_Lists/AgriculturalRoverMK2_Fastener_Schedule.csv  
        Every nut and bolt on the MK2.

  MK2_Reports_and_Drawings/MK2_3D_Print_Part_Catalogue.pdf  
        Every 3D printed part with a picture, its size and its material.

  MK2_Reports_and_Drawings/MK2_Arm_Revision_B_Report.pdf  
        Arm redesign, revision B.

  MK2_Reports_and_Drawings/MK2_Arm_Revision_C_Report.pdf  
        Arm redesign, revision C.

  MK2_Reports_and_Drawings/MK2_Arm_Revision_D_Rebuild_and_Clearance.pdf  
        Arm rebuild and clearance check, revision D.

  MK2_Reports_and_Drawings/MK2_Arm_Revision_E_Correction.pdf  
        Arm correction, revision E.

  MK2_Reports_and_Drawings/MK2_Engineering_Report.pdf  
        The full engineering report: loads, materials, choices.

  MK2_Reports_and_Drawings/MK2_Engineering_Validation_and_Corrections.pdf  
        What was checked, what was found wrong, and what was corrected.

  MK2_Reports_and_Drawings/MK2_Exploded_View.pdf  
        The rover pulled apart, so you can see how it goes together.

  MK2_Reports_and_Drawings/MK2_Final_Project_Details.pdf  
        The final write up of the MK2 as a whole.

  MK2_Reports_and_Drawings/MK2_General_Arrangement_Drawing.pdf  
        The general arrangement drawing of the MK2.

  MK2_Reports_and_Drawings/MK2_Materials_and_Fasteners.pdf  
        Materials and every fastener.

  MK2_STL_Files_ready_to_3D_print  [folder, 64 files]
        65 STL files, ready to slice and print. These are the MK2's printed
        parts - panels, fenders, gripper jaws, wheel rims and so on.


------------------------------------------------------------------------------
  4 GUIDES READ THESE
  THE GUIDES
------------------------------------------------------------------------------
  The same documents that live inside the software folder, copied up here so
  you can find them without digging.

  1_Wiring_and_Setup_AR750_START_HERE.md  
        Every pin, the power wiring, the calibrations, and the nozzle sizing
        problem. Read this before you wire anything on the AR-750.

  2_Opening_the_console_from_outside_your_house.md  
        How to reach the rover's website when you are not at home, safely.
        Short version: use Tailscale, do not forward a port on your router.

  3_Training_the_plant_AI_model.md  
        Collecting photos with the rover, sorting them, training a model,
        putting it on the Pi, and not trusting it too early.

  4_AR750_Software_README.md  
        What the software does, how to start it, and the safety rules in one
        place.

  5_Wiring_and_Setup_MK3_older_design.md  
        The same guide for the MK3, which is a different machine. Only useful
        if you are building that one.


==============================================================================
  WHERE TO START
==============================================================================

  Building the AR-750?
    1. Read 4_GUIDES_READ_THESE/1_Wiring_and_Setup_AR750_START_HERE.md
    2. Print 1_AR750_LATEST_DESIGN/AR750_Cutting_Templates_1to1_PRINT_THESE.pdf
       at 100%, and check the 100 mm bar with a ruler before you cut.
    3. Or send the DXF folder to a laser cutter instead.
    4. Copy AR750_Rover_Software to the Pi and run  bash install.sh
    5. Open the website, sign in as admin / agrirover, change it.

  Just want to see what the website looks like?
    Double click
    1_AR750_LATEST_DESIGN/AR750_Website_Preview_open_in_a_browser.html

  Two things that are still true and worth remembering:

    * There is no trained AI model in here. Until you train one the
      rover photographs every plant and logs it as 'not checked'. It
      will not guess a disease it did not see. Guide 3 walks through
      training one on your own plants.

    * The AR-750 has no wheel encoders, so the distance it reports is
      worked out from what the motors were told to do and it drifts.
      The dashboard says so. Encoders are the cheapest worthwhile
      upgrade and the code already supports them.

