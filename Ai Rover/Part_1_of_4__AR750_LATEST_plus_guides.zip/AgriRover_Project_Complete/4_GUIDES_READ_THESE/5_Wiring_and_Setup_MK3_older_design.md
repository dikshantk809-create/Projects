# AgriRover MK3 — wiring and setup

Everything here matches `agrirover/config.yaml`. If you move a wire, change the
number in that file, not in the code.

Pin numbers are **BCM** (the GPIO number, not the position on the header).
Run `pinout` on the Pi if you want the picture.

---

## 1. What the parts are

| What | Part | Why this one |
|---|---|---|
| Brain | Raspberry Pi 4, 4 GB | what you have |
| Wheel motors | 2 × Johnson gearmotor, 12 V | what you have |
| Motor driver | 2 × BTS7960 (43 A half bridge pair) | a Johnson motor pulls 8–15 A when it stalls; an L298N will burn |
| Arm servos | 6 channels through a PCA9685 | the Pi cannot make steady servo pulses itself |
| Sensors | ADS1115 4-channel ADC | the Pi has no analogue input at all |
| Pump | 12 V diaphragm pump, through a MOSFET module | |
| Remote | your 6-channel set, SBUS or PPM into the Pi | |
| Cameras | Pi camera on the front, USB camera on the arm | |
| Power | 3S LiPo → 12 V rail, plus a 5 V 5 A buck for the Pi | |

---

## 2. Power, before anything else

```
3S LiPo 11.1 V ──┬── main switch ── fuse 20 A ──┬── BTS7960 left   (B+ / B-)
                 │                              ├── BTS7960 right  (B+ / B-)
                 │                              ├── pump MOSFET    (+12 V in)
                 │                              └── lamps
                 └── buck converter 5 V 5 A ────── Raspberry Pi 5 V / GND
```

Rules that matter:

- **One common ground.** Pi GND, both driver GNDs, ADC GND, PCA9685 GND, receiver
  GND all meet at one point. Most "the rover went mad on its own" problems are a
  missing ground.
- **Never power the servos from the Pi's 5 V.** The PCA9685 has a separate V+
  screw terminal. Give it its own 5 V 5 A buck from the battery.
- Put a **1000 µF capacitor** across the 12 V at each motor driver.
- The Pi needs a **clean 5 V**. If it browns out under load you get random
  reboots that look like software bugs.

---

## 3. Motor drivers — BTS7960

Two boards, one per wheel.

| Signal | Left board | Right board |
|---|---|---|
| RPWM | GPIO 12 | GPIO 18 |
| LPWM | GPIO 13 | GPIO 19 |
| R_EN | GPIO 5 | GPIO 20 |
| L_EN | GPIO 6 | GPIO 21 |
| VCC | Pi 5 V | Pi 5 V |
| GND | common | common |

GPIO 12, 13, 18 and 19 are the Pi's four hardware PWM pins. That is why those
four were chosen — pigpio gives them a steady 1 kHz with no jitter.

M+ / M- go to the motor. If a wheel turns the wrong way, **do not rewire it** —
flip `invert_left` or `invert_right` in the config.

---

## 4. Servos — PCA9685 (I²C, address 0x40)

| PCA9685 | Pi |
|---|---|
| SDA | GPIO 2 |
| SCL | GPIO 3 |
| VCC (logic) | Pi 3.3 V |
| GND | common |
| V+ (screw terminal) | own 5 V 5 A buck, **not** the Pi |

| Channel | Joint | Travel in the config |
|---|---|---|
| 0 | yaw (base) | −90° … +90° |
| 1 | shoulder | −10° … +110° |
| 2 | elbow | −20° … +140° |
| 3 | wrist | −90° … +90° |
| 4 | gripper | 0° … 60° |
| 5 | soil probe | 0° … 180° |

Set the limits with the arm **off the rover** first. A servo that fights a hard
stop draws 2 A and cooks itself in about a minute.

---

## 5. Sensors — ADS1115 (I²C, address 0x48)

| ADS1115 | What |
|---|---|
| A0 | soil moisture probe output |
| A1 | tank level sender |
| A2 | battery, through a divider |
| A3 | spare (use it for a current sensor) |

Battery divider: R1 = 100 kΩ from B+ to the junction, R2 = 20 kΩ from the
junction to GND. That is a divider of 6.0, so 12.6 V arrives as 2.1 V — inside
the ADS1115's range. `battery_divider: 6.0` in the config must match the
resistors you actually fitted.

**Calibrate the soil probe once:**

1. Hold it in dry air, note the reading → `dry_counts`
2. Put it in a glass of water to the line → `wet_counts`

---

## 6. The remote — your 6-channel set

Pick one of the three. SBUS is the best if your receiver has it.

### SBUS (one wire, all 6 channels)

SBUS is inverted serial, so it needs an inverter — one NPN transistor and two
10 kΩ resistors, or a cheap inverter module.

```
RX SBUS out ── inverter ── Pi GPIO 15 (RXD)
```

Then in `/boot/firmware/config.txt`:

```
enable_uart=1
dtoverlay=disable-bt
```

and remove `console=serial0,115200` from `/boot/firmware/cmdline.txt`, or the
Linux console will eat your receiver.

### PPM (one wire, no inverter)

Receiver PPM out → GPIO 7. Set `protocol: ppm`.

### PWM (six wires, simplest, works with any receiver)

Six signal wires to GPIO 14, 15, 8, 10, 0, 1 in channel order. Set
`protocol: pwm`. Signal wires only — the receiver gets its 5 V from the BEC.

### Channel map (`rc.map` in the config)

| Channel | Does |
|---|---|
| 1 | steering |
| 2 | arm up / down |
| 3 | throttle |
| 4 | gripper |
| 5 | 3-position switch: manual / hold / auto |
| 6 | 2-position switch: arms the pump |

The remote always wins. Move a stick while it is driving itself and it drops
straight into manual.

---

## 7. Pump and lamps

| Signal | Pin |
|---|---|
| pump MOSFET gate | GPIO 16 |
| front nozzle valve | GPIO 17 |
| rear nozzle valve | GPIO 27 |
| front lamp | GPIO 9 |
| rear lamp | GPIO 11 |

Put a **flyback diode (1N5408)** across the pump, or the back-EMF will reset
the Pi. Use a logic-level MOSFET module with an opto-isolator if you can.

**Measure your pump's real flow rate.** Run it into a measuring cup for 10
seconds, divide by 10, and put that number in `ml_per_second`. The dose the
rover puts on a plant is only as accurate as this number.

---

## 8. Cameras

- Front: Pi camera on the CSI ribbon (`source: picam`)
- Arm: USB camera (`source: usb`, `index: 0`)

Check which index the USB camera got with `ls /dev/video*`.

---

## 9. Full pin list

| GPIO | Used for |
|---|---|
| 0, 1 | RC channels 5, 6 (PWM mode only) |
| 2, 3 | I²C — PCA9685 and ADS1115 |
| 4 | front range sensor echo (if fitted) |
| 5, 6 | left driver R_EN, L_EN |
| 7 | RC PPM in |
| 8, 10 | RC channels 3, 4 (PWM mode only) |
| 9, 11 | front lamp, rear lamp |
| 12, 13 | left driver RPWM, LPWM |
| 14, 15 | RC channels 1, 2 (PWM) / serial for SBUS |
| 16 | pump |
| 17, 27 | front valve, rear valve |
| 18, 19 | right driver RPWM, LPWM |
| 20, 21 | right driver R_EN, L_EN |
| 22 | front range sensor trigger (if fitted) |
| 23, 24, 25, 26 | wheel encoders (if fitted) |

---

## 10. Installing the software

One command does everything below:

```bash
cd ~/AgriRoverMK3
bash install.sh
```

If you would rather do it by hand:

```bash
sudo apt update
sudo apt install -y python3-pip python3-opencv pigpio python3-pigpio i2c-tools python3-smbus
sudo systemctl enable --now pigpiod

cd ~/AgriRoverMK3
pip3 install -r requirements.txt --break-system-packages
pip3 install --break-system-packages adafruit-circuitpython-pca9685 \
  adafruit-circuitpython-ads1x15 pyserial smbus2
```

Turn on I²C and the camera with `sudo raspi-config` → Interface Options.

Check the boards answer:

```bash
i2cdetect -y 1        # you want to see 40 and 48
```

Run it:

```bash
python3 -m agrirover.main
```

Then open `http://<the Pi's address>:8080` on your phone. It tells you the
right address when it starts.

**Signing in.** The first time it is `admin` / `agrirover`, and it makes you
change both straight away. After that the username and password live on the
website itself, under Settings - you never edit a file to change them. They are
stored hashed in `data/users.json`, so even that file does not contain your
password.

To open the console from outside your house, see `docs/REMOTE_ACCESS.md`. Do
not forward a port on your router.

**Test it on a laptop first**, with no hardware at all:

```bash
python3 -m agrirover.main --sim
```

Everything that is missing is simulated, and the website behaves exactly the
same. Run the tests too:

```bash
python3 -m tests.test_decisions
```

### Start it automatically at boot

`install.sh` already did this. By hand, `/etc/systemd/system/agrirover.service`:

```ini
[Unit]
Description=AgriRover MK3
After=network.target pigpiod.service

[Service]
ExecStart=/usr/bin/python3 -m agrirover.main
WorkingDirectory=/home/pi/agrirover
User=pi
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now agrirover
sudo journalctl -u agrirover -f     # watch what it is doing
```

---

## 10b. Three numbers the arm needs before it can aim

The arm can be told "the weed is 285 mm forward and 49 mm to the left", but only
if it knows where the camera is looking from. Measure these off the finished
rover and put them in `cameras.front` in `config.yaml`:

| | |
|---|---|
| `height_mm` | the middle of the lens, straight down to the ground |
| `pitch_deg` | how far below horizontal it points. Stand a ruler up at a known distance, see where the ruler meets the middle of the picture, and work back — or just put it at 30 and adjust until the arm stops missing |
| `vfov_deg` | vertical angle of view. A Pi camera v2 is about 48, a v3 wide about 66. Check the module you bought |
| `forward_offset_mm` | how far the lens sits ahead of the arm's shoulder |
| `side_offset_mm` | how far across, + is the rover's left |

`height_mm` starts at 0, which means "not measured". While it is 0 the rover
will **not** try to aim at anything the camera sees — it says so and falls back
to the fixed poses. That is deliberate: an arm swinging at a guessed position
breaks plants.

Check your work:

```bash
python3 scripts/bench.py arm
```

It prints what the arm can reach, and where each saved pose actually puts the
gripper. If a pose says "below ground, it will drag", fix it before you drive.

---

## 11. The AI model

The rover ships **without** a trained model, and it says so on the dashboard:
the chip reads "no AI model" and every plant is logged as *Not checked*, with a
photo saved. **It will never invent a disease it did not see.** That is
deliberate.

To give it eyes:

1. Train an image classifier on **your own crop, your own camera, your own
   light**. A model trained on PlantVillage photos scores well on PlantVillage
   photos and poorly in a real garden.
2. Export it as `int8` TFLite, 224 × 224 input.
3. Put it at `models/plant_health_int8.tflite`, and the class names one per line
   at `models/labels.txt`.
4. The label names must match the keys in `agrirover/ai/treatment.py`, or the
   rover falls back to "not sure" and asks you.

```bash
pip3 install tflite-runtime --break-system-packages
```

Until then, run it in manual, let it photograph the row, and look at the photos
yourself. That is still useful.

---

## 11b. Wiring the four upgrades, now that the code supports them

The software already has drivers for all of these. Fit the part, set
`enabled: true` in `config.yaml`, restart, and the Settings page will show it
as fitted.

**Wheel encoders** (`drive.encoder`) - quadrature A and B per motor:

| | left | right |
|---|---|---|
| A | GPIO 23 | GPIO 25 |
| B | GPIO 24 | GPIO 26 |

`ticks_per_rev` is counts at the WHEEL. Measure it: jack the wheel up, mark it,
turn it ten times by hand, divide. Once these are fitted the dashboard stops
saying "estimated, drifts" under the distance, and a slipping wheel raises an
alert instead of quietly adding metres it never travelled.

**Tilt sensor** (`sensors.imu`) - an MPU6050 on the I2C bus at 0x68. Bolt it to
the chassis, not a body panel, flat, arrow forwards. Until you fit one, the
"stop if leaning" rule can never fire, whatever number you put in it.

**Front range sensor** (`sensors.range_front`) - HC-SR04, TRIG to GPIO 22 and
ECHO to GPIO 4 **through a divider**: 1 kOhm from ECHO to the Pi pin, 2 kOhm
from that pin to ground. The echo pin is 5 V and the Pi is 3.3 V. Skip the
divider and you damage the Pi.

**Current sensor** (`sensors.adc.current_channel`) - an ACS712 on ADC channel
A3. Set `zero_volts` and `mv_per_amp` to match the module you bought (a 20 A
module is 100 mV/A, a 30 A one is 66 mV/A).

---

## 12. What the MK3 as drawn cannot do yet

Being straight with you: the CAD model has no encoders, no IMU, no GPS and no
obstacle sensor. The software runs without them and tells you so, but here is
what each one actually buys you, best value first.

| Add | Cost | What changes |
|---|---|---|
| **Wheel encoders** (2 × magnetic, on the motor shaft) | low | Right now the distance on the dashboard is *estimated from what was commanded*, so it drifts. With encoders "move 350 mm to the next plant" becomes true, a slipping wheel raises an alert, and turning into the next row stops being a guess. **Do this one first.** Check them with `python3 scripts/bench.py encoders`. |
| **IMU** (MPU6050 or BNO085) | low | Drives straight down the row instead of curving. Also gives the tilt cut-out real data — at the moment `tilt_stop_deg` can never fire. |
| **Front range sensor** (VL53L0X or an ultrasonic) | low | It stops before hitting a person, a pot or a wall. Set `range_front.enabled: true` and it is used immediately. |
| **Current sensor** (ACS712 or INA219 on A3) | low | Catches a jammed wheel or a seized gearbox before it burns the driver. |
| **GPS** (NEO-6M) | medium | Maps where each sick plant actually is, so you can walk to it next week. Not accurate enough to steer by — 2.5 m error, and your plants are 350 mm apart. |
| **Real-time clock** | very low | Without it, timestamps are wrong every time it boots without wifi. |
| **Coral USB accelerator** | medium | ~10× faster classification. Only worth it once you have a model worth running. |

Two more things worth doing that cost nothing:

- **A hardware stop button** wired to cut the motor drivers' enable pins
  directly. The red button on the website goes through software; a real one
  does not care whether the software is alive.
- **A fuse.** 20 A on the main, and one per motor driver.

---

## 13. Safety, in plain words

The pump cannot run until you arm it, and the rover will always stop and ask
before it sprays unless you deliberately turn "let it spray on its own" on.
It will never spray a virus, because nothing cures a virus. It will never
spray a plant it is not sure about.

The doses in `agrirover/ai/treatment.py` are the common ones for kitchen-garden
vegetables. **They are not a prescription.** The label on the bottle you
actually bought is what counts, rules differ in every country, and the waiting
time before you can pick and eat the crop is the number that matters most.
Read it, and set your own doses in that file.
