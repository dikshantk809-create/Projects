#!/usr/bin/env bash
# One command to set the AR-750 up on a fresh Raspberry Pi.
#
#     bash install.sh
#
# It is safe to run more than once. It never deletes your data, your settings
# or your password - those all live in data/ and are left alone.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$HERE"

say() { printf "\n\033[1;33m==>\033[0m %s\n" "$1"; }

say "Checking where we are"
if [ -f /etc/rpi-issue ] || grep -qi raspberry /proc/device-tree/model 2>/dev/null; then
  ON_PI=1; echo "    Raspberry Pi. Installing everything."
else
  ON_PI=0; echo "    Not a Pi. Installing only what is needed to run the simulator."
fi

say "System packages"
if command -v apt-get >/dev/null 2>&1; then
  sudo apt-get update -qq
  sudo apt-get install -y -qq python3-pip python3-opencv python3-yaml
  if [ "$ON_PI" = "1" ]; then
    sudo apt-get install -y -qq pigpio python3-pigpio i2c-tools python3-smbus
    sudo systemctl enable --now pigpiod
  fi
else
  echo "    No apt here, skipping. Install python3, pip and opencv yourself."
fi

say "Python packages"
PIPFLAGS="--quiet"
python3 -c "import sys; sys.exit(0 if sys.version_info>=(3,11) else 1)" 2>/dev/null \
  && PIPFLAGS="$PIPFLAGS --break-system-packages" || true
# shellcheck disable=SC2086
pip3 install $PIPFLAGS -r requirements.txt

if [ "$ON_PI" = "1" ]; then
  say "Raspberry Pi extras (motor board, servo board, ADC, receiver)"
  # shellcheck disable=SC2086
  pip3 install $PIPFLAGS \
    adafruit-circuitpython-pca9685 adafruit-circuitpython-ads1x15 \
    pyserial smbus2 || echo "    some extras failed, the rover will simulate those parts"
fi

say "Folders"
mkdir -p data/photos data/recordings data/logs models
chmod 700 data || true

say "Fonts for working offline"
python3 scripts/fetch_fonts.py || echo "    skipped, the console will use system fonts"

if [ "$ON_PI" = "1" ]; then
  say "Starting it automatically when the Pi boots"
  SERVICE=/etc/systemd/system/ar750.service
  sudo tee "$SERVICE" >/dev/null <<EOF
[Unit]
Description=AR-750 rover
After=network-online.target pigpiod.service
Wants=network-online.target

[Service]
ExecStart=/usr/bin/python3 -m ar750.main
WorkingDirectory=$HERE
User=$USER
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
  sudo systemctl daemon-reload
  sudo systemctl enable ar750
  echo "    Enabled. Start it now with:  sudo systemctl start ar750"
fi

say "Checking it all imports"
python3 -m compileall -q ar750 >/dev/null && echo "    fine"

say "Running the safety tests"
python3 -m tests.test_decisions | tail -3

IP=$(hostname -I 2>/dev/null | awk '{print $1}')
cat <<EOF

--------------------------------------------------------------------
 Ready.

   Try it with no hardware:   python3 -m ar750.main --sim
   Run it for real:           python3 -m ar750.main

   Then open   http://${IP:-<this-pi>}:8080
   Sign in with   admin / agrirover   and change it straight away.

 Before the first drive, bench test each part:
   python3 scripts/bench.py wheels     (on blocks, wheels off the ground)
   python3 scripts/bench.py steering   (protractor on a front wheel)
   python3 scripts/bench.py rc         (check your channel map)
   python3 scripts/bench.py probe      (nothing underneath it)
   python3 scripts/bench.py boom       (nozzle sizing, before you buy nozzles)
--------------------------------------------------------------------
EOF
