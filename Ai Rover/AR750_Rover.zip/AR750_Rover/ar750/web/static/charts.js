/* Charts, drawn on a canvas, with no library.
   ---------------------------------------------------------------------------
   The rover often has no internet where it works, so nothing here is fetched
   from anywhere. Roughly 300 lines instead of a 300 KB download.

   Rules kept to throughout:
     - one y scale per chart, never two. Two units means two charts.
     - every axis label names a value the chart actually reaches.
     - the grid and the axes recede, the data does not.
     - the last point is emphasised, because on a rover the last point is now.
     - hover gives a crosshair and the real numbers, on touch as well as mouse.
*/
(function (global) {
  'use strict';

  var CSS = getComputedStyle(document.documentElement);
  function tok(name, fallback) {
    var v = CSS.getPropertyValue(name);
    return (v && v.trim()) || fallback;
  }
  var INK = tok('--ink', '#e9efe9'),
      DIM = tok('--dim', '#83958a'),
      LINE = tok('--line-soft', '#202a24'),
      PANEL = tok('--panel', '#141a17');

  function dpi(canvas, cssW, cssH) {
    var r = global.devicePixelRatio || 1;
    canvas.width = Math.round(cssW * r);
    canvas.height = Math.round(cssH * r);
    canvas.style.height = cssH + 'px';
    var c = canvas.getContext('2d');
    c.setTransform(r, 0, 0, r, 0, 0);
    return c;
  }

  function nice(v) {
    // a round number at or just above v, so the top label is readable
    if (v <= 0) return 1;
    var mag = Math.pow(10, Math.floor(Math.log10(v)));
    var n = v / mag;
    var step = n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10;
    return step * mag;
  }

  function fmt(v, dp) {
    if (v === null || v === undefined || isNaN(v)) return '—';
    return Number(v).toFixed(dp === undefined ? 1 : dp);
  }

  /* ----------------------------------------------------------------- line --
     opts: {points:[{x,y}], colour, unit, dp, min, max, label, yZero}
     x is a unix time in seconds.                                           */
  function line(box, opts) {
    var canvas = box.querySelector('canvas') || document.createElement('canvas');
    if (!canvas.parentNode) box.appendChild(canvas);
    var tip = box.querySelector('.tip');
    if (!tip) { tip = document.createElement('div'); tip.className = 'tip'; box.appendChild(tip); }

    var pts = (opts.points || []).filter(function (p) {
      return p && p.y !== null && p.y !== undefined && !isNaN(p.y);
    });
    var W = box.clientWidth || 320, H = opts.height || 150;
    var c = dpi(canvas, W, H);
    c.clearRect(0, 0, W, H);

    var padL = 44, padR = 12, padT = 10, padB = 20;
    var iw = Math.max(10, W - padL - padR), ih = Math.max(10, H - padT - padB);

    if (pts.length < 2) {
      c.fillStyle = DIM; c.font = '12px ' + tok('--sans', 'sans-serif');
      c.textAlign = 'center';
      c.fillText('Nothing recorded yet', W / 2, H / 2);
      return;
    }

    var ys = pts.map(function (p) { return p.y; });
    var lo = opts.min !== undefined ? opts.min : Math.min.apply(null, ys);
    var hi = opts.max !== undefined ? opts.max : Math.max.apply(null, ys);
    if (opts.yZero) lo = 0;
    if (hi - lo < 1e-6) { hi = lo + 1; }
    var pad = (hi - lo) * 0.12;
    lo -= pad; hi += pad;
    if (opts.min !== undefined) lo = opts.min;
    if (opts.max !== undefined) hi = opts.max;

    var x0 = pts[0].x, x1 = pts[pts.length - 1].x;
    if (x1 - x0 < 1) x1 = x0 + 1;
    var X = function (x) { return padL + (x - x0) / (x1 - x0) * iw; };
    var Y = function (y) { return padT + (1 - (y - lo) / (hi - lo)) * ih; };

    // grid: three lines, each labelled with a value the chart reaches
    c.strokeStyle = LINE; c.lineWidth = 1;
    c.fillStyle = DIM;
    c.font = '11px ' + tok('--mono', 'monospace');
    c.textAlign = 'right'; c.textBaseline = 'middle';
    for (var i = 0; i <= 2; i++) {
      var v = lo + (hi - lo) * (i / 2), y = Math.round(Y(v)) + 0.5;
      c.beginPath(); c.moveTo(padL, y); c.lineTo(padL + iw, y); c.stroke();
      c.fillText(fmt(v, opts.dp), padL - 7, y);
    }

    // area under the line, then the line
    var col = opts.colour || tok('--s-blue', '#3987e5');
    var grad = c.createLinearGradient(0, padT, 0, padT + ih);
    grad.addColorStop(0, col + '3d');
    grad.addColorStop(1, col + '05');
    c.beginPath();
    c.moveTo(X(pts[0].x), Y(pts[0].y));
    pts.forEach(function (p) { c.lineTo(X(p.x), Y(p.y)); });
    c.lineTo(X(pts[pts.length - 1].x), padT + ih);
    c.lineTo(X(pts[0].x), padT + ih);
    c.closePath(); c.fillStyle = grad; c.fill();

    c.beginPath();
    pts.forEach(function (p, k) {
      var fx = X(p.x), fy = Y(p.y);
      if (k === 0) c.moveTo(fx, fy); else c.lineTo(fx, fy);
    });
    c.strokeStyle = col; c.lineWidth = 2; c.lineJoin = 'round'; c.lineCap = 'round';
    c.stroke();

    // the newest reading, marked
    var last = pts[pts.length - 1];
    c.beginPath(); c.arc(X(last.x), Y(last.y), 4, 0, 6.2832);
    c.fillStyle = col; c.fill();
    c.strokeStyle = PANEL; c.lineWidth = 2; c.stroke();

    // time at each end
    c.fillStyle = DIM; c.textAlign = 'left'; c.textBaseline = 'alphabetic';
    c.font = '11px ' + tok('--mono', 'monospace');
    c.fillText(clock(x0), padL, H - 5);
    c.textAlign = 'right';
    c.fillText(clock(x1), padL + iw, H - 5);

    hover(box, canvas, tip, function (mx) {
      if (mx < padL || mx > padL + iw) return null;
      var want = x0 + (mx - padL) / iw * (x1 - x0), best = pts[0], bd = 1e18;
      pts.forEach(function (p) {
        var d = Math.abs(p.x - want);
        if (d < bd) { bd = d; best = p; }
      });
      return { x: X(best.x), y: Y(best.y), top: padT, bottom: padT + ih,
               text: fmt(best.y, opts.dp) + (opts.unit || '') + '  ' + clock(best.x),
               colour: col };
    });
  }

  function clock(t) {
    var d = new Date(t * 1000);
    return ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
  }

  /* ------------------------------------------------------------------ bars --
     opts: {rows:[{label, a, b}], aName, bName, aColour, bColour}
     Two series side by side, one y scale, a legend, and a 2px gap between
     neighbouring bars so they read as separate objects.                    */
  function bars(box, opts) {
    var canvas = box.querySelector('canvas') || document.createElement('canvas');
    if (!canvas.parentNode) box.appendChild(canvas);
    var tip = box.querySelector('.tip');
    if (!tip) { tip = document.createElement('div'); tip.className = 'tip'; box.appendChild(tip); }

    var rows = opts.rows || [];
    var W = box.clientWidth || 320, H = opts.height || 170;
    var c = dpi(canvas, W, H);
    c.clearRect(0, 0, W, H);
    var padL = 34, padR = 10, padT = 10, padB = 24;
    var iw = Math.max(10, W - padL - padR), ih = Math.max(10, H - padT - padB);

    if (!rows.length) {
      c.fillStyle = DIM; c.font = '12px ' + tok('--sans', 'sans-serif');
      c.textAlign = 'center'; c.fillText('Nothing recorded yet', W / 2, H / 2);
      return;
    }

    var top = 0;
    rows.forEach(function (r) { top = Math.max(top, r.a || 0, r.b || 0); });
    top = nice(Math.max(1, top));

    c.strokeStyle = LINE; c.fillStyle = DIM;
    c.font = '11px ' + tok('--mono', 'monospace');
    c.textAlign = 'right'; c.textBaseline = 'middle';
    for (var i = 0; i <= 2; i++) {
      var v = top * i / 2, y = Math.round(padT + ih - (v / top) * ih) + 0.5;
      c.beginPath(); c.moveTo(padL, y); c.lineTo(padL + iw, y); c.stroke();
      c.fillText(String(Math.round(v)), padL - 6, y);
    }

    var slot = iw / rows.length;
    var bw = Math.max(3, Math.min(16, slot / 2 - 3));
    var hits = [];
    rows.forEach(function (r, k) {
      var cx = padL + slot * k + slot / 2;
      [['a', opts.aColour || tok('--s-blue', '#3987e5'), -1],
       ['b', opts.bColour || tok('--s-orange', '#d95926'), 1]].forEach(function (s) {
        var val = r[s[0]] || 0;
        if (val <= 0) return;
        var h = (val / top) * ih;
        var x = cx + (s[2] < 0 ? -bw - 1 : 1);
        var y = padT + ih - h;
        c.fillStyle = s[1];
        round(c, x, y, bw, h, 3);
        hits.push({ x: x + bw / 2, y: y, w: bw, h: h, colour: s[1],
                    text: r.label + '  ' + (s[0] === 'a' ? opts.aName : opts.bName) +
                          ' ' + val });
      });
      if (k % Math.ceil(rows.length / 7) === 0) {
        c.fillStyle = DIM; c.textAlign = 'center'; c.textBaseline = 'alphabetic';
        c.font = '10.5px ' + tok('--mono', 'monospace');
        c.fillText(r.short || r.label, cx, H - 7);
      }
    });

    hover(box, canvas, tip, function (mx, my) {
      var best = null, bd = 1e9;
      hits.forEach(function (h) {
        var d = Math.abs(h.x - mx);
        if (d < bd && d < 26) { bd = d; best = h; }
      });
      if (!best) return null;
      return { x: best.x, y: best.y, top: padT, bottom: padT + ih,
               text: best.text, colour: best.colour, noline: true };
    });
  }

  function round(c, x, y, w, h, r) {
    r = Math.min(r, w / 2, h);
    c.beginPath();
    c.moveTo(x, y + h);
    c.lineTo(x, y + r);
    c.quadraticCurveTo(x, y, x + r, y);
    c.lineTo(x + w - r, y);
    c.quadraticCurveTo(x + w, y, x + w, y + r);
    c.lineTo(x + w, y + h);
    c.closePath(); c.fill();
  }

  /* ------------------------------------------------------------- tally bars
     A horizontal list: one series, labelled directly, no legend needed.   */
  function tally(el, rows, opts) {
    opts = opts || {};
    if (!rows.length) { el.innerHTML = '<div class="empty">Nothing found yet.</div>'; return; }
    var top = rows.reduce(function (m, r) { return Math.max(m, r.n); }, 1);
    el.innerHTML = rows.map(function (r) {
      var pc = Math.max(4, Math.round(r.n / top * 100));
      return '<div style="display:grid;gap:4px">' +
        '<div style="display:flex;gap:10px;font-size:13px">' +
          '<span>' + esc(r.name) + '</span>' +
          '<span class="num" style="margin-left:auto;color:var(--dim)">' + r.n + '</span>' +
        '</div>' +
        '<div class="meter" style="height:7px"><span style="width:' + pc +
          '%;background:' + (opts.colour || 'var(--s-orange)') + '"></span></div>' +
      '</div>';
    }).join('');
  }

  function esc(s) {
    return String(s === null || s === undefined ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  /* ----------------------------------------------------------- hover layer */
  function hover(box, canvas, tip, find) {
    if (canvas._wired) canvas._wired();
    function at(ev) {
      var r = canvas.getBoundingClientRect();
      var p = ev.touches ? ev.touches[0] : ev;
      return { x: p.clientX - r.left, y: p.clientY - r.top };
    }
    function move(ev) {
      var m = at(ev), hit = find(m.x, m.y);
      if (!hit) { tip.classList.remove('on'); redraw(); return; }
      redraw(hit);
      tip.textContent = hit.text;
      tip.classList.add('on');
      var tw = tip.offsetWidth || 90;
      var left = Math.max(2, Math.min(box.clientWidth - tw - 2, hit.x - tw / 2));
      tip.style.left = left + 'px';
      tip.style.top = Math.max(0, hit.y - 34) + 'px';
      if (ev.cancelable && ev.touches) ev.preventDefault();
    }
    function leave() { tip.classList.remove('on'); redraw(); }
    // the crosshair is drawn on a second pass over a saved copy of the chart
    var saved = null;
    function snapshot() {
      try { saved = canvas.getContext('2d').getImageData(0, 0, canvas.width, canvas.height); }
      catch (e) { saved = null; }
    }
    function redraw(hit) {
      if (!saved) return;
      var c = canvas.getContext('2d'), r = global.devicePixelRatio || 1;
      c.save(); c.setTransform(1, 0, 0, 1, 0, 0);
      c.putImageData(saved, 0, 0); c.restore();
      if (!hit || hit.noline) { if (hit) dot(c, hit); return; }
      c.save();
      c.strokeStyle = DIM; c.lineWidth = 1; c.setLineDash([3, 3]);
      c.beginPath(); c.moveTo(hit.x, hit.top); c.lineTo(hit.x, hit.bottom); c.stroke();
      c.restore();
      dot(c, hit);
    }
    function dot(c, hit) {
      c.save();
      c.beginPath(); c.arc(hit.x, hit.y, 4.5, 0, 6.2832);
      c.fillStyle = hit.colour; c.fill();
      c.strokeStyle = PANEL; c.lineWidth = 2; c.stroke();
      c.restore();
    }
    setTimeout(snapshot, 0);
    canvas.addEventListener('mousemove', move);
    canvas.addEventListener('mouseleave', leave);
    canvas.addEventListener('touchstart', move, { passive: false });
    canvas.addEventListener('touchmove', move, { passive: false });
    canvas.addEventListener('touchend', leave);
    canvas._wired = function () {
      canvas.removeEventListener('mousemove', move);
      canvas.removeEventListener('mouseleave', leave);
      canvas.removeEventListener('touchstart', move);
      canvas.removeEventListener('touchmove', move);
      canvas.removeEventListener('touchend', leave);
    };
  }

  global.Chart = { line: line, bars: bars, tally: tally };
}(window));
