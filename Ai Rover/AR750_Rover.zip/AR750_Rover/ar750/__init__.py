"""AgriRover MK3."""
