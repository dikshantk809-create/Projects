"""The two drive motors, through their ESCs, and the steering servo.

The AR-750 has one motor at each end, each feeding a differential:

    Motor_F --16T--> 40T --16T--> 38T diff --> front wheels
    Motor_R --16T--> 40T --16T--> 38T diff --> rear wheels

    5.9375 : 1 after whatever gearbox is already on the motor

Both motors do the same thing at the same time - this is four wheel drive, not
skid steer. Turning is the steering servo's job, and nothing else's. If you
ever find yourself writing "left motor faster than right" for this machine,
stop: the diffs will simply let the inside wheels spin and it will go straight
anyway, while the motors fight each other through the ground.

An ESC is not an H bridge. It takes the same 1-2 ms pulse a servo takes:

    1000 us  full reverse        (on a reversible ESC)
    1500 us  stopped
    2000 us  full forward

Most cheap brushed ESCs need to see neutral for a moment when they power up
before they will do anything, which this does on startup, and they need a
pause at neutral when changing direction, which this also does.
"""
from __future__ import annotations

import threading
import time
from typing import Optional, Tuple

try:
    import pigpio                                        # type: ignore
except Exception:                                        # pragma: no cover
    pigpio = None


def _clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


class _Channel:
    """One ESC or servo output on one pin."""

    def __init__(self, pi, pin: int, neutral: int, lo: int, hi: int):
        self.pi = pi
        self.pin = int(pin)
        self.neutral, self.lo, self.hi = int(neutral), int(lo), int(hi)
        self.us = self.neutral
        if pi:                                           # pragma: no cover
            pi.set_mode(self.pin, pigpio.OUTPUT)
            pi.set_servo_pulsewidth(self.pin, self.neutral)

    def write_us(self, us: float) -> None:
        self.us = int(_clamp(us, self.lo, self.hi))
        if self.pi:                                      # pragma: no cover
            self.pi.set_servo_pulsewidth(self.pin, self.us)

    def write_frac(self, f: float) -> None:
        """-1..1 onto the pulse range, with neutral in the middle."""
        f = _clamp(f, -1.0, 1.0)
        span = (self.hi - self.neutral) if f >= 0 else (self.neutral - self.lo)
        self.write_us(self.neutral + f * span)

    def off(self) -> None:
        if self.pi:                                      # pragma: no cover
            self.pi.set_servo_pulsewidth(self.pin, 0)


class Drive:
    """Both drive motors together, plus the steering servo."""

    def __init__(self, cfg: dict, rover_cfg: dict, sim: bool = False):
        self.cfg = cfg or {}
        esc = self.cfg.get("esc", {}) or {}
        st = self.cfg.get("steering", {}) or {}
        self.sim = sim or pigpio is None
        self.reason = "pigpio is not installed" if pigpio is None else ""
        self._pi = None
        self._lock = threading.Lock()

        self.ramp = float(self.cfg.get("ramp_per_tick", 0.05))
        self.invert_front = bool(self.cfg.get("invert_front", False))
        self.invert_rear = bool(self.cfg.get("invert_rear", False))
        self.throttle = 0.0                  # what the wheels are being given
        self._want = 0.0
        self.steer_deg = 0.0                 # road wheel angle, not servo angle

        if not self.sim:                                 # pragma: no cover
            try:
                self._pi = pigpio.pi()
                if not self._pi.connected:
                    raise RuntimeError("pigpiod is not running")
            except Exception as e:
                self.sim = True
                self.reason = str(e)
                self._pi = None

        n, lo, hi = (int(esc.get("neutral_us", 1500)),
                     int(esc.get("min_us", 1000)), int(esc.get("max_us", 2000)))
        self.front = _Channel(self._pi, esc.get("front_pin", 12), n, lo, hi)
        self.rear = _Channel(self._pi, esc.get("rear_pin", 13), n, lo, hi)

        self.servo_centre = int(st.get("centre_us", 1500))
        self.servo_us_per_deg = float(st.get("us_per_deg", 9.0))
        self.servo_trim = float(st.get("trim_us", 0))
        self.servo_reverse = bool(st.get("reverse", False))
        self.steer = _Channel(self._pi, st.get("pin", 18), self.servo_centre,
                              int(st.get("min_us", 900)), int(st.get("max_us", 2100)))

        # ESCs want to see neutral for a moment before they will arm
        self.arm_seconds = float(esc.get("arm_seconds", 2.0))
        self._armed_at = time.time()
        self._last_sign = 0

    @property
    def live(self) -> bool:
        return not self.sim

    @property
    def armed(self) -> bool:
        return time.time() - self._armed_at > self.arm_seconds

    # ------------------------------------------------------------- throttle
    def set_throttle(self, f: float) -> None:
        """-1..1. Both motors, same value: it is four wheel drive."""
        self._want = _clamp(f, -1.0, 1.0)

    def tick(self) -> None:
        """Call this from the control loop. Ramps, so nothing snatches."""
        with self._lock:
            if not self.armed:
                self._apply(0.0)
                return
            d = self._want - self.throttle
            step = self.ramp
            if abs(d) > step:
                d = step if d > 0 else -step
            new = self.throttle + d

            # going through neutral when reversing, which a brushed ESC needs
            if new * self.throttle < 0:
                new = 0.0
            self._apply(new)

    def _apply(self, f: float) -> None:
        self.throttle = f
        self.front.write_frac(-f if self.invert_front else f)
        self.rear.write_frac(-f if self.invert_rear else f)

    def stop(self) -> None:
        with self._lock:
            self._want = 0.0
            self._apply(0.0)

    # ------------------------------------------------------------- steering
    def set_steer_deg(self, wheel_deg: float, max_deg: float) -> float:
        """Point the wheels. Takes the ROAD WHEEL angle, returns what it used."""
        wheel_deg = _clamp(wheel_deg, -max_deg, max_deg)
        self.steer_deg = wheel_deg
        return wheel_deg

    def write_servo(self, servo_deg: float) -> None:
        """Send a servo angle out. The linkage maths lives in ackermann.py."""
        s = -servo_deg if self.servo_reverse else servo_deg
        self.steer.write_us(self.servo_centre + self.servo_trim
                            + s * self.servo_us_per_deg)

    def centre_steering(self) -> None:
        self.steer_deg = 0.0
        self.write_servo(0.0)

    # ----------------------------------------------------------------- tidy
    def snapshot(self) -> dict:
        return {"throttle": round(self.throttle, 3),
                "steer_deg": round(self.steer_deg, 1),
                "front_us": self.front.us, "rear_us": self.rear.us,
                "steer_us": self.steer.us, "armed": self.armed}

    def release(self) -> None:
        self.stop()
        self.centre_steering()
        time.sleep(0.1)
        for ch in (self.front, self.rear, self.steer):
            ch.off()
        if self._pi:                                     # pragma: no cover
            try:
                self._pi.stop()
            except Exception:
                pass
