"""Drive motors: two 12 V Johnson type gearmotors, one per rear wheel.

Default driver is the BTS7960 half bridge pair, which is the usual cheap 43 A
module. Cytron MDD10A is also supported. If the GPIO library is missing the
class still works and just remembers what it was told, so the rest of the
software can be tested on a laptop.
"""
from __future__ import annotations

import time
from typing import Optional

try:
    import pigpio  # type: ignore
except Exception:                                    # pragma: no cover
    pigpio = None


class _Sim:
    """Stands in for the GPIO when there is no hardware."""

    def __init__(self):
        self.duty = {}

    def set_mode(self, *_):
        pass

    def write(self, pin, val):
        self.duty[pin] = val * 255

    def set_PWM_frequency(self, *_):
        pass

    def set_PWM_range(self, *_):
        pass

    def set_PWM_dutycycle(self, pin, duty):
        self.duty[pin] = duty

    def stop(self):
        pass


class DriveMotors:
    """Tank steering. Call set(left, right) with -1.0 .. 1.0."""

    def __init__(self, cfg: dict, sim: bool = False):
        self.cfg = cfg
        self.sim = sim or pigpio is None
        self.driver = cfg.get("driver", "bts7960")
        self.pwm_hz = int(cfg.get("pwm_hz", 1000))
        self.inv_l = bool(cfg.get("invert_left", False))
        self.inv_r = bool(cfg.get("invert_right", True))
        self.left_cmd = 0.0
        self.right_cmd = 0.0
        self._ramp = 0.06          # how fast the command may change per step
        self._last = time.time()

        if self.sim:
            self.pi = _Sim()
        else:                                        # pragma: no cover
            self.pi = pigpio.pi()
            if not self.pi.connected:
                self.pi = _Sim()
                self.sim = True

        self.pins = {"left": cfg["left"], "right": cfg["right"]}
        if not self.sim:                             # pragma: no cover
            for side in ("left", "right"):
                p = self.pins[side]
                for key in ("rpwm", "lpwm"):
                    self.pi.set_mode(p[key], pigpio.OUTPUT)
                    self.pi.set_PWM_frequency(p[key], self.pwm_hz)
                    self.pi.set_PWM_range(p[key], 255)
                    self.pi.set_PWM_dutycycle(p[key], 0)
                for key in ("r_en", "l_en"):
                    if key in p:
                        self.pi.set_mode(p[key], pigpio.OUTPUT)
                        self.pi.write(p[key], 1)

    # ------------------------------------------------------------------ api
    def set(self, left: float, right: float) -> None:
        """Ask for a speed. Ramped, so the belts and gearbox get an easy life."""
        left = max(-1.0, min(1.0, float(left)))
        right = max(-1.0, min(1.0, float(right)))
        self.left_cmd = self._step(self.left_cmd, left)
        self.right_cmd = self._step(self.right_cmd, right)
        self._apply("left", self.left_cmd * (-1 if self.inv_l else 1))
        self._apply("right", self.right_cmd * (-1 if self.inv_r else 1))

    def stop(self) -> None:
        self.left_cmd = self.right_cmd = 0.0
        self._apply("left", 0.0)
        self._apply("right", 0.0)

    def coast(self) -> None:
        """Let the wheels turn freely, for pushing the rover by hand."""
        self.stop()
        if not self.sim:                             # pragma: no cover
            for side in ("left", "right"):
                p = self.pins[side]
                for key in ("r_en", "l_en"):
                    if key in p:
                        self.pi.write(p[key], 0)

    def release(self) -> None:
        self.stop()
        if not self.sim:                             # pragma: no cover
            self.pi.stop()

    # -------------------------------------------------------------- inside
    def _step(self, cur: float, target: float) -> float:
        d = target - cur
        if abs(d) <= self._ramp:
            return target
        return cur + self._ramp * (1 if d > 0 else -1)

    def _apply(self, side: str, v: float) -> None:
        p = self.pins[side]
        duty = int(min(255, abs(v) * 255))
        if self.driver == "cytron_mdd10a":
            # DIR on lpwm, PWM on rpwm
            self.pi.write(p["lpwm"], 1 if v < 0 else 0)
            self.pi.set_PWM_dutycycle(p["rpwm"], duty)
            return
        # BTS7960: one side gets the duty, the other stays at zero
        if v >= 0:
            self.pi.set_PWM_dutycycle(p["lpwm"], 0)
            self.pi.set_PWM_dutycycle(p["rpwm"], duty)
        else:
            self.pi.set_PWM_dutycycle(p["rpwm"], 0)
            self.pi.set_PWM_dutycycle(p["lpwm"], duty)


def mix(throttle: float, steer: float, limit: float = 1.0):
    """Turn a stick pair into left and right wheel commands."""
    left = throttle + steer
    right = throttle - steer
    peak = max(1.0, abs(left), abs(right))
    return (left / peak) * limit, (right / peak) * limit
