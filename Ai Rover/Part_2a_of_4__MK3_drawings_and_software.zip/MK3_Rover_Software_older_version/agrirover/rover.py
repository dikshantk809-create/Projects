"""The rover itself. Owns the hardware, runs the control loop, holds the modes.

Control loop, 50 times a second:

  1. read the sensors
  2. check the safety rules, and stop everything if one is broken
  3. read the remote
  4. work out the mode
  5. in MANUAL  - the sticks drive the wheels and the arm
     in AUTO    - the mission state machine drives
     in HOLD    - hold still, keep the telemetry alive
  6. push the commands out to the hardware

The remote always wins. Touch a stick in AUTO and it drops to MANUAL.
"""
from __future__ import annotations

import math
import os
import threading
import time
from typing import Optional

import yaml

from .core.state import Mode, RoverState
from .core.settings import Settings
from .core.db import DB
from .core.notify import Notifier
from .hw.motors import DriveMotors, mix
from .hw.servos import ServoBank
from .hw.rc import RCReceiver
from .hw.io import Outputs, Sprayer, Analog, SimSensors, battery_percent
from .hw.camera import Camera
from .hw.encoders import Encoders
from .hw.imu import IMU
from .hw.rangefinder import RangeFinder
from .hw.kinematics import Arm
from .media.recorder import Recorder
from .ai.vision import RowFollower, Classifier, find_weed, ground_point
from .ai.mission import Mission

try:
    import cv2                                       # type: ignore
except Exception:                                    # pragma: no cover
    cv2 = None


def load_config(path: str) -> dict:
    with open(path) as f:
        return yaml.safe_load(f)


class Rover:
    def __init__(self, cfg_path: str = "agrirover/config.yaml"):
        self.root = os.path.dirname(os.path.dirname(os.path.abspath(cfg_path)))
        self.cfg = load_config(cfg_path)
        self.state = RoverState()

        # ------------------------------------------------------------ folders
        def here(key, fallback):
            p = os.path.join(self.root, self.cfg["web"].get(key, fallback))
            os.makedirs(p, exist_ok=True)
            return p

        self.data_dir = here("data_dir", "data")
        self.photo_dir = here("photo_dir", "data/photos")
        self.video_dir = here("video_dir", "data/recordings")

        # ----------------------------------------------- settings and memory
        self.settings = Settings(self.cfg,
                                 os.path.join(self.data_dir, "settings.json"))
        self.settings.apply_to_config()
        self.settings.on_change(self._settings_changed)
        self.db = DB(os.path.join(self.data_dir, "agrirover.db"))
        self.notify = Notifier(self.settings, self.state)

        sim_flag = self.cfg["rover"].get("sim", "auto")
        force_sim = sim_flag is True

        # ---------------------------------------------------------- hardware
        self.motors = DriveMotors(self.cfg["drive"], sim=force_sim)
        self.servos = ServoBank(self.cfg["servos"], sim=force_sim)
        self.rc = RCReceiver(self.cfg["rc"], sim=force_sim)
        self.out = Outputs(self.cfg["spray"], self.cfg["lamps"], sim=force_sim)
        self.sprayer = Sprayer(self.out, self.cfg["spray"], self.state)
        self.analog = Analog(self.cfg["sensors"], sim=force_sim)
        self.simsens = SimSensors(self.cfg)
        self.enc = Encoders(self.cfg["drive"], self.cfg["rover"], sim=force_sim)
        self.imu = IMU(self.cfg["sensors"], sim=force_sim)
        self.rangef = RangeFinder(self.cfg["sensors"], sim=force_sim)

        self.cam_front = Camera("front", self.cfg["cameras"]["front"], sim=force_sim)
        self.cam_arm = Camera("arm", self.cfg["cameras"]["arm"], sim=force_sim)

        self.arm = Arm(self.cfg["arm"], self.cfg["servos"]["channels"])
        self.row = RowFollower(self.cfg["ai"].get("row", {}))
        self.classifier = Classifier(self.cfg["ai"], root=self.root)
        self.recorder = Recorder(self, self.video_dir)
        self.mission = Mission(self)

        self.state.sim = any([self.motors.sim, self.servos.sim, self.analog.sim])

        # ------------------------------------------------------------- loop
        self._run = True
        self._odo = {"x": 0.0, "y": 0.0, "hdg": 0.0, "d": 0.0}
        self.home = {"x": 0.0, "y": 0.0}
        self._last_cmd = time.time()
        self._last_web = time.time()
        self._t_prev = time.time()
        self._t_sample = 0.0
        self._t_range = 0.0
        self._t_prune = time.time()
        self._returning = False
        self._web_drive = {"throttle": 0.0, "steer": 0.0, "t": 0.0}
        self._speed_limit = float(self.settings.get("drive.speed_limit", 0.6))
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

        # patrols need the loop running, so they start last
        from .core.schedule import Patrols
        self.patrols = Patrols(self)

        self.state.say("Rover ready%s" % (" (simulation)" if self.state.sim else ""))
        if not self.classifier.ready:
            self.state.say("AI model not loaded: %s" % self.classifier.reason, "warn")
        for name, dev in (("wheel encoders", self.enc), ("tilt sensor", self.imu),
                          ("front range sensor", self.rangef)):
            if dev.live:
                self.state.say("%s: fitted and working" % name)

    # ---------------------------------------------------------- settings
    def _settings_changed(self, changed: dict) -> None:
        self.settings.apply_to_config()
        if "drive.speed_limit" in changed:
            self.set_speed_limit(float(changed["drive.speed_limit"]))
        if "spray.tank_litres" in changed:
            self.sprayer.tank_ml = float(changed["spray.tank_litres"]) * 1000.0
        self.state.say("Settings changed: %s" % ", ".join(sorted(changed)))

    # ============================================================ commands
    def set_mode(self, mode: str, autostart: bool = True) -> bool:
        if self.state.estop and mode != Mode.IDLE:
            return False
        if mode not in (Mode.IDLE, Mode.MANUAL, Mode.AUTO, Mode.HOLD):
            return False
        old = self.state.mode
        if old == Mode.AUTO and mode != Mode.AUTO:
            self.mission.stop("mode changed to %s" % mode)
        self.state.set(mode=mode)
        self.drive(0, 0)
        self.state.say("Mode %s -> %s" % (old, mode))
        if autostart and mode == Mode.AUTO and not self.state.mission.get("running"):
            self.mission.start(0)
        return True

    def estop(self, reason: str = "button pressed") -> None:
        self.state.trip_estop(reason)
        self._halt()
        self.out.all_off()
        self.servos.go_safe()
        self.recorder.stop()
        try:
            self.db.add_alert("error", "Emergency stop: %s" % reason)
        except Exception:
            pass
        self.notify.send("estop", "AgriRover: EMERGENCY STOP - %s" % reason)

    def clear_estop(self) -> None:
        self.state.clear_estop()

    def _halt(self) -> None:
        """Stop the wheels AND tell the dashboard they stopped.

        motors.stop() on its own would leave the last commanded numbers in the
        state, so the website would still show it driving and the trip meter
        would keep counting metres it never travelled.
        """
        self.motors.stop()
        if self.state.drive_left or self.state.drive_right:
            self.state.set(drive_left=0.0, drive_right=0.0)

    def drive(self, throttle: float, steer: float) -> None:
        l, r = mix(throttle, steer, self._speed_limit)
        self.state.set(drive_left=l, drive_right=r)
        if self.state.estop:
            self.motors.stop()
        else:
            self.motors.set(l, r)
        self._last_cmd = time.time()

    def web_drive(self, throttle: float, steer: float) -> None:
        self._web_drive = {"throttle": float(throttle), "steer": float(steer),
                           "t": time.time()}
        self._last_web = time.time()

    def set_speed_limit(self, frac: float) -> None:
        self._speed_limit = max(0.1, min(1.0, float(frac)))

    def arm_pose(self, name: str) -> bool:
        poses = self.cfg["arm"].get("poses", {})
        if name not in poses:
            return False
        self.servos.move_pose(poses[name])
        self.state.arm.pose = name
        return True

    def arm_joint(self, joint: str, deg: float) -> None:
        self.servos.move_to(joint, deg)
        self.state.arm.pose = "manual"

    def spray(self, ml: float, nozzle: str = "front"):
        return self.sprayer.spray(ml, nozzle)

    def set_spray_armed(self, on: bool) -> None:
        self.state.set(spray_armed=bool(on))
        self.state.say("Spray %s" % ("ARMED" if on else "disarmed"),
                       "warn" if on else "info")

    def set_auto_spray(self, on: bool) -> None:
        self.state.set(auto_spray=bool(on))
        self.state.say("Auto spray %s" % ("on" if on else "off"), "warn")

    def set_lamps(self, on: bool) -> None:
        self.out.set("lamp_front", on)
        self.out.set("lamp_rear", on)
        self.state.set(lamps_on=bool(on))

    def reach_to(self, x_mm: float, y_mm: float, z_mm: float):
        """Put the gripper at a spot on the ground, in millimetres.

        The frame is the rover's own: x forward, y to its left, z up from the
        ground. Returns (did it, what happened).
        """
        if self.state.estop:
            return False, "the emergency stop is on"
        angles, why = self.arm.solve(x_mm, y_mm, z_mm)
        if angles is None:
            return False, why
        angles, ran_out = self.arm.clamp(angles, self.cfg["servos"]["channels"])
        for joint, deg in angles.items():
            self.servos.move_to(joint, deg)
        self.state.arm.pose = "reaching"
        self.servos.wait_until_still(5.0)
        if ran_out:
            return False, "got as close as it could: " + ran_out
        return True, "at %.0f, %.0f, %.0f mm" % (x_mm, y_mm, z_mm)

    def where_is_hand(self) -> dict:
        """Where the gripper actually is, using the real wrist angle."""
        a = self.state.arm
        return self.arm.forward(a.yaw, a.shoulder, a.elbow, a.wrist)

    def weed_target(self):
        """Where the weed is on the ground, from the front camera. None if
        there is no weed, or if the camera has not been calibrated."""
        img = self.cam_front.frame()
        if img is None:
            return None
        w = find_weed(img, self.cfg["ai"].get("row", {}))
        if not w:
            return None
        h, wd = img.shape[:2]
        spot = ground_point(w["cx"], w["cy"], wd, h, self.cfg["cameras"]["front"])
        if not spot:
            return None
        spot["area"] = w["area"]
        return spot

    def pull_weed(self, target=None) -> bool:
        """Reach down, close the gripper, lift. Returns True if it ran.

        If the camera is calibrated it reaches for where the weed actually is.
        If it is not, it falls back to the fixed poses, which only work if the
        weed happens to be where the poses point. The website says which of the
        two it did, rather than letting you assume it aimed.
        """
        if self.state.estop:
            return False
        try:
            spot = target or self.weed_target()
            aimed = False
            if spot:
                ok, msg = self.reach_to(spot["x_mm"], spot["y_mm"], 30.0)
                aimed = ok
                if not ok:
                    self.state.say("Could not reach the weed: %s" % msg, "warn")
                    return False
                self.state.say("Reaching for the weed at %.0f mm forward, "
                               "%.0f mm across" % (spot["x_mm"], spot["y_mm"]))
            else:
                self.state.say("Camera not calibrated for reaching, using the "
                               "fixed pose instead", "warn")
                self.arm_pose("approach")
                self.servos.wait_until_still(4.0)

            self.servos.move_to("gripper", 5)          # close on it
            self.servos.wait_until_still(2.5)
            if aimed and spot:
                self.reach_to(spot["x_mm"], spot["y_mm"], 180.0)   # straight up
            else:
                self.arm_pose("lift")
                self.servos.wait_until_still(3.0)
            self.servos.move_to("gripper", 45)         # drop it beside the row
            time.sleep(0.4)
            self.arm_pose("stow")
            return True
        except Exception:
            return False

    def probe_soil(self) -> Optional[float]:
        """Drive the probe down, read, and lift it back out."""
        self.servos.move_to("sensor", 150)
        self.servos.wait_until_still(5.0)
        time.sleep(0.8)
        val = (self.analog.soil_percent() if not self.analog.sim
               else self.simsens.soil_percent())
        self.servos.move_to("sensor", 0)
        return val

    def range_blocked(self) -> bool:
        if self.rangef.live:
            return self.rangef.blocked()
        cfg = self.cfg["sensors"].get("range_front", {})
        if not cfg.get("enabled"):
            return False
        d = self.state.telemetry.range_front_cm
        return d is not None and d < float(cfg.get("stop_cm", 35))

    def save_photo(self, img, plant_id: int) -> str:
        if img is None or cv2 is None:
            return ""
        name = "plant_%04d_%s.jpg" % (plant_id, time.strftime("%Y%m%d_%H%M%S"))
        path = os.path.join(self.photo_dir, name)
        try:
            cv2.imwrite(path, img, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
            return name
        except Exception:
            return ""

    # ------------------------------------------------------------ going home
    def mark_home(self) -> None:
        self.home = {"x": self._odo["x"], "y": self._odo["y"]}
        self.state.say("Marked this spot as home")

    def distance_home(self) -> float:
        return math.hypot(self._odo["x"] - self.home["x"],
                          self._odo["y"] - self.home["y"])

    def return_home(self) -> None:
        """Back the way it came. Reversing is safer than turning in a crop row.

        Honest about what this is: without encoders it is dead reckoning, so it
        gets you roughly back, not exactly. It stops when the trip meter says it
        has covered the distance, or when the battery gives out.
        """
        if self._returning or self.state.estop:
            return
        self._returning = True
        self.state.say("Coming back to where it started", "warn")
        self.state.mission["message"] = "Coming home"

        def go():
            target = self.distance_home()
            start = self._odo["d"]
            while (self._returning and not self.state.estop
                   and self._odo["d"] - start < target + 0.2):
                if self.range_blocked():
                    break
                self.drive(-0.5, 0.0)
                time.sleep(0.05)
            self._halt()
            self._returning = False
            self.state.say("Back home, near enough")
            self.state.mission["message"] = "Home"

        threading.Thread(target=go, daemon=True).start()

    def stop_returning(self) -> None:
        self._returning = False

    def shutdown(self) -> None:
        self._run = False
        try:
            self.patrols.stop()
        except Exception:
            pass
        self.recorder.stop()
        try:
            self._thread.join(timeout=1.5)
        except Exception:
            pass
        self.motors.release()
        self.servos.close()
        self.out.close()
        self.rc.close()
        self.cam_front.close()
        self.cam_arm.close()
        self.enc.close()
        self.imu.close()
        self.rangef.close()
        self.db.close()

    # =============================================================== loop
    def _loop(self) -> None:
        hz = float(self.cfg["safety"].get("loop_hz", 50))
        period = 1.0 / hz
        while self._run:
            t0 = time.time()
            try:
                self._read_sensors()
                self._safety()
                self._modes()
                self._drive_for_mode()
                self.mission.tick()
                self._housekeeping()
            except Exception as e:                   # pragma: no cover
                self.state.say("control loop error: %s" % e, "error")
                self._halt()
            dt = period - (time.time() - t0)
            if dt > 0:
                time.sleep(dt)

    # ---------------------------------------------------------- sensors
    def _read_sensors(self) -> None:
        t = self.state.telemetry
        now = time.time()
        dt = max(1e-3, now - self._t_prev)
        self._t_prev = now

        v = self.analog.battery_volts()
        if v is None:
            v = self.simsens.battery_volts()
        t.battery_v = round(v, 2)
        t.battery_pct = round(battery_percent(
            v, int(self.cfg["safety"]["battery"].get("cells", 3))), 1)

        s = self.analog.soil_percent()
        if s is None and self.analog.sim:
            s = self.simsens.soil_percent()
        t.soil_pct = round(s, 1) if s is not None else None

        tank = self.analog.tank_percent()
        if tank is None:
            t.tank_ml = self.sprayer.remaining_ml()
            t.tank_pct = round(100.0 * t.tank_ml / max(1.0, self.sprayer.tank_ml), 1)
        else:
            t.tank_pct = round(tank, 1)

        # the ultrasonic sensor takes milliseconds, so it is read 5 times a
        # second rather than 50 - it would otherwise eat the whole control loop
        if now - self._t_range > 0.2:
            self._t_range = now
            if self.rangef.live:
                t.range_front_cm = self.rangef.read()
            elif self.cfg["sensors"].get("range_front", {}).get("enabled"):
                t.range_front_cm = round(self.simsens.range_cm(), 1)

        # tilt and heading: measured if an IMU is fitted, otherwise worked out
        imu = self.imu.read()
        if imu:
            t.tilt_deg = imu["tilt_deg"]

        # ---- how far it has gone
        vmax = float(self.cfg["rover"].get("max_speed_mps", 0.12))
        e = self.enc.read()
        if e:
            # measured. A wheel that slipped does not add metres it did not go.
            v_lin = (e["left_mps"] + e["right_mps"]) / 2.0
            dl = (e["left_m"] + e["right_m"]) / 2.0
            w_deg = math.degrees(
                (e["right_m"] - e["left_m"])
                / (float(self.cfg["rover"]["track_mm"]) / 1000.0)) / max(1e-3, e["dt"])
        else:
            # estimated from what the motors were told to do. This drifts.
            l, r = self.state.drive_left, self.state.drive_right
            v_lin = (l + r) / 2.0 * vmax
            dl = v_lin * dt
            w_deg = math.degrees(
                (r - l) * vmax / (float(self.cfg["rover"]["track_mm"]) / 1000.0))

        if imu:
            self._odo["hdg"] = imu["heading_deg"]
        else:
            self._odo["hdg"] = (self._odo["hdg"] + w_deg * dt) % 360.0
        hr = math.radians(self._odo["hdg"])
        self._odo["x"] += dl * math.cos(hr)
        self._odo["y"] += dl * math.sin(hr)
        self._odo["d"] += abs(dl)

        t.speed_mps = round(v_lin, 3)
        t.heading_deg = round(self._odo["hdg"], 1)
        t.x_m = round(self._odo["x"], 3)
        t.y_m = round(self._odo["y"], 3)
        t.distance_m = round(self._odo["d"], 2)
        t.odometry_measured = bool(e)

        cur = self.analog.current_amps()
        if cur is not None:
            t.current_a = round(cur, 2)

        try:
            with open("/sys/class/thermal/thermal_zone0/temp") as f:
                t.cpu_temp_c = round(int(f.read()) / 1000.0, 1)
        except Exception:
            t.cpu_temp_c = 45.0

        a = self.servos.snapshot()
        for k, val in a.items():
            setattr(self.state.arm, k, round(val, 1))
        self.state.arm.moving = not self.servos.at_target()
        self.state.set(rc_live=self.rc.live, rc_channels=self.rc.snapshot())

    # ----------------------------------------------------------- safety
    def _safety(self) -> None:
        s = self.cfg["safety"]
        t = self.state.telemetry
        if self.state.estop:
            self._halt()
            return

        stop_v = float(self.settings.get("safety.battery.stop_v", 10.2))
        warn_v = float(self.settings.get("safety.battery.warn_v", 10.8))
        if t.battery_v < stop_v:
            self.estop("battery too low: %.2f V" % t.battery_v)
            return
        if t.battery_v < warn_v:
            if not any("battery" in a.get("text", "") for a in self.state.alerts[:3]):
                self.state.add_alert("warn", "Battery low, %.2f V" % t.battery_v)
                self.db.add_alert("warn", "Battery low, %.2f V" % t.battery_v)
                self.notify.send("low_battery",
                                 "AgriRover: battery low, %.2f V (%.0f%%)"
                                 % (t.battery_v, t.battery_pct), 900)
            # come home before it dies out in the row
            home_at = int(self.settings.get("safety.return_home_pct", 25))
            if (home_at and t.battery_pct <= home_at and not self._returning
                    and self.state.mission.get("running")):
                if self.settings.get("drive.reverse_on_low_batt", True):
                    self.mission.stop("battery low, coming home")
                    self.return_home()
                else:
                    # you told it not to drive itself back, so it parks where
                    # it is and waits for you rather than deciding for itself
                    self.mission.stop("battery low, parked where it is")
                    self.state.add_alert(
                        "warn", "Battery at %.0f%%. Parked in the row - coming "
                        "home is switched off in Settings." % t.battery_pct)

        tilt_max = float(self.settings.get("safety.tilt_stop_deg", 25))
        if self.imu.live and abs(t.tilt_deg) > tilt_max:
            self.estop("rover is leaning %.0f degrees" % t.tilt_deg)
            return

        # a wheel that is being told to turn but is not
        if (self.enc.live and self.state.mode == Mode.AUTO
                and self.enc.slipping(self.state.drive_left, self.state.drive_right,
                                      float(self.cfg["rover"]["max_speed_mps"]))):
            self.state.add_alert("warn", "A wheel is slipping or stuck")

        # dead man: if nothing has commanded a move recently, stop moving
        if (self.state.mode == Mode.MANUAL
                and time.time() - self._last_cmd > float(s.get("command_timeout_s", 0.6))):
            self._halt()

    # ------------------------------------------------------------ modes
    def _modes(self) -> None:
        if self.state.estop:
            return
        if not self.rc.live:
            return

        sw = self.rc.switch3("mode")
        want = {-1: Mode.MANUAL, 0: Mode.HOLD, 1: Mode.AUTO}.get(sw, Mode.HOLD)

        stick = max(abs(self.rc.channel("throttle")), abs(self.rc.channel("steer")))
        if self.state.mode == Mode.AUTO and stick > 0.2:
            self.mission.stop("remote stick moved")
            self.state.set(mode=Mode.MANUAL)
            self.state.add_alert("info", "Remote took over, now in MANUAL")
            return
        if self._returning and stick > 0.2:
            self.stop_returning()

        if want != self.state.mode:
            self.set_mode(want)

        armed = self.rc.switch2("spray_arm")
        if armed != self.state.spray_armed:
            self.set_spray_armed(armed)

    def _drive_for_mode(self) -> None:
        m = self.state.mode
        if self._returning:
            return                                   # the going home thread drives
        if self.state.estop or m in (Mode.IDLE, Mode.ESTOP):
            self._halt()
            return
        if m == Mode.HOLD:
            self._halt()
            return
        if m == Mode.MANUAL:
            if self.rc.live:
                th = self.rc.channel("throttle")
                st = self.rc.channel("steer")
                self.drive(th, st)
                up = self.rc.channel("arm_up")
                if abs(up) > 0.15:
                    self.servos.jog("shoulder", up * 1.2)
                gr = self.rc.channel("gripper")
                if abs(gr) > 0.15:
                    self.servos.jog("gripper", gr * 1.5)
            else:
                w = self._web_drive
                if time.time() - w["t"] < 0.8:
                    self.drive(w["throttle"], w["steer"])
                else:
                    self._halt()
        # AUTO is driven by Mission.tick()

    # ----------------------------------------------------- record keeping
    def _housekeeping(self) -> None:
        now = time.time()
        if now - self._t_sample > 10.0:
            self._t_sample = now
            try:
                self.db.sample(self.state.telemetry)
            except Exception:
                pass
        if now - self._t_prune > 6 * 3600:
            self._t_prune = now
            try:
                keep = int(self.settings.get("record.keep_days", 30))
                self.db.prune(keep)
                self.recorder.prune(keep)
            except Exception:
                pass
