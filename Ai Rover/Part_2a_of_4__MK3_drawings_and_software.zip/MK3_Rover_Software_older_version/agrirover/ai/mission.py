"""The autonomous job: drive the row, stop at each plant, look, decide, act.

It is a small state machine so you can always see on the website exactly which
step it is on, and so any step can be interrupted the moment the remote is
touched or the stop button is pressed.

    FIND_ROW -> FOLLOW -> AT_PLANT -> INSPECT -> DECIDE
                  ^                                |
                  |                                v
                  +---- MOVE_ON <---- ACT (spray / pull weed / ask you)

Nothing here talks to hardware directly. It calls the Rover object, so the same
mission runs against real hardware or against the simulator.
"""
from __future__ import annotations

import os
import time
from typing import Optional

from ..core.state import Mode, PlantRecord
from . import treatment as tx
from .vision import find_weed


class Mission:
    STEPS = ["idle", "find_row", "follow", "at_plant", "inspect", "decide",
             "act", "act_wait", "move_on", "row_end", "turning", "done"]

    def __init__(self, rover):
        self.r = rover
        self.cfg = rover.cfg
        self.ai = rover.cfg.get("ai", {})
        self.state = rover.state
        self.step = "idle"
        self.t_step = time.time()
        self.plants_done = 0
        self.target = 0
        self.mission_id = 0
        self.row_no = 0
        self.plant_no = 0
        self._sprayed_ml = 0.0
        self._problems = 0
        self._d_start = 0.0
        self._d_row = 0.0
        self.rows_done = 0
        self._turn_dir = 1
        self.dist_since_plant = 0.0
        self._last_x = 0.0
        self._last_y = 0.0
        self._pending_started = 0.0

    # ------------------------------------------------------------------ api
    def start(self, plants: int = 0, kind: str = "manual") -> None:
        if self.state.mission.get("running"):
            # close the old run properly instead of leaving it open in the
            # history with no ending
            self.stop("restarted")
        self.target = int(plants or 0)
        self.plants_done = 0
        self.step = "find_row"
        self.t_step = time.time()
        self.row_no += 1
        self.plant_no = 0
        self.rows_done = 0
        self._d_row = self.state.telemetry.distance_m
        self._sprayed_ml = 0.0
        self._problems = 0
        self._d_start = self.state.telemetry.distance_m
        self._mark()
        self.r.mark_home()
        try:
            self.mission_id = self.r.db.start_mission(kind)
        except Exception:
            self.mission_id = 0
        self.r.recorder.start(self.mission_id)
        m = self.state.mission
        m.update(running=True, step=self.step, plants_done=0,
                 plants_target=self.target, sprayed_ml=0.0, row=self.row_no,
                 mission_id=self.mission_id, rows_done=0,
                 rows_target=int(self.ai.get("rows", 1) or 1),
                 message="Looking for the crop row")
        self.state.say("AUTO started. Target %s plants" %
                       (self.target or "as many as it finds"), "info")

    def stop(self, why: str = "stopped") -> None:
        was_running = bool(self.state.mission.get("running"))
        self.step = "idle"
        self.r.drive(0, 0)
        m = self.state.mission
        m.update(running=False, step="idle", message=why)
        self.state.say("AUTO stopped: " + why, "warn")
        if not was_running:
            return
        self.r.recorder.stop()
        gone = self.state.telemetry.distance_m - self._d_start
        try:
            self.r.db.end_mission(self.mission_id,
                                  plants_checked=self.plants_done,
                                  problems=self._problems,
                                  sprayed_ml=round(self._sprayed_ml, 1),
                                  distance_m=round(gone, 2), note=why)
        except Exception:
            pass
        self.r.notify.send(
            "finish",
            "AgriRover finished: %d plants checked, %d needing attention, "
            "%.0f ml sprayed, %.1f m covered."
            % (self.plants_done, self._problems, self._sprayed_ml, gone), 60)

    def answer(self, approve: bool) -> None:
        """You pressed yes or no on the website for a pending action."""
        p = self.state.pending
        if not p:
            return
        self.state.set(pending=None)
        if not approve:
            self.state.say("You declined: %s" % p.get("title", ""), "warn")
            self._finish_plant(p.get("record"), action="declined")
            self.step = "move_on"
            return
        self.state.say("You approved: %s" % p.get("title", ""), "info")
        self._do_action(p["plan"], p["record"], forced=True)
        self.step = "move_on"

    # ----------------------------------------------------------- main tick
    def tick(self) -> None:
        if not self.state.mission.get("running"):
            return
        if self.state.estop or self.state.mode != Mode.AUTO:
            return
        fn = getattr(self, "_s_" + self.step, None)
        if fn:
            fn()
        self.state.mission["step"] = self.step

    # ------------------------------------------------------------- states
    def _s_find_row(self) -> None:
        img = self.r.cam_front.frame()
        steer, conf, dbg = self.r.row.steer(img)
        if conf > 0.25:
            self._go("follow", "Following the row")
            return
        # creep forward slowly looking for green
        self.r.drive(0.22, 0.0)
        if time.time() - self.t_step > 12:
            self.r.drive(0, 0)
            self._go("row_end", "No crop row found. Park and wait for you.")
            self.state.add_alert("warn", "Could not find a crop row to follow")

    def _s_follow(self) -> None:
        img = self.r.cam_front.frame()
        steer, conf, dbg = self.r.row.steer(img)
        base = float(self.ai.get("row", {}).get("base_speed", 0.45))

        # a hard cap on the row, so a row follower that latches onto a hedge
        # cannot walk the rover into the fence
        cap = float(self.ai.get("row_length_m", 0) or 0)
        if cap and self.state.telemetry.distance_m - self._d_row > cap:
            self.r.drive(0, 0)
            self.state.add_alert("warn", "Reached the %.0f m row limit" % cap)
            self._go("row_end", "Row limit reached")
            return

        if self.r.range_blocked():
            self.r.drive(0, 0)
            self.state.add_alert("warn", "Something is in the way, holding")
            self.state.mission["message"] = "Obstacle ahead, waiting"
            return

        if conf < 0.2:
            self.r.drive(0, 0)
            self._go("row_end", "Row has ended")
            return

        self.r.drive(base, steer * 0.6)
        self._accumulate()

        spacing_m = float(self.ai.get("plant_spacing_mm", 350)) / 1000.0
        if self.r.row.plant_ahead(img) and self.dist_since_plant > spacing_m * 0.6:
            self.r.drive(0, 0)
            self._go("at_plant", "Plant found, stopping")

    def _s_at_plant(self) -> None:
        self.r.drive(0, 0)
        if time.time() - self.t_step < 0.5:
            return
        self.r.arm_pose("look")
        self._go("inspect", "Looking at the plant")

    def _s_inspect(self) -> None:
        if time.time() - self.t_step < float(self.ai.get("inspect_seconds", 2.0)):
            return
        self._go("decide", "Deciding what it needs")

    def _s_decide(self) -> None:
        img = self.r.cam_arm.frame()
        if img is None:
            img = self.r.cam_front.frame()

        label, conf = self.r.classifier.classify(img)
        if not self.r.classifier.ready:
            # No model. Say so. Never invent a diagnosis.
            self.state.mission["message"] = ("No AI model loaded: %s"
                                             % self.r.classifier.reason)
            label, conf = "not_checked", 0.0

        floor = float(self.ai.get("min_confidence", 0.60))
        if conf < floor and label not in ("not_checked", "healthy"):
            # it saw something but is not sure enough to name it. Say "not
            # sure" rather than acting on a guess.
            self.state.mission["message"] = ("Only %.0f%% sure, asking you"
                                             % (conf * 100))
            label = "unknown"

        soil = self.state.telemetry.soil_pct
        # limp leaves are the one case where the probe decides, so go and probe
        if label == "water_stress":
            self.state.mission["message"] = "Putting the probe in the soil"
            soil = self.r.probe_soil()
        plan = tx.plan(label, conf, soil,
                       float(self.ai.get("auto_spray_confidence", 0.85)))

        self.plant_no += 1
        plot = "r%dp%02d" % (self.row_no, self.plant_no)
        rec = PlantRecord(
            id=self.state.next_plant_id(),
            plot=plot,
            common_name=str(plan["common_name"]),
            time=time.time(),
            x_m=self.state.telemetry.x_m,
            y_m=self.state.telemetry.y_m,
            label=plan["label"],
            confidence=round(conf, 3),
            healthy=bool(plan["healthy"]),
            severity=str(plan["severity"]),
            treatment=("%s  %s" % (plan["product"], plan["dose"])).strip(),
            advice=str(plan["advice"]),
            soil_pct=soil,
        )
        rec.photo = self.r.save_photo(img, rec.id)

        # A weed does not need the classifier - it is just a green blob off the
        # row line. Only look for one when the crop plant itself is fine, so a
        # sick plant is never quietly relabelled as a weed.
        self._weed_at = None
        if plan["kind"] == "ok":
            weed = find_weed(self.r.cam_front.frame(), self.ai.get("row", {}))
            if weed:
                self._weed_at = self.r.weed_target()
                plan = tx.plan("weed", 0.9, soil)
                rec.label = plan["label"]
                rec.healthy = bool(plan["healthy"])
                rec.severity = str(plan["severity"])
                rec.advice = str(plan["advice"])

        # keep it forever, so this plant has a history and not just a moment
        try:
            rec.db_id = self.r.db.add_plant(rec.as_dict(), self.mission_id, plot)
        except Exception:
            rec.db_id = 0
        if not rec.healthy:
            self._problems += 1
            self.r.notify.send(
                "problem",
                "AgriRover found %s on plant %s (%.0f%% sure). %s"
                % (plan["common_name"], plot, rec.confidence * 100,
                   plan["advice"][:160]), 90)

        seen_before = []
        try:
            seen_before = self.r.db.plant_history(plot, 6)[1:]
        except Exception:
            pass
        if seen_before and not rec.healthy:
            was = seen_before[0]
            if was.get("label") == rec.label:
                self.state.say("Plant %s had %s last time too" %
                               (plot, rec.common_name or rec.label), "warn")

        self.state.add_plant(rec)
        self._go("act", plan["common_name"])
        self._plan = plan
        self._rec = rec

    def _s_act(self) -> None:
        plan = getattr(self, "_plan", None)
        rec = getattr(self, "_rec", None)
        if plan is None:
            self._go("move_on", "")
            return

        if plan["action"] == "none":
            self._finish_plant(rec, "none")
            self._go("move_on", "Plant is healthy")
            return

        # Pulling a plant out of the ground cannot be undone, so unless you
        # have switched auto weeding on in the config, it asks first.
        auto_weed = bool(self.ai.get("auto_weed_pull", False))
        ask = (plan["action"] == "needs_you"
               or (plan["action"] == "spray" and not self.state.auto_spray)
               or (plan["action"] == "weed_pull" and not auto_weed))

        if ask:
            rec.action = "needs_you"          # until you answer, it is on you
            self.state.set(pending={
                "title": "%s on plant %d" % (plan["common_name"], rec.id),
                "question": self._question(plan),
                "plan": plan,
                "record": rec.id,
                "photo": rec.photo,
                "time": time.time(),
            })
            self.state.add_alert("warn", "Waiting for you: %s"
                                 % plan["common_name"], plant=rec.id)
            try:
                self.r.db.add_alert("warn", "Waiting for you: %s on plant %s"
                                    % (plan["common_name"], rec.plot), rec.db_id)
            except Exception:
                pass
            self.state.mission["message"] = "Waiting for your answer"
            self._pending_started = time.time()
            self.step = "act_wait"
            return

        self._do_action(plan, rec.id)
        self._go("move_on", "Done with this plant")

    def _s_act_wait(self) -> None:
        # nothing to do, the website will call answer(). Just keep still.
        self.r.drive(0, 0)
        if self.state.pending is None:
            self.step = "move_on"

    def _s_move_on(self) -> None:
        self.r.arm_pose("stow")
        self.plants_done += 1
        self.state.mission["plants_done"] = self.plants_done
        self.state.mission["rows_done"] = self.rows_done
        self.dist_since_plant = 0.0
        self._mark()
        if self.target and self.plants_done >= self.target:
            self._go("done", "Finished the target number of plants")
            self.stop("finished")
            return
        self._go("follow", "Moving to the next plant")

    def _s_row_end(self) -> None:
        self.r.drive(0, 0)
        self.r.arm_pose("stow")
        want = int(self.ai.get("rows", 1) or 1)
        self.state.add_alert("info", "Row %d finished, %d plants checked so far"
                             % (self.rows_done + 1, self.plants_done))
        self.rows_done += 1
        self.state.mission["rows_done"] = self.rows_done
        if self.rows_done >= want:
            self.state.mission["message"] = ("Finished. %d rows, %d plants."
                                             % (self.rows_done, self.plants_done))
            self.stop("all rows finished")
            return
        self._go("turning", "Turning into row %d" % (self.rows_done + 1))

    def _s_turning(self) -> None:
        """Round the end and into the next row.

        Dead reckoning, and it says so: it turns for a measured time, shuffles
        across by the row gap, and turns again. With encoders fitted this is
        repeatable; without them it drifts, and on the third row you will be
        straightening it out by hand.
        """
        gap_m = float(self.ai.get("row_gap_mm", 700)) / 1000.0
        vmax = float(self.r.cfg["rover"]["max_speed_mps"])
        track = float(self.r.cfg["rover"]["track_mm"]) / 1000.0
        # a spot turn at half speed covers pi*track/2 metres of wheel travel
        turn_s = (3.14159 * track / 2.0) / max(0.01, vmax * 0.5) / 2.0
        cross_s = gap_m / max(0.01, vmax * 0.5)
        t = time.time() - self.t_step

        if self.r.range_blocked():
            self.r.drive(0, 0)
            self.state.mission["message"] = "Something in the way, waiting"
            return

        if t < turn_s:
            self.r.drive(0.0, 0.5 * self._turn_dir)        # quarter turn
        elif t < turn_s + cross_s:
            self.r.drive(0.5, 0.0)                         # across the gap
        elif t < 2 * turn_s + cross_s:
            self.r.drive(0.0, 0.5 * self._turn_dir)        # and straighten up
        else:
            self.r.drive(0, 0)
            self._turn_dir *= -1                           # zig, then zag
            self.plant_no = 0
            self.row_no += 1
            self._d_row = self.state.telemetry.distance_m
            self._go("find_row", "Looking for row %d" % (self.rows_done + 1))

    def _s_done(self) -> None:
        self.r.drive(0, 0)

    # -------------------------------------------------------------- helpers
    def _question(self, plan: dict) -> str:
        if plan["label"] == "not_checked":
            return ("There is no AI model loaded, so I did not check this "
                    "plant. The photo is saved. Mark it as seen?")
        if plan["kind"] == "unknown":
            return ("I am not sure what is wrong with this plant. Look at the "
                    "photo. Mark it as seen and carry on?")
        if plan["kind"] == "weed":
            return ("There is a weed next to this plant. Pull it out with the "
                    "gripper? This cannot be undone.")
        if plan["kind"] == "viral":
            return ("This looks like %s. No spray cures a virus. "
                    "Pull the plant out and bin it?" % plan["common_name"])
        if plan["action"] in ("spray", "needs_you") and plan["product"]:
            return ("Spray %.0f ml of %s (%s) on this plant? "
                    "Do not pick the crop for %d days after."
                    % (plan["dose_ml"], plan["product"], plan["dose"],
                       plan["phi_days"]))
        return "Act on %s?" % plan["common_name"]

    def _save(self, rec) -> None:
        if rec is None or not getattr(rec, "db_id", 0):
            return
        try:
            self.r.db.update_plant(rec.db_id, action=rec.action,
                                   dose_ml=rec.dose_ml,
                                   sprayed=1 if rec.sprayed else 0)
        except Exception:
            pass

    def _do_action(self, plan: dict, rec_id, forced: bool = False) -> None:
        rec = self._find(rec_id)
        act = plan["action"]
        if act == "spray" or (forced and plan["dose_ml"] > 0):
            ok, msg = self.r.spray(plan["dose_ml"])
            if ok:
                if rec:
                    rec.sprayed = True
                    rec.action = "sprayed"
                    rec.dose_ml = plan["dose_ml"]
                self._sprayed_ml += float(plan["dose_ml"])
                self.state.mission["sprayed_ml"] = round(self._sprayed_ml, 1)
                self.state.say("Sprayed %s on plant %s" % (msg, rec_id))
            else:
                if rec:
                    rec.action = "needs_you"
                self.state.add_alert("error", "Could not spray: " + msg)
        elif act == "weed_pull":
            done = self.r.pull_weed(self._weed_at)
            if rec:
                rec.action = "weed_pulled" if done else "needs_you"
            self.state.say("Weed %s at plant %s"
                           % ("pulled" if done else "could not be pulled", rec_id))
        else:
            if rec:
                rec.action = "seen_by_you" if forced else "needs_you"
        self._save(rec)

    def _finish_plant(self, rec_id, action: str) -> None:
        rec = self._find(rec_id)
        if rec:
            rec.action = action
            self._save(rec)

    def _find(self, rec_id):
        if rec_id is None:
            return None
        if hasattr(rec_id, "id"):
            return rec_id
        for p in reversed(self.state.plants):
            if p.id == rec_id:
                return p
        return None

    def _go(self, step: str, message: str) -> None:
        self.step = step
        self.t_step = time.time()
        if message:
            self.state.mission["message"] = message

    def _mark(self) -> None:
        self._last_x = self.state.telemetry.x_m
        self._last_y = self.state.telemetry.y_m

    def _accumulate(self) -> None:
        t = self.state.telemetry
        d = ((t.x_m - self._last_x) ** 2 + (t.y_m - self._last_y) ** 2) ** 0.5
        self.dist_since_plant += d
        self._last_x, self._last_y = t.x_m, t.y_m
