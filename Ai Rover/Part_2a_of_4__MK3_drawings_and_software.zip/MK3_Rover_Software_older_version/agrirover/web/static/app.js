/* AgriRover MK3 console - the whole front end.
   No framework, no CDN: the rover often has no internet where it works. */
(function () {
  'use strict';

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return [].slice.call((r || document).querySelectorAll(s)); };
  var S = {};                 // latest snapshot from the rover
  var ws = null, trail = [], page = 'live', cache = {}, lastAsk = 0;

  function esc(s) {
    return String(s === null || s === undefined ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  function n(v, dp) {
    if (v === null || v === undefined || isNaN(v)) return '—';
    return Number(v).toFixed(dp === undefined ? 1 : dp);
  }
  function when(t) {
    var d = new Date(t * 1000), now = new Date();
    var same = d.toDateString() === now.toDateString();
    var hm = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
    return same ? hm : d.getDate() + ' ' + d.toLocaleString(undefined, { month: 'short' }) + ' ' + hm;
  }
  function ago(t) {
    var s = Date.now() / 1000 - t;
    if (s < 90) return 'just now';
    if (s < 5400) return Math.round(s / 60) + ' min ago';
    if (s < 172800) return Math.round(s / 3600) + ' hours ago';
    return Math.round(s / 86400) + ' days ago';
  }
  function nice(l) {
    return String(l || 'unknown').replace(/_/g, ' ')
      .replace(/\b\w/g, function (c) { return c.toUpperCase(); });
  }
  function toast(msg) {
    var t = $('#toast');
    t.textContent = msg; t.classList.add('on');
    clearTimeout(t._h); t._h = setTimeout(function () { t.classList.remove('on'); }, 3200);
  }

  /* ------------------------------------------------------------- talking -- */
  function api(path, body) {
    var o = { credentials: 'same-origin' };
    if (body) {
      o.method = 'POST';
      o.headers = { 'Content-Type': 'application/json' };
      o.body = JSON.stringify(body);
    }
    return fetch(path, o).then(function (r) {
      if (r.status === 401) { location.href = '/login'; throw new Error('signed out'); }
      return r.json();
    });
  }
  function cmd(name, args) {
    return api('/api/command', { cmd: name, args: args || {} })
      .then(function (r) { if (r && r.message) toast(r.message); return r; })
      .catch(function () {});
  }
  window.cmd = cmd;

  function connect() {
    var proto = location.protocol === 'https:' ? 'wss' : 'ws';
    try { ws = new WebSocket(proto + '://' + location.host + '/ws'); }
    catch (e) { return setTimeout(connect, 2000); }
    ws.onopen = function () {
      $('#camF').src = '/cam/front'; $('#camA').src = '/cam/arm';
      setLink(true);
    };
    ws.onmessage = function (ev) { S = JSON.parse(ev.data); draw(); };
    ws.onclose = function () { setLink(false); setTimeout(connect, 1800); };
    ws.onerror = function () { try { ws.close(); } catch (e) {} };
  }
  function setLink(ok) {
    var c = $('#cLink');
    c.className = 'chip ' + (ok ? (S.sim ? 'warn' : 'on') : 'bad');
    c.lastChild.textContent = ok ? (S.sim ? 'simulation' : 'live') : 'no connection';
  }

  /* ------------------------------------------------------------ the pages - */
  function go(name) {
    page = name;
    $$('.navbtn').forEach(function (b) {
      if (b.dataset.page === name) b.setAttribute('aria-current', 'page');
      else b.removeAttribute('aria-current');
    });
    $$('.page').forEach(function (p) { p.hidden = p.id !== 'p-' + name; });
    if (history.replaceState) history.replaceState(null, '', '#' + name);
    load(name);
    window.scrollTo(0, 0);
  }
  window.go = go;

  function load(name) {
    if (name === 'field') return loadField();
    if (name === 'plants') return loadPlants();
    if (name === 'charts') return loadCharts();
    if (name === 'runs') return loadRuns();
    if (name === 'timetable') return loadPatrols();
    if (name === 'settings') return loadSettings();
  }

  /* =============================================================== LIVE === */
  function draw() {
    if (!S.mode) return;
    setLink(true);

    pill('#cMode', S.mode, S.mode === 'AUTO' ? 'on' : S.mode === 'ESTOP' ? 'bad'
         : S.mode === 'MANUAL' ? 'amber' : '');
    pill('#cRC', S.rc_live ? 'remote live' : 'remote off', S.rc_live ? 'on' : '');
    pill('#cAI', S.ai_ready === true ? 'AI ready' : 'no AI model',
         S.ai_ready === true ? 'on' : 'warn');
    $('#cAI').title = S.ai_ready === true ? 'the plant model is loaded'
      : 'it will not guess a disease: ' + (S.ai_reason || 'no model');
    pill('#cSpray', S.spray_armed ? (S.auto_spray ? 'spray ARMED + auto' : 'spray ARMED')
         : 'spray locked', S.spray_armed ? 'bad' : '');

    var b = $('#banner');
    if (S.estop) { b.style.display = 'block'; b.textContent = 'EMERGENCY STOP — ' + (S.estop_reason || ''); }
    else b.style.display = 'none';
    $('#btnClear').hidden = !S.estop;

    ['IDLE', 'MANUAL', 'AUTO', 'HOLD'].forEach(function (m) {
      $('#m' + m).className = S.mode === m ? 'sel' : '';
    });
    $('#btnArm').className = S.spray_armed ? 'stop' : '';
    $('#btnArm').textContent = S.spray_armed ? 'Disarm the pump' : 'Arm the pump';
    $('#btnAuto').className = S.auto_spray ? 'stop' : '';
    $('#recDot').hidden = !S.recording;

    var t = S.telemetry || {};
    stat('Batt', n(t.battery_v, 2) + ' V', t.battery_pct,
         t.battery_pct < 20 ? 'var(--bad)' : t.battery_pct < 40 ? 'var(--attn)' : 'var(--good)',
         n(t.battery_pct, 0) + '%');
    stat('Tank', Math.round(t.tank_pct || 0) + ' %', t.tank_pct, 'var(--s-violet)',
         Math.round(t.tank_ml || 0) + ' ml');
    stat('Soil', t.soil_pct == null ? '—' : Math.round(t.soil_pct) + ' %',
         t.soil_pct || 0,
         t.soil_pct == null ? '#39423c' : t.soil_pct < 25 ? 'var(--bad)'
           : t.soil_pct < 40 ? 'var(--attn)' : 'var(--s-aqua)',
         t.soil_pct == null ? 'no probe yet' : '');
    $('#vSpeed').textContent = n(t.speed_mps, 2) + ' m/s';
    $('#vDist').textContent = n(t.distance_m, 1) + ' m';
    $('#vDistSub').textContent = t.odometry_measured ? 'measured' : 'estimated, drifts';
    $('#vDistSub').style.color = t.odometry_measured ? 'var(--good)' : 'var(--dim)';
    $('#vCpu').textContent = Math.round(t.cpu_temp_c || 0) + ' °C';

    var plants = S.plants || [];
    $('#vChecked').textContent = plants.length;
    var bad = plants.filter(function (p) { return !p.healthy; }).length;
    $('#vAttn').textContent = bad;
    $('#navAttn').textContent = bad || '';
    $('#navAttn').hidden = !bad;

    var m = S.mission || {};
    $('#missionKv').innerHTML =
      kv('Job', m.running ? 'running' : 'stopped') +
      kv('Step', m.step || '—') +
      kv('Row', (m.rows_target > 1
            ? ((m.rows_done || 0) + 1) + ' of ' + m.rows_target
            : (m.row || '—'))) +
      kv('Plants done', (m.plants_done || 0) + (m.plants_target ? ' / ' + m.plants_target : '')) +
      kv('Sprayed', (m.sprayed_ml || 0) + ' ml');
    $('#missionMsg').textContent = m.message || '';
    $('#btnGoHome').hidden = !!S.returning;
    $('#btnStopHome').hidden = !S.returning;

    var a = S.arm || {}, hand = S.hand || {};
    $('#armKv').innerHTML = ['yaw', 'shoulder', 'elbow', 'wrist', 'gripper', 'sensor']
      .map(function (k) { return kv(k, n(a[k], 0) + '°'); }).join('') +
      kv('pose', (a.pose || '—') + (a.moving ? ' (moving)' : '')) +
      kv('hand is at', hand.x === undefined ? '—'
         : n(hand.x, 0) + ', ' + n(hand.y, 0) + ', ' + n(hand.z, 0) + ' mm');

    var np = S.next_patrol;
    $('#nextPatrol').textContent = np
      ? 'Next patrol: ' + np.name + ', ' + when(np.at)
      : 'No patrol set';

    drawAsk();
    drawPlants(plants);
    drawLog();
    drawTrail(t);
  }

  function pill(sel, text, cls) {
    var el = $(sel);
    el.className = 'chip ' + (cls || '');
    el.lastChild.textContent = text;
  }
  function kv(k, v) {
    return '<div class="kv"><span>' + esc(k) + '</span><span>' + esc(v) + '</span></div>';
  }
  function stat(id, text, pct, colour, sub) {
    $('#v' + id).textContent = text;
    var bar = $('#b' + id);
    if (bar) {
      bar.style.width = Math.max(0, Math.min(100, pct || 0)) + '%';
      bar.style.background = colour;
    }
    var s = $('#s' + id);
    if (s) s.textContent = sub || '';
  }

  function drawAsk() {
    var p = S.pending;
    $('#askCard').hidden = !p;
    if (!p) return;
    $('#askTitle').textContent = p.title || '';
    $('#askText').textContent = p.question || '';
    var img = $('#askPhoto');
    if (p.photo) { img.src = '/photos/' + p.photo; img.hidden = false; }
    else img.hidden = true;
    if (p.time && p.time > lastAsk) {
      lastAsk = p.time;
      if (page !== 'live') toast('The rover needs your answer');
      try {
        if (window.Notification && Notification.permission === 'granted')
          new Notification('AgriRover needs you', { body: p.question });
      } catch (e) {}
    }
  }

  function drawPlants(plants) {
    var tb = $('#tblLive');
    if (!plants.length) {
      tb.innerHTML = '<tr><td colspan="6" class="empty">Nothing checked yet this run.</td></tr>';
      return;
    }
    tb.innerHTML = plants.slice().reverse().map(function (p) {
      var sev = p.healthy ? 'ok' : (p.severity || 'mild');
      return '<tr class="click" onclick="openPlant(\'' + esc(p.plot) + '\')">' +
        '<td data-l="Plant" class="num">' + esc(p.plot || p.id) + '</td>' +
        '<td data-l="Found"><b>' + esc(nice(p.label)) + '</b></td>' +
        '<td data-l="Sure" class="num">' + Math.round((p.confidence || 0) * 100) + '%</td>' +
        '<td data-l="How bad"><span class="tag ' + sev + '">' +
          (p.healthy ? 'fine' : sev) + '</span></td>' +
        '<td data-l="It did">' + esc(didWhat(p)) + '</td>' +
        '<td data-l="You do" class="note">' + esc(p.advice || '') + '</td></tr>';
    }).join('');
  }
  function didWhat(p) {
    return ({ sprayed: 'sprayed ' + (p.dose_ml || 0) + ' ml', weed_pulled: 'weed pulled',
      needs_you: 'waiting for you', declined: 'you skipped it',
      seen_by_you: 'you marked it seen', none: 'nothing needed'
    })[p.action] || String(p.action || '').replace(/_/g, ' ') || '—';
  }

  function drawLog() {
    $('#logBox').innerHTML = (S.log || []).map(function (l) {
      return '<div class="' + (l.level || '') + '"><time>' + when(l.time) + '</time>' +
        esc(l.text) + '</div>';
    }).join('') || '<div style="color:var(--dim)">Nothing yet.</div>';
  }

  /* --------------------------------------------------------- the live map - */
  function drawTrail(t) {
    var c = $('#trail'); if (!c || page !== 'live') return;
    var W = c.parentNode.clientWidth, H = 190, r = devicePixelRatio || 1;
    c.width = W * r; c.height = H * r; c.style.height = H + 'px';
    var g = c.getContext('2d'); g.setTransform(r, 0, 0, r, 0, 0);
    g.clearRect(0, 0, W, H);

    var last = trail[trail.length - 1];
    if (!last || Math.abs(last.x - t.x_m) > 0.01 || Math.abs(last.y - t.y_m) > 0.01)
      trail.push({ x: t.x_m, y: t.y_m });
    if (trail.length > 2500) trail.shift();

    var pts = (S.plants || []).map(function (p) {
      return { x: p.x_m, y: p.y_m, healthy: p.healthy, sprayed: p.sprayed };
    });
    var all = trail.concat(pts).concat([{ x: 0, y: 0 }]);
    var xs = all.map(function (p) { return p.x; }), ys = all.map(function (p) { return p.y; });
    var minx = Math.min.apply(null, xs), maxx = Math.max.apply(null, xs);
    var miny = Math.min.apply(null, ys), maxy = Math.max.apply(null, ys);
    var pad = 0.6;
    minx -= pad; maxx += pad; miny -= pad; maxy += pad;
    var sc = Math.min(W / Math.max(0.4, maxx - minx), H / Math.max(0.4, maxy - miny));
    var ox = (W - (maxx - minx) * sc) / 2, oy = (H - (maxy - miny) * sc) / 2;
    var X = function (x) { return ox + (x - minx) * sc; };
    var Y = function (y) { return H - (oy + (y - miny) * sc); };

    // a one metre grid, so the picture has a scale
    g.strokeStyle = '#1b241f'; g.lineWidth = 1;
    for (var gx = Math.ceil(minx); gx <= maxx; gx++) {
      g.beginPath(); g.moveTo(X(gx), 0); g.lineTo(X(gx), H); g.stroke();
    }
    for (var gy = Math.ceil(miny); gy <= maxy; gy++) {
      g.beginPath(); g.moveTo(0, Y(gy)); g.lineTo(W, Y(gy)); g.stroke();
    }

    if (trail.length > 1) {
      g.beginPath();
      trail.forEach(function (p, i) { i ? g.lineTo(X(p.x), Y(p.y)) : g.moveTo(X(p.x), Y(p.y)); });
      g.strokeStyle = '#2f6b45'; g.lineWidth = 2; g.stroke();
    }
    pts.forEach(function (p) {
      g.beginPath(); g.arc(X(p.x), Y(p.y), 4.5, 0, 6.2832);
      g.fillStyle = p.sprayed ? '#F0544F' : p.healthy ? '#3FB950' : '#E8853A';
      g.fill();
    });
    // where it is now, pointing where it is going
    var hx = X(t.x_m), hy = Y(t.y_m), a = -(t.heading_deg || 0) * Math.PI / 180;
    g.save(); g.translate(hx, hy); g.rotate(a);
    g.beginPath(); g.moveTo(10, 0); g.lineTo(-6, 6); g.lineTo(-6, -6); g.closePath();
    g.fillStyle = '#D9A441'; g.fill(); g.restore();

    $('#trailPos').textContent = 'x ' + n(t.x_m, 2) + ' m, y ' + n(t.y_m, 2) +
      ' m, heading ' + Math.round(t.heading_deg || 0) + '°, 1 m grid';
  }

  /* ============================================================== FIELD === */
  function loadField() {
    api('/api/field').then(function (r) {
      cache.field = r.plants || [];
      drawField();
      $('#fieldCount').textContent = cache.field.length + ' plants known';
    });
  }
  function drawField() {
    var rows = cache.field || [];
    var c = $('#fieldMap'), box = c.parentNode;
    var W = box.clientWidth, H = Math.max(280, Math.min(520, W * 0.55));
    var r = devicePixelRatio || 1;
    c.width = W * r; c.height = H * r; c.style.height = H + 'px';
    var g = c.getContext('2d'); g.setTransform(r, 0, 0, r, 0, 0);
    g.clearRect(0, 0, W, H);
    if (!rows.length) {
      g.fillStyle = '#83958a'; g.font = '13px system-ui'; g.textAlign = 'center';
      g.fillText('No plants recorded yet. Run AUTO once and they appear here.', W / 2, H / 2);
      return;
    }
    var xs = rows.map(function (p) { return p.x || 0; });
    var ys = rows.map(function (p) { return p.y || 0; });
    var minx = Math.min.apply(null, xs) - 0.5, maxx = Math.max.apply(null, xs) + 0.5;
    var miny = Math.min.apply(null, ys) - 0.5, maxy = Math.max.apply(null, ys) + 0.5;
    var sc = Math.min((W - 40) / Math.max(0.5, maxx - minx),
                      (H - 40) / Math.max(0.5, maxy - miny));
    var ox = (W - (maxx - minx) * sc) / 2, oy = (H - (maxy - miny) * sc) / 2;
    var X = function (x) { return ox + (x - minx) * sc; };
    var Y = function (y) { return H - (oy + (y - miny) * sc); };

    g.strokeStyle = '#1b241f';
    for (var gx = Math.ceil(minx); gx <= maxx; gx++) {
      g.beginPath(); g.moveTo(X(gx), 0); g.lineTo(X(gx), H); g.stroke();
    }
    for (var gy = Math.ceil(miny); gy <= maxy; gy++) {
      g.beginPath(); g.moveTo(0, Y(gy)); g.lineTo(W, Y(gy)); g.stroke();
    }

    c._hits = [];
    rows.forEach(function (p) {
      var x = X(p.x || 0), y = Y(p.y || 0);
      var col = p.sprayed ? '#F0544F' : p.healthy ? '#3FB950' : '#E8853A';
      g.beginPath(); g.arc(x, y, 8, 0, 6.2832);
      g.fillStyle = col; g.fill();
      g.strokeStyle = '#0D1210'; g.lineWidth = 2; g.stroke();
      g.fillStyle = '#0D1210'; g.font = '600 9px ui-monospace,monospace';
      g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText(String(p.plot || '').replace(/^r\d+p/, ''), x, y);
      c._hits.push({ x: x, y: y, plot: p.plot });
    });
    g.fillStyle = '#83958a'; g.font = '11px ui-monospace,monospace';
    g.textAlign = 'left'; g.textBaseline = 'alphabetic';
    g.fillText('1 m grid', 10, H - 10);

    c.onclick = function (ev) {
      var b = c.getBoundingClientRect();
      var mx = ev.clientX - b.left, my = ev.clientY - b.top, best = null, bd = 900;
      (c._hits || []).forEach(function (h) {
        var d = (h.x - mx) * (h.x - mx) + (h.y - my) * (h.y - my);
        if (d < bd) { bd = d; best = h; }
      });
      if (best) openPlant(best.plot);
    };
  }

  /* ============================================================= PLANTS === */
  function loadPlants() {
    api('/api/field').then(function (r) {
      cache.field = r.plants || [];
      renderPlantList();
    });
  }
  function renderPlantList() {
    var q = ($('#plantSearch').value || '').toLowerCase();
    var only = $('#plantFilter').value;
    var rows = (cache.field || []).filter(function (p) {
      if (only === 'bad' && p.healthy) return false;
      if (only === 'sprayed' && !p.sprayed) return false;
      if (!q) return true;
      return (String(p.plot) + ' ' + p.label + ' ' + (p.common_name || '')).toLowerCase().indexOf(q) >= 0;
    });
    $('#tblField').innerHTML = rows.length ? rows.map(function (p) {
      var sev = p.healthy ? 'ok' : (p.severity || 'mild');
      return '<tr class="click" onclick="openPlant(\'' + esc(p.plot) + '\')">' +
        '<td data-l="Plant" class="num">' + esc(p.plot) + '</td>' +
        '<td data-l="Last seen"><b>' + esc(p.common_name || nice(p.label)) + '</b>' +
          '<div class="note">' + ago(p.ts) + '</div></td>' +
        '<td data-l="How bad"><span class="tag ' + sev + '">' +
          (p.healthy ? 'fine' : sev) + '</span></td>' +
        '<td data-l="It did">' + esc(didWhat(p)) + '</td>' +
        '<td data-l="Treatment" class="note">' + esc(p.treatment || '—') + '</td></tr>';
    }).join('') : '<tr><td colspan="5" class="empty">No plants match that.</td></tr>';
  }
  window.renderPlantList = renderPlantList;

  function openPlant(plot) {
    if (!plot) return;
    api('/api/plant/' + encodeURIComponent(plot)).then(function (r) {
      var h = r.history || [], s = r.summary || {}, first = h[0] || {};
      $('#drawerBody').innerHTML =
        '<div class="row"><h2 style="font-size:20px">Plant ' + esc(plot) + '</h2>' +
        '<span class="spacer"></span>' +
        '<button class="sm ghost" onclick="closeDrawer()">Close</button></div>' +
        '<div class="stats">' +
          tile('Times checked', s.n || 0) +
          tile('Problems', s.ill || 0) +
          tile('Sprayed', (s.sp || 0) + '×') +
          tile('Total dose', n(s.ml || 0, 0) + ' ml') +
        '</div>' +
        (first.photo ? '<img src="/photos/' + esc(first.photo) +
          '" alt="last photo of plant ' + esc(plot) + '" ' +
          'style="width:100%;border-radius:10px;border:1px solid var(--line)">' : '') +
        '<div class="card"><h2>What happened, newest first</h2><div class="body">' +
        h.map(function (x) {
          var sev = x.healthy ? 'ok' : (x.severity || 'mild');
          return '<div style="display:grid;gap:4px;padding:9px 0;border-bottom:1px solid var(--line-soft)">' +
            '<div class="row"><b>' + esc(x.common_name || nice(x.label)) + '</b>' +
            '<span class="tag ' + sev + '">' + (x.healthy ? 'fine' : sev) + '</span>' +
            '<span class="spacer"></span><span class="note">' + when(x.ts) + '</span></div>' +
            '<div class="note">' + esc(didWhat(x)) +
              (x.treatment ? ' — ' + esc(x.treatment) : '') + '</div>' +
            (x.advice ? '<div class="note">' + esc(x.advice) + '</div>' : '') +
          '</div>';
        }).join('') + '</div></div>';
      $('#drawer').classList.add('on');
    }).catch(function () { toast('No history for that plant yet'); });
  }
  window.openPlant = openPlant;
  window.closeDrawer = function () { $('#drawer').classList.remove('on'); };
  function tile(label, value) {
    return '<div class="stat"><i>' + esc(label) + '</i><b>' + esc(value) + '</b></div>';
  }

  /* ============================================================= CHARTS === */
  function loadCharts() {
    var hours = parseFloat($('#chartRange').value || '6');
    api('/api/samples?hours=' + hours).then(function (r) {
      var s = r.samples || [];
      var pick = function (k) {
        return s.map(function (x) { return { x: x.ts, y: x[k] }; });
      };
      var latest = s[s.length - 1] || {};
      $('#nowBatt').textContent = n(latest.battery_v, 2) + ' V';
      $('#nowSoil').textContent = latest.soil_pct == null ? '—' : n(latest.soil_pct, 0) + ' %';
      $('#nowTank').textContent = n(latest.tank_pct, 0) + ' %';
      Chart.line($('#chBatt'), { points: pick('battery_v'), colour: '#3987e5',
        unit: ' V', dp: 2, height: 148 });
      Chart.line($('#chSoil'), { points: pick('soil_pct'), colour: '#199e70',
        unit: ' %', dp: 0, min: 0, max: 100, height: 148 });
      Chart.line($('#chTank'), { points: pick('tank_pct'), colour: '#9085e9',
        unit: ' %', dp: 0, min: 0, max: 100, height: 148 });
    });
    api('/api/history?days=14').then(function (r) {
      var rows = (r.days || []).map(function (d) {
        return { label: d.day, short: d.day.slice(5).replace('-', '/'),
                 a: d.checked || 0, b: d.problems || 0 };
      });
      Chart.bars($('#chDays'), { rows: rows, aName: 'checked', bName: 'problems',
        aColour: '#3987e5', bColour: '#d95926', height: 180 });
      Chart.tally($('#tally'), (r.problems || []).map(function (p) {
        return { name: p.common_name || nice(p.label), n: p.n };
      }));
    });
  }
  window.loadCharts = loadCharts;

  /* =============================================================== RUNS === */
  function loadRuns() {
    api('/api/missions').then(function (r) {
      $('#tblRuns').innerHTML = (r.missions || []).length ? r.missions.map(function (m) {
        var mins = m.ended ? Math.max(1, Math.round((m.ended - m.started) / 60)) : null;
        return '<tr>' +
          '<td data-l="When">' + when(m.started) + '<div class="note">' +
            (m.kind === 'patrol' ? 'timetabled patrol' : 'you started it') + '</div></td>' +
          '<td data-l="Lasted" class="num">' + (mins ? mins + ' min' : 'running') + '</td>' +
          '<td data-l="Plants" class="num">' + (m.plants_checked || 0) + '</td>' +
          '<td data-l="Problems" class="num">' + (m.problems || 0) + '</td>' +
          '<td data-l="Sprayed" class="num">' + n(m.sprayed_ml, 0) + ' ml</td>' +
          '<td data-l="Went" class="num">' + n(m.distance_m, 1) + ' m</td>' +
          '<td data-l="Ended" class="note">' + esc(m.note || '') + '</td></tr>';
      }).join('') : '<tr><td colspan="7" class="empty">No runs yet.</td></tr>';
    });
    api('/api/photos?limit=2000').then(function (r) {
      var n = (r.photos || []).length;
      $('#photoCount').textContent = n
        ? n + ' photos saved so far'
        : 'No photos yet — they appear after the first AUTO run.';
    });
    api('/api/recordings').then(function (r) {
      var rows = r.recordings || [];
      $('#recList').innerHTML = rows.length ? rows.map(function (v) {
        if (!v.exists) return '';
        return '<div class="card"><h2>' + when(v.started) +
          '<span class="spacer"></span><span class="note">' + v.frames +
          ' frames · ' + v.size_mb + ' MB</span></h2><div class="body">' +
          '<video controls preload="none" style="width:100%;border-radius:8px" ' +
          'src="/video/' + esc(v.path) + '"></video>' +
          '<a class="note" href="/video/' + esc(v.path) + '" download>Download this run</a>' +
          '</div></div>';
      }).join('') : '<div class="empty">No recordings yet. They are made ' +
        'automatically while AUTO is running, if recording is on in Settings.</div>';
    });
  }

  /* ========================================================== TIMETABLE === */
  function loadPatrols() {
    api('/api/patrols').then(function (r) {
      cache.days = r.day_names || ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      var rows = r.patrols || [];
      $('#patrolNext').textContent = r.next
        ? 'Next: ' + (r.next.name || 'patrol') + ', ' + when(r.next.at)
        : 'Nothing scheduled';
      $('#patrolList').innerHTML = rows.length ? rows.map(patrolRow).join('')
        : '<div class="empty">No patrols yet. Add one below.</div>';
    });
  }
  function patrolRow(p) {
    var days = String(p.days || '').split(',').filter(Boolean)
      .map(function (d) { return cache.days[+d]; }).join(' ') || 'every day';
    return '<div class="card"><div class="body" style="gap:9px">' +
      '<div class="row"><b style="font-size:16px">' + esc(p.name || 'patrol') + '</b>' +
      '<span class="tag ' + (p.enabled ? 'ok' : '') + '">' +
        (p.enabled ? 'on' : 'off') + '</span>' +
      (p.spray ? '<span class="tag severe">may spray</span>'
               : '<span class="tag">look only</span>') +
      '<span class="spacer"></span>' +
      '<span class="num" style="font-size:19px">' + esc(p.at) + '</span></div>' +
      '<div class="note">' + esc(days) + ' · ' +
        (p.plants ? p.plants + ' plants' : 'the whole row') +
        (p.last_run ? ' · last ran ' + ago(p.last_run) : '') + '</div>' +
      '<div class="row">' +
      '<button class="sm" onclick="togglePatrol(' + p.id + ',' + (p.enabled ? 0 : 1) + ')">' +
        (p.enabled ? 'Turn off' : 'Turn on') + '</button>' +
      '<button class="sm ghost" onclick="deletePatrol(' + p.id + ')">Delete</button>' +
      '</div></div></div>';
  }
  window.togglePatrol = function (id, on) {
    api('/api/patrols').then(function (r) {
      var p = (r.patrols || []).filter(function (x) { return x.id === id; })[0];
      if (!p) return;
      p.enabled = !!on;
      api('/api/patrols', p).then(loadPatrols);
    });
  };
  window.deletePatrol = function (id) {
    api('/api/patrols', { delete: id }).then(loadPatrols);
  };
  window.addPatrol = function () {
    var days = $$('#dayPick input:checked').map(function (i) { return i.value; }).join(',');
    var body = {
      name: $('#pName').value || 'Morning check',
      at: $('#pAt').value || '07:00',
      days: days,
      plants: parseInt($('#pPlants').value || '0', 10) || 0,
      spray: $('#pSpray').checked, enabled: true
    };
    api('/api/patrols', body).then(function () {
      $('#pName').value = ''; loadPatrols(); toast('Patrol added');
    });
  };

  /* =========================================================== SETTINGS === */
  var LABELS = {
    'drive.max_speed_mps': ['Top speed', 'metres per second at full throttle'],
    'drive.speed_limit': ['Speed limit', 'fraction of top speed the sticks can ask for'],
    'drive.reverse_on_low_batt': ['Come home on low battery', 'reverse back to the start'],
    'spray.max_ml_per_plant': ['Most ml on one plant', 'a hard stop, never exceeded'],
    'spray.max_ml_per_session': ['Most ml in one outing', 'a hard stop, never exceeded'],
    'spray.ml_per_second': ['Pump flow rate', 'measure yours: run it 10 s into a cup'],
    'spray.tank_litres': ['Tank size', 'litres'],
    'spray.require_arm_switch': ['Pump must be armed first', 'leave this on'],
    'ai.min_confidence': ['Ask below this confidence', '0 to 1'],
    'ai.auto_spray_confidence': ['Never spray alone below', '0 to 1'],
    'ai.auto_weed_pull': ['Pull weeds without asking', 'pulling cannot be undone'],
    'ai.inspect_seconds': ['Seconds looking at each plant', ''],
    'ai.plant_spacing_mm': ['Gap between plants', 'millimetres'],
    'ai.row_length_m': ['Row length', 'metres, a hard cap on one row'],
    'ai.rows': ['How many rows', 'it turns into the next one at the end'],
    'ai.row_gap_mm': ['Gap between rows', 'millimetres, for the turn'],
    'safety.battery.warn_v': ['Warn at', 'volts'],
    'safety.battery.stop_v': ['Stop at', 'volts, must be below the warning'],
    'safety.return_home_pct': ['Come home at battery %', '0 turns it off'],
    'safety.tilt_stop_deg': ['Stop if leaning more than', 'degrees, needs a tilt sensor'],
    'record.enabled': ['Record every run', 'a frame every couple of seconds'],
    'record.every_seconds': ['Seconds between frames', ''],
    'record.keep_days': ['Keep recordings for', 'days'],
    'notify.on_problem': ['Tell me about problems', ''],
    'notify.on_finish': ['Tell me when a run ends', ''],
    'notify.on_low_battery': ['Tell me about low battery', ''],
    'notify.on_estop': ['Tell me about emergency stops', ''],
    'notify.telegram_token': ['Telegram bot token', 'from @BotFather'],
    'notify.telegram_chat_id': ['Telegram chat id', 'the number the bot sees']
  };
  var GROUPS = [
    ['Driving', 'drive.'], ['Spraying', 'spray.'], ['Deciding', 'ai.'],
    ['Looking after itself', 'safety.'], ['Recording', 'record.'],
    ['Telling you', 'notify.']
  ];

  function loadSettings() {
    api('/api/settings').then(function (r) {
      cache.settings = r.settings;
      $('#accName').value = (r.user && r.user.name) || '';
      $('#fitted').innerHTML = [
        ['Wheel encoders', r.fitted.encoders, r.why.encoders,
         'without them the distance is estimated and drifts'],
        ['Tilt sensor', r.fitted.imu, r.why.imu,
         'without it the leaning cut-out can never fire'],
        ['Front range sensor', r.fitted.range, r.why.range,
         'without it nothing stops it driving into something'],
        ['Plant AI model', S.ai_ready === true, r.why.ai,
         'without it every plant is logged as not checked'],
        ['Front camera measured', r.fitted.camera_measured, r.why.camera_measured,
         'without it the arm cannot aim at what the camera sees']
      ].map(function (f) {
        return '<div class="kv"><span>' + esc(f[0]) + '<div class="note">' +
          esc(f[1] ? 'working' : f[3]) + '</div></span>' +
          '<span class="tag ' + (f[1] ? 'ok' : '') + '">' +
          (f[1] ? 'fitted' : 'not fitted') + '</span></div>';
      }).join('') + (r.arm ? '<div class="kv"><span>Arm reach' +
        '<div class="note">from the link lengths in the CAD</div></span>' +
        '<span>' + r.arm.min_mm + ' to ' + r.arm.reach_mm + ' mm</span></div>' : '');

      $('#setForm').innerHTML = GROUPS.map(function (grp) {
        var keys = Object.keys(r.settings).filter(function (k) {
          return k.indexOf(grp[1]) === 0;
        });
        if (!keys.length) return '';
        return '<div class="card"><h2>' + esc(grp[0]) + '</h2><div class="body">' +
          '<div class="formgrid">' + keys.map(function (k) {
            return field(k, r.settings[k]);
          }).join('') + '</div></div></div>';
      }).join('');
    });
  }
  function field(key, s) {
    var lab = LABELS[key] || [key, ''];
    var id = 'set_' + key.replace(/\./g, '_');
    if (s.type === 'bool') {
      return '<label class="switch" for="' + id + '"><input type="checkbox" id="' + id +
        '" data-key="' + key + '"' + (s.value ? ' checked' : '') + '>' +
        '<span>' + esc(lab[0]) + (lab[1] ? '<div class="hint">' + esc(lab[1]) +
          '</div>' : '') + '</span></label>';
    }
    var limits = (s.min !== null && s.min !== undefined)
      ? ' (' + s.min + ' to ' + s.max + ')' : '';
    var type = s.type === 'str' ? 'text' : 'number';
    var step = s.type === 'int' ? '1' : '0.01';
    return '<label for="' + id + '">' + esc(lab[0]) +
      '<input type="' + type + '" id="' + id + '" data-key="' + key +
      '" value="' + esc(s.value) + '"' +
      (type === 'number' ? ' step="' + step + '" min="' + s.min + '" max="' + s.max + '"' : '') +
      '><span class="hint">' + esc(lab[1]) + esc(limits) + '</span></label>';
  }
  window.saveSettings = function () {
    var changes = {};
    $$('#setForm [data-key]').forEach(function (el) {
      changes[el.dataset.key] = el.type === 'checkbox' ? el.checked : el.value;
    });
    api('/api/settings', { changes: changes }).then(function (r) {
      var bad = Object.keys(r.refused || {});
      if (bad.length) toast(bad[0] + ': ' + r.refused[bad[0]]);
      else toast('Saved. It is using the new settings now.');
      loadSettings();
    });
  };
  window.testNotify = function () {
    api('/api/notify/test').then(function (r) { toast(r.message || 'sent'); });
  };
  window.changeAccount = function () {
    var body = { old: $('#accOld').value, new: $('#accNew').value,
                 username: $('#accName').value };
    api('/api/account', body).then(function (r) {
      if (!r.ok) return toast(r.error || 'could not change it');
      toast('Changed. Signing you out.');
      setTimeout(function () { location.href = '/login'; }, 1200);
    });
  };
  window.signOut = function () {
    api('/api/logout', {}).then(function () { location.href = '/login'; });
  };

  /* ========================================================== the joypad == */
  function joypad() {
    var pad = $('#pad'), knob = $('#knob'), on = false, timer = null;
    function send(th, st) { cmd('drive', { throttle: th, steer: st }); }
    function at(ev) {
      var r = pad.getBoundingClientRect();
      var p = ev.touches ? ev.touches[0] : ev;
      return { x: (p.clientX - r.left) / r.width * 2 - 1,
               y: -((p.clientY - r.top) / r.height * 2 - 1) };
    }
    function move(ev) {
      if (!on) return;
      var v = at(ev);
      v.x = Math.max(-1, Math.min(1, v.x)); v.y = Math.max(-1, Math.min(1, v.y));
      knob.style.left = (50 + v.x * 42) + '%';
      knob.style.top = (50 - v.y * 42) + '%';
      pad._v = v;
      if (ev.cancelable) ev.preventDefault();
    }
    function start(ev) {
      if (S.rc_live) { toast('The remote is on, so it is driving'); return; }
      on = true; move(ev);
      timer = setInterval(function () {
        if (pad._v) send(pad._v.y, pad._v.x);
      }, 120);
    }
    function end() {
      on = false; pad._v = null;
      clearInterval(timer);
      knob.style.left = '50%'; knob.style.top = '50%';
      send(0, 0);
    }
    pad.addEventListener('mousedown', start);
    pad.addEventListener('touchstart', start, { passive: false });
    document.addEventListener('mousemove', move);
    pad.addEventListener('touchmove', move, { passive: false });
    document.addEventListener('mouseup', end);
    pad.addEventListener('touchend', end);
  }

  /* ================================================================ boot == */
  function boot() {
    $$('.navbtn').forEach(function (b) {
      b.onclick = function () { go(b.dataset.page); };
    });
    $('#speed').oninput = function () {
      $('#speedTxt').textContent = Math.round(this.value * 100) + '%';
    };
    $('#speed').onchange = function () {
      cmd('speed_limit', { value: parseFloat(this.value) });
    };
    $('#dayPick').innerHTML = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
      .map(function (d, i) {
        return '<label class="switch" style="padding:6px 9px"><input type="checkbox" ' +
          'value="' + i + '" checked><span>' + d + '</span></label>';
      }).join('');
    joypad();
    connect();
    go((location.hash || '#live').slice(1) || 'live');
    window.addEventListener('resize', function () {
      clearTimeout(window._rs);
      window._rs = setTimeout(function () {
        if (page === 'charts') loadCharts();
        if (page === 'field') drawField();
      }, 220);
    });
    if (window.Notification && Notification.permission === 'default') {
      $('#askNotify').hidden = false;
    }
  }
  window.reachTo = function () {
    var body = { x: +$('#rx').value, y: +$('#ry').value, z: +$('#rz').value };
    api('/api/command', { cmd: 'reach', args: body }).then(function (r) {
      $('#reachNote').textContent = r.message || '';
      $('#reachNote').style.color = r.ok ? 'var(--good)' : 'var(--attn)';
    });
  };
  window.pullWeed = function () {
    api('/api/command', { cmd: 'pull_weed', args: {} }).then(function (r) {
      toast(r.message || (r.ok ? 'done' : 'could not'));
    });
  };
  window.enableNotifications = function () {
    Notification.requestPermission().then(function () { $('#askNotify').hidden = true; });
  };

  document.addEventListener('DOMContentLoaded', boot);
}());
