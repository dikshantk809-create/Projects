"""The six servos: arm yaw, shoulder, elbow, wrist, gripper and the soil probe.

Driven by a PCA9685 16 channel board over I2C so the Pi does not have to make
six clean PWM signals itself. Every move is rate limited, so the arm never
snaps to a new angle and tears a horn off.
"""
from __future__ import annotations

import threading
import time
from typing import Dict, Optional

try:
    import board                                     # type: ignore
    import busio                                     # type: ignore
    from adafruit_pca9685 import PCA9685             # type: ignore
except Exception:                                    # pragma: no cover
    board = busio = PCA9685 = None


class ServoBank:
    def __init__(self, cfg: dict, sim: bool = False):
        self.cfg = cfg
        self.chans: Dict[str, dict] = cfg["channels"]
        self.speed = float(cfg.get("move_speed_dps", 60))
        self.sim = sim or PCA9685 is None
        self._lock = threading.RLock()
        self.angle: Dict[str, float] = {k: v["safe"] for k, v in self.chans.items()}
        self.target: Dict[str, float] = dict(self.angle)
        self._pca = None

        if not self.sim:                             # pragma: no cover
            try:
                i2c = busio.I2C(board.SCL, board.SDA)
                self._pca = PCA9685(i2c, address=int(cfg.get("i2c_addr", 0x40)))
                self._pca.frequency = int(cfg.get("pwm_hz", 50))
            except Exception:
                self.sim = True
                self._pca = None

        self._run = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    # ------------------------------------------------------------------ api
    def move_to(self, joint: str, deg: float) -> None:
        """Ask a joint to go somewhere. It gets there at a sane speed."""
        if joint not in self.chans:
            return
        c = self.chans[joint]
        deg = max(c["min_deg"], min(c["max_deg"], float(deg)))
        with self._lock:
            self.target[joint] = deg

    def move_pose(self, pose: Dict[str, float]) -> None:
        for j, d in pose.items():
            self.move_to(j, d)

    def jog(self, joint: str, delta: float) -> None:
        with self._lock:
            cur = self.target.get(joint, 0.0)
        self.move_to(joint, cur + delta)

    def at_target(self, tol: float = 1.5) -> bool:
        with self._lock:
            return all(abs(self.angle[j] - self.target[j]) <= tol
                       for j in self.chans)

    def wait_until_still(self, timeout: float = 8.0) -> bool:
        t0 = time.time()
        while time.time() - t0 < timeout:
            if self.at_target():
                return True
            time.sleep(0.05)
        return False

    def go_safe(self) -> None:
        for j, c in self.chans.items():
            self.move_to(j, c["safe"])

    def relax(self) -> None:
        """Cut the pulses so the servos stop holding and stop drawing current."""
        if self._pca is not None:                    # pragma: no cover
            for c in self.chans.values():
                self._pca.channels[c["ch"]].duty_cycle = 0

    def snapshot(self) -> Dict[str, float]:
        with self._lock:
            return dict(self.angle)

    def close(self) -> None:
        self._run = False
        try:
            self._thread.join(timeout=1.0)
        except Exception:
            pass
        self.relax()

    # -------------------------------------------------------------- inside
    def _loop(self) -> None:
        dt = 0.02
        while self._run:
            with self._lock:
                for j in self.chans:
                    a, t = self.angle[j], self.target[j]
                    step = self.speed * dt
                    if abs(t - a) <= step:
                        self.angle[j] = t
                    else:
                        self.angle[j] = a + step * (1 if t > a else -1)
                    self._write(j, self.angle[j])
            time.sleep(dt)

    def _write(self, joint: str, deg: float) -> None:
        if self._pca is None:
            return
        c = self.chans[joint]                        # pragma: no cover
        span = c["max_deg"] - c["min_deg"]
        frac = 0.0 if span == 0 else (deg - c["min_deg"]) / span
        us = c["min_us"] + frac * (c["max_us"] - c["min_us"])
        period_us = 1_000_000.0 / float(self.cfg.get("pwm_hz", 50))
        duty = int(max(0, min(0xFFFF, (us / period_us) * 0xFFFF)))
        try:
            self._pca.channels[c["ch"]].duty_cycle = duty
        except Exception:
            pass
