"""Where the hand is, and what angles put it somewhere else.

Until now the arm only knew five fixed poses. That is fine for "look at the
plant", and useless for "the weed is 180 mm to the left and 240 mm in front,
go and get it". This turns one into the other, using the real link lengths out
of the CAD model.

The arm, side on:

                                 elbow
                                  o---------____
                        upper arm/              ----o wrist
                                /                    \\
                     shoulder  o                      | hand
                              ||                      v
              shoulder_height ||                     grip point
        ______________________||________________________________  ground

Three joints move it: yaw swings the whole arm left and right, shoulder and
elbow set the reach and the height. The wrist is not used to reach - it is used
to keep the gripper level, which is what you want when picking something off the
ground.

All lengths are millimetres, all angles degrees, and the frame is the rover's:
+x forward, +y to the rover's left, +z up from the ground. That is the same
frame the drawings use, so a number measured off a drawing can be typed
straight in.
"""
from __future__ import annotations

import math
from typing import Dict, Optional, Tuple


class Arm:
    def __init__(self, cfg: dict, limits: Optional[dict] = None):
        """limits is servos.channels from the config. Give it, and the arm
        knows the difference between "the geometry works" and "the servos can
        actually get there" - which is not the same question."""
        self.limits = limits or {}
        a = cfg or {}
        self.h = float(a.get("shoulder_height_mm", 180))
        self.l1 = float(a.get("upper_arm_mm", 241))
        self.l2 = float(a.get("forearm_mm", 125))
        self.l3 = float(a.get("hand_mm", 97))
        self.level = bool(a.get("keep_hand_level", True))
        # the shoulder angle in the config is measured from straight up, which
        # is how the servo horn is fitted. The maths below wants it from
        # horizontal, so everything converts at the edges.
        self.reach_max = self.l1 + self.l2 + self.l3
        self.reach_min = abs(self.l1 - self.l2)

    # ------------------------------------------------------------------ out
    def forward(self, yaw: float, shoulder: float, elbow: float,
                wrist: Optional[float] = None) -> Dict[str, float]:
        """Given the joint angles, where is the grip point?

        Pass the real wrist angle and you get where the hand really is. Leave
        it out and it assumes the wrist is doing its job of keeping the gripper
        hanging straight down - which is true while the arm is reaching for
        something, and not true when it is folded away in the stow pose. That
        is why the dashboard passes the real one.
        """
        s = math.radians(90.0 - shoulder)          # upper arm, from horizontal
        f = s - math.radians(elbow)                # forearm, from horizontal
        rw = self.l1 * math.cos(s) + self.l2 * math.cos(f)
        zw = self.h + self.l1 * math.sin(s) + self.l2 * math.sin(f)

        if wrist is None:
            hand = -math.pi / 2 if self.level else f     # straight down, or in line
        else:
            hand = f + math.radians(wrist)
        r = rw + self.l3 * math.cos(hand)
        z = zw + self.l3 * math.sin(hand)
        y_ = math.radians(yaw)
        return {"x": r * math.cos(y_), "y": r * math.sin(y_), "z": z,
                "reach": r, "wrist_z": zw,
                "hand_deg": round(math.degrees(hand), 1)}

    # ------------------------------------------------------------------- in
    def solve(self, x: float, y: float, z: float) -> Tuple[Optional[Dict[str, float]], str]:
        """What angles put the grip point at x, y, z? None if it cannot reach.

        Returns (angles, why not). The elbow-up solution is chosen: it keeps
        the forearm above the plant rather than dragging through it.
        """
        r = math.hypot(x, y)                       # how far out, on the ground
        yaw = math.degrees(math.atan2(y, x))

        # where the wrist has to be for the grip point to land on the target
        if self.level:
            rw, zw = r, z + self.l3
            return self._two_link(rw, zw, yaw)

        # With the hand in line with the forearm, where the wrist has to be
        # depends on the forearm angle, which is the thing being solved for.
        # So: guess, solve, move the guess, solve again. It settles to under a
        # tenth of a millimetre in a handful of passes; the answer returned is
        # always the solve AFTER the last correction, never one step behind.
        rw, zw = r - self.l3, z
        out, why = self._two_link(rw, zw, yaw)
        if out is None:
            return None, why
        for _ in range(12):
            s = math.radians(90.0 - out["shoulder"])
            f = s - math.radians(out["elbow"])
            nrw = r - self.l3 * math.cos(f)
            nzw = z - self.l3 * math.sin(f)
            # damped, or a steep forearm angle makes it swing back and forth
            rw += 0.5 * (nrw - rw)
            zw += 0.5 * (nzw - zw)
            nxt, why = self._two_link(rw, zw, yaw)
            if nxt is None:
                return None, why
            if (abs(nxt["shoulder"] - out["shoulder"]) < 0.02
                    and abs(nxt["elbow"] - out["elbow"]) < 0.02):
                return nxt, ""
            out = nxt
        return out, ""

    def _two_link(self, rw: float, zw: float, yaw: float
                  ) -> Tuple[Optional[Dict[str, float]], str]:
        """Shoulder and elbow that put the WRIST at (rw out, zw up)."""
        if rw < 0:
            return None, "that is behind the shoulder, the arm does not fold that way"
        dz = zw - self.h
        d = math.hypot(rw, dz)
        if d > self.l1 + self.l2 + 1e-9:
            return None, ("too far: the grip point would be %.0f mm from the "
                          "shoulder and the arm reaches %.0f mm"
                          % (d, self.l1 + self.l2))
        if d < self.reach_min - 1e-9:
            return None, "too close to the shoulder to fold into"

        cos_e = (self.l1 ** 2 + self.l2 ** 2 - d ** 2) / (2 * self.l1 * self.l2)
        inner = math.acos(max(-1.0, min(1.0, cos_e)))
        elbow = math.degrees(math.pi - inner)

        cos_a = (self.l1 ** 2 + d ** 2 - self.l2 ** 2) / (2 * self.l1 * d)
        a = math.acos(max(-1.0, min(1.0, cos_a)))
        shoulder_from_horizontal = math.degrees(math.atan2(dz, rw) + a)

        out = {"yaw": round(yaw, 1),
               "shoulder": round(90.0 - shoulder_from_horizontal, 1),
               "elbow": round(elbow, 1)}
        # the wrist angle is measured from in line with the forearm
        f = shoulder_from_horizontal - elbow
        if self.level:
            # turn the hand until it hangs straight down, whatever the forearm
            # is doing: hand angle = forearm angle + wrist, and we want -90
            out["wrist"] = round(-90.0 - f, 1)
        else:
            out["wrist"] = 0.0
        return out, ""

    def can_reach(self, x: float, y: float, z: float) -> bool:
        """Geometry AND travel. A point the arm could reach if the joints
        turned further is not a point the arm can reach."""
        ok, _ = self.check(x, y, z)
        return ok

    def check(self, x: float, y: float, z: float) -> Tuple[bool, str]:
        angles, why = self.solve(x, y, z)
        if angles is None:
            return False, why
        if self.limits:
            _, ran_out = self.clamp(angles, self.limits)
            if ran_out:
                return False, ran_out
        return True, ""

    def clamp(self, angles: Dict[str, float], limits: Dict[str, dict]
              ) -> Tuple[Dict[str, float], str]:
        """Pull the angles inside what the servos can actually do.

        Returns the clamped angles and a note saying which joint ran out, so
        the website can tell you "it got as close as it could" rather than
        silently going somewhere else.
        """
        out, hit = {}, []
        for joint, val in angles.items():
            lim = limits.get(joint)
            if not lim:
                out[joint] = val
                continue
            lo, hi = float(lim["min_deg"]), float(lim["max_deg"])
            if val < lo:
                out[joint] = lo
                hit.append(joint)
            elif val > hi:
                out[joint] = hi
                hit.append(joint)
            else:
                out[joint] = val
        return out, (", ".join(hit) + " ran out of travel" if hit else "")
