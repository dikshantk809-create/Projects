"""Tests you can run on a laptop, no rover and no hardware needed.

    python3 -m tests.test_decisions

It checks the parts that decide whether to put chemicals on a plant, because
those are the parts that must never be wrong. It does not need pytest.
"""
from __future__ import annotations

import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agrirover.ai import treatment as tx           # noqa: E402

PASS, FAIL = 0, 0


def check(name, cond, extra=""):
    global PASS, FAIL
    if cond:
        PASS += 1
        print("  ok    %s" % name)
    else:
        FAIL += 1
        print("  FAIL  %s  %s" % (name, extra))


# ------------------------------------------------------------------ treatment
print("\ntreatment table")

p = tx.plan("healthy", 0.99)
check("a healthy plant is left alone", p["action"] == "none" and p["healthy"])

p = tx.plan("not_checked", 0.0)
check("no model is not the same as healthy", not p["healthy"])
check("no model asks you", p["action"] == "needs_you")
check("no model never sprays", p["dose_ml"] == 0.0)

p = tx.plan("unknown", 0.2)
check("unsure is not healthy", not p["healthy"] and p["action"] == "needs_you")

p = tx.plan("tomato_early_blight", 0.95, auto_spray_conf=0.85)
check("sure about blight, may spray", p["action"] == "spray")
check("blight dose is carried", p["dose_ml"] > 0)
check("blight has a waiting time", p["phi_days"] > 0)

p = tx.plan("tomato_early_blight", 0.70, auto_spray_conf=0.85)
check("unsure about blight, asks first", p["action"] == "needs_you")
check("the dose is still quoted so you can say yes", p["dose_ml"] > 0)

p = tx.plan("tomato_mosaic_virus", 0.99)
check("a virus is never sprayed", p["action"] == "needs_you" and p["dose_ml"] == 0)

p = tx.plan("water_stress", 0.9, soil_pct=70.0)
check("wet soil vetoes thirsty", p["label"] == "healthy")
p = tx.plan("water_stress", 0.9, soil_pct=12.0)
check("dry soil keeps thirsty", p["label"] == "water_stress")

p = tx.plan("weed", 0.9)
check("a weed is pulled, not sprayed", p["action"] == "weed_pull")

p = tx.plan("something_the_model_invented", 0.9)
check("an unknown label falls back safely",
      p["label"] == "unknown" and p["dose_ml"] == 0.0)

for name, t in tx.TREATMENTS.items():
    if t.spray_ok:
        check("%s names a product" % name, bool(t.product))
        check("%s gives a dose" % name, bool(t.dose) and t.dose_ml_per_plant > 0)
        if t.kind in ("fungal", "bacterial", "pest"):
            # a pesticide always has a wait before you can pick the crop
            check("%s has a waiting time" % name, t.phi_days > 0)

# --------------------------------------------------------------------- rover
print("\nrover, in simulation")

import yaml                                        # noqa: E402
from agrirover.rover import Rover                  # noqa: E402
from agrirover.core.state import Mode              # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.join(os.path.dirname(HERE), "agrirover", "config.yaml")
cfg = yaml.safe_load(open(BASE))
cfg["rover"]["sim"] = True
cfg["ai"]["inspect_seconds"] = 0.2
tmp = os.path.join(HERE, "_test_config.yaml")
yaml.safe_dump(cfg, open(tmp, "w"))

r = Rover(tmp)
time.sleep(0.5)


class FakeAI:
    """Stands in for the TFLite model so the decisions can be tested."""
    ready = True
    reason = ""

    def __init__(self, label, conf):
        self.label, self.conf = label, conf

    def classify(self, img):
        return self.label, self.conf


try:
    check("starts stopped", r.state.mode == Mode.IDLE)
    check("spray is locked at boot", not r.state.spray_armed)

    ok, msg = r.spray(5)
    check("cannot spray while locked", not ok, msg)

    r.set_spray_armed(True)
    ok, msg = r.spray(5)
    check("can spray once armed", ok, msg)

    ok, msg = r.spray(9999)
    check("cannot exceed the per plant limit", not ok, msg)

    before = r.sprayer.used_ml
    r.estop("test")
    ok, msg = r.spray(5)
    check("cannot spray during an emergency stop", not ok, msg)
    check("nothing came out", r.sprayer.used_ml == before)

    r.set_mode(Mode.MANUAL)
    check("cannot leave IDLE while stopped", r.state.mode != Mode.MANUAL)
    r.clear_estop()
    check("can leave IDLE once cleared", r.set_mode(Mode.MANUAL))

    # the website has to keep asking, that is the dead man rule
    for _ in range(8):
        r.web_drive(1.0, 0.0)
        time.sleep(0.05)
    check("it drives", r.state.telemetry.speed_mps > 0)
    d0 = r.state.telemetry.distance_m
    for _ in range(14):
        r.web_drive(1.0, 0.0)
        time.sleep(0.05)
    check("the trip meter counts", r.state.telemetry.distance_m > d0,
          "%s -> %s" % (d0, r.state.telemetry.distance_m))
    time.sleep(1.2)
    check("it stops itself when the website goes quiet",
          r.state.telemetry.speed_mps == 0)

    r.set_mode(Mode.IDLE)
    time.sleep(0.3)
    check("IDLE stops the wheels", r.state.drive_left == 0
          and r.state.telemetry.speed_mps == 0)

    # ---- a confident disease, auto spray OFF: it must ask, not act
    r.classifier = FakeAI("tomato_early_blight", 0.97)
    r.set_auto_spray(False)
    r.set_spray_armed(True)
    r.set_mode(Mode.AUTO)
    r.mission.start(1)
    for _ in range(300):
        time.sleep(0.05)
        if r.state.pending:
            break
    q = (r.state.pending or {}).get("question", "")
    check("asks before spraying when auto spray is off", bool(r.state.pending))
    check("the question names the product", "Mancozeb" in q, q)
    check("the question gives the waiting time", "days" in q, q)
    used = r.sprayer.used_ml
    r.mission.answer(True)
    time.sleep(0.5)
    check("saying yes actually sprays", r.sprayer.used_ml > used)
    rec = r.state.plants[-1]
    check("the plant is logged as sprayed", rec.sprayed and rec.dose_ml > 0)
    check("the plant is logged as not healthy", not rec.healthy)
    r.mission.stop("test")

    # ---- a virus: never sprayed, whatever the switches say
    r.classifier = FakeAI("tomato_mosaic_virus", 0.99)
    r.set_auto_spray(True)
    r.set_mode(Mode.AUTO)
    r.mission.start(1)
    for _ in range(300):
        time.sleep(0.05)
        if r.state.pending:
            break
    check("a virus still asks, even with auto spray on", bool(r.state.pending))
    used = r.sprayer.used_ml
    r.mission.answer(True)
    time.sleep(0.5)
    check("and nothing is sprayed on it", r.sprayer.used_ml == used)
    r.mission.stop("test")

    # ---- a confident disease with auto spray ON: it may act by itself
    r.classifier = FakeAI("tomato_late_blight", 0.97)
    r.set_auto_spray(True)
    r.set_spray_armed(True)
    used = r.sprayer.used_ml
    r.set_mode(Mode.AUTO)
    r.mission.start(1)
    for _ in range(400):
        time.sleep(0.05)
        if r.sprayer.used_ml > used:
            break
    check("sprays on its own when you allow it", r.sprayer.used_ml > used)
    r.mission.stop("test")

    # ---- the same disease, but the spray is not armed: it must not spray
    r.set_spray_armed(False)
    used = r.sprayer.used_ml
    r.set_mode(Mode.AUTO)
    r.mission.start(1)
    time.sleep(3.0)
    check("the arming switch beats auto spray", r.sprayer.used_ml == used)
    r.mission.stop("test")

    # ---- the session limit
    r.set_spray_armed(True)
    r.sprayer.used_ml = float(r.sprayer.cfg["max_ml_per_session"]) - 1.0
    ok, msg = r.spray(20)
    check("cannot exceed the session limit", not ok, msg)

finally:
    r.shutdown()
    try:
        os.remove(tmp)
    except OSError:
        pass

# ------------------------------------------------------- settings and login
print("\nsettings and sign in")

from agrirover.core.settings import Settings, HARD          # noqa: E402
from agrirover.core.auth import Auth                        # noqa: E402

st = Settings(yaml.safe_load(open(BASE)), os.path.join(HERE, "_t_settings.json"))
check("the page can read every setting",
      all(v["value"] is not None for v in st.all().values()),
      str([k for k, v in st.all().items() if v["value"] is None]))

bad = st.set_many({"spray.max_ml_per_plant": 10.0})
check("a sensible change is kept", not bad and st.get("spray.max_ml_per_plant") == 10.0)

bad = st.set_many({"spray.max_ml_per_plant": 5000})
check("the website cannot raise a hard limit", "spray.max_ml_per_plant" in bad)
check("and the old value stands", st.get("spray.max_ml_per_plant") == 10.0)

bad = st.set_many({"ai.auto_spray_confidence": 0.20})
check("it cannot be told to spray on a guess", "ai.auto_spray_confidence" in bad)

bad = st.set_many({"drive.max_speed_mps": 3.0})
check("it cannot be made to run", "drive.max_speed_mps" in bad)

bad = st.set_many({"web.password": "x"})
check("it cannot reach settings it was not given", "web.password" in bad)

bad = st.set_many({"safety.battery.stop_v": 11.5, "safety.battery.warn_v": 10.5})
check("stop volts must stay under warn volts", len(bad) == 2)

st2 = Settings(yaml.safe_load(open(BASE)), st.path)
check("changes survive a restart", st2.get("spray.max_ml_per_plant") == 10.0)

au = Auth(os.path.join(HERE, "_t_users.json"))
check("there is a user to start with", au.is_first_run())
check("the starting password works", au.check_password("admin", "agrirover"))
check("a wrong password does not", not au.check_password("admin", "agrirovers"))
check("the password is not stored in the file",
      "agrirover" not in open(au.path).read())

tok = au.login("admin", "agrirover", "1.2.3.4")
check("signing in gives a session", bool(tok) and au.user_for(tok))
check("a made up session is refused", au.user_for("not-a-real-token") is None)

ok, msg = au.change("admin", "wrong", "betterpass")
check("cannot change the password without the old one", not ok, msg)
ok, msg = au.change("admin", "agrirover", "123")
check("a short password is refused", not ok, msg)
ok, msg = au.change("admin", "agrirover", "agrirover")
check("cannot keep the password it came with", not ok, msg)
ok, msg = au.change("admin", "agrirover", "a-better-one", "dikshant")
check("a proper change works", ok, msg)
check("the old session is thrown away", au.user_for(tok) is None)
check("the new details work", au.check_password("dikshant", "a-better-one"))
check("it is no longer a fresh install", not au.is_first_run())

for _ in range(8):
    au.login("dikshant", "nope", "9.9.9.9")
check("guessing gets that address locked out", au.rate_limited("9.9.9.9") > 0)
check("but not everyone else", au.rate_limited("5.5.5.5") == 0)

for f in ("_t_settings.json", "_t_users.json"):
    try:
        os.remove(os.path.join(HERE, f))
    except OSError:
        pass

# ------------------------------------------------------------------- the arm
print("\nthe arm")

import random                                          # noqa: E402
from agrirover.hw.kinematics import Arm                 # noqa: E402

full = yaml.safe_load(open(BASE))
for level in (True, False):
    c = dict(full["arm"]); c["keep_hand_level"] = level
    arm = Arm(c)
    worst, solved, missed = 0.0, 0, 0
    random.seed(11)
    for _ in range(1500):
        x = random.uniform(80, 420); y = random.uniform(-260, 260)
        z = random.uniform(0, 300)
        ang, why = arm.solve(x, y, z)
        if ang is None:
            missed += 1
            continue
        got = arm.forward(ang["yaw"], ang["shoulder"], ang["elbow"], ang["wrist"])
        worst = max(worst, abs(got["x"] - x), abs(got["y"] - y), abs(got["z"] - z))
        solved += 1
    check("hand level %s: the angles put the hand where asked" % level,
          worst < 1.0, "worst error %.2f mm over %d points" % (worst, solved))

arm = Arm(full["arm"], full["servos"]["channels"])
check("it refuses what it cannot reach", not arm.can_reach(900, 0, 50))
check("and says why", "too far" in (arm.solve(900, 0, 50)[1]))
check("it refuses what is behind it, because the yaw servo cannot turn there",
      not arm.can_reach(-200, 0, 50), str(arm.check(-200, 0, 50)))
check("it accepts a point it really can get to", arm.can_reach(300, 100, 40),
      str(arm.check(300, 100, 40)))
ang, _ = arm.solve(300, 0, 40)
got = arm.forward(ang["yaw"], ang["shoulder"], ang["elbow"], ang["wrist"])
check("with the hand level, the gripper really does point straight down",
      abs(got["hand_deg"] + 90) < 0.5, str(got["hand_deg"]))

ch = full["servos"]["channels"]
rest = arm.forward(ch["yaw"]["safe"], ch["shoulder"]["safe"],
                   ch["elbow"]["safe"], ch["wrist"]["safe"])
check("an emergency stop leaves the arm folded low, not waving in the air",
      50 < rest["z"] < 420, "it would rest at %.0f mm up" % rest["z"])
check("and not dragging on the ground", rest["z"] > 30,
      "%.0f mm" % rest["z"])
for name, pose in full["arm"]["poses"].items():
    got = arm.forward(pose.get("yaw", 0), pose["shoulder"], pose["elbow"],
                      pose.get("wrist", 0))
    check("the %s pose keeps the gripper off the ground" % name, got["z"] > 15,
          "%.0f mm up" % got["z"])
ang, _ = arm.solve(300, 0, 40)
cl, ran_out = arm.clamp({"shoulder": -80, "elbow": 400}, full["servos"]["channels"])
check("angles are pulled inside the servo limits",
      cl["shoulder"] == full["servos"]["channels"]["shoulder"]["min_deg"]
      and cl["elbow"] == full["servos"]["channels"]["elbow"]["max_deg"])
check("and it says which joint ran out", "shoulder" in ran_out and "elbow" in ran_out)

# ------------------------------------------------------- camera to the ground
from agrirover.ai.vision import ground_point             # noqa: E402

cam = {"height_mm": 350, "pitch_deg": 30, "vfov_deg": 48}
mid = ground_point(320, 240, 640, 480, cam)
check("the middle of the picture lands in front of the rover",
      mid is not None and 550 < mid["x_mm"] < 680, str(mid))
low = ground_point(320, 460, 640, 480, cam)
check("the bottom of the picture is nearer than the middle",
      low["x_mm"] < mid["x_mm"], "%s vs %s" % (low["x_mm"], mid["x_mm"]))
left = ground_point(100, 400, 640, 480, cam)
check("something on the left of the picture is on the rover's left",
      left["y_mm"] > 0, str(left))
check("it says nothing rather than guessing when not measured",
      ground_point(320, 240, 640, 480, {"height_mm": 0}) is None)
check("and nothing for a pixel above the horizon",
      ground_point(320, 0, 640, 480, {"height_mm": 350, "pitch_deg": 2,
                                      "vfov_deg": 48}) is None)

# ------------------------------------------------------- nothing is a dead end
print("\nevery setting the page shows is actually read")

import subprocess                                       # noqa: E402
from agrirover.core.settings import EDITABLE            # noqa: E402

src = subprocess.run(
    ["grep", "-rh", "--include=*.py", "-e", "", os.path.join(
        os.path.dirname(HERE), "agrirover")],
    capture_output=True, text=True).stdout
dead = []
for key in EDITABLE:
    leaf = key.split(".")[-1]
    # it counts as used if something outside settings.py names it
    uses = [ln for ln in src.splitlines()
            if leaf in ln and "EDITABLE" not in ln and "HARD" not in ln]
    if len(uses) < 2:
        dead.append(key)
check("no setting on the page is ignored by the code", not dead, str(dead))

print("\n%d passed, %d failed\n" % (PASS, FAIL))
sys.exit(1 if FAIL else 0)
