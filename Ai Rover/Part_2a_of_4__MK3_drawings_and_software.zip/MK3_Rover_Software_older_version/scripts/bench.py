"""Bench tests. Run these on the Pi, one at a time, BEFORE the first drive.

    python3 scripts/bench.py wheels     # each wheel, one at a time, slowly
    python3 scripts/bench.py servos     # each joint to its limits, slowly
    python3 scripts/bench.py rc         # print what the remote is sending
    python3 scripts/bench.py adc        # print the raw sensor readings
    python3 scripts/bench.py pump       # 10 seconds of pump, to measure flow
    python3 scripts/bench.py cameras    # save one frame from each camera
    python3 scripts/bench.py encoders   # push the rover and watch it count
    python3 scripts/bench.py imu        # tilt it and watch the angle
    python3 scripts/bench.py range      # wave your hand in front of it
    python3 scripts/bench.py arm        # what the arm can and cannot reach

Put the rover ON BLOCKS with the wheels off the ground for the wheel test.
"""
from __future__ import annotations

import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import yaml                                          # noqa: E402

CFG = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                   "agrirover", "config.yaml")
cfg = yaml.safe_load(open(CFG))


def wheels():
    from agrirover.hw.motors import DriveMotors
    m = DriveMotors(cfg["drive"])
    print("simulation" if m.sim else "real driver boards")
    print("wheels off the ground? starting in 3 seconds")
    time.sleep(3)
    try:
        for name, l, r in [("left forward", 0.3, 0.0), ("left back", -0.3, 0.0),
                           ("right forward", 0.0, 0.3), ("right back", 0.0, -0.3),
                           ("both forward", 0.3, 0.3)]:
            print(" ", name)
            m.set(l, r)
            time.sleep(1.5)
            m.stop()
            time.sleep(0.8)
        print("\nIf a wheel went the wrong way, set invert_left or invert_right")
        print("in config.yaml. Do not swap the motor wires.")
    finally:
        m.stop()
        m.release()


def servos():
    from agrirover.hw.servos import ServoBank
    s = ServoBank(cfg["servos"])
    print("simulation" if s.sim else "real PCA9685")
    print("ARM OFF THE ROVER for this test. Starting in 3 seconds")
    time.sleep(3)
    try:
        for name, c in cfg["servos"]["channels"].items():
            print("  %-9s %+.0f -> %+.0f -> safe %+.0f"
                  % (name, c["min_deg"], c["max_deg"], c["safe"]))
            for target in (c["min_deg"], c["max_deg"], c["safe"]):
                s.move_to(name, target)
                s.wait_until_still(4.0)
                time.sleep(0.4)
        print("\nAny joint that buzzes at the end of its travel is fighting a")
        print("hard stop. Bring min_deg or max_deg in until it stops buzzing.")
    finally:
        s.go_safe()
        time.sleep(1.0)
        s.close()


def rc():
    from agrirover.hw.rc import RCReceiver
    r = RCReceiver(cfg["rc"])
    print("protocol:", cfg["rc"].get("protocol"), "  ctrl-C to stop\n")
    names = cfg["rc"].get("map", {})
    try:
        while True:
            live = "LIVE" if r.live else "no signal"
            raw = " ".join("%+.2f" % v for v in r.snapshot()[:6])
            named = "  ".join("%s %+.2f" % (k, r.channel(k)) for k in names)
            print("\r%-9s  [%s]  %s   " % (live, raw, named), end="", flush=True)
            time.sleep(0.1)
    except KeyboardInterrupt:
        print()
    finally:
        r.close()


def adc():
    from agrirover.hw.io import Analog
    a = Analog(cfg["sensors"])
    print("simulation" if a.sim else "real ADS1115", "  ctrl-C to stop\n")
    try:
        while True:
            print("\rbattery %5.2f V   soil %s   tank %s      "
                  % (a.battery_volts() or 0.0,
                     "%.0f%%" % a.soil_percent() if a.soil_percent() is not None else "—",
                     "%.0f%%" % a.tank_percent() if a.tank_percent() is not None else "—"),
                  end="", flush=True)
            time.sleep(0.3)
    except KeyboardInterrupt:
        print()


def pump():
    """Run the pump for 10 seconds into a measuring cup, then do the sum."""
    from agrirover.hw.io import Outputs
    o = Outputs(cfg["spray"], cfg["lamps"])
    print("Put the nozzle in a measuring cup. 10 seconds of pump in 5.")
    time.sleep(5)
    o.set("front", True)
    o.set("pump", True)
    for i in range(10, 0, -1):
        print("\r  %2d" % i, end="", flush=True)
        time.sleep(1)
    o.set("pump", False)
    o.set("front", False)
    o.close()
    print("\n\nMeasure what came out, in ml, and divide by 10.")
    print("Put that number in config.yaml as ml_per_second.")
    print("The dose it puts on a plant is only as good as this number.")


def cameras():
    import cv2
    from agrirover.hw.camera import Camera
    for name in ("front", "arm"):
        c = Camera(name, cfg["cameras"][name])
        time.sleep(1.5)
        f = c.frame()
        if f is None:
            print(name, "gave no picture")
        else:
            out = "bench_%s.jpg" % name
            cv2.imwrite(out, f)
            print("%-6s %dx%d  saved %s%s" % (name, f.shape[1], f.shape[0], out,
                                              "  (simulated)" if c.sim else ""))
        c.close()


def encoders():
    """Push the rover along by hand and watch the counts."""
    from agrirover.hw.encoders import Encoders
    e = Encoders(cfg["drive"], cfg["rover"])
    if e.sim:
        print("no encoders: %s" % e.reason)
        print("fit them, then set drive.encoder.enabled: true in config.yaml")
        return
    print("Push the rover forward one metre, slowly. ctrl-C to stop.\n")
    try:
        while True:
            e.read()
            print("\r  left %7.3f m   right %7.3f m   %5.2f / %5.2f m/s   "
                  % (e.left_m, e.right_m, e.left_mps, e.right_mps),
                  end="", flush=True)
            time.sleep(0.2)
    except KeyboardInterrupt:
        print("\n\nBoth numbers should match the real distance you pushed it.")
        print("If they are out by the same ratio, fix ticks_per_rev:")
        print("  new value = old value x (what it said / what it really was)")
        print("If one wheel reads backwards, swap its A and B wires.")
    finally:
        e.close()


def imu():
    from agrirover.hw.imu import IMU
    m = IMU(cfg["sensors"])
    if m.sim:
        print("no tilt sensor: %s" % m.reason)
        print("fit an MPU6050 on the I2C bus, then set sensors.imu.enabled: true")
        return
    print("Tilt the rover side to side, then nose up. ctrl-C to stop.\n")
    try:
        while True:
            d = m.read() or {}
            print("\r  tilt %5.1f   pitch %6.1f   roll %6.1f   heading %5.1f   "
                  % (d.get("tilt_deg", 0), d.get("pitch_deg", 0),
                     d.get("roll_deg", 0), d.get("heading_deg", 0)),
                  end="", flush=True)
            time.sleep(0.12)
    except KeyboardInterrupt:
        print("\n\nOn a level floor tilt should sit under a degree or two.")
        print("If it does not, the sensor is not mounted flat.")
    finally:
        m.close()


def range_():
    from agrirover.hw.rangefinder import RangeFinder
    r = RangeFinder(cfg["sensors"])
    if r.sim:
        print("no range sensor: %s" % r.reason)
        print("fit one, then set sensors.range_front.enabled: true")
        return
    stop = float(cfg["sensors"]["range_front"].get("stop_cm", 35))
    print("Hold your hand in front of it and move it in and out. ctrl-C to stop.\n")
    try:
        while True:
            d = r.read()
            bar = "#" * int(min(50, (d or 0) / 4))
            print("\r  %6s cm  %-52s %s" % (d if d else "----", bar,
                  "WOULD STOP" if r.blocked() else ""), end="", flush=True)
            time.sleep(0.15)
    except KeyboardInterrupt:
        print("\n\nIt stops the rover below %.0f cm." % stop)
        print("Readings that jump about mean the echo pin divider is wrong,")
        print("or the sensor is pointing at something soft.")
    finally:
        r.close()


def arm():
    """What the arm can reach, worked out from the CAD link lengths."""
    from agrirover.hw.kinematics import Arm
    a = Arm(cfg["arm"])
    lim = cfg["servos"]["channels"]
    print("link lengths: upper %.0f, fore %.0f, hand %.0f, shoulder %.0f up"
          % (a.l1, a.l2, a.l3, a.h))
    print("reach: %.0f mm at most, %.0f mm at least\n" % (a.reach_max, a.reach_min))
    print("  %-22s %-34s %s" % ("point (fwd, across, up)", "joint angles", "note"))
    for (x, y, z) in [(200, 0, 40), (250, 0, 40), (300, 0, 40), (350, 0, 40),
                      (300, 150, 40), (300, -150, 40), (250, 0, 200), (450, 0, 40)]:
        ang, why = a.solve(x, y, z)
        if ang is None:
            print("  %-22s %-34s %s" % ("%4d %4d %4d" % (x, y, z), "cannot reach", why))
            continue
        cl, ran_out = a.clamp(ang, lim)
        txt = "yaw %6.1f  sh %6.1f  el %6.1f" % (cl["yaw"], cl["shoulder"], cl["elbow"])
        print("  %-22s %-34s %s" % ("%4d %4d %4d" % (x, y, z), txt,
                                    ran_out or "ok"))
    print("\n  your saved poses, and where they put the gripper:")
    for name, pose in (cfg["arm"].get("poses") or {}).items():
        p = a.forward(pose.get("yaw", 0), pose.get("shoulder", 0),
                      pose.get("elbow", 0), pose.get("wrist", 0))
        warn = ""
        if p["z"] < 15:
            warn = "  <-- the gripper is at or below ground, it will drag"
        print("    %-9s -> %4.0f mm forward, %4.0f across, %4.0f up%s"
              % (name, p["x"], p["y"], p["z"], warn))

    print("\nThose are geometry, not a promise: a servo that cannot hold the")
    print("weight will sag whatever the maths says. Try it with the arm off")
    print("the rover first.")


JOBS = {"wheels": wheels, "servos": servos, "rc": rc, "adc": adc,
        "pump": pump, "cameras": cameras, "encoders": encoders, "imu": imu,
        "range": range_, "arm": arm}

if __name__ == "__main__":
    job = sys.argv[1] if len(sys.argv) > 1 else ""
    if job not in JOBS:
        print(__doc__)
        raise SystemExit(1)
    JOBS[job]()
